# Triad3D.js 11.5.0 — Complete Engine Documentation

**Bundle:** `triad3d.js` · ~616 KB · ~13,760 lines · UMD, single file, zero dependencies  
**Reported version:** `Triad3D.version === "11.5.0"`  
**Previous documented version:** `10.0.0` (`triad3d_3.js`, 560 KB, 12,977 lines)

---

## 0. Scope and method

This document describes **11.5.0**. It is updated directly from the `10.0.0` manual against the
current `triad3d.js` source and verified against live headless WebGL renders across four test suites:
an enclosed indoor optics studio (chrome, nested glass-in-glass, indoor oblique floor reflection,
rounded box), a sunlit room shadow-edge A/B comparison, a 360° dynamic sky & rippled water showcase,
and an Edit-vs-Explore render-mode benchmark (`290 → 58` draw calls, `8.69×` frame-time speedup).

`Triad3D.DOCS`, `Triad3D.help()`, and the file header comments are now synchronized to **11.5.0**
(resolving v10.0 Trap §18.1).

---

## 1. What it is

A single-file WebGL2 engine with three authoring languages compiled into one runtime:

| Layer | File type | Role |
|---|---|---|
| **SML** | `.sml` | Scene structure — tags, attributes, macros |
| **3SS** | `.3ss` or `<style>` | Materials, transforms, animation, collision, reflections |
| **3JS** | `.3js` or `<script>` | Behaviour, run once against the compiled scene |

Around that: a viewer (canvas, orbit camera, optional FPS walk mode, reversible **Edit / Explore
Baked Mode**, HUD, GUI, bake overlay), a physics-lite world (box/cylinder/sphere colliders, triggers,
capsule controller), a chunk streaming manager, a navmesh + agent system, a 360° non-raymarched
dynamic sky & cloud engine, tag-level planar water/mirror reflectors, and a clean-room `THREE`
subset with a PBR renderer.

### 1.1 Compile pipeline

`TriadViewer.loadFiles()` → `compileVFSProject()` runs these steps in order:

| # | Step | Detail |
|---:|---|---|
| 1 | `clear()` | scene, generators, colliders, chunks, particles, warnings, uid counter |
| 2 | SML parse + macro expansion | finds `main.sml` → `structure.sml` → first `*.sml`; quote-aware tag parsing (`>` allowed inside attributes); expands `<import>`, `<component>`, `<for>`, `<repeat>`, `<if>`, `<use>`, `{expr}`, `$var`, `<canvas-texture>`; lifts inline `<style>` / `<script>` |
| 3 | 3SS parse | all `*.3ss` + `<link>`ed sheets + inline `<style>`, concatenated and parsed as one cascade |
| 4 | Scene attributes | post, sky/clouds, shadow-edge contrast, env, fog, exposure, wet-floor/water, shadows, physics params |
| 5 | Build Object3D tree | geometry built here; copies `id` → `object3D.name`; warns on unknown tags; handles `reflection="..."`, `<chunk>`, `<navmesh>`, `<agent>`, `<gltf>` |
| 6 | Style pass | `applyStyleToNode` unifies inline SML attributes and 3SS cascade → material, transform, animation, texture |
| 7 | Optimization | auto-instancing → batch merge → matrix freeze (opt-in, or automatic & reversible in Explore Mode) |
| 8 | Collider extraction | `<collider>` tags and `collision` properties → physics world; reads `fps-*` |
| 9 | Inline handlers | `oninit` executed; `onupdate`/`ontick`/`onclick`/`onhover` compiled |
| 10 | **3JS scripts** | all `.3js` + linked + inline bodies concatenated and run **once, last** |

> **Ordering note:** Scripts still run after the tree is built and styled, so anything a script
> registers (generator, pattern, image) is too late for markup that already exists. Register before
> `mount()`, or use `<mesh generator="…">` / `Triad.sky` / `Triad.lighting` / `Triad.mode` at runtime.

### 1.2 Module format

UMD. Browser global `Triad3D`; also assigns `window.THREE` if absent. `require()` works in Node for
math/geometry, not rendering. `Triad3D.THREE` is the bundled subset — mixing in external three.js
objects is unsupported because the renderer reads its own material internals.

---

## 2. What is new in 11.5.0 (since 10.0.0)

| Feature / Fix | Status | Where |
|---|---|---|
| **True zero-diffuse PBR metals** | **fixed** | `kd = (1 - F) * (1 - uMetalness) * (1 - uTransmission)` — chrome no longer retains 22% plastic diffuse |
| **Back-to-front nested transmission** | **new** | Transmissive meshes sort back-to-front and snapshot the framebuffer via `gl.copyTexSubImage2D` so glass nests inside glass cleanly with `outAlpha = 1.0` |
| **Indoor oblique/silent reflection clipping** | **new** | `WetFloorReflector` activates `uUseClipPlane == 2` below `planeY - 0.015` (no cyan cut line), making planar reflectors work inside enclosed rooms |
| **Universal tag-level `reflection` attributes** | **new** | `reflection="true\|water\|mirror\|wet-floor"`, `reflection-amount`, `reflection-tint`, `reflection-distortion`, `reflection-speed` on any SML geometry |
| **Pre-baked FBM rippled water shader** | **new** | Seamless 256×256 4-octave FBM normal map + Schlick Fresnel + horizon fog blend (`<scene water="…">` or `<plane reflection="water">`) |
| **360° non-raymarched dynamic sky & clouds** | **new** | Dual-window `atan` Worley-FBM cumulus bands with organic base undulation, 3D normal (`N·L`) + silver-lining shading, Early-Z `renderOrder = 500`, live `Triad.sky` API |
| **Shadow-edge penumbra color & brightness contrast** | **new** | `shadow-darkness`, `shadow-edge-boost`, `shadow-edge-sat` + `Triad.lighting.setShadowEdgeContrast()` — richer, brighter color adjacent to cast shadows without glow/washout |
| **Reversible Explore (Baked) Render Mode** | **new** | `viewer.setRenderMode('explore' \| 'edit')` / `Triad.mode.set()` — auto static material-bucket merge, 64-frame `Float32Array` animation LUTs, frozen shadows/matrices, front-to-back Early-Z sorting, smart reflector caching (`8.69×` verified speedup) |
| **Quote-aware SML parser (`>` in attributes)** | **fixed** | `>` inside `"..."` or `'...'` no longer truncates SML tags |
| **Unknown SML tag warnings** | **fixed** | Logs `console.warn` + appends to `runtime.warnings` with line number |
| **Unified inline SML + 3SS material attributes** | **fixed** | `transmission`, `ior`, `thickness`, `attenuation-color`, `emissive`, `opacity`, `transparent`, `clearcoat`, `alpha-test`, `wireframe` all work both inline and in 3SS |
| **Texture `color` multiply & alpha preservation** | **fixed** | External textures multiply with `uBaseColor` and preserve `texCol.a` into `outAlpha` |
| **Rounded `<box border-radius>` UVs & normals** | **fixed** | Outward counter-clockwise triangle winding + arc-length perimeter UVs |
| **`id` → `object3D.name` & safe `<camera>` mount** | **fixed** | `getObjectByName(id)` works; `<camera>` orbit sync guards radius/phi singularities |
| **Updated `Triad3D.DOCS` & `Triad3D.help()`** | **fixed** | Synchronized to `11.5.0` |

---

## 3. Mounting and the API surface

### 3.1 Mount

```js
const viewer = Triad3D.mount('#app', {
  sml: '<scene time-of-day="13.8" cloud-coverage="0.50">…</scene>',
  fps: true,
  colliders: false,
  exposure: 1.06, gui: true, hud: true,
  autoPlay: true,
  pixelRatio: Math.min(window.devicePixelRatio || 1, 2)
});

// Switch between Live Edit Mode and Pre-Baked Explore Mode at any time:
const stats = viewer.setRenderMode('explore'); // { bakeMs, mergedBuckets, drawCallsSaved, bakedAnimationLUTs, ... }
viewer.setRenderMode('edit');                  // restores all unmerged editable meshes & live shadows
```

### 3.2 Top-level exports

```
version ("11.5.0"), registerUploadedImage, TextureTelemetry, DOCS, help, THREE, MeshBuilder, noise,
PhysicsWorld, FPSController, TriadViewer, mount, registerGenerator, registerPattern
```

Loaders remain on `Triad3D.THREE` (`GLTFLoader`, `OBJLoader`, `RGBELoader`, `DRACOLoader`, `KTX2Loader`).

### 3.3 Script-facing `Triad` object

Injected into every `.3js` / `<script>` alongside `scene`, `THREE`, `console`:

| Key | Purpose |
|---|---|
| `THREE` | the bundled subset |
| `MeshBuilder` | geometry accumulator |
| `noise` | `fbm3`, `ridge3`, `noise3`, `fbm2`, `hash`, `hash3` |
| `sky` | **`setTimeOfDay(hour)`, `setSun(elevDeg, azimDeg)`, `setClouds(opts)`, `setColors(opts)`, `uniforms`** |
| `lighting` | **`setShadowEdgeContrast({ boost, saturation, darkness })`** |
| `mode` | **`current`, `set('explore' \| 'edit', opts)`, `rebakeShadows()`, `getStats()`** |
| `physics`, `collision` | `TriadPhysicsWorld` |
| `chunks` | chunk streaming manager |
| `agents` | agent manager + navmesh |
| `images` | `register`, `getTelemetry()` |
| `optimize` | `getStats()`, `mergeSubtree()`, `freezeSubtree()` |
| `post` | `setBloom`, `setDOF`, `addWetReflector` |
| `gui` | runtime parameter sliders |
| `camera` | `setPose`, `getPose`, … |
| `setGameMode`, `onTick`, `inspect`, `registerGenerator`, `registerPattern` | |

---

## 4. SML

### 4.1 Parsing rules (updated in 11.5.0)

The tag regex is now quote-aware: `<\/?([a-zA-Z0-9_-]+)((?:"[^"]*"|'[^']*'|[^>"'])*?)(\/?)>`.

- **`>` inside quoted attribute values is now safe** (e.g., `height-expr="x > 0 ? 0.1 : 0.0"`).
- **Unknown tags warn explicitly** via `console.warn` and `runtime.warnings` with line number instead
  of silently creating empty groups.
- **`id` (or `name`) is copied onto `object3D.name`** so `scene.threeScene.getObjectByName(id)` works.
- **Void tags cannot have children** (`box sphere cylinder cone torus circle ring plane radial-plane
  disc lathe extrude tube surface mesh light camera use instance import link script modifier loft`);
  nest with `<group>`.

---

## 5. `<scene>` attributes

### 5.1 Read and effective

| Attribute | Effect |
|---|---|
| `sky` | hex, or `none` to disable the dome |
| `time-of-day` | `0..24` hour driving sun angle and sky/cloud palette |
| `sun-elevation`, `sun-azimuth`, `sun-color` | explicit sun direction & color override |
| `clouds`, `cloud-density`, `cloud-coverage`, `cloud-speed`, `cloud-scale`, `cloud-puffiness`, `cloud-silver`, `cloud-shadow`, `cloud-detail`, `cloud-erosion`, `cloud-crispness`, `cloud-light-color`, `cloud-shadow-color`, `wind-x`, `wind-z`, `sky-stars` | live-modifiable 360° non-raymarched dynamic cloud parameters |
| `fog-color`, `fog-density`, `fog-near`, `fog-far`, `fog="none"` | exponential / linear fog (synced to water & sky) |
| `bloom`, `bloom-threshold`, `dof`, `fxaa`, `vignette`, `exposure`, `tone-mapping` | post-processing & ACES tone mapping |
| `env`, `env-intensity`, `env-horizon`, `env-zenith`, `env-ground` | preset, HDRI `url(…)`, or custom IBL colors |
| `wet-floor` | `true` or `"width depth"` — wet tiled stone reflector (with indoor oblique clipping) |
| `water`, `water-amount`, `water-tint`, `water-color`, `water-distortion` | scene-level pre-baked FBM rippled water plane |
| `shadows`, `shadow-map` | shadow enable / resolution |
| `shadow-darkness`, `shadow-edge-boost`, `shadow-edge-sat` | deeper shadows + brighter, richer color adjacent to cast shadow boundaries |
| `ambient-color`, `ambient-intensity` | ambient contribution |
| `gravity`, `fps-spawn`, `fps-yaw`, `fps-pitch`, `fps-speed`, `fps-sprint`, `fps-jump`, `fps-radius`, `fps-eye-height` | FPS capsule player params |
| `bake-title` | bake overlay heading |

---

## 6. Optics, Reflections & Materials (11.5.0 Overhaul)

### 6.1 Physical Metals (Chrome & Brass)
`kd = (1.0 - F) * (1.0 - uMetalness) * (1.0 - uTransmission)` eliminates the legacy 22% diffuse
leak on metals. Pure chrome (`metalness: 1.0; roughness: 0.04; color: #f5f7fa`) now renders with
clean mirror reflections instead of white plastic.

### 6.2 Back-to-Front Nested Transmission (Glass-in-Glass)
When transmissive meshes exist (`transmission > 0.01`):
1. All opaque meshes render to the main target.
2. Transmissive meshes are sorted **back-to-front** by squared camera distance.
3. Before each transmissive mesh draws, the current framebuffer is copied into `_transmissionRT` via
   `gl.copyTexSubImage2D` — capturing all opaque geometry *and* any further transmissive meshes behind
   it with zero extra full-scene passes.
4. Output alpha is `1.0` (unless `opacity` is explicitly lowered), eliminating milky/ghost blending.

### 6.3 Tag-Level Reflections & Indoor Oblique Clipping
Any SML geometry tag (`<plane>`, `<box>`, `<disc>`, `<mesh>`) accepts:

```xml
<plane pos="0 0 0" width="640" depth="640"
       reflection="water" reflection-amount="0.88"
       reflection-tint="#bfe6ff" reflection-distortion="0.024"
       reflection-speed="1.0" color="#0c2f47" />
```

- `reflection="water"` uses a pre-baked seamless 256×256 4-octave FBM normal map + Schlick Fresnel +
  horizon fog blend (zero tiled puddles).
- `reflection="mirror"` or `reflection="true"` renders a clean glossy planar mirror.
- `reflection="wet-floor"` renders wet stone slabs with puddles.
- All planar reflectors activate silent world-space clipping (`uUseClipPlane == 2`) below
  `planeY - 0.015`, so enclosed indoor rooms reflect cleanly without sub-floor occlusion.

### 6.4 Shadow-Edge Penumbra Color & Brightness Contrast
Lit surfaces sitting adjacent to cast shadow edges or `N·L` terminators receive a configurable chroma
saturation lift (`shadow-edge-sat`) and direct-light brightness lift (`shadow-edge-boost`) without
bloom glow or white washout, paired with `shadow-darkness` to deepen ambient/IBL inside cast shadows.
Live-adjustable via `Triad.lighting.setShadowEdgeContrast({ boost, saturation, darkness })`.

### 6.5 Inline SML vs 3SS Material Parity & Textures
- All material properties (`color`, `roughness`, `metalness`, `clearcoat`, `transmission`, `ior`,
  `thickness`, `attenuation-color`, `emissive`, `emissive-intensity`, `opacity`, `transparent`,
  `alpha-test`, `wireframe`, `side`) now work identically as inline SML attributes or 3SS rules.
- External textures now multiply with `color` (`uBaseColor * texCol.rgb`) and preserve `texCol.a` in
  `outAlpha`.
- `<box border-radius="…">` now builds outward counter-clockwise side walls with arc-length UVs.

---

## 7. Dynamic Sky & Non-Raymarched Cloud Engine

Built into the 1400m camera-centered `skyDome` (`renderOrder = 500`, pinned at `z = w * 0.99999`
so hardware Early-Z skips occluded sky/cloud pixels behind terrain, buildings, and water):

- **360° seamless dual-window `atan` projection**: Eliminates any seam at `±π` when orbiting 360°.
- **Two layered Worley-FBM cumulus bands** with organic FBM base undulation (`baseWave`), 3D surface
  normals (`N·L`), and Henyey-Greenstein Mie silver-lining rims — zero raymarching loops.
- **100% live-modifiable** via `Triad.sky.setTimeOfDay()`, `.setSun()`, `.setClouds()`, `.setColors()`.

---

## 8. Reversible Explore (Baked) Render Mode

Switch seamlessly between **Edit Mode** (live SML/3SS editing, individual objects, live shadows) and
**Explore Mode** (pre-baked high-FPS playback):

```js
const stats = viewer.setRenderMode('explore', {
  mergeStatic: true,       // merge static meshes by material signature (reversible)
  bakeAnimations: true,    // compile loopable 3SS @keyframes into 64-frame Float32Array LUTs
  freezeShadows: true,     // bake shadow maps once & set shadowMap.autoUpdate = false
  freezeMatrices: true,    // set matrixAutoUpdate = false on static objects
  smartReflector: true,    // skip reflection FBO re-renders when camera is stationary
  reflectorInterval: 2,    // update planar reflectors every Nth frame while moving
  lutSteps: 64
});

// Call if a dynamic light moves in Explore Mode:
Triad.mode.rebakeShadows();

// Switch back to live editing cleanly:
viewer.setRenderMode('edit');
```

**Verified benchmark** (120 static meshes + 24 loop-animated meshes + rippled water reflector +
directional shadows): `290 → 58` draw calls (`-80%`), `4.17 ms → 0.48 ms/frame` (**`8.69×` faster**),
`7.5 ms` one-time bake, lossless restore back to `290` editable draw calls.

---

## 9. Rendering Pipeline (11.5.0 Pass Order)

1. **Directional / Spot / Point shadow passes** (skipped per frame in Explore Mode once pre-baked).
2. **Planar reflections** (with silent `uUseClipPlane == 2` clipping; throttled/cached in Explore Mode).
3. **Opaque meshes** — sorted **front-to-back** for hardware Early-Z rejection.
4. **Sky dome** (`renderOrder = 500`, pinned at far depth `z = w * 0.99999` — Early-Z skips occluded pixels).
5. **Back-to-front nested transmission pass** (`gl.copyTexSubImage2D` snapshot per transmissive layer).
6. **Transparent meshes & particles** (sorted back-to-front).
7. **Post-processing** (`EffectComposer`: Bloom / DOF / FXAA / Vignette, bypassed when disabled for native MSAA sharpness).

---

## 10. Updated Traps & Remaining Caveats

**Resolved since 10.0.0** (no longer traps):
- ~~Stale `Triad3D.DOCS` / `help()`~~ → updated to `11.5.0`.
- ~~`>` inside attributes truncates tags~~ → fixed with quote-aware parser.
- ~~Inline `emissive` / `opacity` / `transmission` attributes discarded~~ → unified with 3SS.
- ~~Metals retain 22% plastic diffuse~~ → zero diffuse at `metalness = 1.0`.
- ~~Transmission cannot nest & blends milky~~ → back-to-front `copyTexSubImage2D` with `outAlpha = 1.0`.
- ~~Planar reflectors unusable indoors~~ → silent oblique clipping plane below `planeY`.
- ~~Unknown tags fail silently~~ → now warn with line number in `console.warn` and `runtime.warnings`.
- ~~`border-radius` on `<box>` breaks UVs/winding~~ → outward winding + arc-length UVs.
- ~~`id` missing from `object3D.name`~~ → copied automatically.

**Still good to know:**
1. **Spot lights cast shadows by default, and only the first shadow-casting spot/point light gets a shadow map.** Set `cast-shadow="false"` on secondary spots.
2. **Scripts run last** — register custom generators/patterns/images before `mount()`.
3. **Navmesh `findPath` returns a direct goal point if unreachable**, and agents are not physics bodies.
4. **Chunk children's colliders are not extracted at compile time** — declare colliders outside `<chunk>` or add via `Triad.physics`.
5. **`<csg mode="subtract">`** remains an arched-doorway builder rather than general CSG.
6. **`<particles>` spawn box comes from three-number `size="x y z"`** (`area` is ignored).
7. **A solid collider ejects the player** — build enclosed rooms from box walls rather than a solid cylinder.

---

*Updated for Triad3D.js 11.5.0 (`triad3d.js`). Verified against source and headless WebGL renders.*
