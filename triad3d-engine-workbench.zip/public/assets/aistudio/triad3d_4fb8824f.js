/**
 * ============================================================================
 * Triad3D.js v11.5 — Declarative (.sml + .3ss) & Procedural (.3js / THREE) WebGL2 Engine
 * ============================================================================
 * Calling `Triad3D.help()` in the console prints the interactive API manual.
 *
 * 1. MOUNTING A SCENE:
 *    const viewer = Triad3D.mount('#app', {
 *      sml: '<scene time-of-day="13.8" cloud-coverage="0.50" shadows="true">...</scene>',
 *      fps: true,          // Walkable capsule FPS controller + PointerLock
 *      colliders: false,   // Toggle 3D wireframe collider debug overlay
 *      exposure: 1.06,
 *      gui: true,
 *      hud: true
 *    });
 *    // Switch between Live Edit Mode & Baked Explore Mode (~8.7x faster):
 *    viewer.setRenderMode('explore'); // or viewer.setRenderMode('edit')
 *
 * 2. <scene> ATTRIBUTES (All parsed declaratively):
 *    sky="#hex | none"           time-of-day="13.8"         sun-elevation="44"  sun-azimuth="122"
 *    cloud-density="0.90"        cloud-coverage="0.50"      cloud-speed="0.032" cloud-scale="1.15"
 *    cloud-puffiness="0.86"      cloud-silver="0.90"        cloud-shadow="0.72" cloud-crispness="0.84"
 *    fog-color="#hex"            fog-density="0.012"        fog="none | false"  fog-near="75" fog-far="240"
 *    bloom="0.3 | true | false"  bloom-threshold="0.92"     dof="false | true | 0.002"  fxaa="true | false"
 *    exposure="1.06"             env="sunset|studio|overcast|night|url(...)"    env-intensity="1.2"
 *    env-horizon / env-zenith / env-ground                  wet-floor="true | 28 80"
 *    water="640 640"             water-tint="#bfe6ff"       water-color="#0c2f47" water-distortion="0.024"
 *    shadows="true | false"      shadow-darkness="0.68"     shadow-edge-boost="0.42" shadow-edge-sat="0.34"
 *    gravity="-16.5"             fps-spawn="0 0 18 180"     fps-speed="5.4"     fps-eye-height="1.62"
 *
 * 3. DECLARATIVE SML TAGS (quote-aware parser supports `>` inside attributes; unknown tags warn):
 *    Primitives: <box border-radius="0.2">, <sphere>, <cylinder>, <cone>, <torus>, <capsule>,
 *                <plane reflection="water|mirror|true" reflection-amount="0.88" reflection-tint="#bfe6ff"
 *                       reflection-distortion="0.024" />, <ring>, <circle>, <disc>,
 *                <lathe>, <extrude>, <tube>, <surface>, <csg>, <mesh generator="...">
 *    Models/AI:  <gltf src="...">, <glb>, <model>, <obj>, <navmesh>, <agent behavior="patrol|follow|...">
 *    Macros:     <component>, <repeat>, <for>, <if>, <use>, <batch>, <optimize>, <chunk>, <canvas-texture>
 *    Lights:     <light type="directional|point|spot|hemisphere|ambient"> & shorthands
 *    Physics:    <collider shape="box|cylinder|sphere" type="solid|ground|trigger" />
 *
 * 4. OPTICS & RENDERING CAPABILITIES (v11.5):
 *    - True zero-diffuse PBR metals (kd = (1 - F) * (1 - metalness) * (1 - transmission)) for crisp chrome.
 *    - Back-to-front nested screen-space transmission (glass inside glass via gl.copyTexSubImage2D).
 *    - Indoor oblique/silent planar reflection clipping (uUseClipPlane == 2) — works inside enclosed rooms.
 *    - 360-degree seamless non-raymarched dynamic sky & volumetric-look cumulus clouds (Early-Z renderOrder=500).
 *    - Pre-baked 256x256 seamless 4-octave FBM rippled water normal map + Schlick Fresnel.
 *    - Shadow-edge penumbra color & brightness contrast (uShadowEdgeBoost, uShadowEdgeSat, uShadowDarkness).
 *    - Reversible Explore (Baked) Mode: auto static material-bucket merging, 64-frame Float32Array
 *      animation LUTs, frozen static shadows/matrices, front-to-back Early-Z sorting, smart reflector caching.
 * ============================================================================
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    const api = factory();
    root.Triad3D = api;
    if (!root.THREE) root.THREE = api.THREE;
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // --- Lightweight Standalone Fallbacks for Studio Hooks ---
  
  function escapeHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function formatReplVal(v) {
    if (v === null) return 'null';
    if (v === undefined) return 'undefined';
    if (typeof v === 'object') {
      try { return JSON.stringify(v); } catch (_) { return String(v); }
    }
    return String(v);
  }
  let _customLogger = null;
  function logConsole(msg, level = 'info') {
    if (_customLogger) _customLogger(msg, level);
    else if (level === 'err') console.error('[Triad3D]', msg);
    else if (level === 'warn') console.warn('[Triad3D]', msg);
    else console.log('[Triad3D]', msg);
  }
  function selectSMLNode() {}

  // --- Embedded Optimized WebGL2 PBR + 2048x2048 PCF Shadow Kernel (THREE v7.5) ---

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking

// Complete Local Three.js r169 + Addons Runtime for Offline Headless Chromium Verification & Benchmarking
const REVISION = '169-triad9';
const SRGBColorSpace = 'srgb';
const LinearSRGBColorSpace = 'srgb-linear';
const NoColorSpace = '';
const NoToneMapping = 0;
const LinearToneMapping = 1;
const ReinhardToneMapping = 2;
const CineonToneMapping = 3;
const ACESFilmicToneMapping = 4;
const AgXToneMapping = 6;
const NeutralToneMapping = 7;
const BasicShadowMap = 0;
const PCFShadowMap = 1;
const PCFSoftShadowMap = 2;
const VSMShadowMap = 3;
const RepeatWrapping = 1000;
const ClampToEdgeWrapping = 1001;
const MirroredRepeatWrapping = 1002;
const NearestFilter = 1003;
const NearestMipmapNearestFilter = 1004;
const NearestMipmapLinearFilter = 1005;
const LinearFilter = 1006;
const LinearMipmapNearestFilter = 1007;
const LinearMipmapLinearFilter = 1008;
const RGBAFormat = 1023;
const RGBFormat = 1022;
const AlphaFormat = 1021;
const LuminanceFormat = 1024;
const DepthFormat = 1026;
const UnsignedByteType = 1009;
const ByteType = 1010;
const ShortType = 1011;
const UnsignedShortType = 1012;
const IntType = 1013;
const UnsignedIntType = 1014;
const FloatType = 1015;
const HalfFloatType = 1016;
const FrontSide = 0;
const BackSide = 1;
const DoubleSide = 2;
const NoBlending = 0;
const NormalBlending = 1;
const AdditiveBlending = 2;
const SubtractiveBlending = 3;
const MultiplyBlending = 4;
const CustomBlending = 5;
const StaticDrawUsage = 35044;
const DynamicDrawUsage = 35048;
const StreamDrawUsage = 35040;
const UVMapping = 300;
const EquirectangularReflectionMapping = 303;
const EquirectangularRefractionMapping = 304;

let _seed = 1234567;
const MathUtils = {
  DEG2RAD: Math.PI / 180,
  RAD2DEG: 180 / Math.PI,
  degToRad: (d) => d * Math.PI / 180,
  radToDeg: (r) => r * 180 / Math.PI,
  clamp: (v, a, b) => Math.max(a, Math.min(b, v)),
  euclideanModulo: (n, m) => ((n % m) + m) % m,
  mapLinear: (x, a1, a2, b1, b2) => b1 + (x - a1) * (b2 - b1) / ((a2 - a1) || 1),
  inverseLerp: (x, y, value) => (x !== y) ? (value - x) / (y - x) : 0,
  lerp: (a, b, t) => a + (b - a) * t,
  damp: (x, y, lambda, dt) => MathUtils.lerp(x, y, 1 - Math.exp(-lambda * dt)),
  pingPong: (x, length = 1) => length - Math.abs(MathUtils.euclideanModulo(x, length * 2) - length),
  smoothstep: (x, min, max) => {
    if (x <= min) return 0;
    if (x >= max) return 1;
    x = (x - min) / (max - min);
    return x * x * (3 - 2 * x);
  },
  smootherstep: (x, min, max) => {
    if (x <= min) return 0;
    if (x >= max) return 1;
    x = (x - min) / (max - min);
    return x * x * x * (x * (x * 6 - 15) + 10);
  },
  randInt: (low, high) => low + Math.floor(Math.random() * (high - low + 1)),
  randFloat: (low, high) => low + Math.random() * (high - low),
  randFloatSpread: (range) => range * (0.5 - Math.random()),
  seededRandom: (s) => {
    if (s !== undefined) _seed = s;
    let t = (_seed += 0x6D2B79F5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  },
  isPowerOfTwo: (v) => (v & (v - 1)) === 0 && v !== 0,
  ceilPowerOfTwo: (v) => Math.pow(2, Math.ceil(Math.log(v) / Math.LN2)),
  floorPowerOfTwo: (v) => Math.pow(2, Math.floor(Math.log(v) / Math.LN2)),
  generateUUID: () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  })
};

class Vector2 {
  constructor(x = 0, y = 0) { this.x = x; this.y = y; this.isVector2 = true; }
  get width() { return this.x; }
  set width(v) { this.x = v; }
  get height() { return this.y; }
  set height(v) { this.y = v; }
  set(x, y) { this.x = x; this.y = y === undefined ? x : y; return this; }
  setScalar(s) { this.x = s; this.y = s; return this; }
  setX(x) { this.x = x; return this; }
  setY(y) { this.y = y; return this; }
  setComponent(i, v) { if (i === 0) this.x = v; else this.y = v; return this; }
  getComponent(i) { return i === 0 ? this.x : this.y; }
  copy(v) { this.x = v.x; this.y = v.y; return this; }
  clone() { return new Vector2(this.x, this.y); }
  add(v) { this.x += v.x; this.y += v.y; return this; }
  addScalar(s) { this.x += s; this.y += s; return this; }
  addVectors(a, b) { this.x = a.x + b.x; this.y = a.y + b.y; return this; }
  addScaledVector(v, s) { this.x += v.x * s; this.y += v.y * s; return this; }
  sub(v) { this.x -= v.x; this.y -= v.y; return this; }
  subScalar(s) { this.x -= s; this.y -= s; return this; }
  subVectors(a, b) { this.x = a.x - b.x; this.y = a.y - b.y; return this; }
  multiply(v) { this.x *= v.x; this.y *= v.y; return this; }
  multiplyScalar(s) { this.x *= s; this.y *= s; return this; }
  divide(v) { this.x /= v.x; this.y /= v.y; return this; }
  divideScalar(s) { return this.multiplyScalar(1 / (s || 1)); }
  applyMatrix3(m) {
    const x = this.x, y = this.y, e = m.elements;
    this.x = e[0] * x + e[3] * y + e[6];
    this.y = e[1] * x + e[4] * y + e[7];
    return this;
  }
  min(v) { this.x = Math.min(this.x, v.x); this.y = Math.min(this.y, v.y); return this; }
  max(v) { this.x = Math.max(this.x, v.x); this.y = Math.max(this.y, v.y); return this; }
  clamp(min, max) {
    this.x = Math.max(min.x, Math.min(max.x, this.x));
    this.y = Math.max(min.y, Math.min(max.y, this.y));
    return this;
  }
  clampScalar(minVal, maxVal) {
    this.x = Math.max(minVal, Math.min(maxVal, this.x));
    this.y = Math.max(minVal, Math.min(maxVal, this.y));
    return this;
  }
  clampLength(min, max) {
    const l = this.length();
    return this.divideScalar(l || 1).multiplyScalar(Math.max(min, Math.min(max, l)));
  }
  floor() { this.x = Math.floor(this.x); this.y = Math.floor(this.y); return this; }
  ceil() { this.x = Math.ceil(this.x); this.y = Math.ceil(this.y); return this; }
  round() { this.x = Math.round(this.x); this.y = Math.round(this.y); return this; }
  roundToZero() { this.x = Math.trunc(this.x); this.y = Math.trunc(this.y); return this; }
  negate() { this.x = -this.x; this.y = -this.y; return this; }
  dot(v) { return this.x * v.x + this.y * v.y; }
  cross(v) { return this.x * v.y - this.y * v.x; }
  lengthSq() { return this.x * this.x + this.y * this.y; }
  length() { return Math.hypot(this.x, this.y); }
  manhattanLength() { return Math.abs(this.x) + Math.abs(this.y); }
  normalize() { return this.divideScalar(this.length() || 1); }
  angle() { return Math.atan2(-this.y, -this.x) + Math.PI; }
  angleTo(v) {
    const denom = Math.sqrt(this.lengthSq() * v.lengthSq());
    if (denom === 0) return Math.PI / 2;
    return Math.acos(MathUtils.clamp(this.dot(v) / denom, -1, 1));
  }
  distanceTo(v) { return Math.hypot(this.x - v.x, this.y - v.y); }
  distanceToSquared(v) { const dx = this.x - v.x, dy = this.y - v.y; return dx * dx + dy * dy; }
  manhattanDistanceTo(v) { return Math.abs(this.x - v.x) + Math.abs(this.y - v.y); }
  setLength(l) { return this.normalize().multiplyScalar(l); }
  lerp(v, t) { this.x += (v.x - this.x) * t; this.y += (v.y - this.y) * t; return this; }
  lerpVectors(v1, v2, t) { this.x = v1.x + (v2.x - v1.x) * t; this.y = v1.y + (v2.y - v1.y) * t; return this; }
  equals(v) { return v.x === this.x && v.y === this.y; }
  fromArray(arr, offset = 0) { this.x = arr[offset]; this.y = arr[offset + 1]; return this; }
  toArray(arr = [], offset = 0) { arr[offset] = this.x; arr[offset + 1] = this.y; return arr; }
  fromBufferAttribute(attr, index) { this.x = attr.getX(index); this.y = attr.getY(index); return this; }
  rotateAround(center, angle) {
    const c = Math.cos(angle), s = Math.sin(angle);
    const x = this.x - center.x, y = this.y - center.y;
    this.x = x * c - y * s + center.x;
    this.y = x * s + y * c + center.y;
    return this;
  }
  random() { this.x = Math.random(); this.y = Math.random(); return this; }
  *[Symbol.iterator]() { yield this.x; yield this.y; }
}

class Vector3 {
  constructor(x = 0, y = 0, z = 0) { this.x = x; this.y = y; this.z = z; this.isVector3 = true; }
  set(x, y, z) {
    if (y === undefined && z === undefined) { this.x = x; this.y = x; this.z = x; }
    else { this.x = x; this.y = y; this.z = z; }
    return this;
  }
  setScalar(s) { this.x = s; this.y = s; this.z = s; return this; }
  setX(x) { this.x = x; return this; }
  setY(y) { this.y = y; return this; }
  setZ(z) { this.z = z; return this; }
  setComponent(i, v) { if (i === 0) this.x = v; else if (i === 1) this.y = v; else this.z = v; return this; }
  getComponent(i) { return i === 0 ? this.x : (i === 1 ? this.y : this.z); }
  copy(v) { this.x = v.x; this.y = v.y; this.z = v.z; return this; }
  clone() { return new Vector3(this.x, this.y, this.z); }
  add(v) { this.x += v.x; this.y += v.y; this.z += v.z; return this; }
  addScalar(s) { this.x += s; this.y += s; this.z += s; return this; }
  addVectors(a, b) { this.x = a.x + b.x; this.y = a.y + b.y; this.z = a.z + b.z; return this; }
  addScaledVector(v, s) { this.x += v.x * s; this.y += v.y * s; this.z += v.z * s; return this; }
  sub(v) { this.x -= v.x; this.y -= v.y; this.z -= v.z; return this; }
  subScalar(s) { this.x -= s; this.y -= s; this.z -= s; return this; }
  subVectors(a, b) { this.x = a.x - b.x; this.y = a.y - b.y; this.z = a.z - b.z; return this; }
  multiply(v) { this.x *= v.x; this.y *= v.y; this.z *= v.z; return this; }
  multiplyScalar(s) { this.x *= s; this.y *= s; this.z *= s; return this; }
  multiplyVectors(a, b) { this.x = a.x * b.x; this.y = a.y * b.y; this.z = a.z * b.z; return this; }
  divide(v) { this.x /= v.x; this.y /= v.y; this.z /= v.z; return this; }
  divideScalar(s) { return this.multiplyScalar(1 / (s || 1)); }
  min(v) { this.x = Math.min(this.x, v.x); this.y = Math.min(this.y, v.y); this.z = Math.min(this.z, v.z); return this; }
  max(v) { this.x = Math.max(this.x, v.x); this.y = Math.max(this.y, v.y); this.z = Math.max(this.z, v.z); return this; }
  clamp(min, max) {
    this.x = Math.max(min.x, Math.min(max.x, this.x));
    this.y = Math.max(min.y, Math.min(max.y, this.y));
    this.z = Math.max(min.z, Math.min(max.z, this.z));
    return this;
  }
  clampScalar(minVal, maxVal) {
    this.x = Math.max(minVal, Math.min(maxVal, this.x));
    this.y = Math.max(minVal, Math.min(maxVal, this.y));
    this.z = Math.max(minVal, Math.min(maxVal, this.z));
    return this;
  }
  clampLength(min, max) {
    const l = this.length();
    return this.divideScalar(l || 1).multiplyScalar(Math.max(min, Math.min(max, l)));
  }
  floor() { this.x = Math.floor(this.x); this.y = Math.floor(this.y); this.z = Math.floor(this.z); return this; }
  ceil() { this.x = Math.ceil(this.x); this.y = Math.ceil(this.y); this.z = Math.ceil(this.z); return this; }
  round() { this.x = Math.round(this.x); this.y = Math.round(this.y); this.z = Math.round(this.z); return this; }
  roundToZero() { this.x = Math.trunc(this.x); this.y = Math.trunc(this.y); this.z = Math.trunc(this.z); return this; }
  negate() { this.x = -this.x; this.y = -this.y; this.z = -this.z; return this; }
  dot(v) { return this.x * v.x + this.y * v.y + this.z * v.z; }
  cross(v) { return this.crossVectors(this, v); }
  crossVectors(a, b) {
    const ax = a.x, ay = a.y, az = a.z, bx = b.x, by = b.y, bz = b.z;
    this.x = ay * bz - az * by;
    this.y = az * bx - ax * bz;
    this.z = ax * by - ay * bx;
    return this;
  }
  projectOnVector(v) {
    const denom = v.lengthSq();
    if (denom === 0) return this.set(0, 0, 0);
    const s = v.dot(this) / denom;
    return this.copy(v).multiplyScalar(s);
  }
  projectOnPlane(planeNormal) {
    const v = new Vector3().copy(this).projectOnVector(planeNormal);
    return this.sub(v);
  }
  reflect(normal) {
    return this.sub(new Vector3().copy(normal).multiplyScalar(2 * this.dot(normal)));
  }
  angleTo(v) {
    const denom = Math.sqrt(this.lengthSq() * v.lengthSq());
    if (denom === 0) return Math.PI / 2;
    return Math.acos(MathUtils.clamp(this.dot(v) / denom, -1, 1));
  }
  lengthSq() { return this.x * this.x + this.y * this.y + this.z * this.z; }
  length() { return Math.hypot(this.x, this.y, this.z); }
  manhattanLength() { return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z); }
  distanceTo(v) { return Math.hypot(this.x - v.x, this.y - v.y, this.z - v.z); }
  distanceToSquared(v) { const dx = this.x - v.x, dy = this.y - v.y, dz = this.z - v.z; return dx * dx + dy * dy + dz * dz; }
  manhattanDistanceTo(v) { return Math.abs(this.x - v.x) + Math.abs(this.y - v.y) + Math.abs(this.z - v.z); }
  distanceToManhattan(v) { return this.manhattanDistanceTo(v); }
  normalize() { const l = this.length() || 1; this.x /= l; this.y /= l; this.z /= l; return this; }
  setLength(l) { return this.normalize().multiplyScalar(l); }
  lerp(v, t) { this.x += (v.x - this.x) * t; this.y += (v.y - this.y) * t; this.z += (v.z - this.z) * t; return this; }
  lerpVectors(a, b, t) { this.x = a.x + (b.x - a.x) * t; this.y = a.y + (b.y - a.y) * t; this.z = a.z + (b.z - a.z) * t; return this; }
  applyEuler(e) {
    return this.applyQuaternion(new Quaternion().setFromEuler(e));
  }
  applyAxisAngle(axis, angle) {
    const q = new Quaternion().setFromAxisAngle(axis, angle);
    return this.applyQuaternion(q);
  }
  applyMatrix3(m) {
    const x = this.x, y = this.y, z = this.z, e = m.elements;
    this.x = e[0] * x + e[3] * y + e[6] * z;
    this.y = e[1] * x + e[4] * y + e[7] * z;
    this.z = e[2] * x + e[5] * y + e[8] * z;
    return this;
  }
  applyNormalMatrix(m) {
    return this.applyMatrix3(m).normalize();
  }
  applyQuaternion(q) {
    const x = this.x, y = this.y, z = this.z, qx = q.x, qy = q.y, qz = q.z, qw = q.w;
    const ix = qw * x + qy * z - qz * y;
    const iy = qw * y + qz * x - qx * z;
    const iz = qw * z + qx * y - qy * x;
    const iw = -qx * x - qy * y - qz * z;
    this.x = ix * qw + iw * -qx + iy * -qz - iz * -qy;
    this.y = iy * qw + iw * -qy + iz * -qx - ix * -qz;
    this.z = iz * qw + iw * -qz + ix * -qy - iy * -qx;
    return this;
  }
  applyMatrix4(m) {
    const x = this.x, y = this.y, z = this.z, e = m.elements;
    const w = 1 / (e[3] * x + e[7] * y + e[11] * z + e[15] || 1);
    this.x = (e[0] * x + e[4] * y + e[8] * z + e[12]) * w;
    this.y = (e[1] * x + e[5] * y + e[9] * z + e[13]) * w;
    this.z = (e[2] * x + e[6] * y + e[10] * z + e[14]) * w;
    return this;
  }
  transformDirection(m) {
    const x = this.x, y = this.y, z = this.z, e = m.elements;
    this.x = e[0] * x + e[4] * y + e[8] * z;
    this.y = e[1] * x + e[5] * y + e[9] * z;
    this.z = e[2] * x + e[6] * y + e[10] * z;
    return this.normalize();
  }
  project(cam) {
    cam.updateMatrixWorld();
    return this.applyMatrix4(cam.matrixWorldInverse).applyMatrix4(cam.projectionMatrix);
  }
  unproject(cam) {
    cam.updateMatrixWorld();
    return this.applyMatrix4(cam.projectionMatrixInverse).applyMatrix4(cam.matrixWorld);
  }
  setFromMatrixPosition(m) {
    const e = m.elements;
    this.x = e[12]; this.y = e[13]; this.z = e[14];
    return this;
  }
  setFromMatrixScale(m) {
    const sx = this.setFromMatrixColumn(m, 0).length();
    const sy = this.setFromMatrixColumn(m, 1).length();
    const sz = this.setFromMatrixColumn(m, 2).length();
    this.x = sx; this.y = sy; this.z = sz;
    return this;
  }
  setFromMatrixColumn(m, index) {
    return this.fromArray(m.elements, index * 4);
  }
  setFromMatrix3Column(m, index) {
    return this.fromArray(m.elements, index * 3);
  }
  setFromSpherical(s) { return this.setFromSphericalCoords(s.radius, s.phi, s.theta); }
  setFromSphericalCoords(radius, phi, theta) {
    const sinPhiRadius = Math.sin(phi) * radius;
    this.x = sinPhiRadius * Math.sin(theta);
    this.y = Math.cos(phi) * radius;
    this.z = sinPhiRadius * Math.cos(theta);
    return this;
  }
  setFromCylindrical(c) { return this.setFromCylindricalCoords(c.radius, c.theta, c.y); }
  setFromCylindricalCoords(radius, theta, y) {
    this.x = radius * Math.sin(theta);
    this.y = y;
    this.z = radius * Math.cos(theta);
    return this;
  }
  setFromEuler(e) { this.x = e.x; this.y = e.y; this.z = e.z; return this; }
  setFromColor(c) { this.x = c.r; this.y = c.g; this.z = c.b; return this; }
  equals(v) { return v.x === this.x && v.y === this.y && v.z === this.z; }
  fromArray(arr, offset = 0) { this.x = arr[offset]; this.y = arr[offset + 1]; this.z = arr[offset + 2]; return this; }
  toArray(arr = [], offset = 0) { arr[offset] = this.x; arr[offset + 1] = this.y; arr[offset + 2] = this.z; return arr; }
  fromBufferAttribute(attr, i) {
    const a = attr.array, s = attr.itemSize;
    this.x = a[i * s]; this.y = a[i * s + 1]; this.z = a[i * s + 2];
    return this;
  }
  random() { this.x = Math.random(); this.y = Math.random(); this.z = Math.random(); return this; }
  randomDirection() {
    const u = (Math.random() - 0.5) * 2;
    const t = Math.random() * Math.PI * 2;
    const f = Math.sqrt(1 - u * u);
    this.x = f * Math.cos(t); this.y = f * Math.sin(t); this.z = u;
    return this;
  }
  *[Symbol.iterator]() { yield this.x; yield this.y; yield this.z; }
}

class Vector4 {
  constructor(x = 0, y = 0, z = 0, w = 1) { this.x = x; this.y = y; this.z = z; this.w = w; this.isVector4 = true; }
  set(x, y, z, w) { this.x = x; this.y = y; this.z = z; this.w = w; return this; }
  setScalar(s) { this.x = s; this.y = s; this.z = s; this.w = s; return this; }
  setX(x) { this.x = x; return this; }
  setY(y) { this.y = y; return this; }
  setZ(z) { this.z = z; return this; }
  setW(w) { this.w = w; return this; }
  setComponent(i, v) { if (i === 0) this.x = v; else if (i === 1) this.y = v; else if (i === 2) this.z = v; else this.w = v; return this; }
  getComponent(i) { return i === 0 ? this.x : (i === 1 ? this.y : (i === 2 ? this.z : this.w)); }
  copy(v) { this.x = v.x; this.y = v.y; this.z = v.z; this.w = v.w !== undefined ? v.w : 1; return this; }
  clone() { return new Vector4(this.x, this.y, this.z, this.w); }
  add(v) { this.x += v.x; this.y += v.y; this.z += v.z; this.w += v.w; return this; }
  addScalar(s) { this.x += s; this.y += s; this.z += s; this.w += s; return this; }
  addVectors(a, b) { this.x = a.x + b.x; this.y = a.y + b.y; this.z = a.z + b.z; this.w = a.w + b.w; return this; }
  addScaledVector(v, s) { this.x += v.x * s; this.y += v.y * s; this.z += v.z * s; this.w += v.w * s; return this; }
  sub(v) { this.x -= v.x; this.y -= v.y; this.z -= v.z; this.w -= v.w; return this; }
  subScalar(s) { this.x -= s; this.y -= s; this.z -= s; this.w -= s; return this; }
  subVectors(a, b) { this.x = a.x - b.x; this.y = a.y - b.y; this.z = a.z - b.z; this.w = a.w - b.w; return this; }
  multiply(v) { this.x *= v.x; this.y *= v.y; this.z *= v.z; this.w *= v.w; return this; }
  multiplyScalar(s) { this.x *= s; this.y *= s; this.z *= s; this.w *= s; return this; }
  divideScalar(s) { return this.multiplyScalar(1 / (s || 1)); }
  applyMatrix4(m) {
    const x = this.x, y = this.y, z = this.z, w = this.w, e = m.elements;
    this.x = e[0] * x + e[4] * y + e[8] * z + e[12] * w;
    this.y = e[1] * x + e[5] * y + e[9] * z + e[13] * w;
    this.z = e[2] * x + e[6] * y + e[10] * z + e[14] * w;
    this.w = e[3] * x + e[7] * y + e[11] * z + e[15] * w;
    return this;
  }
  min(v) { this.x = Math.min(this.x, v.x); this.y = Math.min(this.y, v.y); this.z = Math.min(this.z, v.z); this.w = Math.min(this.w, v.w); return this; }
  max(v) { this.x = Math.max(this.x, v.x); this.y = Math.max(this.y, v.y); this.z = Math.max(this.z, v.z); this.w = Math.max(this.w, v.w); return this; }
  clamp(min, max) {
    this.x = Math.max(min.x, Math.min(max.x, this.x));
    this.y = Math.max(min.y, Math.min(max.y, this.y));
    this.z = Math.max(min.z, Math.min(max.z, this.z));
    this.w = Math.max(min.w, Math.min(max.w, this.w));
    return this;
  }
  negate() { this.x = -this.x; this.y = -this.y; this.z = -this.z; this.w = -this.w; return this; }
  dot(v) { return this.x * v.x + this.y * v.y + this.z * v.z + this.w * v.w; }
  lengthSq() { return this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w; }
  length() { return Math.hypot(this.x, this.y, this.z, this.w); }
  manhattanLength() { return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z) + Math.abs(this.w); }
  normalize() { return this.divideScalar(this.length() || 1); }
  setLength(l) { return this.normalize().multiplyScalar(l); }
  lerp(v, t) { this.x += (v.x - this.x) * t; this.y += (v.y - this.y) * t; this.z += (v.z - this.z) * t; this.w += (v.w - this.w) * t; return this; }
  lerpVectors(v1, v2, t) { this.x = v1.x + (v2.x - v1.x) * t; this.y = v1.y + (v2.y - v1.y) * t; this.z = v1.z + (v2.z - v1.z) * t; this.w = v1.w + (v2.w - v1.w) * t; return this; }
  equals(v) { return v.x === this.x && v.y === this.y && v.z === this.z && v.w === this.w; }
  fromArray(arr, offset = 0) { this.x = arr[offset]; this.y = arr[offset + 1]; this.z = arr[offset + 2]; this.w = arr[offset + 3]; return this; }
  toArray(arr = [], offset = 0) { arr[offset] = this.x; arr[offset + 1] = this.y; arr[offset + 2] = this.z; arr[offset + 3] = this.w; return arr; }
  fromBufferAttribute(attr, i) {
    this.x = attr.getX(i); this.y = attr.getY(i); this.z = attr.getZ(i); this.w = attr.getW(i);
    return this;
  }
  *[Symbol.iterator]() { yield this.x; yield this.y; yield this.z; yield this.w; }
}

function hue2rgb(p, q, t) {
  if (t < 0) t += 1;
  if (t > 1) t -= 1;
  if (t < 1 / 6) return p + (q - p) * 6 * t;
  if (t < 1 / 2) return q;
  if (t < 2 / 3) return p + (q - p) * 6 * (2 / 3 - t);
  return p;
}

const _COLOR_NAMES = {
  aliceblue:0xf0f8ff, antiquewhite:0xfaebd7, aqua:0x00ffff, aquamarine:0x7fffd4, azure:0xf0ffff,
  beige:0xf5f5dc, bisque:0xffe4c4, black:0x000000, blanchedalmond:0xffebcd, blue:0x0000ff,
  blueviolet:0x8a2be2, brown:0xa52a2a, burlywood:0xdeb887, cadetblue:0x5f9ea0, chartreuse:0x7fff00,
  chocolate:0xd2691e, coral:0xff7f50, cornflowerblue:0x6495ed, cornsilk:0xffdc, crimson:0xdc143c,
  cyan:0x00ffff, darkblue:0x00008b, darkcyan:0x008b8b, darkgoldenrod:0xb8860b, darkgray:0xa9a9a9,
  darkgreen:0x006400, darkgrey:0xa9a9a9, darkkhaki:0xbdb76b, darkmagenta:0x8b008b, darkolivegreen:0x556b2f,
  darkorange:0xff8c00, darkorchid:0x9932cc, darkred:0x8b0000, darksalmon:0xe9967a, darkseagreen:0x8fbc8f,
  darkslateblue:0x483d8b, darkslategray:0x2f4f4f, darkslategrey:0x2f4f4f, darkturquoise:0x00ced1, darkviolet:0x9400d3,
  deeppink:0xff1493, deepskyblue:0x00bfff, dimgray:0x696969, dimgrey:0x696969, dodgerblue:0x1e90ff,
  firebrick:0xb22222, floralwhite:0xfffaf0, forestgreen:0x228b22, fuchsia:0xff00ff, gainsboro:0xdcdcdc,
  ghostwhite:0xf8f8ff, gold:0xffd700, goldenrod:0xdaa520, gray:0x808080, green:0x008000,
  greenyellow:0xadff2f, grey:0x808080, honeydew:0xf0fff0, hotpink:0xff69b4, indianred:0xcd5c5c,
  indigo:0x4b0082, ivory:0xfffff0, khaki:0xf0e68c, lavender:0xe6e6fa, lavenderblush:0xfff0f5,
  lawngreen:0x7cfc00, lemonchiffon:0xfffacd, lightblue:0xadd8e6, lightcoral:0xf08080, lightcyan:0xe0ffff,
  lightgoldenrodyellow:0xfafad2, lightgray:0xd3d3d3, lightgreen:0x90ee90, lightgrey:0xd3d3d3, lightpink:0xffb6c1,
  lightsalmon:0xffa07a, lightseagreen:0x20b2aa, lightskyblue:0x87cefa, lightslategray:0x778899, lightslategrey:0x778899,
  lightsteelblue:0xb0c4de, lightyellow:0xffffe0, lime:0x00ff00, limegreen:0x32cd32, linen:0xfaf0e6,
  magenta:0xff00ff, maroon:0x800000, mediumaquamarine:0x66cdaa, mediumblue:0x0000cd, mediumorchid:0xba55d3,
  mediumpurple:0x9370db, mediumseagreen:0x3cb371, mediumslateblue:0x7b68ee, mediumspringgreen:0x00fa9a,
  mediumturquoise:0x48d1cc, mediumvioletred:0xc71585, midnightblue:0x191970, mintcream:0xf5fffa, mistyrose:0xffe4e1,
  moccasin:0xffe4b5, navajowhite:0xffdead, navy:0x000080, oldlace:0xfdf5e6, olive:0x808000,
  olivedrab:0x6b8e23, orange:0xffa500, orangered:0xff4500, orchid:0xda70d6, palegoldenrod:0xeee8aa,
  palegreen:0x98fb98, paleturquoise:0xafeeee, palevioletred:0xdb7093, papayawhip:0xffefd5, peachpuff:0xffdab9,
  peru:0xcd853f, pink:0xffc0cb, plum:0xdda0dd, powderblue:0xb0e0e6, purple:0x800080,
  rebeccapurple:0x663399, red:0xff0000, rosybrown:0xbc8f8f, royalblue:0x4169e1, saddlebrown:0x8b4513,
  salmon:0xfa8072, sandybrown:0xf4a460, seagreen:0x2e8b57, seashell:0xfff5ee, sienna:0xa0522d,
  silver:0xc0c0c0, skyblue:0x87ceeb, slateblue:0x6a5acd, slategray:0x708090, slategrey:0x708090,
  snow:0xfffafa, springgreen:0x00ff7f, steelblue:0x4682b4, tan:0xd2b48c, teal:0x008080,
  thistle:0xd8bfd8, tomato:0xff6347, turquoise:0x40e0d0, violet:0xee82ee, wheat:0xf5deb3,
  white:0xffffff, whitesmoke:0xf5f5f5, yellow:0xffff00, yellowgreen:0x9acd32
};

class Color {
  constructor(r, g, b) {
    this.isColor = true;
    this.r = 1; this.g = 1; this.b = 1;
    if (r !== undefined) this.set(r, g, b);
  }
  set(r, g, b) {
    if (g === undefined && b === undefined) {
      if (r && r.isColor) return this.copy(r);
      if (typeof r === 'number') return this.setHex(r);
      if (typeof r === 'string') return this.setStyle(r);
    } else {
      this.r = r; this.g = g; this.b = b;
    }
    return this;
  }
  setScalar(s) { this.r = s; this.g = s; this.b = s; return this; }
  setRGB(r, g, b) { this.r = r; this.g = g; this.b = b; return this; }
  setHex(hex) {
    hex = Math.floor(hex);
    this.r = (hex >> 16 & 255) / 255;
    this.g = (hex >> 8 & 255) / 255;
    this.b = (hex & 255) / 255;
    return this;
  }
  setStyle(style) {
    if (!style || typeof style !== 'string') return this;
    const s = style.trim().toLowerCase();
    if (s.startsWith('#')) {
      const hex = s.slice(1);
      const full = (hex.length === 3 || hex.length === 4)
        ? hex.slice(0, 3).split('').map(c => c + c).join('')
        : hex.slice(0, 6);
      const n = parseInt(full, 16);
      if (!isNaN(n)) this.setHex(n);
      return this;
    }
    if (s.startsWith('0x')) {
      const n = parseInt(s, 16);
      if (!isNaN(n)) this.setHex(n);
      return this;
    }
    const rgbMatch = /^rgba?\(\s*([0-9.%]+)\s*[,\s]\s*([0-9.%]+)\s*[,\s]\s*([0-9.%]+)/.exec(s);
    if (rgbMatch) {
      const parseCh = (v) => v.endsWith('%') ? parseFloat(v) / 100 : parseFloat(v) / 255;
      this.r = MathUtils.clamp(parseCh(rgbMatch[1]), 0, 1);
      this.g = MathUtils.clamp(parseCh(rgbMatch[2]), 0, 1);
      this.b = MathUtils.clamp(parseCh(rgbMatch[3]), 0, 1);
      return this;
    }
    const hslMatch = /^hsla?\(\s*([0-9.]+)\s*[,\s]\s*([0-9.]+)%\s*[,\s]\s*([0-9.]+)%/.exec(s);
    if (hslMatch) {
      return this.setHSL(parseFloat(hslMatch[1]) / 360, parseFloat(hslMatch[2]) / 100, parseFloat(hslMatch[3]) / 100);
    }
    if (_COLOR_NAMES[s] !== undefined) {
      return this.setHex(_COLOR_NAMES[s]);
    }
    return this;
  }
  setColorName(style) { return this.setStyle(style); }
  getHex() {
    return (Math.round(MathUtils.clamp(this.r, 0, 1) * 255) << 16) +
           (Math.round(MathUtils.clamp(this.g, 0, 1) * 255) << 8) +
           Math.round(MathUtils.clamp(this.b, 0, 1) * 255);
  }
  getHexString() {
    return ('000000' + this.getHex().toString(16)).slice(-6);
  }
  getRGB(target) {
    target.r = this.r; target.g = this.g; target.b = this.b;
    return target;
  }
  getStyle() {
    return `rgb(${Math.round(this.r * 255)},${Math.round(this.g * 255)},${Math.round(this.b * 255)})`;
  }
  setHSL(h, s, l) {
    h = ((h % 1) + 1) % 1;
    s = MathUtils.clamp(s, 0, 1);
    l = MathUtils.clamp(l, 0, 1);
    if (s === 0) {
      this.r = this.g = this.b = l;
    } else {
      const p = l <= 0.5 ? l * (1 + s) : l + s - (l * s);
      const q = (2 * l) - p;
      this.r = hue2rgb(q, p, h + 1 / 3);
      this.g = hue2rgb(q, p, h);
      this.b = hue2rgb(q, p, h - 1 / 3);
    }
    return this;
  }
  getHSL(target = { h: 0, s: 0, l: 0 }) {
    const r = this.r, g = this.g, b = this.b;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let hue = 0, saturation = 0;
    const lightness = (min + max) / 2.0;
    if (min !== max) {
      const delta = max - min;
      saturation = lightness <= 0.5 ? delta / (max + min) : delta / (2 - max - min);
      switch (max) {
        case r: hue = (g - b) / delta + (g < b ? 6 : 0); break;
        case g: hue = (b - r) / delta + 2; break;
        case b: hue = (r - g) / delta + 4; break;
      }
      hue /= 6;
    }
    target.h = hue; target.s = saturation; target.l = lightness;
    return target;
  }
  offsetHSL(h, s, l) {
    const hsl = this.getHSL();
    return this.setHSL(hsl.h + h, hsl.s + s, hsl.l + l);
  }
  copy(c) { this.r = c.r; this.g = c.g; this.b = c.b; return this; }
  clone() { return new Color(this.r, this.g, this.b); }
  add(c) { this.r += c.r; this.g += c.g; this.b += c.b; return this; }
  addColors(c1, c2) { this.r = c1.r + c2.r; this.g = c1.g + c2.g; this.b = c1.b + c2.b; return this; }
  addScalar(s) { this.r += s; this.g += s; this.b += s; return this; }
  sub(c) { this.r = Math.max(0, this.r - c.r); this.g = Math.max(0, this.g - c.g); this.b = Math.max(0, this.b - c.b); return this; }
  multiply(c) { this.r *= c.r; this.g *= c.g; this.b *= c.b; return this; }
  multiplyScalar(s) { this.r *= s; this.g *= s; this.b *= s; return this; }
  lerp(c, alpha) {
    this.r += (c.r - this.r) * alpha;
    this.g += (c.g - this.g) * alpha;
    this.b += (c.b - this.b) * alpha;
    return this;
  }
  lerpColors(c1, c2, alpha) {
    this.r = c1.r + (c2.r - c1.r) * alpha;
    this.g = c1.g + (c2.g - c1.g) * alpha;
    this.b = c1.b + (c2.b - c1.b) * alpha;
    return this;
  }
  lerpHSL(c, alpha) {
    const hslA = this.getHSL(), hslB = c.getHSL();
    const h = MathUtils.lerp(hslA.h, hslB.h, alpha);
    const s = MathUtils.lerp(hslA.s, hslB.s, alpha);
    const l = MathUtils.lerp(hslA.l, hslB.l, alpha);
    return this.setHSL(h, s, l);
  }
  convertSRGBToLinear() {
    const toLin = (c) => (c < 0.04045) ? c * 0.0773993808 : Math.pow(c * 0.9478672986 + 0.0521327014, 2.4);
    this.r = toLin(this.r); this.g = toLin(this.g); this.b = toLin(this.b);
    return this;
  }
  convertLinearToSRGB() {
    const toSRGB = (c) => (c < 0.0031308) ? c * 12.92 : 1.055 * Math.pow(c, 0.41666) - 0.055;
    this.r = toSRGB(this.r); this.g = toSRGB(this.g); this.b = toSRGB(this.b);
    return this;
  }
  copySRGBToLinear(c) { return this.copy(c).convertSRGBToLinear(); }
  copyLinearToSRGB(c) { return this.copy(c).convertLinearToSRGB(); }
  equals(c) { return c.r === this.r && c.g === this.g && c.b === this.b; }
  fromArray(arr, offset = 0) { this.r = arr[offset]; this.g = arr[offset + 1]; this.b = arr[offset + 2]; return this; }
  toArray(arr = [], offset = 0) { arr[offset] = this.r; arr[offset + 1] = this.g; arr[offset + 2] = this.b; return arr; }
  fromBufferAttribute(attr, index) {
    this.r = attr.getX(index); this.g = attr.getY(index); this.b = attr.getZ(index);
    return this;
  }
  *[Symbol.iterator]() { yield this.r; yield this.g; yield this.b; }
}

class Euler {
  constructor(x = 0, y = 0, z = 0, order = 'XYZ') {
    this.x = x; this.y = y; this.z = z; this.order = order; this.isEuler = true;
  }
  set(x, y, z, order) {
    this.x = x; this.y = y; this.z = z;
    if (order) this.order = order;
    return this;
  }
  copy(e) { this.x = e.x; this.y = e.y; this.z = e.z; this.order = e.order; return this; }
  clone() { return new Euler(this.x, this.y, this.z, this.order); }
  setFromRotationMatrix(m, order = this.order) {
    const te = m.elements;
    const m11 = te[0], m12 = te[4], m13 = te[8];
    const m21 = te[1], m22 = te[5], m23 = te[9];
    const m31 = te[2], m32 = te[6], m33 = te[10];
    this.order = order;
    switch (order) {
      case 'YXZ':
        this.x = Math.asin(-MathUtils.clamp(m23, -1, 1));
        if (Math.abs(m23) < 0.9999999) { this.y = Math.atan2(m13, m33); this.z = Math.atan2(m21, m22); }
        else { this.y = Math.atan2(-m31, m11); this.z = 0; }
        break;
      case 'ZXY':
        this.x = Math.asin(MathUtils.clamp(m32, -1, 1));
        if (Math.abs(m32) < 0.9999999) { this.y = Math.atan2(-m31, m33); this.z = Math.atan2(-m12, m22); }
        else { this.y = 0; this.z = Math.atan2(m21, m11); }
        break;
      case 'ZYX':
        this.y = Math.asin(-MathUtils.clamp(m31, -1, 1));
        if (Math.abs(m31) < 0.9999999) { this.x = Math.atan2(m32, m33); this.z = Math.atan2(m21, m11); }
        else { this.x = 0; this.z = Math.atan2(-m12, m22); }
        break;
      case 'YZX':
        this.z = Math.asin(MathUtils.clamp(m21, -1, 1));
        if (Math.abs(m21) < 0.9999999) { this.x = Math.atan2(-m23, m22); this.y = Math.atan2(-m31, m11); }
        else { this.x = 0; this.y = Math.atan2(m13, m33); }
        break;
      case 'XZY':
        this.z = Math.asin(-MathUtils.clamp(m12, -1, 1));
        if (Math.abs(m12) < 0.9999999) { this.x = Math.atan2(m32, m22); this.y = Math.atan2(m13, m11); }
        else { this.x = Math.atan2(-m23, m33); this.y = 0; }
        break;
      case 'XYZ':
      default:
        this.y = Math.asin(MathUtils.clamp(m13, -1, 1));
        if (Math.abs(m13) < 0.9999999) { this.x = Math.atan2(-m23, m33); this.z = Math.atan2(-m12, m11); }
        else { this.x = Math.atan2(m32, m22); this.z = 0; }
        break;
    }
    return this;
  }
  setFromQuaternion(q, order = this.order) {
    const m = new Matrix4().makeRotationFromQuaternion(q);
    return this.setFromRotationMatrix(m, order);
  }
  setFromVector3(v, order = this.order) { return this.set(v.x, v.y, v.z, order); }
  reorder(newOrder) {
    const q = new Quaternion().setFromEuler(this);
    return this.setFromQuaternion(q, newOrder);
  }
  equals(e) { return e.x === this.x && e.y === this.y && e.z === this.z && e.order === this.order; }
  fromArray(a) { this.x = a[0]; this.y = a[1]; this.z = a[2]; if (a[3] !== undefined) this.order = a[3]; return this; }
  toArray(a = [], offset = 0) { a[offset] = this.x; a[offset + 1] = this.y; a[offset + 2] = this.z; a[offset + 3] = this.order; return a; }
  *[Symbol.iterator]() { yield this.x; yield this.y; yield this.z; yield this.order; }
}

class Quaternion {
  constructor(x = 0, y = 0, z = 0, w = 1) { this.x = x; this.y = y; this.z = z; this.w = w; this.isQuaternion = true; }
  set(x, y, z, w) { this.x = x; this.y = y; this.z = z; this.w = w; return this; }
  identity() { return this.set(0, 0, 0, 1); }
  copy(q) { this.x = q.x; this.y = q.y; this.z = q.z; this.w = q.w; return this; }
  clone() { return new Quaternion(this.x, this.y, this.z, this.w); }
  setFromAxisAngle(axis, angle) {
    const half = angle * 0.5, s = Math.sin(half);
    this.x = axis.x * s; this.y = axis.y * s; this.z = axis.z * s; this.w = Math.cos(half);
    return this;
  }
  setFromRotationMatrix(m) {
    const te = m.elements;
    const m11 = te[0], m12 = te[4], m13 = te[8],
          m21 = te[1], m22 = te[5], m23 = te[9],
          m31 = te[2], m32 = te[6], m33 = te[10],
          trace = m11 + m22 + m33;
    if (trace > 0) {
      const s = 0.5 / Math.sqrt(trace + 1.0);
      this.w = 0.25 / s;
      this.x = (m32 - m23) * s;
      this.y = (m13 - m31) * s;
      this.z = (m21 - m12) * s;
    } else if (m11 > m22 && m11 > m33) {
      const s = 2.0 * Math.sqrt(1.0 + m11 - m22 - m33);
      this.w = (m32 - m23) / s;
      this.x = 0.25 * s;
      this.y = (m12 + m21) / s;
      this.z = (m13 + m31) / s;
    } else if (m22 > m33) {
      const s = 2.0 * Math.sqrt(1.0 + m22 - m11 - m33);
      this.w = (m13 - m31) / s;
      this.x = (m12 + m21) / s;
      this.y = 0.25 * s;
      this.z = (m23 + m32) / s;
    } else {
      const s = 2.0 * Math.sqrt(1.0 + m33 - m11 - m22);
      this.w = (m21 - m12) / s;
      this.x = (m13 + m31) / s;
      this.y = (m23 + m32) / s;
      this.z = 0.25 * s;
    }
    return this;
  }
  setFromUnitVectors(vFrom, vTo) {
    let r = vFrom.dot(vTo) + 1;
    if (r < 1e-6) {
      r = 0;
      if (Math.abs(vFrom.x) > Math.abs(vFrom.z)) {
        this.x = -vFrom.y; this.y = vFrom.x; this.z = 0; this.w = r;
      } else {
        this.x = 0; this.y = -vFrom.z; this.z = vFrom.y; this.w = r;
      }
    } else {
      this.x = vFrom.y * vTo.z - vFrom.z * vTo.y;
      this.y = vFrom.z * vTo.x - vFrom.x * vTo.z;
      this.z = vFrom.x * vTo.y - vFrom.y * vTo.x;
      this.w = r;
    }
    return this.normalize();
  }
  setFromEuler(e) {
    const c1 = Math.cos(e.x / 2), c2 = Math.cos(e.y / 2), c3 = Math.cos(e.z / 2);
    const s1 = Math.sin(e.x / 2), s2 = Math.sin(e.y / 2), s3 = Math.sin(e.z / 2);
    switch (e.order) {
      case 'YXZ':
        this.x = s1 * c2 * c3 + c1 * s2 * s3;
        this.y = c1 * s2 * c3 - s1 * c2 * s3;
        this.z = c1 * c2 * s3 - s1 * s2 * c3;
        this.w = c1 * c2 * c3 + s1 * s2 * s3;
        break;
      case 'ZXY':
        this.x = s1 * c2 * c3 - c1 * s2 * s3;
        this.y = c1 * s2 * c3 + s1 * c2 * s3;
        this.z = c1 * c2 * s3 + s1 * s2 * c3;
        this.w = c1 * c2 * c3 - s1 * s2 * s3;
        break;
      case 'ZYX':
        this.x = s1 * c2 * c3 - c1 * s2 * s3;
        this.y = c1 * s2 * c3 + s1 * c2 * s3;
        this.z = c1 * c2 * s3 - s1 * s2 * c3;
        this.w = c1 * c2 * c3 + s1 * s2 * s3;
        break;
      case 'YZX':
        this.x = s1 * c2 * c3 + c1 * s2 * s3;
        this.y = c1 * s2 * c3 + s1 * c2 * s3;
        this.z = c1 * c2 * s3 - s1 * s2 * c3;
        this.w = c1 * c2 * c3 - s1 * s2 * s3;
        break;
      case 'XZY':
        this.x = s1 * c2 * c3 - c1 * s2 * s3;
        this.y = c1 * s2 * c3 - s1 * c2 * s3;
        this.z = c1 * c2 * s3 + s1 * s2 * c3;
        this.w = c1 * c2 * c3 + s1 * s2 * s3;
        break;
      case 'XYZ':
      default:
        this.x = s1 * c2 * c3 + c1 * s2 * s3;
        this.y = c1 * s2 * c3 - s1 * c2 * s3;
        this.z = c1 * c2 * s3 + s1 * s2 * c3;
        this.w = c1 * c2 * c3 - s1 * s2 * s3;
        break;
    }
    return this;
  }
  angleTo(q) { return 2 * Math.acos(Math.abs(MathUtils.clamp(this.dot(q), -1, 1))); }
  rotateTowards(q, step) {
    const angle = this.angleTo(q);
    if (angle === 0) return this;
    const t = Math.min(1, step / angle);
    return this.slerp(q, t);
  }
  invert() { return this.conjugate(); }
  conjugate() { this.x *= -1; this.y *= -1; this.z *= -1; return this; }
  dot(v) { return this.x * v.x + this.y * v.y + this.z * v.z + this.w * v.w; }
  lengthSq() { return this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w; }
  length() { return Math.hypot(this.x, this.y, this.z, this.w); }
  normalize() {
    let l = this.length();
    if (l === 0) { this.x = 0; this.y = 0; this.z = 0; this.w = 1; }
    else { l = 1 / l; this.x *= l; this.y *= l; this.z *= l; this.w *= l; }
    return this;
  }
  multiply(q) { return this.multiplyQuaternions(this, q); }
  premultiply(q) { return this.multiplyQuaternions(q, this); }
  multiplyQuaternions(a, b) {
    const qax = a.x, qay = a.y, qaz = a.z, qaw = a.w;
    const qbx = b.x, qby = b.y, qbz = b.z, qbw = b.w;
    this.x = qax * qbw + qaw * qbx + qay * qbz - qaz * qby;
    this.y = qay * qbw + qaw * qby + qaz * qbx - qax * qbz;
    this.z = qaz * qbw + qaw * qbz + qax * qby - qay * qbx;
    this.w = qaw * qbw - qax * qbx - qay * qby - qaz * qbz;
    return this;
  }
  slerp(qb, t) {
    if (t === 0) return this;
    if (t === 1) return this.copy(qb);
    const x = this.x, y = this.y, z = this.z, w = this.w;
    let cosHalfTheta = w * qb.w + x * qb.x + y * qb.y + z * qb.z;
    if (cosHalfTheta < 0) {
      this.w = -qb.w; this.x = -qb.x; this.y = -qb.y; this.z = -qb.z;
      cosHalfTheta = -cosHalfTheta;
    } else {
      this.copy(qb);
    }
    if (cosHalfTheta >= 1.0) {
      this.w = w; this.x = x; this.y = y; this.z = z;
      return this;
    }
    const sqrSinHalfTheta = 1.0 - cosHalfTheta * cosHalfTheta;
    if (sqrSinHalfTheta <= Number.EPSILON) {
      const s = 1 - t;
      this.w = s * w + t * this.w;
      this.x = s * x + t * this.x;
      this.y = s * y + t * this.y;
      this.z = s * z + t * this.z;
      return this.normalize();
    }
    const sinHalfTheta = Math.sqrt(sqrSinHalfTheta);
    const halfTheta = Math.atan2(sinHalfTheta, cosHalfTheta);
    const ratioA = Math.sin((1 - t) * halfTheta) / sinHalfTheta;
    const ratioB = Math.sin(t * halfTheta) / sinHalfTheta;
    this.w = (w * ratioA + this.w * ratioB);
    this.x = (x * ratioA + this.x * ratioB);
    this.y = (y * ratioA + this.y * ratioB);
    this.z = (z * ratioA + this.z * ratioB);
    return this;
  }
  slerpQuaternions(qa, qb, t) { return this.copy(qa).slerp(qb, t); }
  equals(q) { return q.x === this.x && q.y === this.y && q.z === this.z && q.w === this.w; }
  fromArray(arr, offset = 0) { this.x = arr[offset]; this.y = arr[offset + 1]; this.z = arr[offset + 2]; this.w = arr[offset + 3]; return this; }
  toArray(arr = [], offset = 0) { arr[offset] = this.x; arr[offset + 1] = this.y; arr[offset + 2] = this.z; arr[offset + 3] = this.w; return arr; }
  *[Symbol.iterator]() { yield this.x; yield this.y; yield this.z; yield this.w; }
}

class Matrix3 {
  constructor(n11, n12, n13, n21, n22, n23, n31, n32, n33) {
    this.elements = new Float32Array([1, 0, 0, 0, 1, 0, 0, 0, 1]);
    this.isMatrix3 = true;
    if (n11 !== undefined) this.set(n11, n12, n13, n21, n22, n23, n31, n32, n33);
  }
  set(n11, n12, n13, n21, n22, n23, n31, n32, n33) {
    const te = this.elements;
    te[0] = n11; te[1] = n21; te[2] = n31;
    te[3] = n12; te[4] = n22; te[5] = n32;
    te[6] = n13; te[7] = n23; te[8] = n33;
    return this;
  }
  identity() { return this.set(1, 0, 0, 0, 1, 0, 0, 0, 1); }
  copy(m) { this.elements.set(m.elements); return this; }
  clone() { return new Matrix3().copy(this); }
  extractBasis(xAxis, yAxis, zAxis) {
    xAxis.setFromMatrix3Column(this, 0);
    yAxis.setFromMatrix3Column(this, 1);
    zAxis.setFromMatrix3Column(this, 2);
    return this;
  }
  setFromMatrix4(m) {
    const me = m.elements;
    return this.set(me[0], me[4], me[8], me[1], me[5], me[9], me[2], me[6], me[10]);
  }
  multiply(m) { return this.multiplyMatrices(this, m); }
  premultiply(m) { return this.multiplyMatrices(m, this); }
  multiplyMatrices(a, b) {
    const ae = a.elements, be = b.elements, te = this.elements;
    const a11 = ae[0], a12 = ae[3], a13 = ae[6];
    const a21 = ae[1], a22 = ae[4], a23 = ae[7];
    const a31 = ae[2], a32 = ae[5], a33 = ae[8];
    const b11 = be[0], b12 = be[3], b13 = be[6];
    const b21 = be[1], b22 = be[4], b23 = be[7];
    const b31 = be[2], b32 = be[5], b33 = be[8];
    te[0] = a11 * b11 + a12 * b21 + a13 * b31;
    te[3] = a11 * b12 + a12 * b22 + a13 * b32;
    te[6] = a11 * b13 + a12 * b23 + a13 * b33;
    te[1] = a21 * b11 + a22 * b21 + a23 * b31;
    te[4] = a21 * b12 + a22 * b22 + a23 * b32;
    te[7] = a21 * b13 + a22 * b23 + a23 * b33;
    te[2] = a31 * b11 + a32 * b21 + a33 * b31;
    te[5] = a31 * b12 + a32 * b22 + a33 * b32;
    te[8] = a31 * b13 + a32 * b23 + a33 * b33;
    return this;
  }
  multiplyScalar(s) {
    const te = this.elements;
    for (let i = 0; i < 9; i++) te[i] *= s;
    return this;
  }
  determinant() {
    const te = this.elements;
    const a = te[0], b = te[1], c = te[2], d = te[3], e = te[4], f = te[5], g = te[6], h = te[7], i = te[8];
    return a * e * i - a * f * h - b * d * i + b * f * g + c * d * h - c * e * g;
  }
  invert() {
    const te = this.elements,
      n11 = te[0], n21 = te[1], n31 = te[2],
      n12 = te[3], n22 = te[4], n32 = te[5],
      n13 = te[6], n23 = te[7], n33 = te[8],
      t11 = n33 * n22 - n32 * n23,
      t12 = n32 * n13 - n33 * n12,
      t13 = n23 * n12 - n22 * n13,
      det = n11 * t11 + n21 * t12 + n31 * t13;
    if (det === 0) return this.set(0, 0, 0, 0, 0, 0, 0, 0, 0);
    const detInv = 1 / det;
    te[0] = t11 * detInv;
    te[1] = (n31 * n23 - n33 * n21) * detInv;
    te[2] = (n32 * n21 - n31 * n22) * detInv;
    te[3] = t12 * detInv;
    te[4] = (n33 * n11 - n31 * n13) * detInv;
    te[5] = (n31 * n12 - n32 * n11) * detInv;
    te[6] = t13 * detInv;
    te[7] = (n21 * n13 - n23 * n11) * detInv;
    te[8] = (n22 * n11 - n21 * n12) * detInv;
    return this;
  }
  getInverse(m) { return this.copy(m).invert(); }
  transpose() {
    let tmp; const m = this.elements;
    tmp = m[1]; m[1] = m[3]; m[3] = tmp;
    tmp = m[2]; m[2] = m[6]; m[6] = tmp;
    tmp = m[5]; m[5] = m[7]; m[7] = tmp;
    return this;
  }
  getNormalMatrix(matrix4) {
    return this.setFromMatrix4(matrix4).invert().transpose();
  }
  scale(sx, sy) {
    this.premultiply(new Matrix3().set(sx, 0, 0, 0, sy, 0, 0, 0, 1));
    return this;
  }
  rotate(theta) {
    const c = Math.cos(theta), s = Math.sin(theta);
    this.premultiply(new Matrix3().set(c, -s, 0, s, c, 0, 0, 0, 1));
    return this;
  }
  translate(tx, ty) {
    this.premultiply(new Matrix3().set(1, 0, tx, 0, 1, ty, 0, 0, 1));
    return this;
  }
  equals(matrix) {
    const te = this.elements, me = matrix.elements;
    for (let i = 0; i < 9; i++) if (te[i] !== me[i]) return false;
    return true;
  }
  fromArray(array, offset = 0) {
    for (let i = 0; i < 9; i++) this.elements[i] = array[i + offset];
    return this;
  }
  toArray(array = [], offset = 0) {
    const te = this.elements;
    for (let i = 0; i < 9; i++) array[offset + i] = te[i];
    return array;
  }
}

class Matrix4 {
  constructor(n11,n12,n13,n14,n21,n22,n23,n24,n31,n32,n33,n34,n41,n42,n43,n44) {
    this.elements = new Float32Array([1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]);
    this.isMatrix4 = true;
    if (n11 !== undefined) this.set(n11,n12,n13,n14,n21,n22,n23,n24,n31,n32,n33,n34,n41,n42,n43,n44);
  }
  set(n11,n12,n13,n14,n21,n22,n23,n24,n31,n32,n33,n34,n41,n42,n43,n44) {
    const te = this.elements;
    te[0]=n11; te[4]=n12; te[8]=n13; te[12]=n14;
    te[1]=n21; te[5]=n22; te[9]=n23; te[13]=n24;
    te[2]=n31; te[6]=n32; te[10]=n33; te[14]=n34;
    te[3]=n41; te[7]=n42; te[11]=n43; te[15]=n44;
    return this;
  }
  identity() { return this.set(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1); }
  copy(m) { this.elements.set(m.elements); return this; }
  clone() { return new Matrix4().copy(this); }
  copyPosition(m) {
    const te = this.elements, me = m.elements;
    te[12] = me[12]; te[13] = me[13]; te[14] = me[14];
    return this;
  }
  setFromMatrix3(m) {
    const me = m.elements;
    return this.set(
      me[0], me[3], me[6], 0,
      me[1], me[4], me[7], 0,
      me[2], me[5], me[8], 0,
      0,     0,     0,     1
    );
  }
  extractBasis(xAxis, yAxis, zAxis) {
    xAxis.setFromMatrixColumn(this, 0);
    yAxis.setFromMatrixColumn(this, 1);
    zAxis.setFromMatrixColumn(this, 2);
    return this;
  }
  makeBasis(xAxis, yAxis, zAxis) {
    return this.set(
      xAxis.x, yAxis.x, zAxis.x, 0,
      xAxis.y, yAxis.y, zAxis.y, 0,
      xAxis.z, yAxis.z, zAxis.z, 0,
      0,       0,       0,       1
    );
  }
  extractRotation(m) {
    const te = this.elements, me = m.elements;
    const scaleX = 1 / (Math.hypot(me[0], me[1], me[2]) || 1);
    const scaleY = 1 / (Math.hypot(me[4], me[5], me[6]) || 1);
    const scaleZ = 1 / (Math.hypot(me[8], me[9], me[10]) || 1);
    te[0] = me[0] * scaleX; te[1] = me[1] * scaleX; te[2] = me[2] * scaleX; te[3] = 0;
    te[4] = me[4] * scaleY; te[5] = me[5] * scaleY; te[6] = me[6] * scaleY; te[7] = 0;
    te[8] = me[8] * scaleZ; te[9] = me[9] * scaleZ; te[10] = me[10] * scaleZ; te[11] = 0;
    te[12] = 0; te[13] = 0; te[14] = 0; te[15] = 1;
    return this;
  }
  makeRotationFromEuler(euler) {
    const te = this.elements;
    const x = euler.x, y = euler.y, z = euler.z;
    const a = Math.cos(x), b = Math.sin(x);
    const c = Math.cos(y), d = Math.sin(y);
    const e = Math.cos(z), f = Math.sin(z);
    const order = euler.order || 'XYZ';
    if (order === 'XYZ') {
      const ae = a * e, af = a * f, be = b * e, bf = b * f;
      te[0] = c * e; te[4] = -c * f; te[8] = d;
      te[1] = af + be * d; te[5] = ae - bf * d; te[9] = -b * c;
      te[2] = bf - ae * d; te[6] = be + af * d; te[10] = a * c;
    } else if (order === 'YXZ') {
      const ce = c * e, cf = c * f, de = d * e, df = d * f;
      te[0] = ce + df * b; te[4] = de * b - cf; te[8] = a * d;
      te[1] = a * f; te[5] = a * e; te[9] = -b;
      te[2] = cf * b - de; te[6] = df + ce * b; te[10] = a * c;
    } else if (order === 'ZXY') {
      const ce = c * e, cf = c * f, de = d * e, df = d * f;
      te[0] = ce - df * b; te[4] = -a * f; te[8] = de + cf * b;
      te[1] = cf + de * b; te[5] = a * e; te[9] = df - ce * b;
      te[2] = -a * d; te[6] = b; te[10] = a * c;
    } else if (order === 'ZYX') {
      const ae = a * e, af = a * f, be = b * e, bf = b * f;
      te[0] = c * e; te[4] = be * d - af; te[8] = ae * d + bf;
      te[1] = c * f; te[5] = bf * d + ae; te[9] = af * d - be;
      te[2] = -d; te[6] = b * c; te[10] = a * c;
    } else if (order === 'YZX') {
      const ac = a * c, ad = a * d, bc = b * c, bd = b * d;
      te[0] = c * e; te[4] = bd - ac * f; te[8] = bc * f + ad;
      te[1] = f; te[5] = a * e; te[9] = -b * e;
      te[2] = -d * e; te[6] = ad * f + bc; te[10] = ac - bd * f;
    } else if (order === 'XZY') {
      const ac = a * c, ad = a * d, bc = b * c, bd = b * d;
      te[0] = c * e; te[4] = -f; te[8] = d * e;
      te[1] = ac * f + bd; te[5] = a * e; te[9] = ad * f - bc;
      te[2] = bc * f - ad; te[6] = b * e; te[10] = bd * f + ac;
    }
    te[3] = 0; te[7] = 0; te[11] = 0;
    te[12] = 0; te[13] = 0; te[14] = 0; te[15] = 1;
    return this;
  }
  makeRotationFromQuaternion(q) {
    return this.compose(new Vector3(0, 0, 0), q, new Vector3(1, 1, 1));
  }
  compose(pos, q, sc) {
    const te = this.elements;
    const x = q.x, y = q.y, z = q.z, w = q.w;
    const x2 = x + x, y2 = y + y, z2 = z + z;
    const xx = x * x2, xy = x * y2, xz = x * z2;
    const yy = y * y2, yz = y * z2, zz = z * z2;
    const wx = w * x2, wy = w * y2, wz = w * z2;
    const sx = sc.x, sy = sc.y, sz = sc.z;
    te[0] = (1 - (yy + zz)) * sx; te[1] = (xy + wz) * sx; te[2] = (xz - wy) * sx; te[3] = 0;
    te[4] = (xy - wz) * sy; te[5] = (1 - (xx + zz)) * sy; te[6] = (yz + wx) * sy; te[7] = 0;
    te[8] = (xz + wy) * sz; te[9] = (yz - wx) * sz; te[10] = (1 - (xx + yy)) * sz; te[11] = 0;
    te[12] = pos.x; te[13] = pos.y; te[14] = pos.z; te[15] = 1;
    return this;
  }
  decompose(position, quaternion, scale) {
    const te = this.elements;
    let sx = Math.hypot(te[0], te[1], te[2]);
    const sy = Math.hypot(te[4], te[5], te[6]);
    const sz = Math.hypot(te[8], te[9], te[10]);
    if (this.determinant() < 0) sx = -sx;
    position.x = te[12]; position.y = te[13]; position.z = te[14];
    const m = this.clone();
    const invSX = 1 / (sx || 1), invSY = 1 / (sy || 1), invSZ = 1 / (sz || 1);
    m.elements[0] *= invSX; m.elements[1] *= invSX; m.elements[2] *= invSX;
    m.elements[4] *= invSY; m.elements[5] *= invSY; m.elements[6] *= invSY;
    m.elements[8] *= invSZ; m.elements[9] *= invSZ; m.elements[10] *= invSZ;
    quaternion.setFromRotationMatrix(m);
    scale.x = sx; scale.y = sy; scale.z = sz;
    return this;
  }
  setPosition(x, y, z) {
    const te = this.elements;
    if (x && x.isVector3) {
      te[12] = x.x; te[13] = x.y; te[14] = x.z;
    } else {
      te[12] = x; te[13] = y; te[14] = z;
    }
    return this;
  }
  scale(v) {
    const te = this.elements;
    const x = v.x, y = v.y, z = v.z;
    te[0] *= x; te[4] *= y; te[8] *= z;
    te[1] *= x; te[5] *= y; te[9] *= z;
    te[2] *= x; te[6] *= y; te[10] *= z;
    te[3] *= x; te[7] *= y; te[11] *= z;
    return this;
  }
  getMaxScaleOnAxis() {
    const te = this.elements;
    const scaleXSq = te[0] * te[0] + te[1] * te[1] + te[2] * te[2];
    const scaleYSq = te[4] * te[4] + te[5] * te[5] + te[6] * te[6];
    const scaleZSq = te[8] * te[8] + te[9] * te[9] + te[10] * te[10];
    return Math.sqrt(Math.max(scaleXSq, scaleYSq, scaleZSq));
  }
  makeTranslation(x, y, z) {
    if (x && x.isVector3) return this.set(1, 0, 0, x.x, 0, 1, 0, x.y, 0, 0, 1, x.z, 0, 0, 0, 1);
    return this.set(1, 0, 0, x, 0, 1, 0, y, 0, 0, 1, z, 0, 0, 0, 1);
  }
  makeRotationX(theta) {
    const c = Math.cos(theta), s = Math.sin(theta);
    return this.set(1, 0, 0, 0, 0, c, -s, 0, 0, s, c, 0, 0, 0, 0, 1);
  }
  makeRotationY(theta) {
    const c = Math.cos(theta), s = Math.sin(theta);
    return this.set(c, 0, s, 0, 0, 1, 0, 0, -s, 0, c, 0, 0, 0, 0, 1);
  }
  makeRotationZ(theta) {
    const c = Math.cos(theta), s = Math.sin(theta);
    return this.set(c, -s, 0, 0, s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
  }
  makeRotationAxis(axis, angle) {
    const c = Math.cos(angle), s = Math.sin(angle), t = 1 - c;
    const x = axis.x, y = axis.y, z = axis.z;
    const tx = t * x, ty = t * y;
    return this.set(
      tx * x + c, tx * y - s * z, tx * z + s * y, 0,
      tx * y + s * z, ty * y + c, ty * z - s * x, 0,
      tx * z - s * y, ty * z + s * x, t * z * z + c, 0,
      0, 0, 0, 1
    );
  }
  makeScale(x, y, z) {
    return this.set(x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1);
  }
  makeShear(xy, xz, yx, yz, zx, zy) {
    return this.set(1, yx, zx, 0, xy, 1, zy, 0, xz, yz, 1, 0, 0, 0, 0, 1);
  }
  getNormalMatrix(targetMatrix3) {
    const m3 = targetMatrix3 && targetMatrix3.isMatrix3 ? targetMatrix3 : new Matrix3();
    return m3.getNormalMatrix(this);
  }
  multiply(m) { return this.multiplyMatrices(this, m); }
  premultiply(m) { return this.multiplyMatrices(m, this); }
  multiplyMatrices(a, b) {
    const ae = a.elements, be = b.elements;
    const a11=ae[0],a12=ae[4],a13=ae[8],a14=ae[12];
    const a21=ae[1],a22=ae[5],a23=ae[9],a24=ae[13];
    const a31=ae[2],a32=ae[6],a33=ae[10],a34=ae[14];
    const a41=ae[3],a42=ae[7],a43=ae[11],a44=ae[15];
    const b11=be[0],b12=be[4],b13=be[8],b14=be[12];
    const b21=be[1],b22=be[5],b23=be[9],b24=be[13];
    const b31=be[2],b32=be[6],b33=be[10],b34=be[14];
    const b41=be[3],b42=be[7],b43=be[11],b44=be[15];
    const te = this.elements;
    te[0]=a11*b11+a12*b21+a13*b31+a14*b41; te[4]=a11*b12+a12*b22+a13*b32+a14*b42; te[8]=a11*b13+a12*b23+a13*b33+a14*b43; te[12]=a11*b14+a12*b24+a13*b34+a14*b44;
    te[1]=a21*b11+a22*b21+a23*b31+a24*b41; te[5]=a21*b12+a22*b22+a23*b32+a24*b42; te[9]=a21*b13+a22*b23+a23*b33+a24*b43; te[13]=a21*b14+a22*b24+a23*b34+a24*b44;
    te[2]=a31*b11+a32*b21+a33*b31+a34*b41; te[6]=a31*b12+a32*b22+a33*b32+a34*b42; te[10]=a31*b13+a32*b23+a33*b33+a34*b43; te[14]=a31*b14+a32*b24+a33*b34+a34*b44;
    te[3]=a41*b11+a42*b21+a43*b31+a44*b41; te[7]=a41*b12+a42*b22+a43*b32+a44*b42; te[11]=a41*b13+a42*b23+a43*b33+a44*b43; te[15]=a41*b14+a42*b24+a43*b34+a44*b44;
    return this;
  }
  multiplyScalar(s) {
    const te = this.elements;
    for (let i = 0; i < 16; i++) te[i] *= s;
    return this;
  }
  determinant() {
    const te = this.elements;
    const n11 = te[0], n12 = te[4], n13 = te[8], n14 = te[12];
    const n21 = te[1], n22 = te[5], n23 = te[9], n24 = te[13];
    const n31 = te[2], n32 = te[6], n33 = te[10], n34 = te[14];
    const n41 = te[3], n42 = te[7], n43 = te[11], n44 = te[15];
    return (
      n41 * (+n14 * n23 * n32 - n13 * n24 * n32 - n14 * n22 * n33 + n12 * n24 * n33 + n13 * n22 * n34 - n12 * n23 * n34) +
      n42 * (+n11 * n23 * n34 - n11 * n24 * n33 + n14 * n21 * n33 - n13 * n21 * n34 + n13 * n24 * n31 - n14 * n23 * n31) +
      n43 * (+n11 * n24 * n32 - n11 * n22 * n34 - n14 * n21 * n32 + n12 * n21 * n34 + n14 * n22 * n31 - n12 * n24 * n31) +
      n44 * (-n13 * n22 * n31 - n11 * n23 * n32 + n11 * n22 * n33 + n13 * n21 * n32 - n12 * n21 * n33 + n12 * n23 * n31)
    );
  }
  transpose() {
    const te = this.elements; let tmp;
    tmp = te[1]; te[1] = te[4]; te[4] = tmp;
    tmp = te[2]; te[2] = te[8]; te[8] = tmp;
    tmp = te[6]; te[6] = te[9]; te[9] = tmp;
    tmp = te[3]; te[3] = te[12]; te[12] = tmp;
    tmp = te[7]; te[7] = te[13]; te[13] = tmp;
    tmp = te[11]; te[11] = te[14]; te[14] = tmp;
    return this;
  }
  lookAt(eye, target, up) {
    const z = new Vector3().subVectors(eye, target);
    if (z.lengthSq() === 0) z.z = 1; else z.normalize();
    const x = new Vector3().crossVectors(up, z);
    if (x.lengthSq() === 0) {
      if (Math.abs(up.z) === 1) z.x += 0.0001; else z.z += 0.0001;
      z.normalize();
      x.crossVectors(up, z);
    }
    x.normalize();
    const y = new Vector3().crossVectors(z, x);
    const te = this.elements;
    te[0] = x.x; te[4] = y.x; te[8] = z.x;
    te[1] = x.y; te[5] = y.y; te[9] = z.y;
    te[2] = x.z; te[6] = y.z; te[10] = z.z;
    return this;
  }
  invert() {
    const te = this.elements;
    const n11=te[0],n21=te[1],n31=te[2],n41=te[3],n12=te[4],n22=te[5],n32=te[6],n42=te[7],n13=te[8],n23=te[9],n33=te[10],n43=te[11],n14=te[12],n24=te[13],n34=te[14],n44=te[15];
    const t11 = n23*n34*n42 - n24*n33*n42 + n24*n32*n43 - n22*n34*n43 - n23*n32*n44 + n22*n33*n44;
    const t12 = n14*n33*n42 - n13*n34*n42 - n14*n32*n43 + n12*n34*n43 + n13*n32*n44 - n12*n33*n44;
    const t13 = n13*n24*n42 - n14*n23*n42 + n14*n22*n43 - n12*n24*n43 - n13*n22*n44 + n12*n23*n44;
    const t14 = n14*n23*n32 - n13*n24*n32 - n14*n22*n33 + n12*n24*n33 + n13*n22*n34 - n12*n23*n34;
    const det = n11*t11 + n21*t12 + n31*t13 + n41*t14;
    if (det === 0) return this.identity();
    const detInv = 1 / det;
    te[0] = t11*detInv;
    te[1] = (n24*n33*n41 - n23*n34*n41 - n24*n31*n43 + n21*n34*n43 + n23*n31*n44 - n21*n33*n44)*detInv;
    te[2] = (n22*n34*n41 - n24*n32*n41 + n24*n31*n42 - n21*n34*n42 - n22*n31*n44 + n21*n32*n44)*detInv;
    te[3] = (n23*n32*n41 - n22*n33*n41 - n23*n31*n42 + n21*n33*n42 + n22*n31*n43 - n21*n32*n43)*detInv;
    te[4] = t12*detInv;
    te[5] = (n13*n34*n41 - n14*n33*n41 + n14*n31*n43 - n11*n34*n43 - n13*n31*n44 + n11*n33*n44)*detInv;
    te[6] = (n14*n32*n41 - n12*n34*n41 - n14*n31*n42 + n11*n34*n42 + n12*n31*n44 - n11*n32*n44)*detInv;
    te[7] = (n12*n33*n41 - n13*n32*n41 + n13*n31*n42 - n11*n33*n42 - n12*n31*n43 + n11*n32*n43)*detInv;
    te[8] = t13*detInv;
    te[9] = (n14*n23*n41 - n13*n24*n41 - n14*n21*n43 + n11*n24*n43 + n13*n21*n44 - n11*n23*n44)*detInv;
    te[10] = (n12*n24*n41 - n14*n22*n41 + n14*n21*n42 - n11*n24*n42 - n12*n21*n44 + n11*n22*n44)*detInv;
    te[11] = (n13*n22*n41 - n12*n23*n41 - n13*n21*n42 + n11*n23*n42 + n12*n21*n43 - n11*n22*n43)*detInv;
    te[12] = t14*detInv;
    te[13] = (n13*n24*n31 - n14*n23*n31 + n14*n21*n33 - n11*n24*n33 - n13*n21*n34 + n11*n23*n34)*detInv;
    te[14] = (n14*n22*n31 - n12*n24*n31 - n14*n21*n32 + n11*n24*n32 + n12*n21*n34 - n11*n22*n34)*detInv;
    te[15] = (n12*n23*n31 - n13*n22*n31 + n13*n21*n32 - n11*n23*n32 - n12*n21*n33 + n11*n22*n33)*detInv;
    return this;
  }
  getInverse(m) { return this.copy(m).invert(); }
  makePerspective(left, right, top, bottom, near, far) {
    const te = this.elements;
    const x = 2 * near / (right - left);
    const y = 2 * near / (top - bottom);
    const a = (right + left) / (right - left);
    const b = (top + bottom) / (top - bottom);
    const c = -(far + near) / (far - near);
    const d = -2 * far * near / (far - near);
    te[0]=x; te[4]=0; te[8]=a;  te[12]=0;
    te[1]=0; te[5]=y; te[9]=b;  te[13]=0;
    te[2]=0; te[6]=0; te[10]=c; te[14]=d;
    te[3]=0; te[7]=0; te[11]=-1; te[15]=0;
    return this;
  }
  makeOrthographic(left, right, top, bottom, near, far) {
    const te = this.elements;
    const w = 1.0 / (right - left), h = 1.0 / (top - bottom), p = 1.0 / (far - near);
    const x = (right + left) * w, y = (top + bottom) * h, z = (far + near) * p;
    te[0]=2*w; te[4]=0;   te[8]=0;    te[12]=-x;
    te[1]=0;   te[5]=2*h; te[9]=0;    te[13]=-y;
    te[2]=0;   te[6]=0;   te[10]=-2*p;te[14]=-z;
    te[3]=0;   te[7]=0;   te[11]=0;   te[15]=1;
    return this;
  }
  equals(matrix) {
    const te = this.elements, me = matrix.elements;
    for (let i = 0; i < 16; i++) if (te[i] !== me[i]) return false;
    return true;
  }
  fromArray(array, offset = 0) {
    for (let i = 0; i < 16; i++) this.elements[i] = array[i + offset];
    return this;
  }
  toArray(array = [], offset = 0) {
    const te = this.elements;
    for (let i = 0; i < 16; i++) array[offset + i] = te[i];
    return array;
  }
}

class Box2 {
  constructor(min = new Vector2(Infinity, Infinity), max = new Vector2(-Infinity, -Infinity)) {
    this.isBox2 = true; this.min = min; this.max = max;
  }
  set(min, max) { this.min.copy(min); this.max.copy(max); return this; }
  makeEmpty() { this.min.x = this.min.y = Infinity; this.max.x = this.max.y = -Infinity; return this; }
  isEmpty() { return (this.max.x < this.min.x) || (this.max.y < this.min.y); }
  getCenter(target = new Vector2()) { return this.isEmpty() ? target.set(0, 0) : target.addVectors(this.min, this.max).multiplyScalar(0.5); }
  getSize(target = new Vector2()) { return this.isEmpty() ? target.set(0, 0) : target.subVectors(this.max, this.min); }
  expandByPoint(p) { this.min.min(p); this.max.max(p); return this; }
  containsPoint(p) { return p.x >= this.min.x && p.x <= this.max.x && p.y >= this.min.y && p.y <= this.max.y; }
  clone() { return new Box2().copy(this); }
  copy(b) { this.min.copy(b.min); this.max.copy(b.max); return this; }
}

class Box3 {
  constructor(min = new Vector3(Infinity, Infinity, Infinity), max = new Vector3(-Infinity, -Infinity, -Infinity)) {
    this.isBox3 = true; this.min = min; this.max = max;
  }
  set(min, max) { this.min.copy(min); this.max.copy(max); return this; }
  copy(b) { this.min.copy(b.min); this.max.copy(b.max); return this; }
  clone() { return new Box3(this.min.clone(), this.max.clone()); }
  makeEmpty() {
    this.min.set(Infinity, Infinity, Infinity);
    this.max.set(-Infinity, -Infinity, -Infinity);
    return this;
  }
  isEmpty() { return (this.max.x < this.min.x) || (this.max.y < this.min.y) || (this.max.z < this.min.z); }
  expandByPoint(p) {
    if (p.x < this.min.x) this.min.x = p.x;
    if (p.y < this.min.y) this.min.y = p.y;
    if (p.z < this.min.z) this.min.z = p.z;
    if (p.x > this.max.x) this.max.x = p.x;
    if (p.y > this.max.y) this.max.y = p.y;
    if (p.z > this.max.z) this.max.z = p.z;
    return this;
  }
  expandByVector(v) { this.min.sub(v); this.max.add(v); return this; }
  expandByScalar(s) { this.min.addScalar(-s); this.max.addScalar(s); return this; }
  setFromPoints(points) {
    this.makeEmpty();
    for (let i = 0; i < points.length; i++) this.expandByPoint(points[i]);
    return this;
  }
  setFromBufferAttribute(attr) {
    this.makeEmpty();
    const v = new Vector3();
    for (let i = 0; i < attr.count; i++) this.expandByPoint(v.fromBufferAttribute(attr, i));
    return this;
  }
  setFromCenterAndSize(center, size) {
    const half = new Vector3().copy(size).multiplyScalar(0.5);
    this.min.copy(center).sub(half);
    this.max.copy(center).add(half);
    return this;
  }
  setFromObject(obj) {
    this.makeEmpty();
    obj.updateMatrixWorld(true);
    const v = new Vector3();
    obj.traverse(node => {
      if (node.isMesh && node.geometry && node.geometry.attributes.position) {
        const pos = node.geometry.attributes.position;
        if (node.isInstancedMesh) {
          const im = new Matrix4(), wm = new Matrix4();
          for (let k = 0; k < Math.min(node.count, 64); k++) {
            node.getMatrixAt(k, im);
            wm.multiplyMatrices(node.matrixWorld, im);
            for (let i = 0; i < pos.count; i++) {
              v.set(pos.getX(i), pos.getY(i), pos.getZ(i)).applyMatrix4(wm);
              this.expandByPoint(v);
            }
          }
        } else {
          for (let i = 0; i < pos.count; i++) {
            v.set(pos.getX(i), pos.getY(i), pos.getZ(i)).applyMatrix4(node.matrixWorld);
            this.expandByPoint(v);
          }
        }
      }
    });
    if (this.min.x === Infinity) { this.min.set(-0.5, 0, -0.5); this.max.set(0.5, 1, 0.5); }
    return this;
  }
  containsPoint(p) {
    return p.x >= this.min.x && p.x <= this.max.x &&
           p.y >= this.min.y && p.y <= this.max.y &&
           p.z >= this.min.z && p.z <= this.max.z;
  }
  intersectsBox(box) {
    return !(box.max.x < this.min.x || box.min.x > this.max.x ||
             box.max.y < this.min.y || box.min.y > this.max.y ||
             box.max.z < this.min.z || box.min.z > this.max.z);
  }
  union(box) { this.min.min(box.min); this.max.max(box.max); return this; }
  translate(offset) { this.min.add(offset); this.max.add(offset); return this; }
  applyMatrix4(m) {
    if (this.isEmpty()) return this;
    const pts = [
      new Vector3(this.min.x, this.min.y, this.min.z).applyMatrix4(m),
      new Vector3(this.min.x, this.min.y, this.max.z).applyMatrix4(m),
      new Vector3(this.min.x, this.max.y, this.min.z).applyMatrix4(m),
      new Vector3(this.min.x, this.max.y, this.max.z).applyMatrix4(m),
      new Vector3(this.max.x, this.min.y, this.min.z).applyMatrix4(m),
      new Vector3(this.max.x, this.min.y, this.max.z).applyMatrix4(m),
      new Vector3(this.max.x, this.max.y, this.min.z).applyMatrix4(m),
      new Vector3(this.max.x, this.max.y, this.max.z).applyMatrix4(m)
    ];
    return this.setFromPoints(pts);
  }
  getSize(target = new Vector3()) {
    return this.isEmpty() ? target.set(0, 0, 0) : target.set(this.max.x - this.min.x, this.max.y - this.min.y, this.max.z - this.min.z);
  }
  getCenter(target = new Vector3()) {
    return this.isEmpty() ? target.set(0, 0, 0) : target.set((this.min.x + this.max.x) * 0.5, (this.min.y + this.max.y) * 0.5, (this.min.z + this.max.z) * 0.5);
  }
}

class Sphere {
  constructor(center = new Vector3(), radius = -1) {
    this.isSphere = true; this.center = center; this.radius = radius;
  }
  set(center, radius) { this.center.copy(center); this.radius = radius; return this; }
  copy(s) { this.center.copy(s.center); this.radius = s.radius; return this; }
  clone() { return new Sphere(this.center.clone(), this.radius); }
  containsPoint(p) { return p.distanceToSquared(this.center) <= (this.radius * this.radius); }
  intersectsSphere(s) { const r = this.radius + s.radius; return s.center.distanceToSquared(this.center) <= (r * r); }
  applyMatrix4(m) { this.center.applyMatrix4(m); this.radius *= m.getMaxScaleOnAxis(); return this; }
}

class Plane {
  constructor(normal = new Vector3(1, 0, 0), constant = 0) {
    this.isPlane = true; this.normal = normal; this.constant = constant;
  }
  set(normal, constant) { this.normal.copy(normal); this.constant = constant; return this; }
  setComponents(x, y, z, w) { this.normal.set(x, y, z); this.constant = w; return this; }
  setFromNormalAndCoplanarPoint(normal, point) {
    this.normal.copy(normal);
    this.constant = -point.dot(this.normal);
    return this;
  }
  normalize() {
    const invLen = 1.0 / (this.normal.length() || 1);
    this.normal.multiplyScalar(invLen);
    this.constant *= invLen;
    return this;
  }
  distanceToPoint(point) { return this.normal.dot(point) + this.constant; }
  projectPoint(point, target = new Vector3()) { return target.copy(point).addScaledVector(this.normal, -this.distanceToPoint(point)); }
  copy(p) { this.normal.copy(p.normal); this.constant = p.constant; return this; }
  clone() { return new Plane().copy(this); }
}

class Ray {
  constructor(origin = new Vector3(), direction = new Vector3(0, 0, -1)) {
    this.origin = origin; this.direction = direction;
  }
  set(origin, direction) { this.origin.copy(origin); this.direction.copy(direction); return this; }
  copy(r) { this.origin.copy(r.origin); this.direction.copy(r.direction); return this; }
  clone() { return new Ray().copy(this); }
  at(t, target = new Vector3()) { return target.copy(this.origin).addScaledVector(this.direction, t); }
  intersectPlane(plane, target = new Vector3()) {
    const denom = plane.normal.dot(this.direction);
    if (Math.abs(denom) < 1e-6) return null;
    const t = -(this.origin.dot(plane.normal) + plane.constant) / denom;
    return t >= 0 ? this.at(t, target) : null;
  }
  intersectSphere(sphere, target = new Vector3()) {
    const oc = new Vector3().subVectors(sphere.center, this.origin);
    const tca = oc.dot(this.direction);
    const d2 = oc.dot(oc) - tca * tca;
    const r2 = sphere.radius * sphere.radius;
    if (d2 > r2) return null;
    const thc = Math.sqrt(r2 - d2);
    const t0 = tca - thc, t1 = tca + thc;
    if (t1 < 0) return null;
    return this.at(t0 < 0 ? t1 : t0, target);
  }
  applyMatrix4(m) {
    this.origin.applyMatrix4(m);
    this.direction.transformDirection(m);
    return this;
  }
}

class Frustum {
  constructor(p0 = new Plane(), p1 = new Plane(), p2 = new Plane(), p3 = new Plane(), p4 = new Plane(), p5 = new Plane()) {
    this.planes = [p0, p1, p2, p3, p4, p5];
  }
  setFromProjectionMatrix(m) {
    const planes = this.planes, me = m.elements;
    const me0 = me[0], me1 = me[1], me2 = me[2], me3 = me[3];
    const me4 = me[4], me5 = me[5], me6 = me[6], me7 = me[7];
    const me8 = me[8], me9 = me[9], me10 = me[10], me11 = me[11];
    const me12 = me[12], me13 = me[13], me14 = me[14], me15 = me[15];
    planes[0].setComponents(me3 - me0, me7 - me4, me11 - me8, me15 - me12).normalize();
    planes[1].setComponents(me3 + me0, me7 + me4, me11 + me8, me15 + me12).normalize();
    planes[2].setComponents(me3 + me1, me7 + me5, me11 + me9, me15 + me13).normalize();
    planes[3].setComponents(me3 - me1, me7 - me5, me11 - me9, me15 - me13).normalize();
    planes[4].setComponents(me3 - me2, me7 - me6, me11 - me10, me15 - me14).normalize();
    planes[5].setComponents(me3 + me2, me7 + me6, me11 + me10, me15 + me14).normalize();
    return this;
  }
  intersectsSphere(sphere) {
    const planes = this.planes, center = sphere.center, negRadius = -sphere.radius;
    for (let i = 0; i < 6; i++) {
      if (planes[i].distanceToPoint(center) < negRadius) return false;
    }
    return true;
  }
  containsPoint(point) {
    const planes = this.planes;
    for (let i = 0; i < 6; i++) {
      if (planes[i].distanceToPoint(point) < 0) return false;
    }
    return true;
  }
}

class Spherical {
  constructor(radius = 1, phi = 0, theta = 0) { this.radius = radius; this.phi = phi; this.theta = theta; }
  set(radius, phi, theta) { this.radius = radius; this.phi = phi; this.theta = theta; return this; }
  copy(s) { this.radius = s.radius; this.phi = s.phi; this.theta = s.theta; return this; }
  clone() { return new Spherical().copy(this); }
  makeSafe() { const EPS = 0.000001; this.phi = Math.max(EPS, Math.min(Math.PI - EPS, this.phi)); return this; }
  setFromVector3(v) { return this.setFromCartesianCoords(v.x, v.y, v.z); }
  setFromCartesianCoords(x, y, z) {
    this.radius = Math.hypot(x, y, z);
    if (this.radius === 0) { this.theta = 0; this.phi = 0; }
    else { this.theta = Math.atan2(x, z); this.phi = Math.acos(MathUtils.clamp(y / this.radius, -1, 1)); }
    return this;
  }
}

class Cylindrical {
  constructor(radius = 1, theta = 0, y = 0) { this.radius = radius; this.theta = theta; this.y = y; }
  set(radius, theta, y) { this.radius = radius; this.theta = theta; this.y = y; return this; }
  copy(c) { this.radius = c.radius; this.theta = c.theta; this.y = c.y; return this; }
  clone() { return new Cylindrical().copy(this); }
  setFromVector3(v) { return this.setFromCartesianCoords(v.x, v.y, v.z); }
  setFromCartesianCoords(x, y, z) { this.radius = Math.hypot(x, z); this.theta = Math.atan2(x, z); this.y = y; return this; }
}

class Triangle {
  constructor(a = new Vector3(), b = new Vector3(), c = new Vector3()) { this.a = a; this.b = b; this.c = c; }
  set(a, b, c) { this.a.copy(a); this.b.copy(b); this.c.copy(c); return this; }
  getMidpoint(target = new Vector3()) { return target.addVectors(this.a, this.b).add(this.c).multiplyScalar(1 / 3); }
  getNormal(target = new Vector3()) {
    const v0 = new Vector3().subVectors(this.c, this.b);
    target.subVectors(this.a, this.b).cross(v0);
    const l = target.lengthSq();
    return l > 0 ? target.multiplyScalar(1 / Math.sqrt(l)) : target.set(0, 0, 0);
  }
  getArea() {
    const v0 = new Vector3().subVectors(this.c, this.b);
    const v1 = new Vector3().subVectors(this.a, this.b);
    return v0.cross(v1).length() * 0.5;
  }
}

class Fog {
  constructor(color, near = 1, far = 1000) {
    this.isFog = true;
    this.color = new Color(color);
    this.near = near;
    this.far = far;
    this.density = 1.5 / Math.max(10, far);
  }
  clone() { return new Fog(this.color, this.near, this.far); }
}

class FogExp2 {
  constructor(color, density = 0.00025) {
    this.isFogExp2 = true;
    this.color = new Color(color);
    this.density = density;
  }
  clone() { return new FogExp2(this.color, this.density); }
}

class Object3D {
  constructor() {
    this.isObject3D = true;
    this.uuid = MathUtils.generateUUID();
    this.name = '';
    this.type = 'Object3D';
    this.position = new Vector3();
    this.rotation = new Euler();
    this.quaternion = new Quaternion();
    this.scale = new Vector3(1, 1, 1);
    this.up = new Vector3(0, 1, 0);
    this.matrix = new Matrix4();
    this.matrixWorld = new Matrix4();
    this.normalMatrix = new Matrix3();
    this.matrixAutoUpdate = true;
    this.matrixWorldNeedsUpdate = false;
    this.children = [];
    this.parent = null;
    this.visible = true;
    this.castShadow = false;
    this.receiveShadow = false;
    this.frustumCulled = true;
    this.renderOrder = 0;
    this.userData = {};
    this._lastEuler = new Vector3(NaN, NaN, NaN);
    this._lastQuat = new Quaternion(NaN, NaN, NaN, NaN);
  }
  add(...objs) {
    for (const o of objs) {
      if (!o || o === this) continue;
      if (o.parent) o.parent.remove(o);
      o.parent = this;
      this.children.push(o);
    }
    return this;
  }
  remove(...objs) {
    for (const o of objs) {
      const idx = this.children.indexOf(o);
      if (idx !== -1) {
        o.parent = null;
        this.children.splice(idx, 1);
      }
    }
    return this;
  }
  clear() {
    for (let i = 0; i < this.children.length; i++) this.children[i].parent = null;
    this.children.length = 0;
    return this;
  }
  traverse(cb) {
    cb(this);
    const ch = this.children;
    for (let i = 0; i < ch.length; i++) ch[i].traverse(cb);
  }
  traverseVisible(cb) {
    if (!this.visible) return;
    cb(this);
    const ch = this.children;
    for (let i = 0; i < ch.length; i++) ch[i].traverseVisible(cb);
  }
  getObjectByName(name) { return this.getObjectByProperty('name', name); }
  getObjectByProperty(name, value) {
    if (this[name] === value) return this;
    for (let i = 0; i < this.children.length; i++) {
      const found = this.children[i].getObjectByProperty(name, value);
      if (found) return found;
    }
    return undefined;
  }
  getWorldPosition(target = new Vector3()) {
    this.updateMatrixWorld(true);
    return target.setFromMatrixPosition(this.matrixWorld);
  }
  getWorldQuaternion(target = new Quaternion()) {
    const pos = new Vector3(), sc = new Vector3();
    this.updateMatrixWorld(true);
    this.matrixWorld.decompose(pos, target, sc);
    return target;
  }
  getWorldScale(target = new Vector3()) {
    const pos = new Vector3(), q = new Quaternion();
    this.updateMatrixWorld(true);
    this.matrixWorld.decompose(pos, q, target);
    return target;
  }
  getWorldDirection(target = new Vector3()) {
    this.updateMatrixWorld(true);
    const e = this.matrixWorld.elements;
    return target.set(e[8], e[9], e[10]).normalize();
  }
  localToWorld(vector) {
    this.updateMatrixWorld(true);
    return vector.applyMatrix4(this.matrixWorld);
  }
  worldToLocal(vector) {
    this.updateMatrixWorld(true);
    return vector.applyMatrix4(new Matrix4().copy(this.matrixWorld).invert());
  }
  rotateOnAxis(axis, angle) {
    const q = new Quaternion().setFromAxisAngle(axis, angle);
    this.quaternion.multiply(q);
    this.rotation.setFromQuaternion(this.quaternion, this.rotation.order);
    this._lastEuler.set(this.rotation.x, this.rotation.y, this.rotation.z);
    this._lastQuat.copy(this.quaternion);
    return this;
  }
  rotateX(angle) { return this.rotateOnAxis(new Vector3(1, 0, 0), angle); }
  rotateY(angle) { return this.rotateOnAxis(new Vector3(0, 1, 0), angle); }
  rotateZ(angle) { return this.rotateOnAxis(new Vector3(0, 0, 1), angle); }
  translateOnAxis(axis, distance) {
    const v = new Vector3().copy(axis).applyQuaternion(this.quaternion);
    this.position.addScaledVector(v, distance);
    return this;
  }
  translateX(d) { return this.translateOnAxis(new Vector3(1, 0, 0), d); }
  translateY(d) { return this.translateOnAxis(new Vector3(0, 1, 0), d); }
  translateZ(d) { return this.translateOnAxis(new Vector3(0, 0, 1), d); }
  lookAt(x, y, z) {
    const target = (x && x.isVector3) ? x : new Vector3(x, y, z);
    const m = new Matrix4();
    if (this.isCamera || this.isLight) m.lookAt(this.position, target, this.up);
    else m.lookAt(target, this.position, this.up);
    this.quaternion.setFromRotationMatrix(m);
    this.rotation.setFromQuaternion(this.quaternion, this.rotation.order);
    this._lastEuler.set(this.rotation.x, this.rotation.y, this.rotation.z);
    this._lastQuat.copy(this.quaternion);
  }
  applyMatrix4(matrix) {
    if (this.matrixAutoUpdate) this.updateMatrix();
    this.matrix.premultiply(matrix);
    this.matrix.decompose(this.position, this.quaternion, this.scale);
    this.rotation.setFromQuaternion(this.quaternion, this.rotation.order);
    this._lastEuler.set(this.rotation.x, this.rotation.y, this.rotation.z);
    this._lastQuat.copy(this.quaternion);
  }
  updateMatrix() {
    const r = this.rotation, q = this.quaternion;
    const eChanged = (r.x !== this._lastEuler.x || r.y !== this._lastEuler.y || r.z !== this._lastEuler.z);
    const qChanged = (q.x !== this._lastQuat.x || q.y !== this._lastQuat.y || q.z !== this._lastQuat.z || q.w !== this._lastQuat.w);
    if (eChanged && !qChanged) {
      q.setFromEuler(r);
      this._lastEuler.set(r.x, r.y, r.z);
      this._lastQuat.copy(q);
    } else if (qChanged && !eChanged) {
      r.setFromQuaternion(q, r.order);
      this._lastEuler.set(r.x, r.y, r.z);
      this._lastQuat.copy(q);
    } else if (eChanged && qChanged) {
      q.setFromEuler(r);
      this._lastEuler.set(r.x, r.y, r.z);
      this._lastQuat.copy(q);
    }
    this.matrix.compose(this.position, this.quaternion, this.scale);
  }
  updateMatrixWorld(force) {
    if (this.matrixAutoUpdate) this.updateMatrix();
    if (this.parent === null) {
      this.matrixWorld.copy(this.matrix);
    } else {
      this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix);
    }
    const ch = this.children;
    for (let i = 0; i < ch.length; i++) ch[i].updateMatrixWorld(force);
  }
  updateWorldMatrix(updateParents, updateChildren) {
    if (updateParents && this.parent) this.parent.updateWorldMatrix(true, false);
    if (this.matrixAutoUpdate) this.updateMatrix();
    if (this.parent === null) this.matrixWorld.copy(this.matrix);
    else this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix);
    if (updateChildren) {
      for (let i = 0; i < this.children.length; i++) this.children[i].updateWorldMatrix(false, true);
    }
  }
  clone(recursive = true) { return new this.constructor().copy(this, recursive); }
  copy(source, recursive = true) {
    this.name = source.name;
    this.up.copy(source.up);
    this.position.copy(source.position);
    this.rotation.copy(source.rotation);
    this.quaternion.copy(source.quaternion);
    this.scale.copy(source.scale);
    this.matrix.copy(source.matrix);
    this.matrixWorld.copy(source.matrixWorld);
    this.matrixAutoUpdate = source.matrixAutoUpdate;
    this.visible = source.visible;
    this.castShadow = source.castShadow;
    this.receiveShadow = source.receiveShadow;
    this.frustumCulled = source.frustumCulled;
    this.renderOrder = source.renderOrder;
    this.userData = JSON.parse(JSON.stringify(source.userData || {}));
    if (recursive) {
      for (let i = 0; i < source.children.length; i++) this.add(source.children[i].clone());
    }
    return this;
  }
}

class Scene extends Object3D {
  constructor() {
    super();
    this.isScene = true;
    this.type = 'Scene';
    this.background = null;
    this.environment = null;
    this.environmentIntensity = 1.0;
    this.fog = null;
  }
}

class Group extends Object3D {
  constructor() { super(); this.isGroup = true; this.type = 'Group'; }
}

class Camera extends Object3D {
  constructor() {
    super();
    this.isCamera = true;
    this.type = 'Camera';
    this.matrixWorldInverse = new Matrix4();
    this.projectionMatrix = new Matrix4();
    this.projectionMatrixInverse = new Matrix4();
  }
  updateMatrixWorld(force) {
    super.updateMatrixWorld(force);
    this.matrixWorldInverse.copy(this.matrixWorld).invert();
  }
  updateWorldMatrix(updateParents, updateChildren) {
    super.updateWorldMatrix(updateParents, updateChildren);
    this.matrixWorldInverse.copy(this.matrixWorld).invert();
  }
}

class PerspectiveCamera extends Camera {
  constructor(fov = 50, aspect = 1, near = 0.1, far = 2000) {
    super();
    this.isPerspectiveCamera = true;
    this.type = 'PerspectiveCamera';
    this.fov = fov; this.zoom = 1; this.aspect = aspect; this.near = near; this.far = far;
    this.updateProjectionMatrix();
  }
  updateProjectionMatrix() {
    const near = this.near;
    const top = near * Math.tan(MathUtils.degToRad(0.5 * this.fov)) / (this.zoom || 1);
    const height = 2 * top;
    const width = this.aspect * height;
    const left = -0.5 * width;
    this.projectionMatrix.makePerspective(left, left + width, top, top - height, near, this.far);
    this.projectionMatrixInverse.copy(this.projectionMatrix).invert();
  }
}

class OrthographicCamera extends Camera {
  constructor(left = -1, right = 1, top = 1, bottom = -1, near = 0.1, far = 2000) {
    super();
    this.isOrthographicCamera = true;
    this.type = 'OrthographicCamera';
    this.zoom = 1;
    this.left = left; this.right = right; this.top = top; this.bottom = bottom;
    this.near = near; this.far = far;
    this.updateProjectionMatrix();
  }
  updateProjectionMatrix() {
    const dx = (this.right - this.left) / (2 * (this.zoom || 1));
    const dy = (this.top - this.bottom) / (2 * (this.zoom || 1));
    const cx = (this.right + this.left) / 2;
    const cy = (this.top + this.bottom) / 2;
    this.projectionMatrix.makeOrthographic(cx - dx, cx + dx, cy + dy, cy - dy, this.near, this.far);
    this.projectionMatrixInverse.copy(this.projectionMatrix).invert();
  }
}

class BufferAttribute {
  constructor(array, itemSize, normalized = false) {
    this.isBufferAttribute = true;
    this.array = array;
    this.itemSize = itemSize;
    this.count = array !== undefined ? (array.length / itemSize) : 0;
    this.normalized = normalized;
    this.usage = StaticDrawUsage;
    this.needsUpdate = true;
    this.version = 0;
    this._glBuffer = null;
  }
  onUpload(callback) { this.onUploadCallback = callback; return this; }
  setUsage(value) { this.usage = value; return this; }
  copy(source) {
    this.array = new source.array.constructor(source.array);
    this.itemSize = source.itemSize;
    this.count = source.count;
    this.normalized = source.normalized;
    this.usage = source.usage;
    this.needsUpdate = true;
    return this;
  }
  copyAt(index1, attribute, index2) {
    index1 *= this.itemSize;
    index2 *= attribute.itemSize;
    for (let i = 0; i < this.itemSize; i++) this.array[index1 + i] = attribute.array[index2 + i];
    return this;
  }
  copyArray(array) { this.array.set(array); return this; }
  set(value, offset = 0) { this.array.set(value, offset); return this; }
  getX(i) { return this.array[i * this.itemSize]; }
  getY(i) { return this.array[i * this.itemSize + 1]; }
  getZ(i) { return this.array[i * this.itemSize + 2]; }
  getW(i) { return this.array[i * this.itemSize + 3]; }
  setX(i, x) { this.array[i * this.itemSize] = x; return this; }
  setY(i, y) { this.array[i * this.itemSize + 1] = y; return this; }
  setZ(i, z) { this.array[i * this.itemSize + 2] = z; return this; }
  setW(i, w) { this.array[i * this.itemSize + 3] = w; return this; }
  setXY(i, x, y) { const o = i * this.itemSize; this.array[o] = x; this.array[o + 1] = y; return this; }
  setXYZ(i, x, y, z) { const o = i * this.itemSize; this.array[o] = x; this.array[o + 1] = y; this.array[o + 2] = z; return this; }
  setXYZW(i, x, y, z, w) { const o = i * this.itemSize; this.array[o] = x; this.array[o + 1] = y; this.array[o + 2] = z; this.array[o + 3] = w; return this; }
  applyMatrix3(m) {
    const v = new Vector3();
    for (let i = 0; i < this.count; i++) {
      v.fromBufferAttribute(this, i).applyMatrix3(m);
      this.setXYZ(i, v.x, v.y, v.z);
    }
    this.needsUpdate = true;
    return this;
  }
  applyMatrix4(m) {
    const v = new Vector3();
    for (let i = 0; i < this.count; i++) {
      v.fromBufferAttribute(this, i).applyMatrix4(m);
      this.setXYZ(i, v.x, v.y, v.z);
    }
    this.needsUpdate = true;
    return this;
  }
  applyNormalMatrix(m) {
    const v = new Vector3();
    for (let i = 0; i < this.count; i++) {
      v.fromBufferAttribute(this, i).applyNormalMatrix(m);
      this.setXYZ(i, v.x, v.y, v.z);
    }
    this.needsUpdate = true;
    return this;
  }
  transformDirection(m) {
    const v = new Vector3();
    for (let i = 0; i < this.count; i++) {
      v.fromBufferAttribute(this, i).transformDirection(m);
      this.setXYZ(i, v.x, v.y, v.z);
    }
    this.needsUpdate = true;
    return this;
  }
  clone() { return new this.constructor(new this.array.constructor(this.array), this.itemSize, this.normalized); }
}

class Int8BufferAttribute extends BufferAttribute {
  constructor(array, itemSize, normalized) { super(array instanceof Int8Array ? array : new Int8Array(array), itemSize, normalized); }
}
class Uint8BufferAttribute extends BufferAttribute {
  constructor(array, itemSize, normalized) { super(array instanceof Uint8Array ? array : new Uint8Array(array), itemSize, normalized); }
}
class Uint8ClampedBufferAttribute extends BufferAttribute {
  constructor(array, itemSize, normalized) { super(array instanceof Uint8ClampedArray ? array : new Uint8ClampedArray(array), itemSize, normalized); }
}
class Int16BufferAttribute extends BufferAttribute {
  constructor(array, itemSize, normalized) { super(array instanceof Int16Array ? array : new Int16Array(array), itemSize, normalized); }
}
class Uint16BufferAttribute extends BufferAttribute {
  constructor(array, itemSize, normalized) { super(array instanceof Uint16Array ? array : new Uint16Array(array), itemSize, normalized); }
}
class Int32BufferAttribute extends BufferAttribute {
  constructor(array, itemSize, normalized) { super(array instanceof Int32Array ? array : new Int32Array(array), itemSize, normalized); }
}
class Uint32BufferAttribute extends BufferAttribute {
  constructor(array, itemSize, normalized) { super(array instanceof Uint32Array ? array : new Uint32Array(array), itemSize, normalized); }
}
class Float32BufferAttribute extends BufferAttribute {
  constructor(array, itemSize, normalized) { super(array instanceof Float32Array ? array : new Float32Array(array), itemSize, normalized); }
}
class Float64BufferAttribute extends BufferAttribute {
  constructor(array, itemSize, normalized) { super(array instanceof Float64Array ? array : new Float64Array(array), itemSize, normalized); }
}
class InstancedBufferAttribute extends BufferAttribute {
  constructor(array, itemSize, normalized = false, meshPerAttribute = 1) {
    super(array, itemSize, normalized);
    this.isInstancedBufferAttribute = true;
    this.meshPerAttribute = meshPerAttribute;
  }
}

class BufferGeometry {
  constructor() {
    this.attributes = {};
    this.index = null;
    this.boundingSphere = null;
  }
  setAttribute(name, attr) { this.attributes[name] = attr; return this; }
  getAttribute(name) { return this.attributes[name]; }
  deleteAttribute(name) { delete this.attributes[name]; return this; }
  setIndex(idx) {
    if (!idx) { this.index = null; return this; }
    if (idx instanceof BufferAttribute) this.index = idx;
    else this.index = new BufferAttribute(idx instanceof Uint32Array || idx instanceof Uint16Array ? idx : new Uint32Array(idx), 1);
    return this;
  }
  clone() {
    const g = new BufferGeometry();
    for (const k of Object.keys(this.attributes)) {
      g.attributes[k] = this.attributes[k].clone();
    }
    if (this.index) g.index = this.index.clone();
    return g;
  }
  dispose() {
    for (const k of Object.keys(this.attributes)) {
      const a = this.attributes[k];
      if (a && a._glBuffer && a._gl) { a._gl.deleteBuffer(a._glBuffer); a._glBuffer = null; }
    }
    if (this.index && this.index._glBuffer && this.index._gl) {
      this.index._gl.deleteBuffer(this.index._glBuffer);
      this.index._glBuffer = null;
    }
  }
  translate(dx, dy, dz) {
    const p = this.attributes.position;
    if (p) {
      const a = p.array;
      for (let i = 0; i < a.length; i += 3) { a[i] += dx; a[i+1] += dy; a[i+2] += dz; }
      p.needsUpdate = true;
    }
    return this;
  }
  scale(sx, sy, sz) {
    const p = this.attributes.position;
    if (p) {
      const a = p.array;
      for (let i = 0; i < a.length; i += 3) { a[i] *= sx; a[i+1] *= sy; a[i+2] *= sz; }
      p.needsUpdate = true;
    }
    const n = this.attributes.normal;
    if (n) {
      const a = n.array;
      for (let i = 0; i < a.length; i += 3) {
        let nx = a[i] / sx, ny = a[i+1] / sy, nz = a[i+2] / sz;
        const l = Math.hypot(nx, ny, nz) || 1;
        a[i] = nx / l; a[i+1] = ny / l; a[i+2] = nz / l;
      }
      n.needsUpdate = true;
    }
    return this;
  }
  rotateX(angle) {
    const m = new Matrix4();
    const c = Math.cos(angle), s = Math.sin(angle);
    m.set(1,0,0,0, 0,c,-s,0, 0,s,c,0, 0,0,0,1);
    return this.applyMatrix4(m);
  }
  rotateY(angle) {
    const m = new Matrix4();
    const c = Math.cos(angle), s = Math.sin(angle);
    m.set(c,0,s,0, 0,1,0,0, -s,0,c,0, 0,0,0,1);
    return this.applyMatrix4(m);
  }
  rotateZ(angle) {
    const m = new Matrix4();
    const c = Math.cos(angle), s = Math.sin(angle);
    m.set(c,-s,0,0, s,c,0,0, 0,0,1,0, 0,0,0,1);
    return this.applyMatrix4(m);
  }
  applyMatrix4(m) {
    const e = m.elements;
    const m0=e[0],m1=e[1],m2=e[2],m4=e[4],m5=e[5],m6=e[6],m8=e[8],m9=e[9],m10=e[10],m12=e[12],m13=e[13],m14=e[14];
    const p = this.attributes.position;
    if (p) {
      const a = p.array;
      for (let i = 0; i < a.length; i += 3) {
        const x = a[i], y = a[i+1], z = a[i+2];
        a[i]   = m0 * x + m4 * y + m8 * z + m12;
        a[i+1] = m1 * x + m5 * y + m9 * z + m13;
        a[i+2] = m2 * x + m6 * y + m10 * z + m14;
      }
      p.needsUpdate = true;
    }
    const n = this.attributes.normal;
    if (n) {
      const a = n.array;
      for (let i = 0; i < a.length; i += 3) {
        const x = a[i], y = a[i+1], z = a[i+2];
        const nx = m0 * x + m4 * y + m8 * z;
        const ny = m1 * x + m5 * y + m9 * z;
        const nz = m2 * x + m6 * y + m10 * z;
        const l = Math.hypot(nx, ny, nz) || 1;
        a[i] = nx / l; a[i+1] = ny / l; a[i+2] = nz / l;
      }
      n.needsUpdate = true;
    }
    return this;
  }
  weldVertices(tolerance = 0.001) {
    const pos = this.attributes.position;
    if (!pos || pos.count === 0) return this;
    const invTol = 1.0 / Math.max(1e-6, tolerance);
    const hasNorm = !!this.attributes.normal;
    const hasUv = !!this.attributes.uv;
    const hasCol = !!this.attributes.color;
    const pArr = pos.array;
    const nArr = hasNorm ? this.attributes.normal.array : null;
    const uArr = hasUv ? this.attributes.uv.array : null;
    const cArr = hasCol ? this.attributes.color.array : null;

    const map = new Map();
    const newP = [], newN = [], newU = [], newC = [];
    const remap = new Uint32Array(pos.count);
    let uniqueCount = 0;

    for (let i = 0; i < pos.count; i++) {
      const px = pArr[i * 3], py = pArr[i * 3 + 1], pz = pArr[i * 3 + 2];
      const kx = Math.round(px * invTol), ky = Math.round(py * invTol), kz = Math.round(pz * invTol);
      const nx = nArr ? Math.round(nArr[i * 3] * 10) : 0;
      const ny = nArr ? Math.round(nArr[i * 3 + 1] * 10) : 0;
      const nz = nArr ? Math.round(nArr[i * 3 + 2] * 10) : 0;
      const key = `${kx},${ky},${kz}|${nx},${ny},${nz}`;
      let idx = map.get(key);
      if (idx === undefined) {
        idx = uniqueCount++;
        map.set(key, idx);
        newP.push(px, py, pz);
        if (nArr) newN.push(nArr[i * 3], nArr[i * 3 + 1], nArr[i * 3 + 2]);
        if (uArr) newU.push(uArr[i * 2], uArr[i * 2 + 1]);
        if (cArr) newC.push(cArr[i * 3], cArr[i * 3 + 1], cArr[i * 3 + 2]);
      }
      remap[i] = idx;
    }

    const oldIdx = this.index ? this.index.array : null;
    const triCount = oldIdx ? oldIdx.length : pos.count;
    const newIndices = [];
    for (let i = 0; i < triCount; i += 3) {
      const a = remap[oldIdx ? oldIdx[i] : i];
      const b = remap[oldIdx ? oldIdx[i + 1] : i + 1];
      const c = remap[oldIdx ? oldIdx[i + 2] : i + 2];
      if (a !== b && b !== c && a !== c) {
        newIndices.push(a, b, c);
      }
    }

    this.setAttribute('position', new Float32BufferAttribute(newP, 3));
    if (nArr) this.setAttribute('normal', new Float32BufferAttribute(newN, 3));
    if (uArr) this.setAttribute('uv', new Float32BufferAttribute(newU, 2));
    if (cArr) this.setAttribute('color', new Float32BufferAttribute(newC, 3));
    this.setIndex(uniqueCount < 65535 ? new Uint16BufferAttribute(newIndices, 1) : new Uint32BufferAttribute(newIndices, 1));
    this.computeBoundingSphere();
    return this;
  }
  toNonIndexed() {
    if (!this.index) return this.clone();
    const g = new BufferGeometry();
    const idx = this.index.array;
    const n = idx.length;
    for (const k of Object.keys(this.attributes)) {
      const src = this.attributes[k];
      const itemSize = src.itemSize;
      const sArr = src.array;
      const dst = new Float32Array(n * itemSize);
      for (let i = 0; i < n; i++) {
        const si = idx[i] * itemSize;
        const di = i * itemSize;
        for (let c = 0; c < itemSize; c++) dst[di + c] = sArr[si + c];
      }
      g.setAttribute(k, new Float32BufferAttribute(dst, itemSize));
    }
    return g;
  }
  computeVertexNormals() {
    const pos = this.attributes.position; if (!pos) return;
    const pArr = pos.array;
    const norm = new Float32Array(pos.count * 3);
    const idx = this.index ? this.index.array : null;
    const nTri = idx ? idx.length : pos.count;
    for (let i = 0; i < nTri; i += 3) {
      const i0 = (idx ? idx[i] : i) * 3;
      const i1 = (idx ? idx[i+1] : i+1) * 3;
      const i2 = (idx ? idx[i+2] : i+2) * 3;
      const ax = pArr[i0], ay = pArr[i0+1], az = pArr[i0+2];
      const bx = pArr[i1] - ax, by = pArr[i1+1] - ay, bz = pArr[i1+2] - az;
      const cx = pArr[i2] - ax, cy = pArr[i2+1] - ay, cz = pArr[i2+2] - az;
      const nx = by * cz - bz * cy, ny = bz * cx - bx * cz, nz = bx * cy - by * cx;
      norm[i0]+=nx; norm[i0+1]+=ny; norm[i0+2]+=nz;
      norm[i1]+=nx; norm[i1+1]+=ny; norm[i1+2]+=nz;
      norm[i2]+=nx; norm[i2+1]+=ny; norm[i2+2]+=nz;
    }
    for (let i = 0; i < norm.length; i += 3) {
      const x = norm[i], y = norm[i+1], z = norm[i+2], l = Math.hypot(x, y, z) || 1;
      norm[i] = x/l; norm[i+1] = y/l; norm[i+2] = z/l;
    }
    this.setAttribute('normal', new Float32BufferAttribute(norm, 3));
  }
  computeBoundingSphere() {
    const pos = this.attributes.position;
    if (!pos || pos.count === 0) {
      this.boundingSphere = new Sphere(new Vector3(), 0);
      return;
    }
    const a = pos.array;
    let minX=Infinity,minY=Infinity,minZ=Infinity,maxX=-Infinity,maxY=-Infinity,maxZ=-Infinity;
    for (let i = 0; i < a.length; i += 3) {
      const x = a[i], y = a[i+1], z = a[i+2];
      if (x < minX) minX = x; if (x > maxX) maxX = x;
      if (y < minY) minY = y; if (y > maxY) maxY = y;
      if (z < minZ) minZ = z; if (z > maxZ) maxZ = z;
    }
    const cx = (minX + maxX) * 0.5, cy = (minY + maxY) * 0.5, cz = (minZ + maxZ) * 0.5;
    let maxR2 = 0;
    for (let i = 0; i < a.length; i += 3) {
      const dx = a[i] - cx, dy = a[i+1] - cy, dz = a[i+2] - cz;
      const r2 = dx*dx + dy*dy + dz*dz;
      if (r2 > maxR2) maxR2 = r2;
    }
    this.boundingSphere = new Sphere(new Vector3(cx, cy, cz), Math.sqrt(maxR2));
  }
}

class PlaneGeometry extends BufferGeometry {
  constructor(width = 1, height = 1, widthSegments = 1, heightSegments = 1) {
    super();
    const ix = Math.max(1, Math.floor(widthSegments)), iy = Math.max(1, Math.floor(heightSegments));
    const gridX1 = ix + 1, gridY1 = iy + 1;
    const pos = new Float32Array(gridX1 * gridY1 * 3);
    const norm = new Float32Array(gridX1 * gridY1 * 3);
    const uv = new Float32Array(gridX1 * gridY1 * 2);
    let v = 0, u = 0;
    for (let iy0 = 0; iy0 < gridY1; iy0++) {
      const y = iy0 * (height / iy) - height / 2;
      for (let ix0 = 0; ix0 < gridX1; ix0++) {
        const x = ix0 * (width / ix) - width / 2;
        pos[v] = x; pos[v+1] = -y; pos[v+2] = 0;
        norm[v] = 0; norm[v+1] = 0; norm[v+2] = 1;
        uv[u] = ix0 / ix; uv[u+1] = 1 - (iy0 / iy);
        v += 3; u += 2;
      }
    }
    const indices = new Uint32Array(ix * iy * 6);
    let ptr = 0;
    for (let iy0 = 0; iy0 < iy; iy0++) {
      for (let ix0 = 0; ix0 < ix; ix0++) {
        const a = ix0 + gridX1 * iy0, b = ix0 + gridX1 * (iy0 + 1), c = (ix0 + 1) + gridX1 * (iy0 + 1), d = (ix0 + 1) + gridX1 * iy0;
        indices[ptr++] = a; indices[ptr++] = b; indices[ptr++] = d;
        indices[ptr++] = b; indices[ptr++] = c; indices[ptr++] = d;
      }
    }
    this.setAttribute('position', new Float32BufferAttribute(pos, 3));
    this.setAttribute('normal', new Float32BufferAttribute(norm, 3));
    this.setAttribute('uv', new Float32BufferAttribute(uv, 2));
    this.setIndex(indices);
  }
}

class BoxGeometry extends BufferGeometry {
  constructor(width = 1, height = 1, depth = 1) {
    super();
    const hw = width / 2, hh = height / 2, hd = depth / 2;
    // 6 faces, 4 vertices each = 24 vertices, 36 indices
    const faces = [
      // +X
      { n: [1,0,0], v: [[hw,-hh,hd],[hw,-hh,-hd],[hw,hh,hd],[hw,hh,-hd]], u: [[0,0],[1,0],[0,1],[1,1]] },
      // -X
      { n: [-1,0,0], v: [[-hw,-hh,-hd],[-hw,-hh,hd],[-hw,hh,-hd],[-hw,hh,hd]], u: [[0,0],[1,0],[0,1],[1,1]] },
      // +Y
      { n: [0,1,0], v: [[-hw,hh,hd],[hw,hh,hd],[-hw,hh,-hd],[hw,hh,-hd]], u: [[0,0],[1,0],[0,1],[1,1]] },
      // -Y
      { n: [0,-1,0], v: [[-hw,-hh,-hd],[hw,-hh,-hd],[-hw,-hh,hd],[hw,-hh,hd]], u: [[0,0],[1,0],[0,1],[1,1]] },
      // +Z
      { n: [0,0,1], v: [[-hw,-hh,hd],[hw,-hh,hd],[-hw,hh,hd],[hw,hh,hd]], u: [[0,0],[1,0],[0,1],[1,1]] },
      // -Z
      { n: [0,0,-1], v: [[hw,-hh,-hd],[-hw,-hh,-hd],[hw,hh,-hd],[-hw,hh,-hd]], u: [[0,0],[1,0],[0,1],[1,1]] }
    ];
    const pos = new Float32Array(72), norm = new Float32Array(72), uv = new Float32Array(48);
    const idx = new Uint32Array(36);
    let vp = 0, up = 0, ip = 0, base = 0;
    for (const f of faces) {
      for (let i = 0; i < 4; i++) {
        pos[vp] = f.v[i][0]; pos[vp+1] = f.v[i][1]; pos[vp+2] = f.v[i][2];
        norm[vp] = f.n[0]; norm[vp+1] = f.n[1]; norm[vp+2] = f.n[2];
        uv[up] = f.u[i][0]; uv[up+1] = f.u[i][1];
        vp += 3; up += 2;
      }
      idx[ip++] = base; idx[ip++] = base+1; idx[ip++] = base+2;
      idx[ip++] = base+2; idx[ip++] = base+1; idx[ip++] = base+3;
      base += 4;
    }
    this.setAttribute('position', new Float32BufferAttribute(pos, 3));
    this.setAttribute('normal', new Float32BufferAttribute(norm, 3));
    this.setAttribute('uv', new Float32BufferAttribute(uv, 2));
    this.setIndex(idx);
  }
}

class CylinderGeometry extends BufferGeometry {
  constructor(radiusTop = 1, radiusBottom = 1, height = 1, radialSegments = 12, heightSegments = 1, openEnded = false) {
    super();
    const rs = Math.max(3, Math.floor(radialSegments));
    const hs = Math.max(1, Math.floor(heightSegments));
    const pos = [], norm = [], uv = [], indices = [];
    let index = 0;
    const indexArray = [];
    const halfHeight = height / 2;
    const slope = (radiusBottom - radiusTop) / height;

    for (let y = 0; y <= hs; y++) {
      const indexRow = [];
      const v = y / hs;
      const radius = v * (radiusBottom - radiusTop) + radiusTop;
      for (let x = 0; x <= rs; x++) {
        const u = x / rs;
        const theta = u * Math.PI * 2;
        const sinTheta = Math.sin(theta), cosTheta = Math.cos(theta);
        pos.push(radius * sinTheta, -v * height + halfHeight, radius * cosTheta);
        const nl = Math.hypot(sinTheta, slope, cosTheta) || 1;
        norm.push(sinTheta / nl, slope / nl, cosTheta / nl);
        uv.push(u, 1 - v);
        indexRow.push(index++);
      }
      indexArray.push(indexRow);
    }
    for (let x = 0; x < rs; x++) {
      for (let y = 0; y < hs; y++) {
        const a = indexArray[y][x], b = indexArray[y+1][x], c = indexArray[y+1][x+1], d = indexArray[y][x+1];
        indices.push(a, b, d, b, c, d);
      }
    }
    const generateCap = (top) => {
      const r = top ? radiusTop : radiusBottom;
      if (r <= 0) return;
      const sign = top ? 1 : -1;
      const centerIdx = index++;
      pos.push(0, halfHeight * sign, 0);
      norm.push(0, sign, 0);
      uv.push(0.5, 0.5);
      const start = index;
      for (let x = 0; x <= rs; x++) {
        const u = x / rs;
        const theta = u * Math.PI * 2;
        const cosTheta = Math.cos(theta), sinTheta = Math.sin(theta);
        pos.push(r * sinTheta, halfHeight * sign, r * cosTheta);
        norm.push(0, sign, 0);
        uv.push(cosTheta * 0.5 + 0.5, sinTheta * 0.5 * sign + 0.5);
        index++;
      }
      for (let x = 0; x < rs; x++) {
        const i = start + x;
        if (top) indices.push(i, i + 1, centerIdx);
        else indices.push(i + 1, i, centerIdx);
      }
    };
    if (!openEnded) {
      if (radiusTop > 0) generateCap(true);
      if (radiusBottom > 0) generateCap(false);
    }
    this.setAttribute('position', new Float32BufferAttribute(pos, 3));
    this.setAttribute('normal', new Float32BufferAttribute(norm, 3));
    this.setAttribute('uv', new Float32BufferAttribute(uv, 2));
    this.setIndex(indices);
  }
}

class ConeGeometry extends CylinderGeometry {
  constructor(radius = 1, height = 1, radialSegments = 12, heightSegments = 1, openEnded = false) {
    super(0, radius, height, radialSegments, heightSegments, openEnded);
  }
}

class CircleGeometry extends BufferGeometry {
  constructor(radius = 1, segments = 16) {
    super();
    const s = Math.max(3, Math.floor(segments));
    const pos = [0, 0, 0], norm = [0, 0, 1], uv = [0.5, 0.5], indices = [];
    for (let i = 0; i <= s; i++) {
      const a = (i / s) * Math.PI * 2;
      const x = Math.cos(a), y = Math.sin(a);
      pos.push(radius * x, radius * y, 0);
      norm.push(0, 0, 1);
      uv.push(x * 0.5 + 0.5, y * 0.5 + 0.5);
    }
    for (let i = 1; i <= s; i++) indices.push(i, i + 1, 0);
    this.setAttribute('position', new Float32BufferAttribute(pos, 3));
    this.setAttribute('normal', new Float32BufferAttribute(norm, 3));
    this.setAttribute('uv', new Float32BufferAttribute(uv, 2));
    this.setIndex(indices);
  }
}

class SphereGeometry extends BufferGeometry {
  constructor(radius = 1, widthSegments = 16, heightSegments = 12, phiStart = 0, phiLength = Math.PI * 2, thetaStart = 0, thetaLength = Math.PI) {
    super();
    const ws = Math.max(3, Math.floor(widthSegments));
    const hs = Math.max(2, Math.floor(heightSegments));
    const pos = [], norm = [], uv = [], indices = [];
    for (let iy = 0; iy <= hs; iy++) {
      const v = iy / hs;
      const theta = thetaStart + v * thetaLength;
      for (let ix = 0; ix <= ws; ix++) {
        const u = ix / ws;
        const phi = phiStart + u * phiLength;
        const x = -radius * Math.cos(phi) * Math.sin(theta);
        const y = radius * Math.cos(theta);
        const z = radius * Math.sin(phi) * Math.sin(theta);
        pos.push(x, y, z);
        const l = Math.hypot(x, y, z) || 1;
        norm.push(x/l, y/l, z/l);
        uv.push(u, 1 - v);
      }
    }
    for (let iy = 0; iy < hs; iy++) {
      for (let ix = 0; ix < ws; ix++) {
        const a = iy * (ws + 1) + (ix + 1);
        const b = iy * (ws + 1) + ix;
        const c = (iy + 1) * (ws + 1) + ix;
        const d = (iy + 1) * (ws + 1) + (ix + 1);
        if (iy !== 0 || thetaStart > 0) indices.push(a, b, d);
        if (iy !== hs - 1 || thetaStart + thetaLength < Math.PI) indices.push(b, c, d);
      }
    }
    this.setAttribute('position', new Float32BufferAttribute(pos, 3));
    this.setAttribute('normal', new Float32BufferAttribute(norm, 3));
    this.setAttribute('uv', new Float32BufferAttribute(uv, 2));
    this.setIndex(indices);
  }
}

class IcosahedronGeometry extends SphereGeometry {
  constructor(radius = 1, detail = 0) {
    // 20 * 4^1 = 80 triangles (widthSegments=8, heightSegments=6 -> 8*10 = 80 tris, 63 verts)
    const ws = detail <= 0 ? 5 : (detail === 1 ? 8 : 12);
    const hs = detail <= 0 ? 3 : (detail === 1 ? 6 : 8);
    super(radius, ws, hs);
  }
}

class TorusGeometry extends BufferGeometry {
  constructor(radius = 1, tube = 0.4, radialSegments = 8, tubularSegments = 16, arc = Math.PI * 2) {
    super();
    const rs = Math.max(3, Math.floor(radialSegments));
    const ts = Math.max(3, Math.floor(tubularSegments));
    const pos = [], norm = [], uv = [], indices = [];
    for (let j = 0; j <= rs; j++) {
      for (let i = 0; i <= ts; i++) {
        const u = (i / ts) * arc;
        const v = (j / rs) * Math.PI * 2;
        const x = (radius + tube * Math.cos(v)) * Math.cos(u);
        const y = (radius + tube * Math.cos(v)) * Math.sin(u);
        const z = tube * Math.sin(v);
        pos.push(x, y, z);
        const cx = radius * Math.cos(u), cy = radius * Math.sin(u);
        const nx = x - cx, ny = y - cy, nz = z;
        const nl = Math.hypot(nx, ny, nz) || 1;
        norm.push(nx/nl, ny/nl, nz/nl);
        uv.push(i / ts, j / rs);
      }
    }
    for (let j = 1; j <= rs; j++) {
      for (let i = 1; i <= ts; i++) {
        const a = (ts + 1) * j + i - 1;
        const b = (ts + 1) * (j - 1) + i - 1;
        const c = (ts + 1) * (j - 1) + i;
        const d = (ts + 1) * j + i;
        indices.push(a, b, d, b, c, d);
      }
    }
    this.setAttribute('position', new Float32BufferAttribute(pos, 3));
    this.setAttribute('normal', new Float32BufferAttribute(norm, 3));
    this.setAttribute('uv', new Float32BufferAttribute(uv, 2));
    this.setIndex(indices);
  }
}

class LatheGeometry extends BufferGeometry {
  constructor(points = [], segments = 12, phiStart = 0, phiLength = Math.PI * 2) {
    super();
    const seg = Math.max(3, Math.floor(segments));
    const pos = [], norm = [], uv = [], indices = [];
    const invSeg = 1 / seg;
    const initNormals = [];
    for (let j = 0; j < points.length; j++) {
      const pPrev = points[Math.max(0, j - 1)];
      const pNext = points[Math.min(points.length - 1, j + 1)];
      const dx = pNext.x - pPrev.x, dy = pNext.y - pPrev.y;
      const l = Math.hypot(dx, dy) || 1;
      initNormals.push([dy / l, -dx / l]);
    }
    for (let i = 0; i <= seg; i++) {
      const phi = phiStart + i * invSeg * phiLength;
      const sin = Math.sin(phi), cos = Math.cos(phi);
      for (let j = 0; j < points.length; j++) {
        const pt = points[j];
        pos.push(pt.x * sin, pt.y, pt.x * cos);
        const nr = initNormals[j];
        norm.push(nr[0] * sin, nr[1], nr[0] * cos);
        uv.push(i / seg, j / Math.max(1, points.length - 1));
      }
    }
    const np = points.length;
    for (let i = 0; i < seg; i++) {
      for (let j = 0; j < np - 1; j++) {
        const base = j + i * np;
        const a = base, b = base + np, c = base + np + 1, d = base + 1;
        indices.push(a, b, d, c, d, b);
      }
    }
    this.setAttribute('position', new Float32BufferAttribute(pos, 3));
    this.setAttribute('normal', new Float32BufferAttribute(norm, 3));
    this.setAttribute('uv', new Float32BufferAttribute(uv, 2));
    this.setIndex(indices);
  }
}

class Shape {
  constructor() { this.pts = []; }
  moveTo(x, y) { this.pts.push(new Vector2(x, y)); return this; }
  lineTo(x, y) { this.pts.push(new Vector2(x, y)); return this; }
  quadraticCurveTo(cpx, cpy, x, y) {
    const p0 = this.pts.length ? this.pts[this.pts.length - 1] : new Vector2(0, 0);
    const steps = 2;
    for (let i = 1; i <= steps; i++) {
      const t = i / steps, mt = 1 - t;
      this.pts.push(new Vector2(mt*mt*p0.x + 2*mt*t*cpx + t*t*x, mt*mt*p0.y + 2*mt*t*cpy + t*t*y));
    }
    return this;
  }
  absarc(aX, aY, aRadius, aStartAngle, aEndAngle, aClockwise) {
    const steps = 8;
    let delta = aEndAngle - aStartAngle;
    if (aClockwise && delta > 0) delta -= Math.PI * 2;
    if (!aClockwise && delta < 0) delta += Math.PI * 2;
    for (let i = 0; i <= steps; i++) {
      const ang = aStartAngle + (i / steps) * delta;
      this.pts.push(new Vector2(aX + Math.cos(ang) * aRadius, aY + Math.sin(ang) * aRadius));
    }
    return this;
  }
  closePath() { return this; }
}

class ExtrudeGeometry extends BufferGeometry {
  constructor(shape, options = {}) {
    super();
    const pts = (shape && shape.pts && shape.pts.length >= 3) ? shape.pts.slice() : [new Vector2(-0.5,-0.5), new Vector2(0.5,-0.5), new Vector2(0.5,0.5), new Vector2(-0.5,0.5)];
    if (pts.length > 2 && Math.hypot(pts[0].x - pts[pts.length-1].x, pts[0].y - pts[pts.length-1].y) < 1e-4) pts.pop();
    let signedArea = 0;
    for (let i = 0; i < pts.length; i++) {
      const p0 = pts[i], p1 = pts[(i + 1) % pts.length];
      signedArea += (p0.x * p1.y - p1.x * p0.y);
    }
    if (signedArea < 0) pts.reverse();
    const depth = options.depth !== undefined ? options.depth : 1;
    const bevel = options.bevelEnabled ? (options.bevelThickness || 0.01) : 0;
    const z0 = -bevel, z1 = depth + bevel;
    let cx = 0, cy = 0;
    for (const p of pts) { cx += p.x; cy += p.y; }
    cx /= pts.length; cy /= pts.length;

    const pos = [], norm = [], uv = [], indices = [];
    let vIdx = 0;
    // Front cap (+z1)
    const fCenter = vIdx++;
    pos.push(cx, cy, z1); norm.push(0, 0, 1); uv.push(0.5, 0.5);
    const fStart = vIdx;
    for (let i = 0; i < pts.length; i++) {
      pos.push(pts[i].x, pts[i].y, z1); norm.push(0, 0, 1); uv.push(pts[i].x, pts[i].y);
      vIdx++;
    }
    for (let i = 0; i < pts.length; i++) {
      indices.push(fCenter, fStart + i, fStart + ((i + 1) % pts.length));
    }
    // Back cap (z0)
    const bCenter = vIdx++;
    pos.push(cx, cy, z0); norm.push(0, 0, -1); uv.push(0.5, 0.5);
    const bStart = vIdx;
    for (let i = 0; i < pts.length; i++) {
      pos.push(pts[i].x, pts[i].y, z0); norm.push(0, 0, -1); uv.push(pts[i].x, pts[i].y);
      vIdx++;
    }
    for (let i = 0; i < pts.length; i++) {
      indices.push(bCenter, bStart + ((i + 1) % pts.length), bStart + i);
    }
    // Side walls
    for (let i = 0; i < pts.length; i++) {
      const p0 = pts[i], p1 = pts[(i + 1) % pts.length];
      const dx = p1.x - p0.x, dy = p1.y - p0.y;
      const l = Math.hypot(dx, dy) || 1;
      const nx = dy / l, ny = -dx / l;
      const sBase = vIdx;
      pos.push(p0.x, p0.y, z0, p1.x, p1.y, z0, p1.x, p1.y, z1, p0.x, p0.y, z1);
      norm.push(nx, ny, 0, nx, ny, 0, nx, ny, 0, nx, ny, 0);
      uv.push(0, 0, 1, 0, 1, 1, 0, 1);
      indices.push(sBase, sBase + 1, sBase + 2, sBase, sBase + 2, sBase + 3);
      vIdx += 4;
    }
    this.setAttribute('position', new Float32BufferAttribute(pos, 3));
    this.setAttribute('normal', new Float32BufferAttribute(norm, 3));
    this.setAttribute('uv', new Float32BufferAttribute(uv, 2));
    this.setIndex(indices);
  }
}

class CatmullRomCurve3 {
  constructor(points = []) { this.points = points; }
  getPoint(t) {
    const pts = this.points;
    if (!pts.length) return new Vector3();
    if (pts.length === 1) return pts[0].clone();
    const p = (pts.length - 1) * MathUtils.clamp(t, 0, 1);
    const intPoint = Math.floor(p);
    const weight = p - intPoint;
    const p0 = pts[Math.max(0, intPoint - 1)];
    const p1 = pts[intPoint];
    const p2 = pts[Math.min(pts.length - 1, intPoint + 1)];
    const p3 = pts[Math.min(pts.length - 1, intPoint + 2)];
    const w2 = weight * weight, w3 = w2 * weight;
    const catmull = (v0, v1, v2, v3) => 0.5 * ((2 * v1) + (-v0 + v2) * weight + (2 * v0 - 5 * v1 + 4 * v2 - v3) * w2 + (-v0 + 3 * v1 - 3 * v2 + v3) * w3);
    return new Vector3(catmull(p0.x, p1.x, p2.x, p3.x), catmull(p0.y, p1.y, p2.y, p3.y), catmull(p0.z, p1.z, p2.z, p3.z));
  }
  getTangent(t) {
    const pNext = this.getPoint(Math.min(1, t + 0.005));
    const pPrev = this.getPoint(Math.max(0, t - 0.005));
    return pNext.sub(pPrev).normalize();
  }
}

class TubeGeometry extends BufferGeometry {
  constructor(path, tubularSegments = 16, radius = 0.1, radialSegments = 8, closed = false) {
    super();
    const ts = Math.max(2, Math.floor(tubularSegments));
    const rs = Math.max(3, Math.floor(radialSegments));
    const pos = [], norm = [], uv = [], indices = [];
    const N = new Vector3(), B = new Vector3(), T = new Vector3();
    for (let i = 0; i <= ts; i++) {
      const u = i / ts;
      const P = path.getPoint(u);
      const Pnext = path.getPoint(Math.min(1, u + 0.005));
      const Pprev = path.getPoint(Math.max(0, u - 0.005));
      T.subVectors(Pnext, Pprev).normalize();
      if (i === 0) {
        const ax = Math.abs(T.x), ay = Math.abs(T.y), az = Math.abs(T.z);
        const ref = (az <= ax && az <= ay) ? new Vector3(0, 0, 1) : (ax <= ay ? new Vector3(1, 0, 0) : new Vector3(0, 1, 0));
        N.crossVectors(T, ref).normalize();
        B.crossVectors(T, N).normalize();
      } else {
        // Parallel transport (Rotation Minimizing Frame) so tube never twists at vertical/horizontal bends!
        const dotTN = T.dot(N);
        N.addScaledVector(T, -dotTN);
        if (N.lengthSq() < 1e-6) N.crossVectors(T, new Vector3(0, 0, 1)).normalize();
        else N.normalize();
        B.crossVectors(T, N).normalize();
      }
      for (let j = 0; j <= rs; j++) {
        const v = (j / rs) * Math.PI * 2;
        const cx = -Math.cos(v), cy = Math.sin(v);
        const nx = cx * N.x + cy * B.x;
        const ny = cx * N.y + cy * B.y;
        const nz = cx * N.z + cy * B.z;
        pos.push(P.x + radius * nx, P.y + radius * ny, P.z + radius * nz);
        norm.push(nx, ny, nz);
        uv.push(u, j / rs);
      }
    }
    for (let j = 1; j <= ts; j++) {
      for (let i = 1; i <= rs; i++) {
        const a = (rs + 1) * (j - 1) + (i - 1);
        const b = (rs + 1) * j + (i - 1);
        const c = (rs + 1) * j + i;
        const d = (rs + 1) * (j - 1) + i;
        indices.push(a, b, d, b, c, d);
      }
    }
    this.setAttribute('position', new Float32BufferAttribute(pos, 3));
    this.setAttribute('normal', new Float32BufferAttribute(norm, 3));
    this.setAttribute('uv', new Float32BufferAttribute(uv, 2));
    this.setIndex(indices);
  }
}

class Texture {
  constructor(image) {
    this.isTexture = true;
    this.image = image;
    this.needsUpdate = true;
    this.wrapS = ClampToEdgeWrapping;
    this.wrapT = ClampToEdgeWrapping;
    this.minFilter = LinearMipmapLinearFilter;
    this.magFilter = LinearFilter;
    this.repeat = new Vector2(1, 1);
    this.anisotropy = 1;
    this.colorSpace = NoColorSpace;
    this.generateMipmaps = true;
    this.flipY = true;
    this._glTex = null;
  }
  dispose() {}
}

class CanvasTexture extends Texture {
  constructor(canvas) { super(canvas); }
}

class DataTexture extends Texture {
  constructor(data, width, height, format = RGBAFormat, type = UnsignedByteType) {
    super({ data, width, height });
    this.isDataTexture = true;
    this.format = format;
    this.type = type;
    this.flipY = false;
  }
}

class WebGLRenderTarget {
  constructor(width, height, options = {}) {
    this.width = Math.max(1, Math.floor(width));
    this.height = Math.max(1, Math.floor(height));
    this.options = options;
    this.texture = new Texture(null);
    this.depthTexture = new Texture(null);
    this._fbo = null;
  }
  setSize(w, h) {
    const nw = Math.max(1, Math.floor(w));
    const nh = Math.max(1, Math.floor(h));
    if (nw === this.width && nh === this.height) return;
    this.width = nw;
    this.height = nh;
    this._needsResize = true;
  }
  dispose() {}
}

class Material {
  constructor(params = {}) {
    this.isMaterial = true;
    this.uuid = MathUtils.generateUUID();
    this.name = '';
    this.color = new Color(0xffffff);
    this.roughness = 0.8;
    this.metalness = 0.0;
    this.clearcoat = 0.0;
    this.clearcoatRoughness = 0.1;
    this.transmission = 0.0;
    this.ior = 1.5;
    this.thickness = 0.5;
    this.attenuationColor = new Color(0xffffff);
    this.attenuationDistance = Infinity;
    this.sheen = 0.0;
    this.sheenRoughness = 0.5;
    this.sheenColor = new Color(0x000000);
    this.envMap = null;
    this.envMapIntensity = 1.0;
    this.emissive = new Color(0x000000);
    this.emissiveIntensity = 1.0;
    this.map = null;
    this.alphaMap = null;
    this.roughnessMap = null;
    this.metalnessMap = null;
    this.normalMap = null;
    this.emissiveMap = null;
    this.aoMap = null;
    this.normalScale = new Vector2(1, 1);
    this.parallaxScale = 0.0;
    this.interiorDepth = 0.0;
    this.vertexColors = false;
    this.side = FrontSide;
    this.transparent = false;
    this.opacity = 1.0;
    this.alphaTest = 0.0;
    this.blending = NormalBlending;
    this.depthWrite = true;
    this.depthTest = true;
    this.wireframe = false;
    this.fog = true;
    this.toneMapped = true;
    this.size = 1.0;
    this.sizeAttenuation = true;
    this.needsUpdate = false;
    this.userData = {};
    this.setValues(params);
  }
  setValues(params) {
    if (!params) return;
    for (const k of Object.keys(params)) {
      const v = params[k];
      if (v === undefined) continue;
      if (k === 'color' || k === 'emissive' || k === 'sheenColor' || k === 'attenuationColor') {
        if (!this[k]) this[k] = new Color();
        this[k].set(v);
      } else if (k === 'normalScale' && !(v && v.isVector2)) {
        this.normalScale.set(Array.isArray(v) ? v[0] : v, Array.isArray(v) ? v[1] : v);
      } else {
        this[k] = v;
      }
    }
  }
  clone() {
    const m = new this.constructor();
    for (const k of Object.keys(this)) {
      const v = this[k];
      if (v && v.isColor) m[k] = v.clone();
      else if (v && v.isVector2) m[k] = v.clone();
      else m[k] = v;
    }
    return m;
  }
  dispose() {}
}

class MeshStandardMaterial extends Material {
  constructor(params = {}) { super(params); this.isMeshStandardMaterial = true; }
}
class MeshPhysicalMaterial extends MeshStandardMaterial {
  constructor(params = {}) { super(params); this.isMeshPhysicalMaterial = true; }
}
class MeshLambertMaterial extends MeshStandardMaterial {
  constructor(params = {}) { super(params); this.isMeshLambertMaterial = true; }
}
class MeshPhongMaterial extends MeshStandardMaterial {
  constructor(params = {}) { super(params); this.isMeshPhongMaterial = true; }
}
class MeshToonMaterial extends MeshStandardMaterial {
  constructor(params = {}) { super(params); this.isMeshToonMaterial = true; }
}
class MeshBasicMaterial extends Material {
  constructor(params = {}) { super(params); this.isMeshBasicMaterial = true; }
}
class MeshNormalMaterial extends Material {
  constructor(params = {}) { super(params); this.isMeshNormalMaterial = true; }
}
class MeshDepthMaterial extends Material {
  constructor(params = {}) { super(params); this.isMeshDepthMaterial = true; }
}
class ShadowMaterial extends Material {
  constructor(params = {}) { super(params); this.isShadowMaterial = true; }
}
class PointsMaterial extends Material {
  constructor(params = {}) {
    super(params);
    this.isPointsMaterial = true;
    this.size = params.size !== undefined ? params.size : 1.0;
    this.sizeAttenuation = params.sizeAttenuation !== undefined ? params.sizeAttenuation : true;
  }
}
class SpriteMaterial extends Material {
  constructor(params = {}) {
    super(params);
    this.isSpriteMaterial = true;
    this.transparent = params.transparent !== undefined ? params.transparent : true;
  }
}
class ShaderMaterial extends Material {
  constructor(params = {}) {
    super(params);
    this.isShaderMaterial = true;
    this.uniforms = params.uniforms || {};
    this.vertexShader = params.vertexShader || '';
    this.fragmentShader = params.fragmentShader || '';
    this.defines = params.defines || {};
    this.glslVersion = params.glslVersion || null;
  }
}
class RawShaderMaterial extends ShaderMaterial {
  constructor(params = {}) {
    super(params);
    this.isRawShaderMaterial = true;
  }
}

class Mesh extends Object3D {
  constructor(geometry = new BufferGeometry(), material = new MeshStandardMaterial()) {
    super();
    this.geometry = geometry;
    this.material = material;
    this.isMesh = true;
    this.type = 'Mesh';
    this.castShadow = true;
    this.receiveShadow = true;
  }
}

class Points extends Object3D {
  constructor(geometry = new BufferGeometry(), material = new PointsMaterial()) {
    super();
    this.geometry = geometry;
    this.material = material;
    this.isPoints = true;
    this.type = 'Points';
    this.frustumCulled = false;
  }
}

class Sprite extends Mesh {
  constructor(material = new SpriteMaterial()) {
    super(new PlaneGeometry(1, 1), material);
    this.isSprite = true;
    this.type = 'Sprite';
    this.center = new Vector2(0.5, 0.5);
  }
}

class InstancedMesh extends Mesh {
  constructor(geometry, material, count) {
    super(geometry, material);
    this.count = count;
    this.isInstancedMesh = true;
    this.type = 'InstancedMesh';
    this.instanceMatrix = new InstancedBufferAttribute(new Float32Array(count * 16), 16);
    this.instanceColor = null;
    for (let i = 0; i < count; i++) {
      this.instanceMatrix.array[i * 16] = 1;
      this.instanceMatrix.array[i * 16 + 5] = 1;
      this.instanceMatrix.array[i * 16 + 10] = 1;
      this.instanceMatrix.array[i * 16 + 15] = 1;
    }
  }
  setMatrixAt(i, m) {
    this.instanceMatrix.array.set(m.elements, i * 16);
    this.instanceMatrix.needsUpdate = true;
  }
  getMatrixAt(i, m) {
    for (let k = 0; k < 16; k++) m.elements[k] = this.instanceMatrix.array[i * 16 + k];
  }
  setColorAt(i, c) {
    if (!this.instanceColor) {
      this.instanceColor = new InstancedBufferAttribute(new Float32Array(this.count * 3), 3);
    }
    this.instanceColor.array[i * 3] = c.r;
    this.instanceColor.array[i * 3 + 1] = c.g;
    this.instanceColor.array[i * 3 + 2] = c.b;
    this.instanceColor.needsUpdate = true;
  }
  getColorAt(i, c) {
    if (this.instanceColor) c.fromArray(this.instanceColor.array, i * 3);
  }
  computeBoundingSphere() {
    if (this.geometry && !this.geometry.boundingSphere) this.geometry.computeBoundingSphere();
    const arr = this.instanceMatrix.array;
    const n = this.count;
    if (!n) { this.boundingSphere = new Sphere(new Vector3(), 0); return; }
    let minX=Infinity, minY=Infinity, minZ=Infinity, maxX=-Infinity, maxY=-Infinity, maxZ=-Infinity;
    for (let i = 0; i < n; i++) {
      const o = i * 16;
      const x = arr[o+12], y = arr[o+13], z = arr[o+14];
      if (x < minX) minX = x; if (x > maxX) maxX = x;
      if (y < minY) minY = y; if (y > maxY) maxY = y;
      if (z < minZ) minZ = z; if (z > maxZ) maxZ = z;
    }
    const cx = (minX + maxX) * 0.5, cy = (minY + maxY) * 0.5, cz = (minZ + maxZ) * 0.5;
    let maxR2 = 0;
    for (let i = 0; i < n; i++) {
      const o = i * 16;
      const dx = arr[o+12] - cx, dy = arr[o+13] - cy, dz = arr[o+14] - cz;
      const r2 = dx*dx + dy*dy + dz*dz;
      if (r2 > maxR2) maxR2 = r2;
    }
    const gRad = (this.geometry && this.geometry.boundingSphere) ? this.geometry.boundingSphere.radius : 1.0;
    this.boundingSphere = new Sphere(new Vector3(cx, cy, cz), Math.sqrt(maxR2) + gRad * 2.5 + 8.0);
  }
}

class DirectionalLight extends Object3D {
  constructor(color = 0xffffff, intensity = 1) {
    super();
    this.isLight = true;
    this.isDirectionalLight = true;
    this.type = 'DirectionalLight';
    this.color = new Color(color);
    this.intensity = intensity;
    this.target = new Object3D();
    this.shadow = {
      mapSize: new Vector2(2048, 2048),
      camera: new OrthographicCamera(-50, 50, 50, -50, 0.5, 500),
      bias: 0,
      normalBias: 0,
      radius: 1,
      map: null
    };
  }
}

class HemisphereLight extends Object3D {
  constructor(skyColor = 0xffffff, groundColor = 0x444444, intensity = 1) {
    super();
    this.isLight = true;
    this.isHemisphereLight = true;
    this.type = 'HemisphereLight';
    this.color = new Color(skyColor);
    this.groundColor = new Color(groundColor);
    this.intensity = intensity;
  }
}

class PMREMGenerator {
  constructor(renderer) { this.renderer = renderer; }
  compileEquirectangularShader() {}
  compileCubemapShader() {}
  fromEquirectangular(equirectTexture) {
    const rt = new WebGLRenderTarget(128, 64);
    rt.texture = equirectTexture;
    rt.texture.isPMREM = true;
    return rt;
  }
  fromScene(scene, sigma = 0, near = 0.1, far = 100) {
    const w = 128, h = 64;
    const data = new Uint8Array(w * h * 4);
    let dirL = null, hemiL = null;
    const ptLights = [];
    if (scene && scene.traverse) {
      scene.traverse(o => {
        if (o.isDirectionalLight && !dirL) dirL = o;
        else if (o.isHemisphereLight && !hemiL) hemiL = o;
        else if (o.isPointLight && ptLights.length < 8) ptLights.push(o);
      });
    }
    const bgCol = (scene && scene.background && scene.background.isColor) ? scene.background : new Color(0x1e3a5f);
    const fogCol = (scene && scene.fog && scene.fog.color) ? scene.fog.color : new Color(0xc8b496);
    const sunDir = dirL ? new Vector3().subVectors(dirL.position, dirL.target.position).normalize() : new Vector3(0.4, 0.7, 0.5).normalize();
    const sunCol = dirL ? dirL.color : new Color(1, 0.95, 0.85);
    const gndCol = hemiL ? hemiL.groundColor : new Color(0.28, 0.22, 0.18);

    for (let y = 0; y < h; y++) {
      const v = y / (h - 1);
      const lat = (v - 0.5) * Math.PI;
      const cosLat = Math.cos(lat), sinLat = Math.sin(lat);
      for (let x = 0; x < w; x++) {
        const u = x / (w - 1);
        const lon = (u - 0.5) * Math.PI * 2;
        const dx = cosLat * Math.cos(lon), dy = sinLat, dz = cosLat * Math.sin(lon);
        let r, g, b;
        if (dy >= 0) {
          const t = Math.pow(dy, 0.55);
          r = MathUtils.lerp(fogCol.r, bgCol.r, t);
          g = MathUtils.lerp(fogCol.g, bgCol.g, t);
          b = MathUtils.lerp(fogCol.b, bgCol.b, t);
          const sDot = Math.max(0, dx * sunDir.x + dy * sunDir.y + dz * sunDir.z);
          const sGlow = Math.pow(sDot, 12.0) * 0.65;
          r += sunCol.r * sGlow; g += sunCol.g * sGlow; b += sunCol.b * sGlow;
        } else {
          const t = Math.min(1, -dy * 2.2);
          r = MathUtils.lerp(fogCol.r * 0.85, gndCol.r, t);
          g = MathUtils.lerp(fogCol.g * 0.85, gndCol.g, t);
          b = MathUtils.lerp(fogCol.b * 0.85, gndCol.b, t);
        }
        const idx = (y * w + x) * 4;
        data[idx]     = Math.min(255, Math.round(r * 255));
        data[idx + 1] = Math.min(255, Math.round(g * 255));
        data[idx + 2] = Math.min(255, Math.round(b * 255));
        data[idx + 3] = 255;
      }
    }
    const envTex = new DataTexture(data, w, h);
    envTex.needsUpdate = true;
    envTex.isPMREM = true;
    const rt = new WebGLRenderTarget(w, h);
    rt.texture = envTex;
    return rt;
  }
  dispose() {}
}

class Clock {
  constructor(autoStart = true) {
    this.autoStart = autoStart;
    this.startTime = performance.now();
    this.oldTime = this.startTime;
    this.elapsedTime = 0;
    this.running = autoStart;
  }
  start() { this.startTime = performance.now(); this.oldTime = this.startTime; this.elapsedTime = 0; this.running = true; }
  stop() { this.getElapsedTime(); this.running = false; this.autoStart = false; }
  getElapsedTime() { this.getDelta(); return this.elapsedTime; }
  getDelta() {
    const now = performance.now();
    const dt = Math.max(0.0005, (now - this.oldTime) / 1000);
    this.oldTime = now;
    this.elapsedTime += dt;
    return dt;
  }
}

// Built-in Points Shaders (THREE.Points + THREE.PointsMaterial)
const POINTS_VS = `
  precision highp float;
  uniform mat4 modelMatrix;
  uniform mat4 viewMatrix;
  uniform mat4 projectionMatrix;
  uniform float uPointSize;
  uniform float uViewportHeight;
  uniform int uSizeAttenuation;
  attribute vec3 position;
  attribute vec3 color;
  attribute float size;
  varying vec3 vColor;
  varying vec3 vWorldPos;
  void main() {
    vec4 wp = modelMatrix * vec4(position, 1.0);
    vWorldPos = wp.xyz;
    vec4 mvPos = viewMatrix * wp;
    vColor = color;
    float baseSz = size > 0.0001 ? size * uPointSize : uPointSize;
    if (uSizeAttenuation == 1) {
      gl_PointSize = clamp(baseSz * (uViewportHeight * 0.5) / max(-mvPos.z, 0.1), 1.0, 128.0);
    } else {
      gl_PointSize = clamp(baseSz, 1.0, 128.0);
    }
    gl_Position = projectionMatrix * mvPos;
  }
`;

const POINTS_FS = `
  precision highp float;
  uniform vec3 cameraPosition;
  uniform vec3 uBaseColor;
  uniform float uOpacity;
  uniform float uAlphaTest;
  uniform int uUseVertexColors;
  uniform int uHasMap;
  uniform sampler2D uMap;
  uniform vec3 uFogColor;
  uniform float uFogDensity;
  uniform int uUseFog;
  varying vec3 vColor;
  varying vec3 vWorldPos;
  void main() {
    vec3 col = uBaseColor;
    if (uUseVertexColors == 1) col *= vColor;
    float alpha = uOpacity;
    if (uHasMap == 1) {
      vec4 tCol = texture2D(uMap, gl_PointCoord);
      col *= tCol.rgb;
      alpha *= tCol.a;
    } else {
      float d = length(gl_PointCoord - vec2(0.5)) * 2.0;
      if (d > 1.0) discard;
      alpha *= smoothstep(1.0, 0.35, d);
    }
    if (uAlphaTest > 0.0 && alpha < uAlphaTest) discard;
    if (uUseFog == 1) {
      float dist = length(cameraPosition - vWorldPos);
      float fogF = clamp(1.0 - exp(-uFogDensity * uFogDensity * dist * dist * 0.55), 0.0, 0.92);
      col = mix(col, uFogColor, fogF);
    }
    gl_FragColor = vec4(col, alpha);
  }
`;

// Built-in PBR / Standard / Physical / Transmission / Spotlight / 16-PointLight Shaders
const STD_VS = `
  precision highp float;
  uniform mat4 modelMatrix;
  uniform mat4 viewMatrix;
  uniform mat4 projectionMatrix;
  uniform mat4 uShadowMatrix;
  attribute vec3 position;
  attribute vec3 normal;
  attribute vec2 uv;
  attribute vec3 color;
  #ifdef USE_INSTANCING
    attribute vec4 instanceMatrix0;
    attribute vec4 instanceMatrix1;
    attribute vec4 instanceMatrix2;
    attribute vec4 instanceMatrix3;
    attribute vec3 instanceColor;
  #endif
  varying vec3 vWorldPos;
  varying vec3 vNormal;
  varying vec3 vLocalNormal;
  varying vec2 vUv;
  varying vec3 vColor;
  varying vec4 vShadowCoord;
  void main() {
    mat4 mMat = modelMatrix;
    vec3 vCol = color;
    #ifdef USE_INSTANCING
      mat4 instMat = mat4(instanceMatrix0, instanceMatrix1, instanceMatrix2, instanceMatrix3);
      mMat = modelMatrix * instMat;
      vCol = instanceColor;
    #endif
    vec4 wp = mMat * vec4(position, 1.0);
    vWorldPos = wp.xyz;
    vLocalNormal = normalize(normal + vec3(0.0, 1e-5, 0.0));
    vNormal = normalize(mat3(mMat[0].xyz, mMat[1].xyz, mMat[2].xyz) * normal + vec3(0.0, 1e-5, 0.0));
    vUv = uv;
    vColor = vCol;
    vShadowCoord = uShadowMatrix * wp;
    gl_Position = projectionMatrix * viewMatrix * wp;
  }
`;

const STD_FS = `
  precision highp float;
  uniform vec3 cameraPosition;
  uniform vec3 uBaseColor;
  uniform vec3 uEmissive;
  uniform float uEmissiveIntensity;
  uniform float uRoughness;
  uniform float uMetalness;
  uniform float uClearcoat;
  uniform float uTransmission;
  uniform float uIOR;
  uniform float uThickness;
  uniform vec3 uAttenuationColor;
  uniform float uEnvIntensity;
  uniform float uShadowEdgeBoost;
  uniform float uShadowEdgeSat;
  uniform float uShadowDarkness;
  uniform float uExposure;
  uniform float uOpacity;
  uniform float uAlphaTest;
  uniform int uIsBasic;
  uniform int uIsNormalMat;
  uniform int uIsShadowMat;
  uniform int uUseVertexColors;
  uniform int uHasMap;
  uniform int uTexTargetFace;
  uniform int uIsExternalTex;
  uniform int uTexBlendMode;
  uniform int uHasRoughMap;
  uniform int uHasNormalMap;
  uniform int uHasEmissiveMap;
  uniform int uHasEnvMap;
  uniform vec2 uMapRepeat;
  uniform float uMetricUVScale;
  uniform vec2 uNormalScale;
  uniform float uParallaxScale;
  uniform float uInteriorDepth;
  uniform sampler2D uMap;
  uniform sampler2D uRoughMap;
  uniform sampler2D uNormalMap;
  uniform sampler2D uEmissiveMap;
  uniform sampler2D uShadowMap;
  uniform sampler2D uEnvMap;
  uniform sampler2D uTransmissionMap;
  uniform sampler2D uSpotShadowMap;
  uniform mat4 uViewProj;
  uniform mat4 uSpotShadowMatrix;
  uniform int uHasTransmissionMap;
  uniform int uHasShadowMap;
  uniform int uHasSpotShadowMap;
  uniform float uShadowSoftness;
  uniform float uShadowBias;
  uniform vec3 uSunDir;
  uniform vec3 uSunCol;
  uniform float uSunIntensity;
  uniform vec3 uHemiSky;
  uniform vec3 uHemiGround;
  uniform float uHemiIntensity;
  uniform int uEnvPreset;
  uniform vec3 uEnvHorizon;
  uniform vec3 uEnvZenith;
  uniform vec3 uEnvGround;
  uniform int uHasPointShadow;
  uniform vec3 uPointShadowPos;
  uniform float uPointShadowFar;
  uniform sampler2D uPointShadowMap;
  uniform int uPointLightCount;
  uniform vec3 uPointLightPos[16];
  uniform vec3 uPointLightCol[16];
  uniform vec2 uPointLightParam[16];
  uniform int uSpotLightCount;
  uniform vec3 uSpotLightPos[8];
  uniform vec3 uSpotLightDir[8];
  uniform vec3 uSpotLightCol[8];
  uniform vec4 uSpotLightParam[8];
  uniform vec3 uFogColor;
  uniform float uFogDensity;
  uniform int uUseFog;
  uniform int uDebugMode;
  uniform int uSelectedHighlight;
  uniform int uHoveredHighlight;
  uniform vec4 uClipPlane;
  uniform int uUseClipPlane;

  varying vec3 vWorldPos;
  varying vec3 vNormal;
  varying vec3 vLocalNormal;
  varying vec2 vUv;
  varying vec3 vColor;
  varying vec4 vShadowCoord;

  float unpackDepth(vec4 rgba) {
    return dot(rgba.rgb, vec3(1.0, 1.0 / 255.0, 1.0 / 65025.0));
  }

  float sampleShadow(vec4 sc, float ndl) {
    if (uHasShadowMap == 0) return 1.0;
    vec3 proj = sc.xyz / max(sc.w, 0.0001);
    proj = proj * 0.5 + 0.5;
    if (proj.x < 0.003 || proj.x > 0.997 || proj.y < 0.003 || proj.y > 0.997 || proj.z > 0.9995 || proj.z < 0.0005) return 1.0;
    float baseBias = uShadowBias > 0.0 ? uShadowBias : 0.00045;
    float bias = max(baseBias * 2.2 * (1.0 - ndl), baseBias);
    float spread = (uShadowSoftness > 0.0 ? uShadowSoftness : 1.55);
    vec2 texel = vec2(1.0 / 2048.0) * spread;

    float rotA = fract(sin(dot(vWorldPos.xz, vec2(12.9898, 78.233))) * 43758.5453) * 6.283185;
    float cR = cos(rotA), sR = sin(rotA);
    mat2 rotM = mat2(cR, -sR, sR, cR);

    float s = 0.0;
    s += (proj.z - bias > unpackDepth(texture2D(uShadowMap, proj.xy + (rotM * vec2(-0.942, -0.399)) * texel))) ? 0.0 : 1.0;
    s += (proj.z - bias > unpackDepth(texture2D(uShadowMap, proj.xy + (rotM * vec2( 0.945, -0.768)) * texel))) ? 0.0 : 1.0;
    s += (proj.z - bias > unpackDepth(texture2D(uShadowMap, proj.xy + (rotM * vec2(-0.094, -0.929)) * texel))) ? 0.0 : 1.0;
    s += (proj.z - bias > unpackDepth(texture2D(uShadowMap, proj.xy + (rotM * vec2( 0.344,  0.293)) * texel))) ? 0.0 : 1.0;
    s += (proj.z - bias > unpackDepth(texture2D(uShadowMap, proj.xy + (rotM * vec2(-0.915,  0.457)) * texel))) ? 0.0 : 1.0;
    s += (proj.z - bias > unpackDepth(texture2D(uShadowMap, proj.xy + (rotM * vec2(-0.815, -0.879)) * texel))) ? 0.0 : 1.0;
    s += (proj.z - bias > unpackDepth(texture2D(uShadowMap, proj.xy + (rotM * vec2(-0.382,  0.276)) * texel))) ? 0.0 : 1.0;
    s += (proj.z - bias > unpackDepth(texture2D(uShadowMap, proj.xy + (rotM * vec2( 0.974,  0.756)) * texel))) ? 0.0 : 1.0;
    s += (proj.z - bias > unpackDepth(texture2D(uShadowMap, proj.xy + (rotM * vec2( 0.443, -0.975)) * texel))) ? 0.0 : 1.0;
    s += (proj.z - bias > unpackDepth(texture2D(uShadowMap, proj.xy + (rotM * vec2( 0.537, -0.473)) * texel))) ? 0.0 : 1.0;
    s += (proj.z - bias > unpackDepth(texture2D(uShadowMap, proj.xy + (rotM * vec2(-0.264, -0.418)) * texel))) ? 0.0 : 1.0;
    s += (proj.z - bias > unpackDepth(texture2D(uShadowMap, proj.xy + (rotM * vec2( 0.791,  0.190)) * texel))) ? 0.0 : 1.0;

    float edge = smoothstep(0.0, 0.06, min(min(proj.x, 1.0 - proj.x), min(proj.y, 1.0 - proj.y)));
    return mix(1.0, s / 12.0, edge);
  }


  float sampleSpotShadow(vec4 sc, float ndl) {
    if (uHasSpotShadowMap == 0) return 1.0;
    if (sc.w <= 0.0001) return 1.0;
    vec3 proj = sc.xyz / sc.w;
    proj = proj * 0.5 + 0.5;
    if (proj.x < 0.003 || proj.x > 0.997 || proj.y < 0.003 || proj.y > 0.997 || proj.z > 0.9995 || proj.z < 0.0005) return 1.0;
    float bias = max(0.0008 * (1.0 - ndl), 0.00035);
    vec2 texel = vec2(1.0 / 1024.0) * 1.4;
    float s = 0.0;
    s += (proj.z - bias > unpackDepth(texture2D(uSpotShadowMap, proj.xy))) ? 0.0 : 1.0;
    s += (proj.z - bias > unpackDepth(texture2D(uSpotShadowMap, proj.xy + vec2( texel.x, 0.0)))) ? 0.0 : 1.0;
    s += (proj.z - bias > unpackDepth(texture2D(uSpotShadowMap, proj.xy + vec2(-texel.x, 0.0)))) ? 0.0 : 1.0;
    s += (proj.z - bias > unpackDepth(texture2D(uSpotShadowMap, proj.xy + vec2(0.0,  texel.y)))) ? 0.0 : 1.0;
    s += (proj.z - bias > unpackDepth(texture2D(uSpotShadowMap, proj.xy + vec2(0.0, -texel.y)))) ? 0.0 : 1.0;
    return s / 5.0;
  }

  float samplePointShadow(vec3 worldPos, float ndl) {
    if (uHasPointShadow == 0) return 1.0;
    vec3 d = worldPos - uPointShadowPos;
    float dist = length(d);
    if (dist > uPointShadowFar || dist < 0.05) return 1.0;
    vec3 dir = d / dist;
    float u = atan(dir.z, dir.x) * 0.1591549 + 0.5;
    float v = asin(clamp(dir.y, -0.999, 0.999)) * 0.3183098 + 0.5;
    float stored = unpackDepth(texture2D(uPointShadowMap, vec2(u, v))) * uPointShadowFar;
    float bias = max(0.08 * (1.0 - ndl), 0.035);
    return (dist - bias > stored) ? 0.15 : 1.0;
  }

  vec3 acesFilm(vec3 x) {
    float a = 2.51, b = 0.03, c = 2.43, d = 0.59, e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
  }

  vec3 sampleEquirectIBL(vec3 dir, float rough, vec3 envHorizon, vec3 envZenith, vec3 envGround) {
    float rH = clamp(dir.y, 1e-4, 1.0);
    vec3 procSky = dir.y >= 0.0
      ? mix(envHorizon, envZenith, sqrt(rH))
      : mix(envHorizon * 0.85, envGround, clamp(-dir.y * 2.2, 0.0, 1.0));
    if (uHasEnvMap == 1) {
      vec2 eqUv = vec2(dir.x * 0.25 + 0.5, dir.y * 0.5 + 0.5);
      return mix(procSky, texture2D(uEnvMap, eqUv).rgb, 0.65);
    }
    return procSky;
  }

  void main() {
    if (uUseClipPlane >= 1) {
      float clipDist = dot(vWorldPos, uClipPlane.xyz) - uClipPlane.w;
      if (clipDist > 0.0) discard;
      if (uUseClipPlane == 1 && abs(clipDist) < 0.018) {
        gl_FragColor = vec4(0.0, 0.95, 1.0, 1.0);
        return;
      }
    }
    if (uIsShadowMat == 1) {
      float sh = sampleShadow(vShadowCoord, 0.5);
      float a = (1.0 - sh) * uOpacity;
      if (a < 0.01) discard;
      gl_FragColor = vec4(0.03, 0.025, 0.02, a);
      return;
    }

    vec2 uv = vUv * uMapRepeat;
    if (uMetricUVScale > 0.001 && uIsExternalTex == 0) {
      vec3 an = abs(vNormal);
      if (an.y >= an.x && an.y >= an.z) uv = vWorldPos.xz / uMetricUVScale;
      else if (an.x >= an.z) uv = vWorldPos.zy / uMetricUVScale;
      else uv = vWorldPos.xy / uMetricUVScale;
    }

    bool faceMatch = true;
    if (uTexTargetFace == 1) faceMatch = (vLocalNormal.z > 0.65);
    else if (uTexTargetFace == 2) faceMatch = (vLocalNormal.z < -0.65);
    else if (uTexTargetFace == 3) faceMatch = (vLocalNormal.y > 0.65);
    else if (uTexTargetFace == 4) faceMatch = (vLocalNormal.y < -0.65);
    else if (uTexTargetFace == 5) faceMatch = (vLocalNormal.x > 0.65);
    else if (uTexTargetFace == 6) faceMatch = (vLocalNormal.x < -0.65);
    else if (uTexTargetFace == 7) faceMatch = (abs(vLocalNormal.y) > 0.65);
    else if (uTexTargetFace == 8) faceMatch = (abs(vLocalNormal.y) < 0.45);

    vec3 geomN = normalize(vNormal + vec3(0.0, 1e-5, 0.0));
    if (!gl_FrontFacing) geomN = -geomN;
    if (uIsNormalMat == 1) {
      gl_FragColor = vec4(geomN * 0.5 + 0.5, uOpacity);
      return;
    }
    vec3 upRef = abs(geomN.y) < 0.92 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 tangT = normalize(cross(upRef, geomN));
    vec3 tangB = normalize(cross(geomN, tangT));
    vec3 viewDirW = normalize(cameraPosition - vWorldPos);
    vec3 viewTS = vec3(dot(viewDirW, tangT), dot(viewDirW, tangB), max(dot(viewDirW, geomN), 0.16));

    float pomSelfShadow = 1.0;
    vec3 pomBumpN = vec3(0.0);

    if (uParallaxScale > 0.0005 && uHasMap == 1 && faceMatch) {
      float numLayers = 8.0;
      float layerStep = 1.0 / numLayers;
      vec2 P = (viewTS.xy / viewTS.z) * uParallaxScale;
      vec2 dUv = P * layerStep;
      vec2 currUv = uv;
      float currLayer = 0.0;
      vec3 cSample = texture2D(uMap, currUv).rgb;
      float currDepth = 1.0 - dot(cSample, vec3(0.299, 0.587, 0.114));
      for (int i = 0; i < 8; i++) {
        if (currLayer < currDepth) {
          currUv -= dUv;
          cSample = texture2D(uMap, currUv).rgb;
          currDepth = 1.0 - dot(cSample, vec3(0.299, 0.587, 0.114));
          currLayer += layerStep;
        }
      }
      vec2 prevUv = currUv + dUv;
      float afterD = currDepth - currLayer;
      float beforeD = (1.0 - dot(texture2D(uMap, prevUv).rgb, vec3(0.299, 0.587, 0.114))) - currLayer + layerStep;
      float weight = clamp(afterD / max(afterD - beforeD, 0.0001), 0.0, 1.0);
      uv = mix(currUv, prevUv, weight);

      float hC = dot(texture2D(uMap, uv).rgb, vec3(0.299, 0.587, 0.114));
      float hR = dot(texture2D(uMap, uv + vec2(0.004, 0.0)).rgb, vec3(0.299, 0.587, 0.114));
      float hU = dot(texture2D(uMap, uv + vec2(0.0, 0.004)).rgb, vec3(0.299, 0.587, 0.114));
      pomBumpN = (tangT * (hC - hR) + tangB * (hC - hU)) * (uParallaxScale * 42.0);
      pomSelfShadow = 0.72 + 0.28 * smoothstep(0.15, 0.75, hC);
    }

    vec4 texCol = vec4(1.0);
    if (uHasMap == 1 && faceMatch) {
      texCol = texture2D(uMap, uv);
      if (uInteriorDepth > 0.001) {
        vec2 roomUv = clamp(uv - (viewTS.xy / viewTS.z) * uInteriorDepth, 0.02, 0.98);
        vec2 midUv  = clamp(uv - (viewTS.xy / viewTS.z) * (uInteriorDepth * 0.48), 0.01, 0.99);
        vec3 backWallCol = texture2D(uMap, roomUv).rgb;
        vec3 midRackCol  = texture2D(uMap, midUv).rgb;
        vec2 edgeDist = abs(roomUv - 0.5) * 2.0;
        float roomAO = 1.0 - 0.35 * smoothstep(0.65, 1.0, max(edgeDist.x, edgeDist.y));
        texCol.rgb = mix(backWallCol * roomAO, midRackCol, 0.42);
      }
    }
    if (faceMatch && uAlphaTest > 0.0 && texCol.a < uAlphaTest) discard;
    if (faceMatch && uIsExternalTex == 1 && uTexBlendMode == 2 && texCol.a < 0.08) discard;

    vec3 baseCol = uBaseColor;
    if (uHasMap == 1 && faceMatch) {
      if (uIsExternalTex == 1 && uTexBlendMode == 2) baseCol = uBaseColor * texCol.rgb;
      else baseCol = uBaseColor * texCol.rgb;
    }
    if (uUseVertexColors == 1) baseCol *= vColor;

    float microNoise = sin(vWorldPos.x * 11.7 + vWorldPos.z * 9.3 + vWorldPos.y * 7.1) * cos(vWorldPos.x * 5.3 - vWorldPos.z * 8.1);
    baseCol *= (0.98 + 0.02 * microNoise);

    if (uIsBasic == 1) {
      vec3 c = baseCol;
      if (uUseFog == 1) {
        float dist = length(cameraPosition - vWorldPos);
        float fogF = clamp(1.0 - exp(-uFogDensity * uFogDensity * dist * dist), 0.0, 1.0);
        c = mix(c, uFogColor, fogF);
      }
      gl_FragColor = vec4(c, texCol.a * uOpacity);
      return;
    }

    vec3 N = normalize(geomN + pomBumpN);
    if (uHasNormalMap == 1) {
      vec3 nm = texture2D(uNormalMap, uv).xyz * 2.0 - 1.0;
      N = normalize(N + (tangT * nm.x * uNormalScale.x + tangB * nm.y * uNormalScale.y) * 1.25);
    }

    if (uDebugMode == 2) { gl_FragColor = vec4(N * 0.5 + 0.5, 1.0); return; }
    if (uDebugMode == 3) {
      vec2 guv = uv * 4.0;
      float cx = mod(floor(guv.x) + floor(guv.y), 2.0);
      vec2 fuv = fract(guv);
      float line = (fuv.x < 0.06 || fuv.y < 0.06) ? 1.0 : 0.0;
      vec3 uvCol = mix(vec3(0.14, 0.16, 0.22) + vec3(fract(uv.x) * 0.45, fract(uv.y) * 0.45, 0.2), vec3(0.88, 0.91, 0.96), cx * 0.65);
      uvCol = mix(uvCol, vec3(0.0, 0.92, 1.0), line * 0.75);
      gl_FragColor = vec4(uvCol, 1.0);
      return;
    }
    if (uDebugMode == 4) {
      float d = length(cameraPosition - vWorldPos);
      float nd = clamp(1.0 - d / 50.0, 0.0, 1.0);
      vec3 dCol = mix(vec3(0.05, 0.08, 0.18), vec3(0.2, 0.95, 0.85), pow(nd, 1.4));
      gl_FragColor = vec4(dCol, 1.0);
      return;
    }

    float rough = uRoughness;
    if (uHasRoughMap == 1) rough *= (0.55 + 0.65 * texture2D(uRoughMap, uv).r);
    rough = clamp(rough, 0.04, 1.0);

    vec3 V = normalize(cameraPosition - vWorldPos);
    vec3 L = normalize(uSunDir);
    vec3 H = normalize(V + L);

    float ndl = max(dot(N, L), 0.0);
    float ndv = max(dot(N, V), 0.001);
    float ndh = max(dot(N, H), 0.0);

    float shadow = sampleShadow(vShadowCoord, ndl);

    float groundContactAO = (abs(N.y) < 0.55) ? (0.62 + 0.38 * smoothstep(0.0, 0.85, max(0.0, vWorldPos.y))) : 1.0;
    float soffitAO = (N.y < -0.1) ? mix(1.0, 0.68, clamp(-N.y, 0.0, 1.0)) : 1.0;
    float cornerWave = 0.94 + 0.06 * cos(vWorldPos.x * 3.14159) * cos(vWorldPos.z * 3.14159);
    float cavityAO = groundContactAO * soffitAO * cornerWave * pomSelfShadow;

    float hemiW = N.y * 0.5 + 0.5;
    vec3 warmBounce = max(uHemiGround, vec3(0.48, 0.34, 0.22)) * (0.35 + 0.65 * max(0.0, -N.y));
    vec3 ambient = (mix(warmBounce, uHemiSky, hemiW) * (uHemiIntensity * 0.38 + 0.08)) * (0.20 + 0.80 * shadow) * cavityAO;

    vec3 R = reflect(-V, N);
    vec3 envHorizon = uEnvHorizon;
    vec3 envZenith  = uEnvZenith;
    vec3 envGround  = uEnvGround;

    vec3 envSky = sampleEquirectIBL(R, rough, envHorizon, envZenith, envGround);
    vec3 envIrradiance = sampleEquirectIBL(N, 0.85, envHorizon, envZenith, envGround);
    ambient += envIrradiance * (0.14 * uEnvIntensity) * cavityAO;
    float shadowAtten = mix(1.0, 0.22, (1.0 - shadow) * uShadowDarkness);
    ambient *= shadowAtten;

    float softboxKey  = pow(max(dot(R, normalize(vec3(0.45, 0.78, 0.42))), 0.0), mix(28.0, 3.0, rough));
    float softboxFill = pow(max(dot(R, normalize(vec3(-0.65, 0.45, 0.60))), 0.0), mix(18.0, 2.5, rough));
    float softboxRim  = pow(max(dot(R, normalize(vec3(0.10, 0.35, -0.92))), 0.0), mix(22.0, 3.0, rough));
    float horizonBand = exp(-pow((R.y - 0.08) * 4.2, 2.0)) * (1.0 - rough * 0.55);
    envSky += vec3(1.0, 0.96, 0.88) * softboxKey * 0.65
            + vec3(0.86, 0.92, 1.0) * softboxFill * 0.45
            + vec3(1.0, 0.88, 0.72) * softboxRim * 0.38
            + envHorizon * horizonBand * 0.42;
    envSky *= (0.45 + 0.55 * shadow) * cavityAO;

    float sunRefl = pow(max(dot(R, L), 1e-4), mix(96.0, 6.0, rough)) * shadow;
    envSky += uSunCol * sunRefl * (1.0 - rough * 0.70) * 1.10;

    float fresnel = pow(clamp(1.0 - ndv, 1e-4, 1.0), 4.0);
    if (uAlphaTest > 0.0) fresnel *= 0.08;
    float f0Scalar = pow((uIOR - 1.0) / max(uIOR + 1.0, 1.01), 2.0);
    vec3 F0 = mix(vec3(f0Scalar), baseCol, uMetalness);
    vec3 F = F0 + (max(vec3(1.0 - rough * 0.75), F0) - F0) * fresnel;

    vec3 kd = (1.0 - F) * (1.0 - uMetalness) * (1.0 - uTransmission);
    float wrapNdl = max((dot(N, L) + 0.14) / 1.14, 0.0);
    float neighborShadow = 0.0;
    if (shadow > 0.25 && uHasShadowMap == 1) {
      vec3 sp = vShadowCoord.xyz / max(vShadowCoord.w, 0.0001) * 0.5 + 0.5;
      if (sp.x > 0.01 && sp.x < 0.99 && sp.y > 0.01 && sp.y < 0.99) {
        vec2 wOff = vec2(18.0 / 2048.0);
        float sN = 0.0;
        sN += (sp.z - 0.0012 > unpackDepth(texture2D(uShadowMap, sp.xy + vec2(wOff.x, 0.0)))) ? 0.0 : 1.0;
        sN += (sp.z - 0.0012 > unpackDepth(texture2D(uShadowMap, sp.xy - vec2(wOff.x, 0.0)))) ? 0.0 : 1.0;
        sN += (sp.z - 0.0012 > unpackDepth(texture2D(uShadowMap, sp.xy + vec2(0.0, wOff.y)))) ? 0.0 : 1.0;
        sN += (sp.z - 0.0012 > unpackDepth(texture2D(uShadowMap, sp.xy - vec2(0.0, wOff.y)))) ? 0.0 : 1.0;
        neighborShadow = (1.0 - sN * 0.25) * smoothstep(0.35, 0.85, shadow);
      }
    }
    float castPenumbra = max(4.0 * shadow * (1.0 - shadow), neighborShadow);
    float termPenumbra = 4.0 * clamp(ndl, 0.0, 1.0) * (1.0 - clamp(ndl, 0.0, 1.0)) * smoothstep(0.25, 0.75, shadow);
    float edgeMask = clamp(max(castPenumbra, termPenumbra * 0.82), 0.0, 1.0) * smoothstep(0.18, 0.65, shadow) * smoothstep(0.04, 0.24, ndl);
    float lum = dot(baseCol, vec3(0.299, 0.587, 0.114));
    vec3 richCol = clamp(mix(vec3(lum), baseCol, 1.0 + uShadowEdgeSat * 1.35 * edgeMask), 0.0, 1.0);
    vec3 sunDirect = uSunCol * uSunIntensity * 0.52 * mix(ndl, wrapNdl, 0.22) * (0.01 + 0.99 * shadow) * (1.0 + uShadowEdgeBoost * 1.85 * edgeMask);
    vec3 diffuse = kd * richCol * (ambient + sunDirect);

    if (uAlphaTest > 0.0 || (uUseVertexColors == 1 && vColor.g > vColor.r * 1.25 && vColor.g > vColor.b * 1.35)) {
      float backL = max(dot(-N, L), 0.0);
      float rimL = pow(clamp(1.0 - ndv, 1e-4, 1.0), 2.2) * max(dot(V, -L) * 0.5 + 0.5, 0.0);
      diffuse += baseCol * vec3(1.12, 0.96, 0.40) * uSunCol * uSunIntensity * 0.18 * (backL * 0.70 + rimL * 0.45) * (0.25 + 0.75 * shadow);
    }

    float specPow = exp2(10.0 * (1.0 - rough) + 1.0);
    float spec = ((specPow + 2.0) / 8.0) * pow(max(ndh, 1e-4), specPow) * ndl * shadow;
    vec3 metalTint = mix(vec3(1.0), baseCol, uMetalness);
    float iblGain = mix(0.45, 1.45, uMetalness) * (1.0 - rough * 0.38);
    if (uAlphaTest > 0.0) iblGain *= 0.14;
    vec3 specular = F * uSunCol * uSunIntensity * (uAlphaTest > 0.0 ? 0.10 : 0.34) * spec + F * metalTint * envSky * uEnvIntensity * iblGain;

    // True Screen-Space Physical Refraction & Volume Transmission (samples scene behind glass!)
    if (uTransmission > 0.01) {
      float eta = 1.0 / max(uIOR, 1.01);
      vec3 refrR = refract(-V, N, eta * 0.99);
      vec3 refrG = refract(-V, N, eta);
      vec3 refrB = refract(-V, N, eta * 1.01);
      vec3 refrBg;
      if (uHasTransmissionMap == 1) {
        float thickScale = clamp(uThickness, 0.05, 4.0) * 0.55;
        vec4 clipR = uViewProj * vec4(vWorldPos + refrR * thickScale, 1.0);
        vec4 clipG = uViewProj * vec4(vWorldPos + refrG * thickScale, 1.0);
        vec4 clipB = uViewProj * vec4(vWorldPos + refrB * thickScale, 1.0);
        vec2 uvR = clamp((clipR.xy / max(clipR.w, 0.001)) * 0.5 + 0.5, 0.002, 0.998);
        vec2 uvG = clamp((clipG.xy / max(clipG.w, 0.001)) * 0.5 + 0.5, 0.002, 0.998);
        vec2 uvB = clamp((clipB.xy / max(clipB.w, 0.001)) * 0.5 + 0.5, 0.002, 0.998);
        float blurR = rough * 0.008;
        float rCh = (texture2D(uTransmissionMap, uvR).r * 0.5 + texture2D(uTransmissionMap, clamp(uvR + vec2(blurR, 0.0), 0.002, 0.998)).r * 0.25 + texture2D(uTransmissionMap, clamp(uvR - vec2(blurR, 0.0), 0.002, 0.998)).r * 0.25);
        float gCh = (texture2D(uTransmissionMap, uvG).g * 0.5 + texture2D(uTransmissionMap, clamp(uvG + vec2(0.0, blurR), 0.002, 0.998)).g * 0.25 + texture2D(uTransmissionMap, clamp(uvG - vec2(0.0, blurR), 0.002, 0.998)).g * 0.25);
        float bCh = (texture2D(uTransmissionMap, uvB).b * 0.5 + texture2D(uTransmissionMap, clamp(uvB + vec2(blurR, blurR), 0.002, 0.998)).b * 0.25 + texture2D(uTransmissionMap, clamp(uvB - vec2(blurR, blurR), 0.002, 0.998)).b * 0.25);
        refrBg = vec3(rCh, gCh, bCh);
      } else {
        refrBg = vec3(
          sampleEquirectIBL(refrR, rough * 0.65, envHorizon, envZenith, envGround).r,
          sampleEquirectIBL(refrG, rough * 0.65, envHorizon, envZenith, envGround).g,
          sampleEquirectIBL(refrB, rough * 0.65, envHorizon, envZenith, envGround).b
        );
      }
      vec3 absorb = exp(-(vec3(1.0) - clamp(uAttenuationColor * baseCol, vec3(0.02), vec3(1.0))) * max(uThickness, 0.05) * 1.15);
      diffuse = mix(diffuse, refrBg * absorb, uTransmission * (1.0 - F));
    }

    if (uClearcoat > 0.01) {
      float ccSpec = pow(max(ndh, 1e-4), 160.0) * ndl * shadow * uClearcoat;
      specular += (uSunCol * ccSpec * 0.55 + envSky * fresnel * uClearcoat * 0.32);
    }

    // Up to 16 Simultaneous PointLights
    for (int i = 0; i < 16; i++) {
      if (i >= uPointLightCount) break;
      vec3 lVec = uPointLightPos[i] - vWorldPos;
      float dist = length(lVec);
      float maxD = max(uPointLightParam[i].y, 0.5);
      if (dist < maxD) {
        vec3 pL = lVec / max(dist, 0.001);
        float pNdl = max((dot(N, pL) + 0.18) / 1.18, 0.0);
        float normD = clamp(1.0 - dist / maxD, 0.0, 1.0);
        float atten = (normD * normD) / (1.0 + 0.18 * dist * dist);
        float pShad = (i == 0) ? samplePointShadow(vWorldPos, pNdl) : 1.0;
        vec3 pRadiance = uPointLightCol[i] * uPointLightParam[i].x * atten * pShad;
        diffuse += kd * baseCol * pRadiance * pNdl * 0.75;
        vec3 pH = normalize(V + pL);
        float pSpec = pow(max(dot(N, pH), 1e-4), max(8.0, specPow * 0.5)) * pNdl;
        specular += F * pRadiance * pSpec * 0.30;
      }
    }

    // Up to 8 Simultaneous SpotLights with Smooth Inner/Outer Cone Penumbra
    for (int i = 0; i < 8; i++) {
      if (i >= uSpotLightCount) break;
      vec3 lVec = uSpotLightPos[i] - vWorldPos;
      float dist = length(lVec);
      float maxD = max(uSpotLightParam[i].y, 0.5);
      if (dist < maxD) {
        vec3 sL = lVec / max(dist, 0.001);
        float theta = dot(-sL, normalize(uSpotLightDir[i]));
        float cosOuter = uSpotLightParam[i].z;
        float cosInner = uSpotLightParam[i].w;
        float spotCone = smoothstep(cosOuter, max(cosOuter + 0.001, cosInner), theta);
        if (spotCone > 0.001) {
          float sNdl = max((dot(N, sL) + 0.12) / 1.12, 0.0);
          float normD = clamp(1.0 - dist / maxD, 0.0, 1.0);
          float atten = spotCone * (normD * normD) / (1.0 + 0.12 * dist * dist);
          float sShad = (i == 0) ? sampleSpotShadow(uSpotShadowMatrix * vec4(vWorldPos, 1.0), sNdl) : 1.0;
          vec3 sRadiance = uSpotLightCol[i] * uSpotLightParam[i].x * atten * sShad;
          diffuse += kd * baseCol * sRadiance * sNdl * 0.82;
          vec3 sH = normalize(V + sL);
          float sSpec = pow(max(dot(N, sH), 1e-4), max(10.0, specPow * 0.6)) * sNdl;
          specular += F * sRadiance * sSpec * 0.38;
        }
      }
    }

    vec3 emis = uEmissive * uEmissiveIntensity * 0.55;
    if (uUseVertexColors == 1) emis *= vColor;
    if (uHasEmissiveMap == 1) emis *= texture2D(uEmissiveMap, uv).rgb;
    else if (uHasMap == 1 && faceMatch) emis *= texCol.rgb;

    vec3 col = (diffuse + specular) * (uExposure > 0.0 ? uExposure : 1.0) + emis;

    col = acesFilm(col * 0.90);
    col = pow(max(col, vec3(0.0)), vec3(0.95));

    if (uUseFog == 1) {
      float dist = length(cameraPosition - vWorldPos);
      float heightFalloff = exp(-max(0.0, vWorldPos.y) * 0.045);
      float fogF = clamp((1.0 - exp(-uFogDensity * uFogDensity * dist * dist * 0.55)) * heightFalloff, 0.0, 0.88);
      col = mix(col, uFogColor, fogF);
    }

    if (uDebugMode == 1) {
      vec3 clayBase = vec3(0.76, 0.74, 0.71);
      float studioKey = max(dot(N, normalize(vec3(0.5, 0.8, 0.6))), 0.0);
      float studioFill = max(dot(N, normalize(vec3(-0.6, 0.3, -0.4))), 0.0) * 0.35;
      float studioRim = pow(clamp(1.0 - ndv, 0.0, 1.0), 3.0) * 0.45;
      float aoApprox = clamp(0.55 + 0.45 * N.y, 0.35, 1.0) * (0.35 + 0.65 * shadow) * cavityAO;
      col = clayBase * (0.28 + 0.68 * studioKey * (0.25 + 0.75 * shadow) + studioFill) * aoApprox + vec3(0.85, 0.88, 0.95) * studioRim;
    } else if (uDebugMode == 5) {
      float lum = dot(col, vec3(0.299, 0.587, 0.114));
      vec3 cLow = vec3(0.08, 0.15, 0.55), cMid = vec3(0.1, 0.85, 0.45), cHigh = vec3(1.0, 0.25, 0.15);
      col = lum < 0.5 ? mix(cLow, cMid, lum * 2.0) : mix(cMid, cHigh, clamp((lum - 0.5) * 1.6, 0.0, 1.0));
    }
    if (uSelectedHighlight == 1) {
      float rim = pow(clamp(1.0 - ndv, 0.0, 1.0), 2.2);
      col = mix(col, vec3(0.0, 0.94, 1.0), 0.16 + 0.55 * rim);
    } else if (uHoveredHighlight == 1) {
      float rim = pow(clamp(1.0 - ndv, 0.0, 1.0), 2.5);
      col = mix(col, vec3(1.0, 0.75, 0.15), 0.12 + 0.45 * rim);
    }
    float outAlpha = (uAlphaTest > 0.0 && uOpacity > 0.98)
      ? 1.0
      : (uTransmission > 0.01 ? (uHasTransmissionMap == 1 ? clamp(uOpacity, 0.99, 1.0) : clamp(mix(0.18, 0.92, fresnel), 0.15, 0.96)) : (texCol.a * uOpacity));
    gl_FragColor = vec4(col, outAlpha);
  }
`;

const SHADOW_VS = `
  precision highp float;
  uniform mat4 modelMatrix;
  uniform mat4 viewMatrix;
  uniform mat4 projectionMatrix;
  attribute vec3 position;
  attribute vec2 uv;
  #ifdef USE_INSTANCING
    attribute vec4 instanceMatrix0;
    attribute vec4 instanceMatrix1;
    attribute vec4 instanceMatrix2;
    attribute vec4 instanceMatrix3;
  #endif
  varying vec2 vUv;
  void main() {
    mat4 mMat = modelMatrix;
    #ifdef USE_INSTANCING
      mat4 instMat = mat4(instanceMatrix0, instanceMatrix1, instanceMatrix2, instanceMatrix3);
      mMat = modelMatrix * instMat;
    #endif
    vUv = uv;
    gl_Position = projectionMatrix * viewMatrix * (mMat * vec4(position, 1.0));
  }
`;

const SHADOW_FS = `
  precision highp float;
  uniform float uAlphaTest;
  uniform int uHasMap;
  uniform sampler2D uMap;
  varying vec2 vUv;
  void main() {
    if (uAlphaTest > 0.0 && uHasMap == 1) {
      if (texture2D(uMap, vUv).a < uAlphaTest) discard;
    }
    float d = clamp(gl_FragCoord.z, 0.0, 1.0);
    float r = floor(d * 255.0) / 255.0;
    float f1 = (d - r) * 255.0;
    float g = floor(f1 * 255.0) / 255.0;
    float b = (f1 - g) * 255.0;
    gl_FragColor = vec4(r, g, b, 1.0);
  }
`;

function _transpileGLSL300To100(src, isFrag) {
  let s = src.replace(/^\s*#version\s+300\s+es\s*/m, '');
  if (!isFrag) {
    s = s.replace(/\bin\s+((?:highp|mediump|lowp)\s+)?(vec[234]|float|int|mat[234])\b/g, 'attribute $1$2');
    s = s.replace(/\bout\s+((?:highp|mediump|lowp)\s+)?(vec[234]|float)\b/g, 'varying $1$2');
  } else {
    s = s.replace(/\bin\s+((?:highp|mediump|lowp)\s+)?(vec[234]|float)\b/g, 'varying $1$2');
    const outMatch = s.match(/\bout\s+(?:highp\s+|mediump\s+|lowp\s+)?vec4\s+(\w+)\s*;/);
    if (outMatch) {
      const outVar = outMatch[1];
      s = s.replace(outMatch[0], '');
      s = s.replace(new RegExp(`\\b${outVar}\\b`, 'g'), 'gl_FragColor');
    }
  }
  s = s.replace(/\btexture\s*\(/g, 'texture2D(');
  return s;
}

class WebGLRenderer {
  constructor(params = {}) {
    this.domElement = params.canvas || document.createElement('canvas');
    const gl = this.domElement.getContext('webgl2', { antialias: true, preserveDrawingBuffer: true }) ||
               this.domElement.getContext('webgl', { antialias: true, preserveDrawingBuffer: true });
    this.gl = gl;
    this.isWebGL2 = (typeof WebGL2RenderingContext !== 'undefined' && gl instanceof WebGL2RenderingContext);
    if (!this.isWebGL2 && gl) {
      this.extInst = gl.getExtension('ANGLE_instanced_arrays');
      this.extUint = gl.getExtension('OES_element_index_uint');
    }
    this.extAniso = gl ? (gl.getExtension("EXT_texture_filter_anisotropic") ||
                          gl.getExtension("MOZ_EXT_texture_filter_anisotropic") ||
                          gl.getExtension("WEBKIT_EXT_texture_filter_anisotropic")) : null;
    this.maxAniso = (this.extAniso && gl) ? gl.getParameter(this.extAniso.MAX_TEXTURE_MAX_ANISOTROPY_EXT) : 1;
    this.capabilities = {
      isWebGL2: this.isWebGL2,
      getMaxAnisotropy: () => this.maxAniso || 16
    };
    this.shadowMap = { enabled: false, type: PCFSoftShadowMap, autoUpdate: true, needsUpdate: true };
    this.outputColorSpace = SRGBColorSpace;
    this.toneMapping = ACESFilmicToneMapping;
    this.toneMappingExposure = 1.0;
    this.autoClear = true;
    this.pixelRatio = 1;
    this.width = (typeof window !== 'undefined' && window.innerWidth) || 1280;
    this.height = (typeof window !== 'undefined' && window.innerHeight) || 720;
    this.currentRT = null;
    this.info = { render: { calls: 0, triangles: 0, points: 0, lines: 0, frame: 0 }, memory: { geometries: 0, textures: 0 } };
    this._whiteTex = new DataTexture(new Uint8Array([255, 255, 255, 255]), 1, 1);
    this._flatNormTex = new DataTexture(new Uint8Array([128, 128, 255, 255]), 1, 1);
    this._shadowRT = null;
    this._shadowMatrix = new Matrix4();
    this._spotShadowRT = null;
    this._spotShadowMatrix = new Matrix4();
    this._pointShadowRT = null;
    this._pointShadowPos = new Vector3();
    this._pointShadowFar = 25.0;
    this._transmissionRT = null;
    this.envPreset = 0;
    this.envColors = null; // Optional custom { horizon: Color, zenith: Color, ground: Color }
    this._mvMat = new Matrix4();
    this._normalMat = new Matrix3();
    this._projViewMat = new Matrix4();
    this._sProjViewMat = new Matrix4();
    this._sunDirVec = new Vector3();
    this._plPosArr = new Float32Array(16 * 3);
    this._plColArr = new Float32Array(16 * 3);
    this._plParArr = new Float32Array(16 * 2);
    this._slPosArr = new Float32Array(8 * 3);
    this._slDirArr = new Float32Array(8 * 3);
    this._slColArr = new Float32Array(8 * 3);
    this._slParArr = new Float32Array(8 * 4);
    this._lastShadowSig = '';
    this._loopCb = null;
  }
  getContext() { return this.gl; }
  setPixelRatio(r) { this.pixelRatio = r; this.setSize(this.width, this.height); }
  getPixelRatio() { return this.pixelRatio; }
  getSize(target = new Vector2()) { return target.set(this.width, this.height); }
  setSize(w, h, updateStyle = true) {
    this.width = w; this.height = h;
    this.domElement.width = Math.max(1, Math.floor(w * this.pixelRatio));
    this.domElement.height = Math.max(1, Math.floor(h * this.pixelRatio));
    if (updateStyle !== false) {
      this.domElement.style.width = w + 'px';
      this.domElement.style.height = h + 'px';
    }
    if (this.gl && !this.currentRT) {
      this.gl.viewport(0, 0, this.domElement.width, this.domElement.height);
    }
  }
  setClearColor(color, alpha = 1) {
    if (!this._clearColor) this._clearColor = new Color();
    this._clearColor.set(color);
    this._clearAlpha = alpha;
  }
  getDrawingBufferSize(target = new Vector2()) {
    return target.set(this.domElement.width, this.domElement.height);
  }
  getRenderTarget() { return this.currentRT; }
  setRenderTarget(rt) {
    const gl = this.gl;
    this.currentRT = rt;
    if (!rt) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.viewport(0, 0, this.domElement.width, this.domElement.height);
    } else {
      if (!rt._fbo || rt._needsResize) this._initRT(rt);
      gl.bindFramebuffer(gl.FRAMEBUFFER, rt._fbo);
      gl.viewport(0, 0, rt.width, rt.height);
    }
  }
  _initRT(rt) {
    const gl = this.gl;
    rt._needsResize = false;
    if (!rt._fbo) rt._fbo = gl.createFramebuffer();
    if (!rt.texture._glTex) rt.texture._glTex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, rt.texture._glTex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, rt.width, rt.height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    const filt = rt._isShadowRT ? gl.NEAREST : gl.LINEAR;
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filt);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filt);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    rt.texture.needsUpdate = false;
    gl.bindFramebuffer(gl.FRAMEBUFFER, rt._fbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, rt.texture._glTex, 0);
    if (!rt._rbo) rt._rbo = gl.createRenderbuffer();
    gl.bindRenderbuffer(gl.RENDERBUFFER, rt._rbo);
    gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, rt.width, rt.height);
    gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, rt._rbo);
  }
  clear(color = true, depth = true) {
    const gl = this.gl;
    let mask = 0;
    if (color) mask |= gl.COLOR_BUFFER_BIT;
    if (depth) { gl.depthMask(true); mask |= gl.DEPTH_BUFFER_BIT; }
    if (mask) gl.clear(mask);
  }
  dispose() {}
  setAnimationLoop(cb) {
    this._loopCb = cb;
    if (cb) {
      const step = (t) => {
        if (!this._loopCb) return;
        this._loopCb(t);
        requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    }
  }
  _formatShaderSourceError(src, log) {
    const lines = src.split('\n').map((l, i) => `${String(i + 1).padStart(3, ' ')}: ${l}`).join('\n');
    return `${log}\n--- Shader Source ---\n${lines}`;
  }
  _compileProg(vsSrc, fsSrc) {
    const gl = this.gl;
    const vs = gl.createShader(gl.VERTEX_SHADER);
    gl.shaderSource(vs, vsSrc); gl.compileShader(vs);
    if (!gl.getShaderParameter(vs, gl.COMPILE_STATUS)) {
      console.error('[Triad3D WebGL Vertex Shader Error]\n' + this._formatShaderSourceError(vsSrc, gl.getShaderInfoLog(vs)));
    }
    const fs = gl.createShader(gl.FRAGMENT_SHADER);
    gl.shaderSource(fs, fsSrc); gl.compileShader(fs);
    if (!gl.getShaderParameter(fs, gl.COMPILE_STATUS)) {
      console.error('[Triad3D WebGL Fragment Shader Error]\n' + this._formatShaderSourceError(fsSrc, gl.getShaderInfoLog(fs)));
    }
    const prog = gl.createProgram();
    gl.attachShader(prog, vs); gl.attachShader(prog, fs); gl.bindAttribLocation(prog, 0, 'position'); gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      console.error('[Triad3D WebGL Program Link Error]', gl.getProgramInfoLog(prog));
    }
    const uniforms = {}, attribs = {};
    const nU = gl.getProgramParameter(prog, gl.ACTIVE_UNIFORMS);
    for (let i = 0; i < nU; i++) {
      const info = gl.getActiveUniform(prog, i);
      if (!info) continue;
      const base = info.name.replace(/\[0\]$/, '');
      uniforms[base] = gl.getUniformLocation(prog, info.name);
      uniforms[info.name] = uniforms[base];
    }
    const nA = gl.getProgramParameter(prog, gl.ACTIVE_ATTRIBUTES);
    for (let i = 0; i < nA; i++) {
      const info = gl.getActiveAttrib(prog, i);
      if (!info) continue;
      attribs[info.name] = gl.getAttribLocation(prog, info.name);
    }
    return { prog, uniforms, attribs };
  }
  _getShaderMatProg(mat, isInst) {
    const key = isInst ? '_progInst' : '_progStd';
    if (mat[key]) return mat[key];
    let rawVS = mat.vertexShader || '';
    let rawFS = mat.fragmentShader || '';
    const isGLSL3 = (mat.glslVersion === '300 es') || /#version\s+300\s+es/.test(rawVS) || /#version\s+300\s+es/.test(rawFS) || /\bout\s+vec4\b/.test(rawFS);
    if (isGLSL3) {
      rawVS = _transpileGLSL300To100(rawVS, false);
      rawFS = _transpileGLSL300To100(rawFS, true);
    }
    let definesPrefix = '';
    if (mat.defines) {
      for (const dk of Object.keys(mat.defines)) {
        const dv = mat.defines[dk];
        if (dv !== false && dv !== undefined && dv !== null) definesPrefix += `#define ${dk} ${dv === true ? 1 : dv}\n`;
      }
    }
    if (mat.isRawShaderMaterial) {
      const hasPrecVS = /precision\s+\w+\s+float/.test(rawVS);
      const hasPrecFS = /precision\s+\w+\s+float/.test(rawFS);
      mat[key] = this._compileProg(
        (hasPrecVS ? '' : 'precision highp float;\n') + definesPrefix + rawVS,
        (hasPrecFS ? '' : 'precision highp float;\n') + definesPrefix + rawFS
      );
      return mat[key];
    }
    const cleanFS = rawFS.replace(/precision\s+\w+\s+float\s*;/g, '');
    const cleanVS = rawVS.replace(/precision\s+\w+\s+float\s*;/g, '');
    const hasDecl = (src, kind, name) => new RegExp(`\\b${kind}\\s+(?:highp\\s+|mediump\\s+|lowp\\s+)?\\w+\\s+${name}\\b`).test(src);
    let prefixVS = 'precision highp float;\n' + definesPrefix;
    if (!hasDecl(cleanVS, 'uniform', 'modelMatrix'))     prefixVS += 'uniform mat4 modelMatrix;\n';
    if (!hasDecl(cleanVS, 'uniform', 'modelViewMatrix')) prefixVS += 'uniform mat4 modelViewMatrix;\n';
    if (!hasDecl(cleanVS, 'uniform', 'projectionMatrix'))prefixVS += 'uniform mat4 projectionMatrix;\n';
    if (!hasDecl(cleanVS, 'uniform', 'viewMatrix'))      prefixVS += 'uniform mat4 viewMatrix;\n';
    if (!hasDecl(cleanVS, 'uniform', 'normalMatrix'))    prefixVS += 'uniform mat3 normalMatrix;\n';
    if (!hasDecl(cleanVS, 'uniform', 'cameraPosition'))  prefixVS += 'uniform vec3 cameraPosition;\n';
    if (!hasDecl(cleanVS, 'attribute', 'position'))      prefixVS += 'attribute vec3 position;\n';
    if (!hasDecl(cleanVS, 'attribute', 'normal'))        prefixVS += 'attribute vec3 normal;\n';
    if (!hasDecl(cleanVS, 'attribute', 'uv'))            prefixVS += 'attribute vec2 uv;\n';

    let prefixFS = 'precision highp float;\n' + definesPrefix;
    if (!hasDecl(cleanFS, 'uniform', 'viewMatrix'))      prefixFS += 'uniform mat4 viewMatrix;\n';
    if (!hasDecl(cleanFS, 'uniform', 'cameraPosition'))  prefixVS && (prefixFS += 'uniform vec3 cameraPosition;\n');
    mat[key] = this._compileProg(prefixVS + '\n' + cleanVS, prefixFS + '\n' + cleanFS);
    return mat[key];
  }
  _getPointsProg() {
    if (!this._ptsProg) this._ptsProg = this._compileProg(POINTS_VS, POINTS_FS);
    return this._ptsProg;
  }
  _getStdProg(isInst, isShadowPass) {
    if (isShadowPass) {
      const k = isInst ? '_shProgInst' : '_shProgStd';
      if (!this[k]) this[k] = this._compileProg((isInst ? '#define USE_INSTANCING\n' : '') + SHADOW_VS, SHADOW_FS);
      return this[k];
    }
    const k = isInst ? '_stdProgInst' : '_stdProgStd';
    if (!this[k]) this[k] = this._compileProg((isInst ? '#define USE_INSTANCING\n' : '') + STD_VS, STD_FS);
    return this[k];
  }
  _bindTex(tex, unit) {
    const gl = this.gl;
    gl.activeTexture(gl.TEXTURE0 + unit);
    if (!tex) tex = this._whiteTex;
    if (!tex._glTex) tex._glTex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex._glTex);
    if (tex.needsUpdate && tex.image) {
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, tex.flipY ? 1 : 0);
      if (tex.isDataTexture) {
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, tex.image.width, tex.image.height, 0, gl.RGBA, gl.UNSIGNED_BYTE, tex.image.data);
      } else {
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, tex.image);
      }
      const wrapS = tex.wrapS === RepeatWrapping ? gl.REPEAT : (tex.wrapS === MirroredRepeatWrapping ? gl.MIRRORED_REPEAT : gl.CLAMP_TO_EDGE);
      const wrapT = tex.wrapT === RepeatWrapping ? gl.REPEAT : (tex.wrapT === MirroredRepeatWrapping ? gl.MIRRORED_REPEAT : gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, wrapS);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, wrapT);
      if (tex.generateMipmaps && tex.image.width > 1 && ((tex.image.width & (tex.image.width - 1)) === 0)) {
        gl.generateMipmap(gl.TEXTURE_2D);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
        if (this.extAniso) {
          gl.texParameterf(gl.TEXTURE_2D, this.extAniso.TEXTURE_MAX_ANISOTROPY_EXT, Math.min(this.maxAniso, 16));
        }
      } else {
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, tex.minFilter === NearestFilter ? gl.NEAREST : gl.LINEAR);
      }
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, tex.magFilter === NearestFilter ? gl.NEAREST : gl.LINEAR);
      tex.needsUpdate = false;
    }
  }
  _bindAttr(attr, target) {
    const gl = this.gl;
    if (!attr._glBuffer) {
      attr._glBuffer = gl.createBuffer();
      attr._gl = gl;
      gl.bindBuffer(target, attr._glBuffer);
      gl.bufferData(target, attr.array, gl.STATIC_DRAW);
      attr.needsUpdate = false;
    } else if (attr.needsUpdate) {
      gl.bindBuffer(target, attr._glBuffer);
      gl.bufferData(target, attr.array, gl.DYNAMIC_DRAW);
      attr.needsUpdate = false;
    } else {
      gl.bindBuffer(target, attr._glBuffer);
    }
  }
  render(scene, camera) {
    const gl = this.gl;
    if (!gl) return;
    if (!this._inShadowPass && !this.currentRT) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.viewport(0, 0, this.domElement.width, this.domElement.height);
    }
    if (!this._inShadowPass && !camera.isOrthographicCamera && (!this.currentRT || !this._inReflectionPass)) {
      this.info.render.calls = 0;
      this.info.render.triangles = 0;
      this.info.render.points = 0;
      this.info.render.lines = 0;
      this.info.render.frame++;
    }
    scene.updateMatrixWorld(false);
    camera.updateMatrixWorld(false);

    if (scene.background && scene.background.isColor) {
      gl.depthMask(true);
      gl.clearColor(scene.background.r, scene.background.g, scene.background.b, 1.0);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    } else if (this._clearColor && this.autoClear && !this._inShadowPass) {
      gl.depthMask(true);
      gl.clearColor(this._clearColor.r, this._clearColor.g, this._clearColor.b, this._clearAlpha !== undefined ? this._clearAlpha : 1.0);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    }

    const meshes = [];
    let dirLight = null, hemiLight = null;
    const allPointLights = [];
    const allSpotLights = [];

    const projView = this._projViewMat.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse);
    const me = projView.elements;
    const planes = [
      [me[3]-me[0], me[7]-me[4], me[11]-me[8], me[15]-me[12]],
      [me[3]+me[0], me[7]+me[4], me[11]+me[8], me[15]+me[12]],
      [me[3]+me[1], me[7]+me[5], me[11]+me[9], me[15]+me[13]],
      [me[3]-me[1], me[7]-me[5], me[11]-me[9], me[15]-me[13]],
      [me[3]-me[2], me[7]-me[6], me[11]-me[10], me[15]-me[14]],
      [me[3]+me[2], me[7]+me[6], me[11]+me[10], me[15]+me[14]]
    ];
    for (let i = 0; i < 6; i++) {
      const p = planes[i];
      const invL = 1.0 / (Math.hypot(p[0], p[1], p[2]) || 1);
      p[0] *= invL; p[1] *= invL; p[2] *= invL; p[3] *= invL;
    }
    const inFrustum = (mesh) => {
      if (!mesh.frustumCulled || mesh.isPoints) return true;
      if (mesh.geometry && !mesh.geometry.boundingSphere && mesh.geometry.attributes && mesh.geometry.attributes.position) {
        mesh.geometry.computeBoundingSphere();
      }
      const bs = mesh.boundingSphere || (mesh.geometry && mesh.geometry.boundingSphere) || (mesh.parent && mesh.parent.userData && mesh.parent.userData.bounds);
      if (!bs || bs.radius <= 0) return true;
      const mw = mesh.matrixWorld.elements;
      const cx = mw[0]*bs.center.x + mw[4]*bs.center.y + mw[8]*bs.center.z + mw[12];
      const cy = mw[1]*bs.center.x + mw[5]*bs.center.y + mw[9]*bs.center.z + mw[13];
      const cz = mw[2]*bs.center.x + mw[6]*bs.center.y + mw[10]*bs.center.z + mw[14];
      const r = bs.radius * Math.max(Math.hypot(mw[0],mw[1],mw[2]), Math.hypot(mw[4],mw[5],mw[6]), Math.hypot(mw[8],mw[9],mw[10]), 1);
      for (let i = 0; i < 6; i++) {
        const p = planes[i];
        if (p[0]*cx + p[1]*cy + p[2]*cz + p[3] < -r - 8.0) return false;
      }
      return true;
    };

    const camPos = camera.position;
    this.info.render.culledByDistance = 0;
    this.info.render.culledShadows = 0;
    const collect = (o) => {
      if (!o.visible) return;
      if (o.userData) {
        if (o.userData._maxDrawDistance > 0) {
          const mw = o.matrixWorld.elements;
          const dist = Math.hypot(mw[12] - camPos.x, mw[13] - camPos.y, mw[14] - camPos.z);
          if (dist > o.userData._maxDrawDistance) {
            this.info.render.culledByDistance++;
            return;
          }
        }
        if (o.userData._lodDistances && o.children.length > 0) {
          const mw = o.matrixWorld.elements;
          const dist = Math.hypot(mw[12] - camPos.x, mw[13] - camPos.y, mw[14] - camPos.z);
          const dArr = o.userData._lodDistances;
          let activeIdx = 0;
          for (let li = 0; li < dArr.length; li++) {
            if (dist >= dArr[li]) activeIdx = Math.min(o.children.length - 1, li + 1);
          }
          for (let ci = 0; ci < o.children.length; ci++) {
            o.children[ci].visible = (ci === activeIdx);
          }
        }
      }
      if (o.userData && o.userData.bounds) {
        const bs = o.userData.bounds;
        const cx = bs.center.x, cy = bs.center.y, cz = bs.center.z, r = bs.radius;
        for (let i = 0; i < 6; i++) {
          const p = planes[i];
          if (p[0]*cx + p[1]*cy + p[2]*cz + p[3] < -r - 16.0) return;
        }
      }
      if (o.isSpotLight) allSpotLights.push(o);
      else if (o.isDirectionalLight && !dirLight) dirLight = o;
      else if (o.isHemisphereLight && !hemiLight) hemiLight = o;
      else if (o.isPointLight) allPointLights.push(o);
      else if (o.isMesh || o.isPoints || o.isLineSegments || o.isLine || o.isLineLoop) {
        if ((!o.isInstancedMesh || o.count > 0) && inFrustum(o)) meshes.push(o);
      }
      const ch = o.children;
      for (let i = 0; i < ch.length; i++) collect(ch[i]);
    };
    collect(scene);
    if (allPointLights.length > 16) {
      allPointLights.sort((a, b) => {
        const mwA = a.matrixWorld.elements, mwB = b.matrixWorld.elements;
        const dA = Math.hypot(mwA[12] - camPos.x, mwA[13] - camPos.y, mwA[14] - camPos.z) / Math.max(0.5, a.intensity || 1);
        const dB = Math.hypot(mwB[12] - camPos.x, mwB[13] - camPos.y, mwB[14] - camPos.z) / Math.max(0.5, b.intensity || 1);
        return dA - dB;
      });
    }
    const pointLights = allPointLights.slice(0, 16);
    const spotLights = allSpotLights.slice(0, 8);

    meshes.sort((a, b) => {
      const roA = a.renderOrder || 0, roB = b.renderOrder || 0;
      if (roA !== roB) return roA - roB;
      const trA = ((a.material && (a.material.transparent || a.material.transmission > 0.01) && (a.material.opacity === undefined || a.material.opacity < 0.99 || a.material.transmission > 0.01)) || a.isPoints) ? 1 : 0;
      const trB = ((b.material && (b.material.transparent || b.material.transmission > 0.01) && (b.material.opacity === undefined || b.material.opacity < 0.99 || b.material.transmission > 0.01)) || b.isPoints) ? 1 : 0;
      if (trA !== trB) return trA - trB;
      const mwA = a.matrixWorld.elements, mwB = b.matrixWorld.elements;
      const dxA = mwA[12] - camPos.x, dyA = mwA[13] - camPos.y, dzA = mwA[14] - camPos.z;
      const dxB = mwB[12] - camPos.x, dyB = mwB[13] - camPos.y, dzB = mwB[14] - camPos.z;
      const dSqA = dxA * dxA + dyA * dyA + dzA * dzA;
      const dSqB = dxB * dxB + dyB * dyB + dzB * dzB;
      // Back-to-front for transparents, Front-to-back for opaques (Hardware Early-Z!)
      return trA === 1 ? (dSqB - dSqA) : (dSqA - dSqB);
    });

    let hasShadowMap = (this.shadowMap.enabled && this._shadowRT) ? 1 : 0;
    if (this.shadowMap.enabled && dirLight && dirLight.castShadow && !this._inShadowPass && (!this.currentRT || this.currentRT !== this._shadowRT) && (!this.currentRT || this.currentRT.width >= this.domElement.width)) {
      const sw = dirLight.shadow.mapSize.x || 2048;
      const sh = dirLight.shadow.mapSize.y || 2048;
      if (!this._shadowRT || this._shadowRT.width !== sw) {
        this._shadowRT = new WebGLRenderTarget(sw, sh);
        this._shadowRT._isShadowRT = true;
      }
      dirLight.shadow.map = this._shadowRT;
      dirLight.shadow.matrix = this._shadowMatrix;
      if (this.shadowMap.autoUpdate || this.shadowMap.needsUpdate) {
        const allMeshes = [];
        let maxR = 14.0;
        const tPos = dirLight.target.position;
        let matrixHash = 0.0;
        const collectAll = (o) => {
          if (!o.visible) return;
          if (o.isMesh && (!o.isInstancedMesh || o.count > 0)) {
            if (o.castShadow && o.geometry && o.material && !o.material.isShaderMaterial) {
              if (o.userData) {
                if (o.userData._smallShadowCullRadius > 0) {
                  if (!o.geometry.boundingSphere) o.geometry.computeBoundingSphere();
                  const r = o.geometry.boundingSphere ? o.geometry.boundingSphere.radius : 1;
                  if (r < o.userData._smallShadowCullRadius) { this.info.render.culledShadows++; return; }
                }
                if (o.userData._shadowCullDistance > 0) {
                  const mw = o.matrixWorld.elements;
                  const sd = Math.hypot(mw[12] - camPos.x, mw[13] - camPos.y, mw[14] - camPos.z);
                  if (sd > o.userData._shadowCullDistance) { this.info.render.culledShadows++; return; }
                }
              }
              allMeshes.push(o);
              const mw = o.matrixWorld.elements;
              matrixHash += mw[0] * 1.1 + mw[5] * 1.7 + mw[10] * 2.3 + mw[12] * 3.1 + mw[13] * 3.7 + mw[14] * 4.3;
              const d = Math.hypot(mw[12] - tPos.x, mw[14] - tPos.z);
              if (d > 1.0 && d < 140.0) maxR = Math.max(maxR, Math.min(115.0, d + 12.0));
            }
          }
          for (let i = 0; i < o.children.length; i++) collectAll(o.children[i]);
        };
        collectAll(scene);
        const sCam = dirLight.shadow.camera;
        const lp = dirLight.position;
        const curShadowSig = `${lp.x.toFixed(3)},${lp.y.toFixed(3)},${lp.z.toFixed(3)}|${tPos.x.toFixed(2)},${tPos.y.toFixed(2)},${tPos.z.toFixed(2)}|${sCam.right.toFixed(1)}|${allMeshes.length}|${matrixHash.toFixed(3)}`;
        if (this.shadowMap.needsUpdate || this._lastShadowSig !== curShadowSig) {
          this._lastShadowSig = curShadowSig;
          this._inShadowPass = true;
          const prevRT = this.currentRT;
          if (Math.abs(sCam.right) <= 15.0 && maxR > Math.abs(sCam.right)) {
            sCam.left = -maxR; sCam.right = maxR; sCam.top = maxR; sCam.bottom = -maxR;
          }
          const lDist = Math.max(10.0, lp.distanceTo(tPos));
          const ext = Math.max(Math.abs(sCam.right), 14.0);
          sCam.near = Math.max(0.5, lDist - ext * 3.5 - 60.0);
          sCam.far = Math.max(sCam.far || 80.0, lDist + ext * 3.5 + 140.0);
          sCam.updateProjectionMatrix();
          sCam.position.copy(lp);
          sCam.lookAt(tPos);
          sCam.updateMatrixWorld(true);
          this._shadowMatrix.multiplyMatrices(sCam.projectionMatrix, sCam.matrixWorldInverse);
          this._bindTex(this._whiteTex, 4);
          this._bindTex(this._whiteTex, 7);

          this.setRenderTarget(this._shadowRT);
          gl.clearColor(1, 1, 1, 1);
          gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
          gl.enable(gl.DEPTH_TEST);
          gl.depthMask(true);
          gl.disable(gl.BLEND);
          for (let i = 0; i < allMeshes.length; i++) {
            this._drawMesh(allMeshes[i], sCam, scene, dirLight, hemiLight, null, null, true, 0);
          }
          this.setRenderTarget(prevRT);
          this.shadowMap.needsUpdate = false;
          this._inShadowPass = false;
        }
      }
      hasShadowMap = 1;
    }

    // SpotLight Shadow Map Pass (for first shadow-casting SpotLight)
    let hasSpotShadow = 0;
    const shadowSpot = spotLights.find(s => s.castShadow);
    if (this.shadowMap.enabled && shadowSpot && !this._inShadowPass && !this._inTransmissionPass && !this._inReflectionPass) {
      if (!this._spotShadowRT) {
        this._spotShadowRT = new WebGLRenderTarget(1024, 1024);
        this._spotShadowRT._isShadowRT = true;
      }
      this._inShadowPass = true;
      const prevRT = this.currentRT;
      const spCam = new PerspectiveCamera(Math.min(150, MathUtils.radToDeg(shadowSpot.angle || Math.PI / 4) * 2), 1.0, 0.3, shadowSpot.distance || 35);
      shadowSpot.updateMatrixWorld(true);
      const smw = shadowSpot.matrixWorld.elements;
      spCam.position.set(smw[12], smw[13], smw[14]);
      const tPos = new Vector3();
      if (shadowSpot.target) {
        shadowSpot.target.updateMatrixWorld(true);
        tPos.setFromMatrixPosition(shadowSpot.target.matrixWorld);
      }
      spCam.lookAt(tPos);
      spCam.updateMatrixWorld(true);
      this._spotShadowMatrix.multiplyMatrices(spCam.projectionMatrix, spCam.matrixWorldInverse);
      this._bindTex(this._whiteTex, 7);
      this.setRenderTarget(this._spotShadowRT);
      gl.clearColor(1, 1, 1, 1);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.enable(gl.DEPTH_TEST);
      gl.depthMask(true);
      gl.disable(gl.BLEND);
      for (let i = 0; i < meshes.length; i++) {
        const m = meshes[i];
        if (m.castShadow && m.isMesh && !m.material.isShaderMaterial) {
          this._drawMesh(m, spCam, scene, dirLight, hemiLight, null, null, true, 0);
        }
      }
      this.setRenderTarget(prevRT);
      this._inShadowPass = false;
      hasSpotShadow = 1;
    }

    // PointLight Shadow Pass (for first shadow-casting PointLight using equirectangular/6-view distance bake)
    let hasPointShadow = 0;
    const shadowPt = pointLights.find(p => p.castShadow);
    if (this.shadowMap.enabled && shadowPt && !this._inShadowPass && !this._inTransmissionPass && !this._inReflectionPass) {
      shadowPt.updateMatrixWorld(true);
      this._pointShadowPos.setFromMatrixPosition(shadowPt.matrixWorld);
      this._pointShadowFar = shadowPt.distance || 25.0;
      if (!this._pointShadowRT) {
        this._pointShadowRT = new WebGLRenderTarget(512, 256);
        this._pointShadowRT._isShadowRT = true;
      }
      // Bake 6 cardinal frustums into a compact equirectangular-like depth atlas if shadowMap needs update
      if (this.shadowMap.autoUpdate || this.shadowMap.needsUpdate || !this._pointShadowBaked) {
        this._pointShadowBaked = true;
        this._inShadowPass = true;
        const prevRT = this.currentRT;
        const ptCam = new PerspectiveCamera(90, 1.0, 0.25, this._pointShadowFar);
        ptCam.position.copy(this._pointShadowPos);
        const dirs = [
          [1,0,0],[0,1,0], [-1,0,0],[0,1,0], [0,1,0],[0,0,-1], [0,-1,0],[0,0,1], [0,0,1],[0,1,0], [0,0,-1],[0,1,0]
        ];
        this.setRenderTarget(this._pointShadowRT);
        gl.clearColor(1, 1, 1, 1);
        gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
        gl.enable(gl.DEPTH_TEST);
        gl.depthMask(true);
        gl.disable(gl.BLEND);
        // Render front/back hemisphere viewports for fast 360 point occlusion
        const pDirs = [
          { look: [1,0,0], up: [0,1,0], vx: 0, vy: 0, vw: 128, vh: 256 },
          { look: [-1,0,0], up: [0,1,0], vx: 128, vy: 0, vw: 128, vh: 256 },
          { look: [0,0,1], up: [0,1,0], vx: 256, vy: 0, vw: 128, vh: 256 },
          { look: [0,0,-1], up: [0,1,0], vx: 384, vy: 0, vw: 128, vh: 256 }
        ];
        for (const pd of pDirs) {
          gl.viewport(pd.vx, pd.vy, pd.vw, pd.vh);
          ptCam.up.set(pd.up[0], pd.up[1], pd.up[2]);
          ptCam.lookAt(this._pointShadowPos.x + pd.look[0], this._pointShadowPos.y + pd.look[1], this._pointShadowPos.z + pd.look[2]);
          ptCam.updateMatrixWorld(true);
          for (let i = 0; i < meshes.length; i++) {
            const m = meshes[i];
            if (m.castShadow && m.isMesh && !m.material.isShaderMaterial) {
              this._drawMesh(m, ptCam, scene, dirLight, hemiLight, null, null, true, 0);
            }
          }
        }
        this.setRenderTarget(prevRT);
        this._inShadowPass = false;
      }
      hasPointShadow = 1;
    }

    // Back-to-Front Nested Screen-Space Transmission Pass (supports glass nested inside glass!)
    const transMeshes = [];
    const opaqueMeshes = [];
    for (let i = 0; i < meshes.length; i++) {
      const m = meshes[i];
      if (!this._inShadowPass && !this._inTransmissionPass && !this._inReflectionPass && !camera.isOrthographicCamera && m.material && (m.material.transmission || 0) > 0.01) {
        transMeshes.push(m);
      } else {
        opaqueMeshes.push(m);
      }
    }
    const hasTransmissive = transMeshes.length > 0;
    let hasTransmissionMap = 0;
    if (hasTransmissive) {
      const fbW = this.currentRT ? this.currentRT.width : this.domElement.width;
      const fbH = this.currentRT ? this.currentRT.height : this.domElement.height;
      const tw = Math.max(64, fbW), th = Math.max(64, fbH);
      if (!this._transmissionRT) {
        this._transmissionRT = new WebGLRenderTarget(tw, th);
      } else {
        this._transmissionRT.setSize(tw, th);
      }
      // Draw all opaque meshes to main target first
      for (let i = 0; i < opaqueMeshes.length; i++) {
        this._drawMesh(opaqueMeshes[i], camera, scene, dirLight, hemiLight, pointLights, spotLights, false, hasShadowMap, hasSpotShadow, hasPointShadow, 0);
      }
      // Sort transmissive meshes back-to-front by camera distance so inner glass renders first
      const cPos = camera.position;
      const tmpW = new Vector3();
      transMeshes.sort((a, b) => {
        const da = tmpW.setFromMatrixPosition(a.matrixWorld).distanceToSquared(cPos);
        const db = tmpW.setFromMatrixPosition(b.matrixWorld).distanceToSquared(cPos);
        return db - da;
      });
      hasTransmissionMap = 1;
      for (let i = 0; i < transMeshes.length; i++) {
        // Snapshot current framebuffer (opaque + further transmissive meshes!) into _transmissionRT texture
        gl.activeTexture(gl.TEXTURE6);
        if (!this._transmissionRT.texture._glTex || this._transmissionRT._needsResize) {
          const _prevRT = this.currentRT; this.setRenderTarget(this._transmissionRT); this.setRenderTarget(_prevRT);
        }
        gl.bindTexture(gl.TEXTURE_2D, this._transmissionRT.texture._glTex);
        gl.copyTexSubImage2D(gl.TEXTURE_2D, 0, 0, 0, 0, 0, tw, th);
        this._drawMesh(transMeshes[i], camera, scene, dirLight, hemiLight, pointLights, spotLights, false, hasShadowMap, hasSpotShadow, hasPointShadow, 1);
      }
    } else {
      for (let i = 0; i < meshes.length; i++) {
        this._drawMesh(meshes[i], camera, scene, dirLight, hemiLight, pointLights, spotLights, false, hasShadowMap, hasSpotShadow, hasPointShadow, 0);
      }
    }
  }
  _drawMesh(mesh, camera, scene, dirLight, hemiLight, pointLights, spotLights, isShadowPass, hasShadowMap, hasSpotShadow = 0, hasPointShadow = 0, hasTransmissionMap = 0) {
    const gl = this.gl;
    const geo = mesh.geometry, mat = mesh.material;
    if (!geo || !mat || !geo.attributes.position) return;

    // Sprite billboarding
    if (mesh.isSprite) {
      mesh.quaternion.copy(camera.quaternion);
      mesh.updateMatrixWorld(false);
    }

    const isInst = !!mesh.isInstancedMesh;
    const isPts = !!mesh.isPoints;
    const pObj = mat.isShaderMaterial
      ? this._getShaderMatProg(mat, isInst)
      : (isPts ? this._getPointsProg() : this._getStdProg(isInst, isShadowPass));
    const { prog, uniforms, attribs } = pObj;
    gl.useProgram(prog);

    if (mat.depthTest !== false) { gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); } else gl.disable(gl.DEPTH_TEST);
    if (mat.polygonOffset) { gl.enable(gl.POLYGON_OFFSET_FILL); gl.polygonOffset(mat.polygonOffsetFactor || -1, mat.polygonOffsetUnits || -1); } else { gl.disable(gl.POLYGON_OFFSET_FILL); }
    const isTranslucentGlass = (!isShadowPass && ((mat.transparent && (mat.opacity !== undefined && mat.opacity < 0.99)) || (mat.transmission > 0.01)) && (!mat.alphaTest || mat.alphaTest <= 0.0));
    gl.depthMask(isShadowPass ? true : (isTranslucentGlass ? false : (mat.depthWrite !== false)));

    if (!isShadowPass && (mat.transparent || mat.isShadowMaterial || mat.blending === AdditiveBlending || (isPts && !mat.isShaderMaterial))) {
      gl.enable(gl.BLEND);
      if (mat.blending === AdditiveBlending) gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
      else gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    } else {
      gl.disable(gl.BLEND);
    }

    if (mat.side === BackSide) {
      gl.enable(gl.CULL_FACE);
      gl.cullFace(gl.FRONT);
    } else if (mat.side === DoubleSide) {
      gl.disable(gl.CULL_FACE);
    } else {
      gl.enable(gl.CULL_FACE);
      gl.cullFace(gl.BACK);
    }

    const mvMat = this._mvMat.multiplyMatrices(camera.matrixWorldInverse, mesh.matrixWorld);
    if (uniforms.modelMatrix) gl.uniformMatrix4fv(uniforms.modelMatrix, false, mesh.matrixWorld.elements);
    if (uniforms.viewMatrix) gl.uniformMatrix4fv(uniforms.viewMatrix, false, camera.matrixWorldInverse.elements);
    if (uniforms.modelViewMatrix) gl.uniformMatrix4fv(uniforms.modelViewMatrix, false, mvMat.elements);
    if (uniforms.projectionMatrix) gl.uniformMatrix4fv(uniforms.projectionMatrix, false, camera.projectionMatrix.elements);
    if (uniforms.normalMatrix) {
      this._normalMat.getNormalMatrix(mvMat);
      gl.uniformMatrix3fv(uniforms.normalMatrix, false, this._normalMat.elements);
    }
    if (uniforms.cameraPosition) gl.uniform3f(uniforms.cameraPosition, camera.position.x, camera.position.y, camera.position.z);

    if (mat.isShaderMaterial) {
      let texUnit = 0;
      if (uniforms.uShadowMatrix) gl.uniformMatrix4fv(uniforms.uShadowMatrix, false, this._shadowMatrix.elements);
      if (uniforms.uHasShadowMap) gl.uniform1i(uniforms.uHasShadowMap, hasShadowMap ? 1 : 0);
      if (uniforms.tShadow) {
        gl.uniform1i(uniforms.tShadow, 7);
        this._bindTex(this._shadowRT ? this._shadowRT.texture : this._whiteTex, 7);
      }
      for (const uName of Object.keys(mat.uniforms)) {
        if (uName === "tShadow" || uName === "uShadowMatrix" || uName === "uHasShadowMap") continue;
        const loc = uniforms[uName];
        if (!loc) continue;
        const uEntry = mat.uniforms[uName];
        const val = (uEntry && typeof uEntry === 'object' && 'value' in uEntry) ? uEntry.value : uEntry;
        if (val === null || val === undefined || val.isTexture) {
          gl.uniform1i(loc, texUnit);
          this._bindTex(val, texUnit++);
        } else if (typeof val === 'number') gl.uniform1f(loc, val);
        else if (typeof val === 'boolean') gl.uniform1i(loc, val ? 1 : 0);
        else if (val.isVector2) gl.uniform2f(loc, val.x, val.y);
        else if (val.isVector3) gl.uniform3f(loc, val.x, val.y, val.z);
        else if (val.isColor) gl.uniform3f(loc, val.r, val.g, val.b);
        else if (val.isVector4 || val.isQuaternion) gl.uniform4f(loc, val.x, val.y, val.z, val.w);
        else if (val.isMatrix3) gl.uniformMatrix3fv(loc, false, val.elements);
        else if (val.isMatrix4) gl.uniformMatrix4fv(loc, false, val.elements);
        else if (val instanceof Float32Array) gl.uniform1fv(loc, val);
        else if (val instanceof Int32Array) gl.uniform1iv(loc, val);
        else if (Array.isArray(val) && val.length > 0) {
          const first = val[0];
          if (typeof first === 'number') {
            gl.uniform1fv(loc, new Float32Array(val));
          } else if (first && first.isVector2) {
            const flat = new Float32Array(val.length * 2);
            for (let ai = 0; ai < val.length; ai++) { flat[ai*2] = val[ai].x; flat[ai*2+1] = val[ai].y; }
            gl.uniform2fv(loc, flat);
          } else if (first && (first.isVector3 || first.isColor)) {
            const flat = new Float32Array(val.length * 3);
            for (let ai = 0; ai < val.length; ai++) {
              flat[ai*3]   = first.isColor ? val[ai].r : val[ai].x;
              flat[ai*3+1] = first.isColor ? val[ai].g : val[ai].y;
              flat[ai*3+2] = first.isColor ? val[ai].b : val[ai].z;
            }
            gl.uniform3fv(loc, flat);
          } else if (first && first.isVector4) {
            const flat = new Float32Array(val.length * 4);
            for (let ai = 0; ai < val.length; ai++) {
              flat[ai*4] = val[ai].x; flat[ai*4+1] = val[ai].y; flat[ai*4+2] = val[ai].z; flat[ai*4+3] = val[ai].w;
            }
            gl.uniform4fv(loc, flat);
          }
        }
      }
    } else if (isPts) {
      const col = mat.color || new Color(1, 1, 1);
      if (uniforms.uBaseColor) gl.uniform3f(uniforms.uBaseColor, col.r, col.g, col.b);
      if (uniforms.uPointSize) gl.uniform1f(uniforms.uPointSize, (mat.size !== undefined ? mat.size : 1.0) * this.pixelRatio);
      if (uniforms.uViewportHeight) gl.uniform1f(uniforms.uViewportHeight, this.domElement.height || 720);
      if (uniforms.uSizeAttenuation) gl.uniform1i(uniforms.uSizeAttenuation, mat.sizeAttenuation !== false ? 1 : 0);
      if (uniforms.uOpacity) gl.uniform1f(uniforms.uOpacity, mat.opacity !== undefined ? mat.opacity : 1.0);
      if (uniforms.uAlphaTest) gl.uniform1f(uniforms.uAlphaTest, mat.alphaTest || 0.0);
      if (uniforms.uUseVertexColors) gl.uniform1i(uniforms.uUseVertexColors, (mat.vertexColors || !!geo.attributes.color) ? 1 : 0);
      if (uniforms.uHasMap) gl.uniform1i(uniforms.uHasMap, mat.map ? 1 : 0);
      if (uniforms.uMap) { gl.uniform1i(uniforms.uMap, 0); this._bindTex(mat.map || this._whiteTex, 0); }
      if (scene.fog && mat.fog !== false) {
        if (uniforms.uUseFog) gl.uniform1i(uniforms.uUseFog, 1);
        if (uniforms.uFogColor) gl.uniform3f(uniforms.uFogColor, scene.fog.color.r, scene.fog.color.g, scene.fog.color.b);
        if (uniforms.uFogDensity) gl.uniform1f(uniforms.uFogDensity, scene.fog.density || 0.005);
      } else {
        if (uniforms.uUseFog) gl.uniform1i(uniforms.uUseFog, 0);
      }
    } else if (isShadowPass) {
      if (uniforms.uAlphaTest) gl.uniform1f(uniforms.uAlphaTest, mat.alphaTest || 0.0);
      if (uniforms.uHasMap) gl.uniform1i(uniforms.uHasMap, (mat.alphaTest > 0 && mat.map) ? 1 : 0);
      if (uniforms.uMap && mat.alphaTest > 0 && mat.map) {
        gl.uniform1i(uniforms.uMap, 0);
        this._bindTex(mat.map, 0);
      }
    } else {
      if (uniforms.uShadowMatrix) gl.uniformMatrix4fv(uniforms.uShadowMatrix, false, this._shadowMatrix.elements);
      const col = mat.color || new Color(1,1,1);
      const emis = mat.emissive || new Color(0,0,0);
      const attCol = mat.attenuationColor || new Color(1,1,1);
      if (uniforms.uBaseColor) gl.uniform3f(uniforms.uBaseColor, col.r, col.g, col.b);
      if (uniforms.uEmissive) gl.uniform3f(uniforms.uEmissive, emis.r, emis.g, emis.b);
      if (uniforms.uEmissiveIntensity) gl.uniform1f(uniforms.uEmissiveIntensity, mat.emissiveIntensity !== undefined ? mat.emissiveIntensity : 1.0);
      if (uniforms.uRoughness) gl.uniform1f(uniforms.uRoughness, mat.roughness !== undefined ? mat.roughness : 0.8);
      if (uniforms.uMetalness) gl.uniform1f(uniforms.uMetalness, mat.metalness !== undefined ? mat.metalness : 0.0);
      if (uniforms.uClearcoat) gl.uniform1f(uniforms.uClearcoat, mat.clearcoat || 0.0);
      if (uniforms.uTransmission) gl.uniform1f(uniforms.uTransmission, mat.transmission || 0.0);
      if (uniforms.uIOR) gl.uniform1f(uniforms.uIOR, mat.ior || 1.5);
      if (uniforms.uThickness) gl.uniform1f(uniforms.uThickness, mat.thickness !== undefined ? mat.thickness : 0.5);
      if (uniforms.uAttenuationColor) gl.uniform3f(uniforms.uAttenuationColor, attCol.r, attCol.g, attCol.b);
      if (uniforms.uEnvIntensity) gl.uniform1f(uniforms.uEnvIntensity, (mat.envMapIntensity !== undefined ? mat.envMapIntensity : 1.0) * (scene.environmentIntensity || 1.15));
      if (uniforms.uShadowEdgeBoost) gl.uniform1f(uniforms.uShadowEdgeBoost, this._shadowEdgeBoost !== undefined ? this._shadowEdgeBoost : 0.42);
      if (uniforms.uShadowEdgeSat) gl.uniform1f(uniforms.uShadowEdgeSat, this._shadowEdgeSat !== undefined ? this._shadowEdgeSat : 0.34);
      if (uniforms.uShadowDarkness) gl.uniform1f(uniforms.uShadowDarkness, this._shadowDarkness !== undefined ? this._shadowDarkness : 0.68);
      if (uniforms.uEnvPreset) gl.uniform1i(uniforms.uEnvPreset, this.envPreset || 0);
      {
        const presetPalette = [
          { h: [1.02, 0.82, 0.62], z: [0.30, 0.52, 0.84], g: [0.52, 0.36, 0.24] },
          { h: [0.96, 0.98, 1.00], z: [0.80, 0.85, 0.92], g: [0.44, 0.46, 0.50] },
          { h: [0.92, 0.95, 0.98], z: [0.74, 0.80, 0.88], g: [0.46, 0.44, 0.42] },
          { h: [0.24, 0.32, 0.48], z: [0.06, 0.10, 0.22], g: [0.12, 0.14, 0.18] }
        ][this.envPreset || 0] || { h: [0.9, 0.92, 0.95], z: [0.3, 0.4, 0.6], g: [0.2, 0.2, 0.2] };
        const ec = this.envColors;
        const hCol = (ec && ec.horizon) ? [ec.horizon.r, ec.horizon.g, ec.horizon.b] : presetPalette.h;
        const zCol = (ec && ec.zenith) ? [ec.zenith.r, ec.zenith.g, ec.zenith.b] : presetPalette.z;
        const gCol = (ec && ec.ground) ? [ec.ground.r, ec.ground.g, ec.ground.b] : presetPalette.g;
        if (uniforms.uEnvHorizon) gl.uniform3f(uniforms.uEnvHorizon, hCol[0], hCol[1], hCol[2]);
        if (uniforms.uEnvZenith)  gl.uniform3f(uniforms.uEnvZenith,  zCol[0], zCol[1], zCol[2]);
        if (uniforms.uEnvGround)  gl.uniform3f(uniforms.uEnvGround,  gCol[0], gCol[1], gCol[2]);
      }
      if (uniforms.uViewProj) gl.uniformMatrix4fv(uniforms.uViewProj, false, this._projViewMat.elements);
      if (uniforms.uHasTransmissionMap) gl.uniform1i(uniforms.uHasTransmissionMap, (hasTransmissionMap && (mat.transmission || 0) > 0.01) ? 1 : 0);
      if (uniforms.uTransmissionMap) {
        gl.uniform1i(uniforms.uTransmissionMap, 6);
        this._bindTex((hasTransmissionMap && this._transmissionRT) ? this._transmissionRT.texture : this._whiteTex, 6);
      }
      if (uniforms.uHasSpotShadowMap) gl.uniform1i(uniforms.uHasSpotShadowMap, hasSpotShadow ? 1 : 0);
      if (uniforms.uSpotShadowMatrix) gl.uniformMatrix4fv(uniforms.uSpotShadowMatrix, false, this._spotShadowMatrix.elements);
      if (uniforms.uSpotShadowMap) {
        gl.uniform1i(uniforms.uSpotShadowMap, 7);
        this._bindTex((hasSpotShadow && this._spotShadowRT) ? this._spotShadowRT.texture : this._whiteTex, 7);
      }
      if (uniforms.uHasPointShadow) gl.uniform1i(uniforms.uHasPointShadow, hasPointShadow ? 1 : 0);
      if (uniforms.uPointShadowPos) gl.uniform3f(uniforms.uPointShadowPos, this._pointShadowPos.x, this._pointShadowPos.y, this._pointShadowPos.z);
      if (uniforms.uPointShadowFar) gl.uniform1f(uniforms.uPointShadowFar, this._pointShadowFar || 25.0);
      if (uniforms.uPointShadowMap) {
        gl.uniform1i(uniforms.uPointShadowMap, 8);
        this._bindTex((hasPointShadow && this._pointShadowRT) ? this._pointShadowRT.texture : this._whiteTex, 8);
      }
      if (uniforms.uExposure) gl.uniform1f(uniforms.uExposure, this.toneMappingExposure !== undefined ? this.toneMappingExposure : 1.0);
      if (uniforms.uMetricUVScale) gl.uniform1f(uniforms.uMetricUVScale, mat.metricUVScale || 0.0);
      if (uniforms.uShadowSoftness) gl.uniform1f(uniforms.uShadowSoftness, (dirLight && dirLight.shadow && dirLight.shadow.radius) ? dirLight.shadow.radius : 1.55);
      if (uniforms.uShadowBias) gl.uniform1f(uniforms.uShadowBias, (dirLight && dirLight.shadow && dirLight.shadow.bias) ? dirLight.shadow.bias : 0.00045);
      if (uniforms.uOpacity) gl.uniform1f(uniforms.uOpacity, mat.opacity !== undefined ? mat.opacity : 1.0);
      if (uniforms.uAlphaTest) gl.uniform1f(uniforms.uAlphaTest, mat.alphaTest || 0.0);
      if (uniforms.uIsBasic) gl.uniform1i(uniforms.uIsBasic, (mat.isMeshBasicMaterial || mat.isLineBasicMaterial || mat.isSpriteMaterial) ? 1 : 0);
      if (uniforms.uIsNormalMat) gl.uniform1i(uniforms.uIsNormalMat, mat.isMeshNormalMaterial ? 1 : 0);
      if (uniforms.uIsShadowMat) gl.uniform1i(uniforms.uIsShadowMat, mat.isShadowMaterial ? 1 : 0);
      if (uniforms.uUseVertexColors) gl.uniform1i(uniforms.uUseVertexColors, (mat.vertexColors || isInst) ? 1 : 0);

      if (uniforms.uHasMap) gl.uniform1i(uniforms.uHasMap, mat.map ? 1 : 0);
      if (uniforms.uTexTargetFace) gl.uniform1i(uniforms.uTexTargetFace, mat.texTargetFace || 0);
      if (uniforms.uIsExternalTex) gl.uniform1i(uniforms.uIsExternalTex, mat.isExternalTex ? 1 : 0);
      if (uniforms.uTexBlendMode) gl.uniform1i(uniforms.uTexBlendMode, mat.texBlendMode || 0);
      if (uniforms.uMapRepeat) {
        const rep = (mat.map && mat.map.repeat) ? mat.map.repeat : { x: 1, y: 1 };
        gl.uniform2f(uniforms.uMapRepeat, rep.x, rep.y);
      }
      if (uniforms.uMap) { gl.uniform1i(uniforms.uMap, 0); this._bindTex(mat.map || this._whiteTex, 0); }
      if (uniforms.uHasRoughMap) gl.uniform1i(uniforms.uHasRoughMap, mat.roughnessMap ? 1 : 0);
      if (uniforms.uRoughMap) { gl.uniform1i(uniforms.uRoughMap, 1); this._bindTex(mat.roughnessMap || this._whiteTex, 1); }
      if (uniforms.uHasNormalMap) gl.uniform1i(uniforms.uHasNormalMap, mat.normalMap ? 1 : 0);
      if (uniforms.uNormalScale) {
        const ns = mat.normalScale || { x: 1, y: 1 };
        gl.uniform2f(uniforms.uNormalScale, ns.x, ns.y);
      }
      let skipPom = !!this._inReflectionPass || (mesh.userData && mesh.userData._shaderTier === 'fast');
      if (!skipPom && mesh.userData && mesh.userData._pomCullDistance > 0) {
        const mw = mesh.matrixWorld.elements;
        const dist = Math.hypot(mw[12] - camera.position.x, mw[13] - camera.position.y, mw[14] - camera.position.z);
        if (dist > mesh.userData._pomCullDistance) skipPom = true;
      }
      if (uniforms.uParallaxScale) gl.uniform1f(uniforms.uParallaxScale, skipPom ? 0.0 : (mat.parallaxScale || 0.0));
      if (uniforms.uInteriorDepth) gl.uniform1f(uniforms.uInteriorDepth, skipPom ? 0.0 : (mat.interiorDepth || 0.0));
      if (uniforms.uNormalMap) { gl.uniform1i(uniforms.uNormalMap, 2); this._bindTex(mat.normalMap || this._flatNormTex, 2); }
      if (uniforms.uHasEmissiveMap) gl.uniform1i(uniforms.uHasEmissiveMap, mat.emissiveMap ? 1 : 0);
      if (uniforms.uEmissiveMap) { gl.uniform1i(uniforms.uEmissiveMap, 3); this._bindTex(mat.emissiveMap || this._whiteTex, 3); }
      if (uniforms.uHasShadowMap) gl.uniform1i(uniforms.uHasShadowMap, (hasShadowMap && mesh.receiveShadow) ? 1 : 0);
      if (uniforms.uShadowMap) {
        gl.uniform1i(uniforms.uShadowMap, 4);
        this._bindTex(this._shadowRT ? this._shadowRT.texture : this._whiteTex, 4);
      }
      const envTex = mat.envMap || scene.environment || null;
      if (uniforms.uHasEnvMap) gl.uniform1i(uniforms.uHasEnvMap, (envTex && envTex.isPMREM) ? 1 : 0);
      if (uniforms.uEnvMap) {
        gl.uniform1i(uniforms.uEnvMap, 5);
        this._bindTex(envTex || this._whiteTex, 5);
      }

      if (dirLight) {
        const sd = this._sunDirVec.subVectors(dirLight.position, dirLight.target.position).normalize();
        if (uniforms.uSunDir) gl.uniform3f(uniforms.uSunDir, sd.x, sd.y, sd.z);
        if (uniforms.uSunCol) gl.uniform3f(uniforms.uSunCol, dirLight.color.r, dirLight.color.g, dirLight.color.b);
        if (uniforms.uSunIntensity) gl.uniform1f(uniforms.uSunIntensity, dirLight.intensity);
      } else {
        if (uniforms.uSunDir) gl.uniform3f(uniforms.uSunDir, 0.2, 0.8, 0.5);
        if (uniforms.uSunCol) gl.uniform3f(uniforms.uSunCol, 1, 0.95, 0.9);
        if (uniforms.uSunIntensity) gl.uniform1f(uniforms.uSunIntensity, 2.5);
      }
      if (hemiLight) {
        if (uniforms.uHemiSky) gl.uniform3f(uniforms.uHemiSky, hemiLight.color.r, hemiLight.color.g, hemiLight.color.b);
        if (uniforms.uHemiGround) gl.uniform3f(uniforms.uHemiGround, hemiLight.groundColor.r, hemiLight.groundColor.g, hemiLight.groundColor.b);
        if (uniforms.uHemiIntensity) gl.uniform1f(uniforms.uHemiIntensity, hemiLight.intensity);
      } else {
        if (uniforms.uHemiSky) gl.uniform3f(uniforms.uHemiSky, 0.6, 0.7, 0.85);
        if (uniforms.uHemiGround) gl.uniform3f(uniforms.uHemiGround, 0.3, 0.25, 0.2);
        if (uniforms.uHemiIntensity) gl.uniform1f(uniforms.uHemiIntensity, 0.4);
      }
      if (uniforms.uPointLightCount) {
        const nPL = pointLights ? Math.min(16, pointLights.length) : 0;
        gl.uniform1i(uniforms.uPointLightCount, nPL);
        if (nPL > 0) {
          const posArr = this._plPosArr;
          const colArr = this._plColArr;
          const parArr = this._plParArr;
          for (let pi = 0; pi < nPL; pi++) {
            const pl = pointLights[pi];
            const mw = pl.matrixWorld.elements;
            posArr[pi * 3]     = mw[12];
            posArr[pi * 3 + 1] = mw[13];
            posArr[pi * 3 + 2] = mw[14];
            colArr[pi * 3]     = pl.color.r;
            colArr[pi * 3 + 1] = pl.color.g;
            colArr[pi * 3 + 2] = pl.color.b;
            parArr[pi * 2]     = pl.intensity;
            parArr[pi * 2 + 1] = pl.distance || 15.0;
          }
          if (uniforms.uPointLightPos) gl.uniform3fv(uniforms.uPointLightPos, posArr);
          if (uniforms.uPointLightCol) gl.uniform3fv(uniforms.uPointLightCol, colArr);
          if (uniforms.uPointLightParam) gl.uniform2fv(uniforms.uPointLightParam, parArr);
        }
      }
      if (uniforms.uSpotLightCount) {
        const nSL = spotLights ? Math.min(8, spotLights.length) : 0;
        gl.uniform1i(uniforms.uSpotLightCount, nSL);
        if (nSL > 0) {
          const posArr = this._slPosArr;
          const dirArr = this._slDirArr;
          const colArr = this._slColArr;
          const parArr = this._slParArr;
          for (let si = 0; si < nSL; si++) {
            const sl = spotLights[si];
            const mw = sl.matrixWorld.elements;
            const sx = mw[12], sy = mw[13], sz = mw[14];
            posArr[si * 3] = sx; posArr[si * 3 + 1] = sy; posArr[si * 3 + 2] = sz;
            let tx = 0, ty = 0, tz = 0;
            if (sl.target) {
              if (sl.target.parent) {
                sl.target.updateMatrixWorld(false);
                const tmw = sl.target.matrixWorld.elements;
                tx = tmw[12]; ty = tmw[13]; tz = tmw[14];
              } else {
                tx = sl.target.position.x; ty = sl.target.position.y; tz = sl.target.position.z;
              }
            }
            let dx = tx - sx, dy = ty - sy, dz = tz - sz;
            const dl = Math.hypot(dx, dy, dz) || 1;
            dirArr[si * 3] = dx / dl; dirArr[si * 3 + 1] = dy / dl; dirArr[si * 3 + 2] = dz / dl;
            colArr[si * 3] = sl.color.r; colArr[si * 3 + 1] = sl.color.g; colArr[si * 3 + 2] = sl.color.b;
            const angle = sl.angle !== undefined ? sl.angle : Math.PI / 4;
            const pen = MathUtils.clamp(sl.penumbra !== undefined ? sl.penumbra : 0.25, 0, 1);
            const cosOuter = Math.cos(angle);
            const cosInner = Math.cos(angle * (1.0 - pen));
            parArr[si * 4]     = sl.intensity !== undefined ? sl.intensity : 1.0;
            parArr[si * 4 + 1] = sl.distance || 30.0;
            parArr[si * 4 + 2] = cosOuter;
            parArr[si * 4 + 3] = cosInner;
          }
          if (uniforms.uSpotLightPos) gl.uniform3fv(uniforms.uSpotLightPos, posArr);
          if (uniforms.uSpotLightDir) gl.uniform3fv(uniforms.uSpotLightDir, dirArr);
          if (uniforms.uSpotLightCol) gl.uniform3fv(uniforms.uSpotLightCol, colArr);
          if (uniforms.uSpotLightParam) gl.uniform4fv(uniforms.uSpotLightParam, parArr);
        }
      }
      if (scene.fog && mat.fog !== false) {
        if (uniforms.uUseFog) gl.uniform1i(uniforms.uUseFog, 1);
        if (uniforms.uFogColor) gl.uniform3f(uniforms.uFogColor, scene.fog.color.r, scene.fog.color.g, scene.fog.color.b);
        if (uniforms.uFogDensity) gl.uniform1f(uniforms.uFogDensity, scene.fog.density || 0.005);
      } else {
        if (uniforms.uUseFog) gl.uniform1i(uniforms.uUseFog, 0);
      }
      if (uniforms.uDebugMode) gl.uniform1i(uniforms.uDebugMode, mat.isMeshBasicMaterial ? 0 : (this.debugMode || 0));
      if (uniforms.uSelectedHighlight) gl.uniform1i(uniforms.uSelectedHighlight, mesh.userData && mesh.userData._isSelected ? 1 : 0);
      if (uniforms.uHoveredHighlight) gl.uniform1i(uniforms.uHoveredHighlight, mesh.userData && mesh.userData._isHovered ? 1 : 0);
      if (this._inReflectionPass && this._reflectionClipPlane) {
        if (uniforms.uUseClipPlane) gl.uniform1i(uniforms.uUseClipPlane, 2);
        if (uniforms.uClipPlane) gl.uniform4f(uniforms.uClipPlane, this._reflectionClipPlane[0], this._reflectionClipPlane[1], this._reflectionClipPlane[2], this._reflectionClipPlane[3]);
      } else {
        if (uniforms.uUseClipPlane) gl.uniform1i(uniforms.uUseClipPlane, (this.useClipPlane && !mat.isMeshBasicMaterial) ? 1 : 0);
        if (uniforms.uClipPlane && this.clipPlane) gl.uniform4f(uniforms.uClipPlane, this.clipPlane.x, this.clipPlane.y, this.clipPlane.z, this.clipPlane.w);
      }
    }

    const setDiv = (loc, d) => {
      if (this.isWebGL2) gl.vertexAttribDivisor(loc, d);
      else if (this.extInst) this.extInst.vertexAttribDivisorANGLE(loc, d);
    };

    const getGLAttrType = (arr) => {
      if (arr instanceof Uint16Array) return gl.UNSIGNED_SHORT;
      if (arr instanceof Int16Array) return gl.SHORT;
      if (arr instanceof Uint8Array || arr instanceof Uint8ClampedArray) return gl.UNSIGNED_BYTE;
      if (arr instanceof Int8Array) return gl.BYTE;
      if (arr instanceof Uint32Array) return gl.UNSIGNED_INT;
      if (arr instanceof Int32Array) return gl.INT;
      return gl.FLOAT;
    };

    // Dynamically bind ALL vertex attributes declared in the active shader program!
    const enabled = [];
    for (const aName of Object.keys(attribs)) {
      if (aName.startsWith('instanceMatrix') || aName === 'instanceColor') continue;
      const loc = attribs[aName];
      if (loc === undefined || loc < 0) continue;
      const attr = geo.attributes[aName];
      if (attr && attr.array) {
        this._bindAttr(attr, gl.ARRAY_BUFFER);
        gl.enableVertexAttribArray(loc);
        gl.vertexAttribPointer(loc, attr.itemSize, getGLAttrType(attr.array), !!attr.normalized, 0, 0);
        setDiv(loc, attr.isInstancedBufferAttribute ? (attr.meshPerAttribute || 1) : 0);
        enabled.push(loc);
      } else {
        gl.disableVertexAttribArray(loc);
        if (aName === 'color') gl.vertexAttrib3f(loc, 1, 1, 1);
        else if (aName === 'normal') gl.vertexAttrib3f(loc, 0, 1, 0);
        else if (aName === 'uv') gl.vertexAttrib2f(loc, 0, 0);
        else if (aName === 'size') gl.vertexAttrib1f(loc, 0);
        else gl.vertexAttrib4f(loc, 0, 0, 0, 1);
      }
    }

    if (isInst) {
      this._bindAttr(mesh.instanceMatrix, gl.ARRAY_BUFFER);
      for (let c = 0; c < 4; c++) {
        const loc = attribs['instanceMatrix' + c];
        if (loc !== undefined && loc >= 0) {
          gl.enableVertexAttribArray(loc);
          gl.vertexAttribPointer(loc, 4, gl.FLOAT, false, 64, c * 16);
          setDiv(loc, 1);
          enabled.push(loc);
        }
      }
      const cLoc = attribs['instanceColor'];
      if (cLoc !== undefined && cLoc >= 0) {
        if (mesh.instanceColor) {
          this._bindAttr(mesh.instanceColor, gl.ARRAY_BUFFER);
          gl.enableVertexAttribArray(cLoc);
          gl.vertexAttribPointer(cLoc, 3, gl.FLOAT, false, 0, 0);
          setDiv(cLoc, 1);
          enabled.push(cLoc);
        } else {
          gl.disableVertexAttribArray(cLoc);
          gl.vertexAttrib3f(cLoc, 1, 1, 1);
        }
      }
    }

    this.info.render.calls++;
    const isLine = !!(mesh.isLineSegments || mesh.isLine || mesh.isLineLoop || mat.wireframe || this.forceWireframe);
    const primMode = isPts ? gl.POINTS : (mesh.isLineLoop ? gl.LINE_LOOP : (mesh.isLine ? gl.LINE_STRIP : (isLine ? gl.LINES : gl.TRIANGLES)));
    if (geo.index && !isPts) {
      if (isLine && !mesh.isLineSegments && !mesh.isLine && !mesh.isLineLoop) {
        if (!geo._wireIndex) {
          const src = geo.index.array;
          const wArr = new Uint32Array(src.length * 2);
          let wp = 0;
          for (let i = 0; i < src.length; i += 3) {
            wArr[wp++] = src[i]; wArr[wp++] = src[i+1];
            wArr[wp++] = src[i+1]; wArr[wp++] = src[i+2];
            wArr[wp++] = src[i+2]; wArr[wp++] = src[i];
          }
          geo._wireIndex = new BufferAttribute(wArr, 1);
        }
        this._bindAttr(geo._wireIndex, gl.ELEMENT_ARRAY_BUFFER);
        gl.drawElements(gl.LINES, geo._wireIndex.count, gl.UNSIGNED_INT, 0);
      } else {
        this._bindAttr(geo.index, gl.ELEMENT_ARRAY_BUFFER);
        const count = geo.index.count;
        const type = (geo.index.array instanceof Uint32Array) ? gl.UNSIGNED_INT : (geo.index.array instanceof Uint8Array ? gl.UNSIGNED_BYTE : gl.UNSIGNED_SHORT);
        if (isInst) {
          this.info.render.triangles += (count / 3) * mesh.count;
          if (this.isWebGL2) gl.drawElementsInstanced(primMode, count, type, 0, mesh.count);
          else if (this.extInst) this.extInst.drawElementsInstancedANGLE(primMode, count, type, 0, mesh.count);
        } else {
          if (!isLine) this.info.render.triangles += count / 3;
          else this.info.render.lines += count / 2;
          gl.drawElements(primMode, count, type, 0);
        }
      }
    } else {
      const count = geo.attributes.position.count;
      if (isInst) {
        if (isPts) this.info.render.points += count * mesh.count;
        else this.info.render.triangles += (count / 3) * mesh.count;
        if (this.isWebGL2) gl.drawArraysInstanced(primMode, 0, count, mesh.count);
        else if (this.extInst) this.extInst.drawArraysInstancedANGLE(primMode, 0, count, mesh.count);
      } else {
        if (isPts) this.info.render.points += count;
        else if (!isLine) this.info.render.triangles += count / 3;
        else this.info.render.lines += count / 2;
        gl.drawArrays(primMode, 0, count);
      }
    }

    for (let i = 0; i < enabled.length; i++) {
      setDiv(enabled[i], 0);
      gl.disableVertexAttribArray(enabled[i]);
    }
  }
}

// BufferGeometryUtils
function mergeGeometries(geos, useGroups = false) {
  if (!geos || !geos.length) return null;
  const isIndexed = !!geos[0].index;
  let totalVerts = 0, totalIdx = 0;
  for (let i = 0; i < geos.length; i++) {
    const g = geos[i];
    if (!g || !g.attributes.position) continue;
    totalVerts += g.attributes.position.count;
    if (isIndexed && g.index) totalIdx += g.index.count;
  }
  const out = new BufferGeometry();
  const keys = Object.keys(geos[0].attributes);
  for (const k of keys) {
    const itemSize = geos[0].attributes[k].itemSize;
    const arr = new Float32Array(totalVerts * itemSize);
    let offset = 0;
    for (let i = 0; i < geos.length; i++) {
      const a = geos[i].attributes[k];
      if (a) {
        arr.set(a.array, offset);
        offset += a.array.length;
      } else {
        offset += geos[i].attributes.position.count * itemSize;
      }
    }
    out.setAttribute(k, new Float32BufferAttribute(arr, itemSize));
  }
  if (isIndexed) {
    const idxArr = new Uint32Array(totalIdx);
    let iOffset = 0, vOffset = 0;
    for (let i = 0; i < geos.length; i++) {
      const g = geos[i];
      const srcIdx = g.index.array;
      const n = srcIdx.length;
      for (let j = 0; j < n; j++) {
        idxArr[iOffset + j] = srcIdx[j] + vOffset;
      }
      iOffset += n;
      vOffset += g.attributes.position.count;
    }
    out.setIndex(idxArr);
  }
  return out;
}
function mergeVertices(g) { return g; }
function toCreasedNormals(g) { return g; }

// Post-processing Addons
class RenderPass {
  constructor(scene, camera) { this.scene = scene; this.camera = camera; this.enabled = true; this.needsSwap = false; }
  setSize(w, h) {}
  render(renderer, writeBuffer, readBuffer) {
    renderer.setRenderTarget(readBuffer);
    renderer.clear(true, true);
    renderer.render(this.scene, this.camera);
  }
}

class ShaderPass {
  constructor(shader, textureID = 'tDiffuse') {
    this.textureID = textureID;
    this.enabled = true;
    this.needsSwap = true;
    this.uniforms = {};
    for (const k of Object.keys(shader.uniforms || {})) {
      const v = shader.uniforms[k].value;
      this.uniforms[k] = { value: (v && v.clone) ? v.clone() : v };
    }
    this.material = new ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: shader.vertexShader,
      fragmentShader: shader.fragmentShader,
      depthTest: false,
      depthWrite: false
    });
    this.fsScene = new Scene();
    this.fsCam = new OrthographicCamera(-1, 1, 1, -1, 0, 1);
    this.fsScene.add(new Mesh(new PlaneGeometry(2, 2), this.material));
  }
  setSize(w, h) {}
  render(renderer, writeBuffer, readBuffer, renderToScreen) {
    if (this.uniforms[this.textureID]) this.uniforms[this.textureID].value = readBuffer.texture;
    renderer.setRenderTarget(renderToScreen ? null : writeBuffer);
    renderer.render(this.fsScene, this.fsCam);
  }
}

class BokehPass {
  constructor(scene, camera, params = {}) {
    this.scene = scene;
    this.camera = camera;
    this.enabled = true;
    this.needsSwap = true;
    this.pass = new ShaderPass({
      uniforms: {
        tDiffuse: { value: null },
        uMaxBlur: { value: params.maxblur || 0.002 }
      },
      vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`,
      fragmentShader: `
        precision highp float;
        uniform sampler2D tDiffuse;
        uniform float uMaxBlur;
        varying vec2 vUv;
        void main(){
          vec2 d = vUv - 0.5;
          float b = smoothstep(0.18, 0.85, length(d)) * uMaxBlur * 0.45;
          vec3 c = texture2D(tDiffuse, vUv).rgb * 0.5;
          c += texture2D(tDiffuse, vUv + vec2(b, 0.0)).rgb * 0.125;
          c += texture2D(tDiffuse, vUv - vec2(b, 0.0)).rgb * 0.125;
          c += texture2D(tDiffuse, vUv + vec2(0.0, b)).rgb * 0.125;
          c += texture2D(tDiffuse, vUv - vec2(0.0, b)).rgb * 0.125;
          gl_FragColor = vec4(c, 1.0);
        }
      `
    });
  }
  setSize(w, h) {}
  render(renderer, writeBuffer, readBuffer, renderToScreen) {
    this.pass.render(renderer, writeBuffer, readBuffer, renderToScreen);
  }
}

class UnrealBloomPass {
  constructor(resolution, strength = 0.2, radius = 0.4, threshold = 2.0) {
    this.enabled = true;
    this.needsSwap = true;
    this.strength = strength;
    this.radius = radius;
    this.threshold = threshold;
    this.pass = new ShaderPass({
      uniforms: {
        tDiffuse: { value: null },
        uStrength: { value: strength },
        uThreshold: { value: threshold }
      },
      vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`,
      fragmentShader: `
        precision highp float;
        uniform sampler2D tDiffuse;
        uniform float uStrength, uThreshold;
        varying vec2 vUv;
        vec3 bright(vec3 c){
          float l = max(c.r, max(c.g, c.b));
          return c * max(0.0, l - uThreshold * 0.45) / max(l, 0.001);
        }
        vec3 ringSample(vec2 uv, float r) {
          vec3 s = vec3(0.0);
          float d = r * 0.7071;
          s += bright(texture2D(tDiffuse, clamp(uv + vec2( r, 0.0), 0.001, 0.999)).rgb);
          s += bright(texture2D(tDiffuse, clamp(uv + vec2(-r, 0.0), 0.001, 0.999)).rgb);
          s += bright(texture2D(tDiffuse, clamp(uv + vec2(0.0,  r), 0.001, 0.999)).rgb);
          s += bright(texture2D(tDiffuse, clamp(uv + vec2(0.0, -r), 0.001, 0.999)).rgb);
          s += bright(texture2D(tDiffuse, clamp(uv + vec2( d,  d), 0.001, 0.999)).rgb);
          s += bright(texture2D(tDiffuse, clamp(uv + vec2(-d,  d), 0.001, 0.999)).rgb);
          s += bright(texture2D(tDiffuse, clamp(uv + vec2( d, -d), 0.001, 0.999)).rgb);
          s += bright(texture2D(tDiffuse, clamp(uv + vec2(-d, -d), 0.001, 0.999)).rgb);
          return s * 0.125;
        }
        void main(){
          vec3 base = texture2D(tDiffuse, vUv).rgb;
          vec3 bl = ringSample(vUv, 0.0038) * 0.50
                  + ringSample(vUv, 0.0115) * 0.34
                  + ringSample(vUv, 0.0250) * 0.22;
          gl_FragColor = vec4(base + bl * uStrength, 1.0);
        }
      `
    });
  }
  setSize(w, h) {}
  render(renderer, writeBuffer, readBuffer, renderToScreen) {
    this.pass.uniforms.uStrength.value = this.strength;
    this.pass.uniforms.uThreshold.value = this.threshold;
    this.pass.render(renderer, writeBuffer, readBuffer, renderToScreen);
  }
}

class EffectComposer {
  constructor(renderer, renderTarget) {
    this.renderer = renderer;
    const w = renderTarget ? renderTarget.width : renderer.domElement.width;
    const h = renderTarget ? renderTarget.height : renderer.domElement.height;
    this.rt1 = renderTarget || new WebGLRenderTarget(w, h);
    this.rt2 = new WebGLRenderTarget(w, h);
    this.writeBuffer = this.rt1;
    this.readBuffer = this.rt2;
    this.passes = [];
  }
  addPass(pass) { this.passes.push(pass); }
  setSize(w, h) {
    this.rt1.setSize(w, h);
    this.rt2.setSize(w, h);
    for (const p of this.passes) if (p.setSize) p.setSize(w, h);
  }
  swapBuffers() {
    const tmp = this.readBuffer;
    this.readBuffer = this.writeBuffer;
    this.writeBuffer = tmp;
  }
  render() {
    const active = this.passes.filter(p => p.enabled !== false);
    for (let i = 0; i < active.length; i++) {
      const pass = active[i];
      const isLast = (i === active.length - 1);
      pass.render(this.renderer, this.writeBuffer, this.readBuffer, isLast);
      if (pass.needsSwap) this.swapBuffers();
    }
  }
}


class AmbientLight extends HemisphereLight {
  constructor(color = 0xffffff, intensity = 1) {
    super(color, color, intensity);
    this.isAmbientLight = true;
  }
}

class PointLight extends Object3D {
  constructor(color = 0xffffff, intensity = 1, distance = 0, decay = 2) {
    super();
    this.isLight = true;
    this.isPointLight = true;
    this.color = new Color(color);
    this.intensity = intensity;
    this.distance = distance;
    this.decay = decay;
  }
}

class SpotLight extends DirectionalLight {
  constructor(color = 0xffffff, intensity = 1, distance = 0, angle = Math.PI / 3, penumbra = 0, decay = 2) {
    super(color, intensity);
    this.isSpotLight = true;
    this.distance = distance;
    this.angle = angle;
    this.penumbra = penumbra;
    this.decay = decay;
  }
}

class LineBasicMaterial extends MeshBasicMaterial {
  constructor(params = {}) {
    super(params);
    this.isLineBasicMaterial = true;
  }
}

class LineSegments extends Mesh {
  constructor(geometry, material) {
    super(geometry, material || new LineBasicMaterial({ color: 0x00f0ff }));
    this.isLineSegments = true;
  }
}

class Line extends Mesh {
  constructor(geometry, material) {
    super(geometry, material || new LineBasicMaterial({ color: 0x00f0ff }));
    this.isLine = true;
  }
}

class RingGeometry extends BufferGeometry {
  constructor(innerRadius = 0.5, outerRadius = 1, thetaSegments = 32) {
    super();
    const segs = Math.max(3, thetaSegments);
    const pos = [], norm = [], uv = [], indices = [];
    for (let j = 0; j <= 1; j++) {
      const r = j === 0 ? innerRadius : outerRadius;
      for (let i = 0; i <= segs; i++) {
        const u = (i / segs) * Math.PI * 2;
        const x = r * Math.cos(u), y = r * Math.sin(u);
        pos.push(x, y, 0);
        norm.push(0, 0, 1);
        uv.push((x / outerRadius + 1) * 0.5, (y / outerRadius + 1) * 0.5);
      }
    }
    for (let i = 0; i < segs; i++) {
      const a = i, b = i + segs + 1, c = i + segs + 2, d = i + 1;
      indices.push(a, b, d, b, c, d);
    }
    this.setAttribute('position', new Float32BufferAttribute(pos, 3));
    this.setAttribute('normal', new Float32BufferAttribute(norm, 3));
    this.setAttribute('uv', new Float32BufferAttribute(uv, 2));
    this.setIndex(indices);
  }
}

class Raycaster {
  constructor() {
    this.rayOrigin = new Vector3();
    this.rayDir = new Vector3(0, 0, -1);
  }
  setFromCamera(coords, camera) {
    camera.updateMatrixWorld();
    this.rayOrigin.set(
      camera.matrixWorld.elements[12],
      camera.matrixWorld.elements[13],
      camera.matrixWorld.elements[14]
    );
    const invProj = camera.projectionMatrixInverse;
    const vx = coords.x, vy = coords.y, vz = 0.5;
    const p = new Vector3(vx, vy, vz).applyMatrix4(invProj).applyMatrix4(camera.matrixWorld);
    this.rayDir.subVectors(p, this.rayOrigin).normalize();
  }
  intersectObjects(objects, recursive = true) {
    const hits = [];
    const visit = (obj) => {
      if (!obj || !obj.visible || obj.userData._isHelper) return;
      if (obj.isMesh && !obj.isLineSegments && !obj.isLine && obj.geometry && obj.geometry.attributes.position) {
        this._intersectMesh(obj, hits);
      }
      if (recursive && obj.children) {
        for (let i = 0; i < obj.children.length; i++) visit(obj.children[i]);
      }
    };
    for (let i = 0; i < objects.length; i++) visit(objects[i]);
    hits.sort((a, b) => a.distance - b.distance);
    return hits;
  }
  _intersectMesh(mesh, hits) {
    const geo = mesh.geometry;
    const pos = geo.attributes.position;
    if (!pos) return;
    const invMat = new Matrix4().copy(mesh.matrixWorld).invert();
    const localOrig = this.rayOrigin.clone().applyMatrix4(invMat);
    const localEnd = this.rayOrigin.clone().add(this.rayDir).applyMatrix4(invMat);
    const localDir = new Vector3().subVectors(localEnd, localOrig).normalize();

    if (!geo.boundingSphere) geo.computeBoundingSphere();
    if (geo.boundingSphere && geo.boundingSphere.radius > 0) {
      const oc = new Vector3().subVectors(geo.boundingSphere.center, localOrig);
      const tca = oc.dot(localDir);
      const d2 = oc.dot(oc) - tca * tca;
      const r = geo.boundingSphere.radius * 1.15;
      if (d2 > r * r) return;
    }

    const idx = geo.index ? geo.index.array : null;
    const pArr = pos.array;
    const nTri = idx ? idx.length : pos.count;
    const v0 = new Vector3(), v1 = new Vector3(), v2 = new Vector3();
    const edge1 = new Vector3(), edge2 = new Vector3(), h = new Vector3(), s = new Vector3(), q = new Vector3();

    let bestT = Infinity, bestFace = -1, bestU = 0, bestV = 0;
    for (let i = 0; i < nTri; i += 3) {
      const i0 = (idx ? idx[i] : i) * 3;
      const i1 = (idx ? idx[i+1] : i+1) * 3;
      const i2 = (idx ? idx[i+2] : i+2) * 3;
      v0.set(pArr[i0], pArr[i0+1], pArr[i0+2]);
      v1.set(pArr[i1], pArr[i1+1], pArr[i1+2]);
      v2.set(pArr[i2], pArr[i2+1], pArr[i2+2]);
      edge1.subVectors(v1, v0);
      edge2.subVectors(v2, v0);
      h.crossVectors(localDir, edge2);
      const a = edge1.dot(h);
      if (Math.abs(a) < 1e-7) continue;
      const f = 1.0 / a;
      s.subVectors(localOrig, v0);
      const u = f * s.dot(h);
      if (u < 0.0 || u > 1.0) continue;
      q.crossVectors(s, edge1);
      const v = f * localDir.dot(q);
      if (v < 0.0 || u + v > 1.0) continue;
      const t = f * edge2.dot(q);
      if (t > 1e-4 && t < bestT) {
        bestT = t;
        bestFace = Math.floor(i / 3);
        bestU = u;
        bestV = v;
      }
    }
    if (bestT < Infinity) {
      const localHit = localOrig.clone().addScaledVector(localDir, bestT);
      const worldHit = localHit.clone().applyMatrix4(mesh.matrixWorld);
      const dist = this.rayOrigin.distanceTo(worldHit);
      const f0 = (idx ? idx[bestFace * 3] : bestFace * 3) * 3;
      const f1 = (idx ? idx[bestFace * 3 + 1] : bestFace * 3 + 1) * 3;
      const f2 = (idx ? idx[bestFace * 3 + 2] : bestFace * 3 + 2) * 3;
      v0.set(pArr[f0], pArr[f0+1], pArr[f0+2]);
      v1.set(pArr[f1], pArr[f1+1], pArr[f1+2]);
      v2.set(pArr[f2], pArr[f2+1], pArr[f2+2]);
      edge1.subVectors(v1, v0);
      edge2.subVectors(v2, v0);
      const faceNorm = new Vector3().crossVectors(edge1, edge2).transformDirection(mesh.matrixWorld);
      let hitUv = new Vector2(bestU, bestV);
      if (geo.attributes.uv) {
        const uvAttr = geo.attributes.uv;
        const u0i = idx ? idx[bestFace * 3] : bestFace * 3;
        const u1i = idx ? idx[bestFace * 3 + 1] : bestFace * 3 + 1;
        const u2i = idx ? idx[bestFace * 3 + 2] : bestFace * 3 + 2;
        const w0 = 1 - bestU - bestV;
        hitUv.set(
          uvAttr.getX(u0i) * w0 + uvAttr.getX(u1i) * bestU + uvAttr.getX(u2i) * bestV,
          uvAttr.getY(u0i) * w0 + uvAttr.getY(u1i) * bestU + uvAttr.getY(u2i) * bestV
        );
      }
      hits.push({
        distance: dist,
        point: worldHit,
        normal: faceNorm,
        uv: hitUv,
        faceIndex: bestFace,
        object: mesh
      });
    }
  }
}


class TextureLoader {
  constructor() {}
  load(url, onLoad, onProgress, onError) {
    const cv = document.createElement('canvas');
    cv.width = 512;
    cv.height = 512;
    const ctx = cv.getContext('2d');
    ctx.fillStyle = '#181820';
    ctx.fillRect(0, 0, 512, 512);
    const tex = new CanvasTexture(cv);
    tex.wrapS = ClampToEdgeWrapping;
    tex.wrapT = ClampToEdgeWrapping;
    tex.generateMipmaps = true;
    if (typeof url === 'string' && url.length > 0) {
      const img = new Image();
      if (!url.startsWith('data:')) img.crossOrigin = 'anonymous';
      img.onload = () => {
        const nextPow2 = (v) => Math.min(1024, Math.max(64, Math.pow(2, Math.round(Math.log2(v || 512)))));
        cv.width = nextPow2(img.naturalWidth || img.width || 512);
        cv.height = nextPow2(img.naturalHeight || img.height || 512);
        ctx.clearRect(0, 0, cv.width, cv.height);
        ctx.drawImage(img, 0, 0, cv.width, cv.height);
        tex.needsUpdate = true;
        if (onLoad) onLoad(tex);
      };
      img.onerror = (err) => {
        if (onError) onError(err);
      };
      img.src = url;
    }
    return tex;
  }
}


function _getWaterNormalTex() {
  if (WetFloorReflector._waterNormTex) return WetFloorReflector._waterNormTex;
  const N = 256;
  const cv = document.createElement('canvas');
  cv.width = N; cv.height = N;
  const ctx = cv.getContext('2d');
  const img = ctx.createImageData(N, N);
  const d = img.data;
  const hash2 = (ix, iy, p) => {
    const wx = ((ix % p) + p) % p, wy = ((iy % p) + p) % p;
    let n = Math.sin(wx * 127.1 + wy * 311.7 + p * 17.3) * 43758.5453123;
    return n - Math.floor(n);
  };
  const vnoise = (u, v, p) => {
    const x = u * p, y = v * p;
    const ix = Math.floor(x), iy = Math.floor(y);
    const fx = x - ix, fy = y - iy;
    const ux = fx * fx * (3 - 2 * fx), uy = fy * fy * (3 - 2 * fy);
    return (hash2(ix, iy, p) * (1 - ux) + hash2(ix + 1, iy, p) * ux) * (1 - uy) +
           (hash2(ix, iy + 1, p) * (1 - ux) + hash2(ix + 1, iy + 1, p) * ux) * uy;
  };
  const hBuf = new Float32Array(N * N);
  for (let y = 0; y < N; y++) {
    for (let x = 0; x < N; x++) {
      const u = x / N, v = y / N;
      hBuf[y * N + x] = vnoise(u, v, 4) * 0.50 + vnoise(u, v, 8) * 0.28 + vnoise(u, v, 16) * 0.14 + vnoise(u, v, 32) * 0.08;
    }
  }
  for (let y = 0; y < N; y++) {
    for (let x = 0; x < N; x++) {
      const h = hBuf[y * N + x];
      const hx = hBuf[y * N + ((x + 1) % N)] - hBuf[y * N + ((x - 1 + N) % N)];
      const hy = hBuf[((y + 1) % N) * N + x] - hBuf[((y - 1 + N) % N) * N + x];
      const idx = (y * N + x) * 4;
      d[idx]     = Math.max(0, Math.min(255, Math.round((hx * 7.5 + 0.5) * 255)));
      d[idx + 1] = Math.max(0, Math.min(255, Math.round((hy * 7.5 + 0.5) * 255)));
      d[idx + 2] = Math.max(0, Math.min(255, Math.round(h * 255)));
      d[idx + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  const tex = new CanvasTexture(cv);
  tex.wrapS = RepeatWrapping;
  tex.wrapT = RepeatWrapping;
  tex.needsUpdate = true;
  WetFloorReflector._waterNormTex = tex;
  return tex;
};

class WetFloorReflector {
  constructor(width = 24, depth = 64, options = {}) {
    this.planeY = options.planeY || 0.0;
    this.rt = new WebGLRenderTarget(options.textureWidth || 512, options.textureHeight || 512);
    this.reflCam = new PerspectiveCamera(45, 1.6, 0.15, 600);
    this.reflVP = new Matrix4();
    const modeStr = String(options.mode || 'wet-floor').toLowerCase();
    const modeVal = modeStr === 'water' ? 1.0 : (modeStr === 'mirror' || modeStr === 'true' ? 2.0 : 0.0);
    this.uniforms = {
      tReflect:     { value: this.rt.texture },
      uReflVP:      { value: this.reflVP },
      uTime:        { value: 0.0 },
      uResolution:  { value: new Vector2(1440, 900) },
      uReflectivity:{ value: options.reflectivity !== undefined ? options.reflectivity : (modeVal === 1.0 ? 0.88 : 0.94) },
      uTint:        { value: options.tint ? new Color(options.tint) : new Color(modeVal === 1.0 ? '#bfe6ff' : '#ffffff') },
      uBaseColor:   { value: options.baseColor ? new Color(options.baseColor) : new Color(modeVal === 1.0 ? '#0c2f47' : '#28262b') },
      uMode:        { value: modeVal },
      uDistortion:  { value: options.distortion !== undefined ? options.distortion : (modeVal === 1.0 ? 0.024 : 0.0) },
      uSpeed:       { value: options.speed !== undefined ? options.speed : 1.0 },
      uFogColor:    { value: options.fogColor ? new Color(options.fogColor) : new Color('#8dc2eb') },
      uFogNear:     { value: options.fogNear !== undefined ? options.fogNear : 85.0 },
      uFogFar:      { value: options.fogFar !== undefined ? options.fogFar : 280.0 },
      uWaterNorm:   { value: _getWaterNormalTex() }
    };
    const geo = options.customGeometry || new PlaneGeometry(width, depth, 1, 1);
    if (!options.customGeometry) geo.rotateX(-Math.PI / 2);
    this.material = new ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: `
        varying vec3 vWorldPos;
        void main() {
          vec4 wp = modelMatrix * vec4(position, 1.0);
          vWorldPos = wp.xyz;
          gl_Position = projectionMatrix * viewMatrix * wp;
        }
      `,
      fragmentShader: `
        uniform sampler2D tReflect;
        uniform mat4 uReflVP;
        uniform float uTime;
        uniform vec2 uResolution;
        uniform float uReflectivity;
        uniform vec3 uTint;
        uniform vec3 uBaseColor;
        uniform float uMode;
        uniform float uDistortion;
        uniform float uSpeed;
        uniform vec3 uFogColor;
        uniform float uFogNear;
        uniform float uFogFar;
        uniform sampler2D uWaterNorm;
        varying vec3 vWorldPos;

        float hash2(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
        }
        float vnoise(vec2 p) {
          vec2 i = floor(p), f = fract(p);
          vec2 u = f * f * (3.0 - 2.0 * f);
          return mix(
            mix(hash2(i), hash2(i + vec2(1.0, 0.0)), u.x),
            mix(hash2(i + vec2(0.0, 1.0)), hash2(i + vec2(1.0, 1.0)), u.x),
            u.y
          );
        }
        float fbm(vec2 p) {
          return vnoise(p) * 0.55 + vnoise(p * 2.13 + 7.1) * 0.30 + vnoise(p * 4.41 + 13.7) * 0.15;
        }

        void main() {
          vec4 clip = uReflVP * vec4(vWorldPos, 1.0);
          vec2 rUv = (clip.xy / max(clip.w, 0.0001)) * 0.5 + 0.5;
          vec2 wp = vWorldPos.xz;
          vec3 V = normalize(cameraPosition - vWorldPos);

          // MODE 1.0: Pre-Baked Seamless 4-Octave FBM Water Normal Map (Full FBM Fidelity at 10x Speed!)
          if (uMode > 0.5 && uMode < 1.5) {
            float t = uTime * uSpeed;
            vec3 n1 = texture2D(uWaterNorm, wp * 0.042 + vec2(t * 0.022, t * 0.014)).rgb;
            vec3 n2 = texture2D(uWaterNorm, wp * 0.095 - vec2(t * 0.016, -t * 0.024)).rgb;
            vec2 grad = ((n1.xy - 0.5) * 1.3 + (n2.xy - 0.5) * 0.9);
            float h0 = n1.z * 0.6 + n2.z * 0.4;

            vec2 distUv = clamp(rUv + grad * (uDistortion * 1.45), 0.002, 0.998);
            vec3 refl = texture2D(tReflect, distUv).rgb;

            float fresnel = 0.08 + 0.92 * pow(1.0 - max(V.y, 0.01), 3.6);
            float reflWeight = clamp(fresnel * uReflectivity, 0.0, 0.96);

            vec3 waterBody = uBaseColor * (0.86 + 0.30 * h0);
            vec3 col = mix(waterBody, refl * uTint, reflWeight);

            float fogDist = length(vWorldPos - cameraPosition);
            col = mix(col, uFogColor, smoothstep(uFogNear, uFogFar, fogDist) * 0.92);
            gl_FragColor = vec4(col, 1.0);
            return;
          }

          // MODE 2.0: Clean Mirror / Glossy Surface Reflection (tag-level reflection="true|mirror")
          if (uMode >= 1.5) {
            float t = uTime * uSpeed;
            vec2 rip = vec2(fbm(wp * 2.2 + t * 0.15) - 0.5, fbm(wp * 2.2 - t * 0.12) - 0.5) * uDistortion;
            vec2 distUv = clamp(rUv + rip, 0.002, 0.998);
            vec3 refl = texture2D(tReflect, distUv).rgb;
            float fresnel = 0.25 + 0.75 * pow(1.0 - max(V.y, 0.01), 2.5);
            vec3 col = mix(uBaseColor, refl * uTint, clamp(fresnel * uReflectivity, 0.0, 0.98));
            gl_FragColor = vec4(col, 1.0);
            return;
          }

          // MODE 0.0: Wet Tiled Stone Slabs + Puddles (wet-floor)
          vec2 tileCoord = wp * vec2(2.2, 1.65);
          vec2 tileId = floor(tileCoord);
          vec2 tileFrac = fract(tileCoord);
          float grout = smoothstep(0.0, 0.04, tileFrac.x) * smoothstep(0.0, 0.04, 1.0 - tileFrac.x)
                      * smoothstep(0.0, 0.04, tileFrac.y) * smoothstep(0.0, 0.04, 1.0 - tileFrac.y);
          float tileVar = hash2(tileId);
          float puddleNoise = fbm(wp * 0.48 + vec2(2.1, 1.4));
          float puddle = smoothstep(0.30, 0.58, puddleNoise + (tileVar - 0.5) * 0.22);
          float micro = (fbm(wp * 6.0 + vec2(0.0, uTime * 0.20)) - 0.5);
          float streakX = sin(wp.x * 32.0 + micro * 8.0) * mix(0.0085, 0.0022, puddle);
          float streakY = micro * mix(0.032, 0.008, puddle);
          vec2 distUv = clamp(rUv + vec2(streakX, streakY), 0.002, 0.998);
          float sm = mix(0.016, 0.006, puddle);
          vec3 refl = texture2D(tReflect, distUv).rgb * 0.34
                    + texture2D(tReflect, clamp(distUv + vec2(0.0,  sm), 0.002, 0.998)).rgb * 0.21
                    + texture2D(tReflect, clamp(distUv + vec2(0.0, -sm), 0.002, 0.998)).rgb * 0.21
                    + texture2D(tReflect, clamp(distUv + vec2(0.0,  sm * 2.2), 0.002, 0.998)).rgb * 0.12
                    + texture2D(tReflect, clamp(distUv + vec2(0.0, -sm * 2.2), 0.002, 0.998)).rgb * 0.12;
          float grain = fbm(wp * 14.0);
          vec3 drySlab = mix(vec3(0.14, 0.13, 0.15), vec3(0.24, 0.22, 0.25), tileVar * 0.65 + grain * 0.35) * (0.62 + 0.38 * grout);
          vec3 wetSlab = drySlab * 0.26;
          vec3 baseStone = mix(drySlab, wetSlab, puddle * 0.88 + 0.12);
          float fresnel = 0.32 + 0.68 * pow(1.0 - max(V.y, 0.02), 2.1);
          float reflWeight = clamp(mix(0.42, 0.95, puddle) * fresnel * uReflectivity * (0.78 + 0.22 * grout), 0.0, 0.96);
          vec3 col = mix(baseStone * uBaseColor * 4.0, refl * 1.25 * uTint, reflWeight);
          gl_FragColor = vec4(col, 1.0);
        }
      `
    });
    this.mesh = new Mesh(geo, this.material);
    this.mesh.position.y = this.planeY;
    this.mesh.receiveShadow = false;
    this.mesh.castShadow = false;
    this.mesh.frustumCulled = false;
    this.mesh.userData._isWetReflector = true;
  }

  renderReflection(renderer, scene, camera) {
    if (renderer._exploreMode && renderer._exploreOpts && renderer._exploreOpts.smartReflector !== false) {
      const cp = camera.position, cq = camera.quaternion;
      const sig = `${cp.x.toFixed(3)}|${cp.y.toFixed(3)}|${cp.z.toFixed(3)}|${cq.x.toFixed(3)}|${cq.y.toFixed(3)}|${cq.z.toFixed(3)}|${cq.w.toFixed(3)}`;
      this._reflFrame = (this._reflFrame || 0) + 1;
      const interval = Math.max(1, renderer._exploreOpts.reflectorInterval || 2);
      if (this._hasBakedRefl) {
        if (this._lastCamSig === sig && !this._forceReflUpdate) return;
        if (interval > 1 && (this._reflFrame % interval) !== 0 && !this._forceReflUpdate) return;
      }
      this._lastCamSig = sig;
      this._hasBakedRefl = true;
      this._forceReflUpdate = false;
    }
    const prevVis = this.mesh.visible;
    this.mesh.visible = false;

    this.reflCam.fov = camera.fov || 45;
    this.reflCam.aspect = camera.aspect || 1.6;
    this.reflCam.near = camera.near || 0.15;
    this.reflCam.far = camera.far || 600;
    this.reflCam.updateProjectionMatrix();

    // Mirror camera position & look target across y = planeY
    const cp = camera.position;
    this.reflCam.position.set(cp.x, 2.0 * this.planeY - cp.y, cp.z);

    const fwd = new Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
    const tgt = new Vector3(cp.x + fwd.x * 10, 2.0 * this.planeY - (cp.y + fwd.y * 10), cp.z + fwd.z * 10);
    this.reflCam.up.set(0, 1, 0);
    this.reflCam.lookAt(tgt);
    this.reflCam.updateMatrixWorld(true);

    // Compute uReflVP = projectionMatrix * matrixWorldInverse
    this.reflVP.multiplyMatrices(this.reflCam.projectionMatrix, this.reflCam.matrixWorldInverse);

    // Match screen resolution uniform
    this.uniforms.uResolution.value.set(renderer.domElement.width, renderer.domElement.height);

    const prevRT = renderer.getRenderTarget();
    const prevAutoShad = renderer.shadowMap.autoUpdate;
    renderer.shadowMap.autoUpdate = false;
    renderer._inReflectionPass = true;
    renderer._reflectionClipPlane = [0.0, -1.0, 0.0, -(this.planeY - 0.015)];
    renderer.setRenderTarget(this.rt);
    renderer.clear(true, true);
    renderer.render(scene, this.reflCam);
    renderer.setRenderTarget(prevRT);
    renderer._reflectionClipPlane = null;
    renderer._inReflectionPass = false;
    renderer.shadowMap.autoUpdate = prevAutoShad;

    this.mesh.visible = prevVis;
  }
}


class ParallaxStorefrontMaterial extends ShaderMaterial {
  constructor(options = {}) {
    const u = {
      tMap:            { value: options.map || null },
      uParallaxDepth:  { value: options.parallaxDepth !== undefined ? options.parallaxDepth : 0.045 },
      uRoomDepth:      { value: options.roomDepth !== undefined ? options.roomDepth : 0.16 },
      uEmissiveBoost:  { value: options.emissiveBoost !== undefined ? options.emissiveBoost : 2.35 },
      uEmissiveThresh: { value: options.emissiveThreshold !== undefined ? options.emissiveThreshold : 0.36 },
      uBaseExposure:   { value: options.baseExposure !== undefined ? options.baseExposure : 1.05 },
      uTint:           { value: options.tint ? new Color(options.tint) : new Color('#ffffff') }
    };
    super({
      uniforms: u,
      vertexShader: `
        varying vec2 vUv;
        varying vec3 vWorldPos;
        varying vec3 vWorldNormal;
        void main() {
          vUv = uv;
          vec4 wp = modelMatrix * vec4(position, 1.0);
          vWorldPos = wp.xyz;
          vWorldNormal = normalize(mat3(modelMatrix[0].xyz, modelMatrix[1].xyz, modelMatrix[2].xyz) * normal);
          gl_Position = projectionMatrix * viewMatrix * wp;
        }
      `,
      fragmentShader: `
        uniform sampler2D tMap;
        uniform float uParallaxDepth;
        uniform float uRoomDepth;
        uniform float uEmissiveBoost;
        uniform float uEmissiveThresh;
        uniform float uBaseExposure;
        uniform vec3 uTint;
        varying vec2 vUv;
        varying vec3 vWorldPos;
        varying vec3 vWorldNormal;

        float luma(vec3 c) {
          return dot(c, vec3(0.299, 0.587, 0.114));
        }

        void main() {
          vec3 N = normalize(vWorldNormal);
          vec3 V = normalize(cameraPosition - vWorldPos);

          // Construct tangent basis (T, B, N) on upright or angled architectural surfaces
          vec3 upRef = abs(N.y) < 0.95 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
          vec3 T = normalize(cross(upRef, N));
          vec3 B = cross(N, T);
          vec3 viewTS = vec3(dot(V, T), dot(V, B), max(dot(V, N), 0.18));

          // 5-Step Contact-Refined Parallax Occlusion Mapping (POM)
          // Preserves razor-sharp neon text while shifting recessed interior shelves & dark masonry
          vec2 uv = vUv;
          float baseLum = luma(texture2D(tMap, uv).rgb);
          float reliefMask = 1.0 - smoothstep(0.48, 0.82, baseLum);
          float curLayer = 0.0;
          vec2 deltaUv = (viewTS.xy / viewTS.z) * (uParallaxDepth * 0.28 * reliefMask) / 5.0;
          for (int i = 0; i < 5; i++) {
            vec3 sCol = texture2D(tMap, clamp(uv, 0.002, 0.998)).rgb;
            float h = 1.0 - smoothstep(0.15, 0.85, luma(sCol));
            if (curLayer < h) {
              uv -= deltaUv;
              curLayer += 0.2;
            }
          }
          uv = clamp(uv, 0.002, 0.998);
          vec3 frontCol = texture2D(tMap, uv).rgb;

          // Interior-Mapped Room Depth Layer (recessed shelves & back-wall parallax)
          vec2 interiorUv = clamp(vUv - (viewTS.xy / viewTS.z) * uRoomDepth, 0.004, 0.996);
          vec3 deepCol = texture2D(tMap, interiorUv).rgb;

          // Blend recessed interior parallax into mid-tone shop windows while keeping bright neon & dark frames crisp
          float lum = luma(frontCol);
          float windowMask = smoothstep(0.12, 0.35, lum) * (1.0 - smoothstep(0.75, 0.95, lum));
          vec3 combined = mix(frontCol, mix(frontCol, deepCol, 0.38), windowMask);

          // Saturation-Preserving Selective HDR Emissive Extraction (prevents white blowout on bright signs/shelves!)
          float maxCh = max(combined.r, max(combined.g, combined.b));
          float minCh = min(combined.r, min(combined.g, combined.b));
          float sat = (maxCh - minCh) / max(maxCh, 0.001);
          // Boost saturated neon colors while softly compressing near-white highlights
          vec3 satProtected = mix(combined, combined / max(maxCh, 0.65), 0.35 * smoothstep(0.65, 0.98, lum));
          float neonMask = smoothstep(uEmissiveThresh, 0.92, lum * (0.42 + 0.58 * sat));

          vec3 hdrCol = (satProtected * uBaseExposure + satProtected * sat * neonMask * uEmissiveBoost) * uTint;
          // Subtle grazing glass Fresnel reflection on storefront windows
          float fresnel = pow(1.0 - max(dot(N, V), 0.0), 3.0) * 0.12;
          hdrCol += vec3(0.08, 0.10, 0.16) * fresnel;

          gl_FragColor = vec4(hdrCol, 1.0);
        }
      `
    });
  }
}


class LineLoop extends Line {
  constructor(geometry, material) {
    super(geometry, material);
    this.isLineLoop = true;
    this.type = 'LineLoop';
  }
}

class LineDashedMaterial extends LineBasicMaterial {
  constructor(params = {}) {
    super(params);
    this.isLineDashedMaterial = true;
    this.scale = params.scale || 1;
    this.dashSize = params.dashSize || 3;
    this.gapSize = params.gapSize || 1;
  }
}

class CapsuleGeometry extends BufferGeometry {
  constructor(radius = 0.5, length = 1, capSegments = 8, radialSegments = 16) {
    super();
    const cyl = new CylinderGeometry(radius, radius, length, radialSegments, 1, true);
    const topCap = new SphereGeometry(radius, radialSegments, capSegments, 0, Math.PI * 2, 0, Math.PI * 0.5);
    topCap.translate(0, length * 0.5, 0);
    const botCap = new SphereGeometry(radius, radialSegments, capSegments, 0, Math.PI * 2, Math.PI * 0.5, Math.PI * 0.5);
    botCap.translate(0, -length * 0.5, 0);
    const merged = mergeGeometries([cyl, topCap, botCap]);
    if (merged) {
      this.attributes = merged.attributes;
      this.index = merged.index;
    }
  }
}

class EdgesGeometry extends BufferGeometry {
  constructor(geometry, thresholdAngle = 1) {
    super();
    if (!geometry || !geometry.attributes || !geometry.attributes.position) return;
    const pos = geometry.attributes.position;
    const idx = geometry.index ? geometry.index.array : null;
    const nTri = idx ? idx.length : pos.count;
    const verts = [];
    for (let i = 0; i < nTri; i += 3) {
      const i0 = idx ? idx[i] : i;
      const i1 = idx ? idx[i + 1] : i + 1;
      const i2 = idx ? idx[i + 2] : i + 2;
      verts.push(
        pos.getX(i0), pos.getY(i0), pos.getZ(i0), pos.getX(i1), pos.getY(i1), pos.getZ(i1),
        pos.getX(i1), pos.getY(i1), pos.getZ(i1), pos.getX(i2), pos.getY(i2), pos.getZ(i2),
        pos.getX(i2), pos.getY(i2), pos.getZ(i2), pos.getX(i0), pos.getY(i0), pos.getZ(i0)
      );
    }
    this.setAttribute('position', new Float32BufferAttribute(verts, 3));
  }
}

class WireframeGeometry extends EdgesGeometry {}
class DodecahedronGeometry extends SphereGeometry {
  constructor(radius = 1, detail = 0) { super(radius, 10 + detail * 4, 8 + detail * 4); }
}
class OctahedronGeometry extends SphereGeometry {
  constructor(radius = 1, detail = 0) { super(radius, 8 + detail * 4, 6 + detail * 4); }
}
class TetrahedronGeometry extends SphereGeometry {
  constructor(radius = 1, detail = 0) { super(radius, 6 + detail * 4, 4 + detail * 4); }
}

const BoxBufferGeometry = BoxGeometry;
const PlaneBufferGeometry = PlaneGeometry;
const SphereBufferGeometry = SphereGeometry;
const CylinderBufferGeometry = CylinderGeometry;
const ConeBufferGeometry = ConeGeometry;
const TorusBufferGeometry = TorusGeometry;
const RingBufferGeometry = RingGeometry;
const CircleBufferGeometry = CircleGeometry;
const ExtrudeBufferGeometry = ExtrudeGeometry;
const LatheBufferGeometry = LatheGeometry;
const TubeBufferGeometry = TubeGeometry;
const BufferGeometryUtils = { mergeGeometries, mergeBufferGeometries: mergeGeometries, mergeVertices, toCreasedNormals };


class DRACOLoader {
  constructor() { this.decoderPath = ''; }
  setDecoderPath(path) { this.decoderPath = path; return this; }
  setDecoderConfig() { return this; }
  preload() { return this; }
  dispose() {}
}

class KTX2Loader {
  constructor() { this.transcoderPath = ''; }
  setTranscoderPath(path) { this.transcoderPath = path; return this; }
  detectSupport() { return this; }
  load(url, onLoad, onProgress, onError) {
    return new TextureLoader().load(url, onLoad, onProgress, onError);
  }
  dispose() {}
}

class RGBELoader {
  constructor() { this.type = HalfFloatType; }
  setDataType(t) { this.type = t; return this; }
  parse(buffer) {
    const bytes = new Uint8Array(buffer);
    let pos = 0;
    const readLine = () => {
      let line = '';
      while (pos < bytes.length) {
        const c = bytes[pos++];
        if (c === 10) break;
        if (c !== 13) line += String.fromCharCode(c);
      }
      return line;
    };
    let line = readLine();
    while (pos < bytes.length && line.length > 0) line = readLine();
    const resLine = readLine();
    const m = resLine.match(/-Y\s+(\d+)\s+\+X\s+(\d+)/);
    if (!m) return { width: 1, height: 1, data: new Uint8Array([128, 128, 128, 255]) };
    const height = parseInt(m[1], 10), width = parseInt(m[2], 10);
    const out = new Uint8Array(width * height * 4);
    const scanline = new Uint8Array(width * 4);
    for (let y = 0; y < height; y++) {
      if (pos + 4 > bytes.length) break;
      const a = bytes[pos], b = bytes[pos + 1];
      if (a === 2 && b === 2 && width >= 8 && width <= 32767) {
        pos += 4;
        for (let ch = 0; ch < 4; ch++) {
          let x = 0;
          while (x < width && pos < bytes.length) {
            const count = bytes[pos++];
            if (count > 128) {
              const run = count - 128;
              const val = bytes[pos++];
              for (let r = 0; r < run && x < width; r++) scanline[x++ * 4 + ch] = val;
            } else {
              for (let r = 0; r < count && x < width; r++) scanline[x++ * 4 + ch] = bytes[pos++];
            }
          }
        }
      } else {
        for (let i = 0; i < width * 4 && pos < bytes.length; i++) scanline[i] = bytes[pos++];
      }
      for (let x = 0; x < width; x++) {
        const si = x * 4;
        const e = scanline[si + 3];
        const oi = ((height - 1 - y) * width + x) * 4;
        if (e === 0) {
          out[oi] = out[oi + 1] = out[oi + 2] = 0;
        } else {
          const f = Math.pow(2.0, e - 128 - 8);
          const tone = (v) => Math.min(255, Math.round(Math.pow(v / (1.0 + v), 1.0 / 2.2) * 255));
          out[oi]     = tone(scanline[si] * f);
          out[oi + 1] = tone(scanline[si + 1] * f);
          out[oi + 2] = tone(scanline[si + 2] * f);
        }
        out[oi + 3] = 255;
      }
    }
    return { width, height, data: out };
  }
  load(url, onLoad, onProgress, onError) {
    const tex = new DataTexture(new Uint8Array([40, 50, 70, 255]), 1, 1);
    tex.isPMREM = true;
    fetch(url).then(r => r.arrayBuffer()).then(buf => {
      const parsed = this.parse(buf);
      tex.image = parsed;
      tex.needsUpdate = true;
      if (onLoad) onLoad(tex);
    }).catch(err => { if (onError) onError(err); });
    return tex;
  }
}

class OBJLoader {
  parse(text) {
    const group = new Group();
    const verts = [], norms = [], uvs = [];
    const posOut = [], normOut = [], uvOut = [];
    const lines = text.split(/\r?\n/);
    for (const raw of lines) {
      const l = raw.trim();
      if (!l || l.startsWith('#')) continue;
      const parts = l.split(/\s+/);
      if (parts[0] === 'v') verts.push([parseFloat(parts[1]), parseFloat(parts[2]), parseFloat(parts[3])]);
      else if (parts[0] === 'vn') norms.push([parseFloat(parts[1]), parseFloat(parts[2]), parseFloat(parts[3])]);
      else if (parts[0] === 'vt') uvs.push([parseFloat(parts[1]), parseFloat(parts[2])]);
      else if (parts[0] === 'f') {
        const fVerts = parts.slice(1).map(tok => {
          const [vi, ti, ni] = tok.split('/').map(s => s ? parseInt(s, 10) : 0);
          return {
            v: vi < 0 ? verts.length + vi : vi - 1,
            t: ti < 0 ? uvs.length + ti : ti - 1,
            n: ni < 0 ? norms.length + ni : ni - 1
          };
        });
        for (let k = 1; k < fVerts.length - 1; k++) {
          for (const fv of [fVerts[0], fVerts[k], fVerts[k + 1]]) {
            const vp = verts[fv.v] || [0, 0, 0];
            posOut.push(vp[0], vp[1], vp[2]);
            const vn = (fv.n >= 0 && norms[fv.n]) ? norms[fv.n] : [0, 1, 0];
            normOut.push(vn[0], vn[1], vn[2]);
            const vt = (fv.t >= 0 && uvs[fv.t]) ? uvs[fv.t] : [0, 0];
            uvOut.push(vt[0], vt[1]);
          }
        }
      }
    }
    const geo = new BufferGeometry();
    geo.setAttribute('position', new Float32BufferAttribute(posOut, 3));
    if (norms.length > 0) geo.setAttribute('normal', new Float32BufferAttribute(normOut, 3));
    else geo.computeVertexNormals();
    geo.setAttribute('uv', new Float32BufferAttribute(uvOut, 2));
    group.add(new Mesh(geo, new MeshStandardMaterial({ color: 0xd1d5db, roughness: 0.6 })));
    return group;
  }
  load(url, onLoad, onProgress, onError) {
    fetch(url).then(r => r.text()).then(txt => {
      const grp = this.parse(txt);
      if (onLoad) onLoad(grp);
    }).catch(err => { if (onError) onError(err); });
  }
}

class GLTFLoader {
  constructor() { this.dracoLoader = null; this.ktx2Loader = null; }
  setDRACOLoader(d) { this.dracoLoader = d; return this; }
  setKTX2Loader(k) { this.ktx2Loader = k; return this; }

  parse(data, path = '', onLoad, onError) {
    try {
      let json = null, binChunk = null;
      if (data instanceof ArrayBuffer) {
        const dv = new DataView(data);
        const magic = dv.getUint32(0, true);
        if (magic === 0x46546C67) { // 'glTF' binary GLB
          let offset = 12;
          while (offset < dv.byteLength) {
            const chunkLen = dv.getUint32(offset, true);
            const chunkType = dv.getUint32(offset + 4, true);
            offset += 8;
            if (chunkType === 0x4E4F534A) {
              json = JSON.parse(new TextDecoder().decode(new Uint8Array(data, offset, chunkLen)));
            } else if (chunkType === 0x004E4942) {
              binChunk = data.slice(offset, offset + chunkLen);
            }
            offset += chunkLen;
          }
        } else {
          json = JSON.parse(new TextDecoder().decode(new Uint8Array(data)));
        }
      } else if (typeof data === 'string') {
        json = JSON.parse(data);
      } else {
        json = data;
      }

      const buffers = (json.buffers || []).map((b, idx) => {
        if (idx === 0 && binChunk && !b.uri) return binChunk;
        if (b.uri && b.uri.startsWith('data:')) {
          const b64 = b.uri.split(',')[1];
          const bin = atob(b64);
          const arr = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
          return arr.buffer;
        }
        return binChunk || new ArrayBuffer(b.byteLength || 0);
      });

      const readAccessor = (accIdx) => {
        const acc = json.accessors[accIdx];
        const bv = json.bufferViews[acc.bufferView || 0];
        const buf = buffers[bv.buffer || 0];
        const byteOffset = (bv.byteOffset || 0) + (acc.byteOffset || 0);
        const typeCounts = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT4: 16 };
        const itemSize = typeCounts[acc.type] || 3;
        const count = acc.count;
        const compMap = { 5120: Int8Array, 5121: Uint8Array, 5122: Int16Array, 5123: Uint16Array, 5125: Uint32Array, 5126: Float32Array };
        const TypedArr = compMap[acc.componentType] || Float32Array;
        const stride = bv.byteStride || 0;
        if (!stride || stride === itemSize * TypedArr.BYTES_PER_ELEMENT) {
          return { array: new TypedArr(buf, byteOffset, count * itemSize), itemSize, normalized: !!acc.normalized };
        }
        const out = new TypedArr(count * itemSize);
        const dv = new DataView(buf);
        for (let i = 0; i < count; i++) {
          const base = byteOffset + i * stride;
          for (let c = 0; c < itemSize; c++) {
            const off = base + c * TypedArr.BYTES_PER_ELEMENT;
            if (TypedArr === Float32Array) out[i * itemSize + c] = dv.getFloat32(off, true);
            else if (TypedArr === Uint16Array) out[i * itemSize + c] = dv.getUint16(off, true);
            else if (TypedArr === Uint32Array) out[i * itemSize + c] = dv.getUint32(off, true);
            else out[i * itemSize + c] = dv.getUint8(off);
          }
        }
        return { array: out, itemSize, normalized: !!acc.normalized };
      };

      const materials = (json.materials || []).map(gm => {
        const pbr = gm.pbrMetallicRoughness || {};
        const bc = pbr.baseColorFactor || [1, 1, 1, 1];
        const mat = new MeshStandardMaterial({
          color: new Color(bc[0], bc[1], bc[2]),
          roughness: pbr.roughnessFactor !== undefined ? pbr.roughnessFactor : 0.7,
          metalness: pbr.metallicFactor !== undefined ? pbr.metallicFactor : 0.0,
          transparent: gm.alphaMode === 'BLEND' || bc[3] < 0.99,
          opacity: bc[3],
          side: gm.doubleSided ? DoubleSide : FrontSide
        });
        if (gm.emissiveFactor) mat.emissive.setRGB(gm.emissiveFactor[0], gm.emissiveFactor[1], gm.emissiveFactor[2]);
        return mat;
      });

      const buildNode = (nIdx) => {
        const gn = json.nodes[nIdx];
        const grp = new Group();
        grp.name = gn.name || '';
        if (gn.translation) grp.position.set(gn.translation[0], gn.translation[1], gn.translation[2]);
        if (gn.rotation) grp.quaternion.set(gn.rotation[0], gn.rotation[1], gn.rotation[2], gn.rotation[3]);
        if (gn.scale) grp.scale.set(gn.scale[0], gn.scale[1], gn.scale[2]);
        if (gn.matrix) {
          const m = new Matrix4().fromArray(gn.matrix);
          m.decompose(grp.position, grp.quaternion, grp.scale);
        }
        if (gn.mesh !== undefined) {
          const gm = json.meshes[gn.mesh];
          for (const prim of gm.primitives || []) {
            const geo = new BufferGeometry();
            const attrMap = { POSITION: 'position', NORMAL: 'normal', TEXCOORD_0: 'uv', COLOR_0: 'color' };
            for (const [gName, accIdx] of Object.entries(prim.attributes || {})) {
              const a = readAccessor(accIdx);
              const tName = attrMap[gName] || gName;
              geo.setAttribute(tName, new BufferAttribute(a.array, a.itemSize, a.normalized));
            }
            if (prim.indices !== undefined) {
              const idxAcc = readAccessor(prim.indices);
              geo.setIndex(new BufferAttribute(idxAcc.array, 1));
            }
            if (!geo.attributes.normal) geo.computeVertexNormals();
            const mat = (prim.material !== undefined && materials[prim.material]) ? materials[prim.material] : new MeshStandardMaterial();
            const mesh = new Mesh(geo, mat);
            mesh.castShadow = true; mesh.receiveShadow = true;
            grp.add(mesh);
          }
        }
        if (gn.children) {
          for (const cIdx of gn.children) grp.add(buildNode(cIdx));
        }
        return grp;
      };

      const sceneIdx = json.scene || 0;
      const rootScene = new Group();
      const gScene = (json.scenes && json.scenes[sceneIdx]) || { nodes: json.nodes ? [0] : [] };
      for (const nIdx of gScene.nodes || []) rootScene.add(buildNode(nIdx));

      const result = { scene: rootScene, scenes: [rootScene], asset: json.asset || {}, parser: { json } };
      if (onLoad) onLoad(result);
      return result;
    } catch (err) {
      if (onError) onError(err);
      else console.error('[Triad3D GLTFLoader Error]', err);
    }
  }

  load(url, onLoad, onProgress, onError) {
    fetch(url).then(r => r.arrayBuffer()).then(buf => this.parse(buf, url, onLoad, onError)).catch(err => {
      if (onError) onError(err);
    });
  }
}


const THREE = {
  REVISION,
  SRGBColorSpace,
  LinearSRGBColorSpace,
  NoColorSpace,
  NoToneMapping,
  LinearToneMapping,
  ReinhardToneMapping,
  CineonToneMapping,
  ACESFilmicToneMapping,
  AgXToneMapping,
  NeutralToneMapping,
  BasicShadowMap,
  PCFShadowMap,
  PCFSoftShadowMap,
  VSMShadowMap,
  RepeatWrapping,
  ClampToEdgeWrapping,
  MirroredRepeatWrapping,
  NearestFilter,
  NearestMipmapNearestFilter,
  NearestMipmapLinearFilter,
  LinearFilter,
  LinearMipmapNearestFilter,
  LinearMipmapLinearFilter,
  RGBAFormat,
  RGBFormat,
  AlphaFormat,
  LuminanceFormat,
  DepthFormat,
  UnsignedByteType,
  ByteType,
  ShortType,
  UnsignedShortType,
  IntType,
  UnsignedIntType,
  FloatType,
  HalfFloatType,
  FrontSide,
  BackSide,
  DoubleSide,
  NoBlending,
  NormalBlending,
  AdditiveBlending,
  SubtractiveBlending,
  MultiplyBlending,
  CustomBlending,
  StaticDrawUsage,
  DynamicDrawUsage,
  StreamDrawUsage,
  UVMapping,
  EquirectangularReflectionMapping,
  EquirectangularRefractionMapping,
  MathUtils,
  Vector2,
  Vector3,
  Vector4,
  Color,
  Euler,
  Quaternion,
  Matrix3,
  Matrix4,
  Box2,
  Box3,
  Sphere,
  Plane,
  Ray,
  Frustum,
  Spherical,
  Cylindrical,
  Triangle,
  Fog,
  FogExp2,
  Object3D,
  Scene,
  Group,
  Camera,
  PerspectiveCamera,
  OrthographicCamera,
  BufferAttribute,
  Int8BufferAttribute,
  Uint8BufferAttribute,
  Uint8ClampedBufferAttribute,
  Int16BufferAttribute,
  Uint16BufferAttribute,
  Int32BufferAttribute,
  Uint32BufferAttribute,
  Float32BufferAttribute,
  Float64BufferAttribute,
  InstancedBufferAttribute,
  BufferGeometry,
  PlaneGeometry,
  BoxGeometry,
  CylinderGeometry,
  ConeGeometry,
  CircleGeometry,
  SphereGeometry,
  IcosahedronGeometry,
  TorusGeometry,
  LatheGeometry,
  Shape,
  ExtrudeGeometry,
  CatmullRomCurve3,
  TubeGeometry,
  Texture,
  CanvasTexture,
  DataTexture,
  WebGLRenderTarget,
  Material,
  MeshStandardMaterial,
  MeshPhysicalMaterial,
  MeshLambertMaterial,
  MeshPhongMaterial,
  MeshToonMaterial,
  MeshBasicMaterial,
  MeshNormalMaterial,
  MeshDepthMaterial,
  ShadowMaterial,
  PointsMaterial,
  SpriteMaterial,
  ShaderMaterial,
  RawShaderMaterial,
  Mesh,
  Points,
  Sprite,
  InstancedMesh,
  DirectionalLight,
  HemisphereLight,
  PMREMGenerator,
  Clock,
  WebGLRenderer,
  mergeGeometries,
  mergeVertices,
  toCreasedNormals,
  RenderPass,
  ShaderPass,
  BokehPass,
  UnrealBloomPass,
  EffectComposer,
  AmbientLight,
  PointLight,
  SpotLight,
  LineBasicMaterial,
  LineSegments,
  Line,
  RingGeometry,
  Raycaster,
  TextureLoader,
  WetFloorReflector,
  ParallaxStorefrontMaterial,
  LineLoop,
  LineDashedMaterial,
  CapsuleGeometry,
  EdgesGeometry,
  WireframeGeometry,
  DodecahedronGeometry,
  OctahedronGeometry,
  TetrahedronGeometry,
  BoxBufferGeometry,
  PlaneBufferGeometry,
  SphereBufferGeometry,
  CylinderBufferGeometry,
  ConeBufferGeometry,
  TorusBufferGeometry,
  RingBufferGeometry,
  CircleBufferGeometry,
  ExtrudeBufferGeometry,
  LatheBufferGeometry,
  TubeBufferGeometry,
  BufferGeometryUtils,
  DRACOLoader,
  KTX2Loader,
  RGBELoader,
  OBJLoader,
  GLTFLoader,
  Math: MathUtils
};

// ============================================================================
// 1. PROCEDURAL PBR TEXTURE SYNTHESIZER
// ============================================================================

// ============================================================================
// 1B. EXTERNAL INTERNET PNG LOADER & PADDED SURFACE COMPOSITOR
// ============================================================================
const ExternalImageCache = new Map(); // url -> { status, img }
const PaddedTexCache = new Map();     // compositeKey -> THREE.CanvasTexture

function drawBuiltinPresetPNG(ctx, presetName, x, y, w, h) {
  ctx.save();
  ctx.translate(x, y);
      if (presetName === "triad://fascia-sovereign-atelier" || presetName === "fascia-sovereign-atelier") {
    ctx.fillStyle = "#0d121c";
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = "#e0b054";
    ctx.lineWidth = Math.max(3, h * 0.045);
    ctx.strokeRect(w * 0.012, h * 0.08, w * 0.976, h * 0.84);
    ctx.fillStyle = "#f8fafc";
    ctx.font = `800 ${Math.round(w * 0.062)}px system-ui, -apple-system, sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("SOVEREIGN  GT-X  ATELIER", w * 0.5, h * 0.42, w * 0.88);
    ctx.fillStyle = "#e0b054";
    ctx.font = `600 ${Math.round(w * 0.033)}px ui-monospace, monospace`;
    ctx.fillText("TRIAD3D v7.6 · CLIFFSIDE HYPERCAR & HOROLOGY PAVILION", w * 0.5, h * 0.74, w * 0.88);
    ctx.restore();
    return true;
  }
  if (presetName === "triad://oak-foliage-sprig" || presetName === "oak-foliage-sprig") {
    // Hi-DPI Alpha-Cutout Quercus robur (English Oak) Branchlet with 18 Wavy-Lobed Oak Leaves
    ctx.clearRect(0, 0, w, h);
    const drawOakLeaf = (lx, ly, angle, len, wid, baseHex, veinHex, highlightHex) => {
      ctx.save();
      ctx.translate(lx, ly);
      ctx.rotate(angle);
      // Draw scalloped 6-lobe obovate oak leaf silhouette
      ctx.beginPath();
      ctx.moveTo(0, 0);
      const steps = 44;
      for (let i = 0; i <= steps; i++) {
        const u = i / steps;
        const y = -u * len;
        const env = Math.sin(Math.pow(u, 0.72) * Math.PI) * (0.35 + 0.65 * Math.sin(u * Math.PI * 0.85));
        const lobe = 0.72 + 0.28 * Math.sin(u * Math.PI * 11.0 - 0.6);
        const x = wid * env * lobe;
        ctx.lineTo(x, y);
      }
      for (let i = steps; i >= 0; i--) {
        const u = i / steps;
        const y = -u * len;
        const env = Math.sin(Math.pow(u, 0.72) * Math.PI) * (0.35 + 0.65 * Math.sin(u * Math.PI * 0.85));
        const lobe = 0.72 + 0.28 * Math.sin(u * Math.PI * 11.0 - 0.6);
        const x = -wid * env * lobe;
        ctx.lineTo(x, y);
      }
      ctx.closePath();
      const grad = ctx.createLinearGradient(-wid, 0, wid, -len);
      grad.addColorStop(0, baseHex);
      grad.addColorStop(0.55, highlightHex);
      grad.addColorStop(1, baseHex);
      ctx.fillStyle = grad;
      ctx.fill();
      ctx.strokeStyle = "rgba(20, 42, 12, 0.65)";
      ctx.lineWidth = Math.max(1.2, len * 0.015);
      ctx.stroke();

      // Central midrib & pinnate lateral lobe veins
      ctx.strokeStyle = veinHex;
      ctx.lineWidth = Math.max(1.4, len * 0.022);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(0, -len * 0.92);
      ctx.stroke();
      ctx.lineWidth = Math.max(0.9, len * 0.012);
      for (let v = 1; v <= 5; v++) {
        const vu = v / 6.0;
        const vy = -vu * len * 0.9;
        const vw = wid * Math.sin(Math.pow(vu, 0.72) * Math.PI) * 0.72;
        ctx.beginPath();
        ctx.moveTo(0, vy); ctx.lineTo(vw, vy - len * 0.08);
        ctx.moveTo(0, vy); ctx.lineTo(-vw, vy - len * 0.08);
        ctx.stroke();
      }
      ctx.restore();
    };

    // Woody Forked Branchlet Stems
    ctx.strokeStyle = "#4a3525";
    ctx.lineCap = "round";
    ctx.lineWidth = w * 0.022;
    ctx.beginPath();
    ctx.moveTo(w * 0.50, h * 0.94);
    ctx.quadraticCurveTo(w * 0.48, h * 0.58, w * 0.50, h * 0.18);
    ctx.stroke();
    ctx.lineWidth = w * 0.015;
    ctx.beginPath();
    ctx.moveTo(w * 0.49, h * 0.72); ctx.quadraticCurveTo(w * 0.30, h * 0.52, w * 0.16, h * 0.30);
    ctx.moveTo(w * 0.50, h * 0.66); ctx.quadraticCurveTo(w * 0.70, h * 0.48, w * 0.84, h * 0.28);
    ctx.stroke();

    // 18 Overlapping Scalloped Oak Leaves in Rich Botanical Chlorophyll Tones
    const leaves = [
      // Lower & Mid Layer (Deeper forest green for self-shadowing depth)
      [0.50, 0.82, -1.15, 0.34, 0.13, "#1f4216", "#5c8a32", "#2e5c1e"],
      [0.50, 0.80,  1.12, 0.34, 0.13, "#234919", "#629136", "#356622"],
      [0.34, 0.62, -0.88, 0.36, 0.14, "#1e3e15", "#56822e", "#2d591d"],
      [0.66, 0.58,  0.86, 0.36, 0.14, "#244b1a", "#649438", "#376923"],
      [0.24, 0.46, -1.25, 0.33, 0.13, "#28521c", "#6a993b", "#3d7226"],
      [0.76, 0.44,  1.22, 0.33, 0.13, "#214517", "#5e8c34", "#326120"],
      [0.48, 0.60, -0.42, 0.38, 0.15, "#264e1b", "#689639", "#3a6d25"],
      [0.52, 0.56,  0.44, 0.38, 0.15, "#2b571e", "#6fa13e", "#417728"],
      // Upper & Outer Sun-Kissed Layer (Vibrant emerald & warm olive-gold highlights)
      [0.18, 0.34, -0.58, 0.35, 0.14, "#316121", "#84b84a", "#4b852d"],
      [0.82, 0.32,  0.56, 0.35, 0.14, "#356824", "#89bd4e", "#518c30"],
      [0.32, 0.42, -0.15, 0.37, 0.14, "#2f5e20", "#7fb346", "#48802b"],
      [0.68, 0.40,  0.18, 0.37, 0.14, "#386c25", "#8ec252", "#559132"],
      [0.48, 0.38, -0.72, 0.36, 0.14, "#336422", "#86ba4c", "#4e882e"],
      [0.52, 0.36,  0.70, 0.36, 0.14, "#3b7027", "#94c756", "#599635"],
      [0.42, 0.26, -0.32, 0.35, 0.13, "#3f7629", "#98cc5a", "#5f9d38"],
      [0.58, 0.25,  0.32, 0.35, 0.13, "#376a24", "#8cc050", "#538e31"],
      [0.50, 0.22,  0.02, 0.37, 0.14, "#437c2b", "#a1d462", "#65a33b"],
      [0.50, 0.48,  0.00, 0.34, 0.13, "#3b7027", "#92c454", "#589434"]
    ];
    for (const [lx, ly, ang, lLen, lWid, cBase, cVein, cHi] of leaves) {
      drawOakLeaf(lx * w, ly * h, ang, lLen * h, lWid * w, cBase, cVein, cHi);
    }
    // Two small oak acorns at the twig fork
    for (const [ax, ay, rot] of [[0.44 * w, 0.52 * h, -0.3], [0.56 * w, 0.49 * h, 0.35]]) {
      ctx.save();
      ctx.translate(ax, ay);
      ctx.rotate(rot);
      ctx.fillStyle = "#854d0e";
      ctx.beginPath(); ctx.ellipse(0, 8, 7, 10, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#451a03";
      ctx.beginPath(); ctx.ellipse(0, 1, 8.5, 5, 0, Math.PI, Math.PI * 2); ctx.fill();
      ctx.restore();
    }
    // Add 10 additional dense interior oak leaves to fill out the branchlet cluster
    const extraLeaves = [
      [0.36, 0.74, -0.65, 0.34, 0.14, "#1b3b13", "#4e7a28", "#28521b"],
      [0.64, 0.72,  0.65, 0.34, 0.14, "#1d3e14", "#527e2a", "#2b561d"],
      [0.28, 0.50, -0.95, 0.36, 0.15, "#224618", "#58852e", "#316020"],
      [0.72, 0.48,  0.92, 0.36, 0.15, "#254a19", "#5c8a31", "#356522"],
      [0.40, 0.48, -0.25, 0.38, 0.15, "#28501c", "#629135", "#3a6c25"],
      [0.60, 0.46,  0.25, 0.38, 0.15, "#2b541d", "#669638", "#3e7227"],
      [0.22, 0.24, -0.45, 0.33, 0.13, "#305d20", "#6fa13d", "#457b2b"],
      [0.78, 0.23,  0.45, 0.33, 0.13, "#336122", "#73a640", "#49802d"],
      [0.36, 0.18, -0.18, 0.34, 0.13, "#366624", "#78ab43", "#4e8630"],
      [0.64, 0.18,  0.18, 0.34, 0.13, "#396a25", "#7cb046", "#528b32"]
    ];
    for (const [lx, ly, ang, lLen, lWid, cBase, cVein, cHi] of extraLeaves) {
      drawOakLeaf(lx * w, ly * h, ang, lLen * h, lWid * w, cBase, cVein, cHi);
    }
    // Alpha-Edge RGB Color-Bleed Padding: set RGB of transparent pixels to deep forest green (38, 68, 24)
    // so bilinear texture filtering at cutout edges never bleeds white or black!
    const imgData = ctx.getImageData(0, 0, w, h);
    const d = imgData.data;
    for (let i = 0; i < d.length; i += 4) {
      const a = d[i + 3];
      if (a < 180) {
        if (a < 64) {
          d[i] = 38; d[i + 1] = 68; d[i + 2] = 24; d[i + 3] = 0;
        } else {
          // Un-premultiply & sharpen cutout edge alpha
          const invA = 255.0 / Math.max(64, a);
          d[i]     = Math.min(255, Math.round(d[i] * invA * 0.85));
          d[i + 1] = Math.min(255, Math.round(d[i + 1] * invA * 0.85));
          d[i + 2] = Math.min(255, Math.round(d[i + 2] * invA * 0.85));
          d[i + 3] = 255;
        }
      }
    }
    // Radial Botanical Margin Mask: guarantee zero pixels ever touch the 4 straight quad borders!
    for (let py = 0; py < h; py++) {
      const ny = (py / h - 0.50) * 2.0;
      for (let px = 0; px < w; px++) {
        const nx = (px / w - 0.50) * 2.0;
        const ang = Math.atan2(ny, nx);
        const maxR = 0.84 + 0.08 * Math.sin(ang * 7.0) + 0.05 * Math.cos(ang * 11.0);
        if (Math.hypot(nx, ny) > maxR || px < 10 || px > w - 10 || py < 10 || py > h - 10) {
          const pIdx = (py * w + px) * 4;
          d[pIdx] = 38; d[pIdx + 1] = 68; d[pIdx + 2] = 24; d[pIdx + 3] = 0;
        }
      }
    }
    ctx.putImageData(imgData, 0, 0);
  } else if (presetName === "triad://indian-tricolor" || presetName === "indian-tricolor") {
    // True Indian National Flag (Tiranga) with Saffron, White, India Green & 24-Spoke Navy Blue Ashoka Chakra
    const bh = h / 3.0;
    ctx.fillStyle = "#FF671F"; ctx.fillRect(0, 0, w, bh);
    ctx.fillStyle = "#FFFFFF"; ctx.fillRect(0, bh, w, bh);
    ctx.fillStyle = "#046A38"; ctx.fillRect(0, bh * 2, w, bh);
    // Subtle woven fabric fold shading
    const foldGrad = ctx.createLinearGradient(0, 0, w, 0);
    foldGrad.addColorStop(0, "rgba(0,0,0,0.08)");
    foldGrad.addColorStop(0.25, "rgba(255,255,255,0.10)");
    foldGrad.addColorStop(0.5, "rgba(0,0,0,0.10)");
    foldGrad.addColorStop(0.75, "rgba(255,255,255,0.08)");
    foldGrad.addColorStop(1, "rgba(0,0,0,0.12)");
    ctx.fillStyle = foldGrad; ctx.fillRect(0, 0, w, h);
    // 24-Spoke Ashoka Chakra in Navy Blue (#06038D)
    const cx = w * 0.5, cy = h * 0.5, r = bh * 0.41;
    ctx.strokeStyle = "#06038D";
    ctx.fillStyle = "#06038D";
    ctx.lineWidth = Math.max(2.5, r * 0.10);
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.18, 0, Math.PI * 2); ctx.fill();
    ctx.lineWidth = Math.max(1.5, r * 0.045);
    for (let i = 0; i < 24; i++) {
      const a = (i / 24) * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * r * 0.18, cy + Math.sin(a) * r * 0.18);
      ctx.lineTo(cx + Math.cos(a) * r * 0.96, cy + Math.sin(a) * r * 0.96);
      ctx.stroke();
      const midA = a + (Math.PI / 24);
      ctx.beginPath();
      ctx.arc(cx + Math.cos(midA) * r * 0.92, cy + Math.sin(midA) * r * 0.92, r * 0.045, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (presetName === "triad://jaali-screen" || presetName === "jaali-screen") {
    // Perforated Rajasthani / Mughal Carved Sandstone Jaali Lattice with Alpha-Cutout Holes!
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "#d99b66";
    ctx.fillRect(0, 0, w, h);
    // Carve transparent 8-pointed Mughal stars & rosettes using destination-out
    ctx.globalCompositeOperation = "destination-out";
    const cells = 4, cw = w / cells, ch = h / cells;
    for (let gy = 0; gy < cells; gy++) {
      for (let gx = 0; gx < cells; gx++) {
        const cx = (gx + 0.5) * cw, cy = (gy + 0.5) * ch;
        const rOuter = Math.min(cw, ch) * 0.36, rInner = rOuter * 0.52;
        ctx.beginPath();
        for (let k = 0; k < 16; k++) {
          const a = (k / 16) * Math.PI * 2;
          const r = k % 2 === 0 ? rOuter : rInner;
          if (k === 0) ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
          else ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
        }
        ctx.closePath();
        ctx.fill();
        // Corner diamond cutouts between stars
        if (gx < cells && gy < cells) {
          const dx = gx * cw, dy = gy * ch, dr = Math.min(cw, ch) * 0.14;
          ctx.beginPath();
          ctx.moveTo(dx, dy - dr); ctx.lineTo(dx + dr, dy);
          ctx.lineTo(dx, dy + dr); ctx.lineTo(dx - dr, dy);
          ctx.closePath(); ctx.fill();
        }
      }
    }
    ctx.globalCompositeOperation = "source-over";
    // Carved sandstone bevel border & lattice ribs
    ctx.strokeStyle = "#8c421e";
    ctx.lineWidth = Math.max(4, w * 0.018);
    ctx.strokeRect(2, 2, w - 4, h - 4);
    for (let gy = 0; gy < cells; gy++) {
      for (let gx = 0; gx < cells; gx++) {
        const cx = (gx + 0.5) * cw, cy = (gy + 0.5) * ch;
        ctx.strokeStyle = "#f3d5b5";
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(cx, cy, Math.min(cw, ch) * 0.40, 0, Math.PI * 2); ctx.stroke();
      }
    }
  } else if (presetName.startsWith("triad://fascia-") || presetName.startsWith("fascia-")) {
    const kind = presetName.replace("triad://", "");
    // High-Craft 3D Architectural Fascia Signboard Plaque (Brushed Brass & Deep Royal Enamel)
    const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
    if (kind.includes("surya")) {
      bgGrad.addColorStop(0, "#3b0a14"); bgGrad.addColorStop(0.5, "#590d1d"); bgGrad.addColorStop(1, "#2a060d");
    } else if (kind.includes("zaveri")) {
      bgGrad.addColorStop(0, "#062e22"); bgGrad.addColorStop(0.5, "#084735"); bgGrad.addColorStop(1, "#041f17");
    } else if (kind.includes("anokhi")) {
      bgGrad.addColorStop(0, "#121f45"); bgGrad.addColorStop(0.5, "#1d316b"); bgGrad.addColorStop(1, "#0b132b");
    } else if (kind.includes("imax")) {
      bgGrad.addColorStop(0, "#111827"); bgGrad.addColorStop(0.5, "#1f2937"); bgGrad.addColorStop(1, "#090d16");
    } else {
      bgGrad.addColorStop(0, "#451a03"); bgGrad.addColorStop(0.5, "#6b2706"); bgGrad.addColorStop(1, "#2b0f02");
    }
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);

    // Double Brushed Gold Architectural Moulding Border
    ctx.strokeStyle = "#f59e0b";
    ctx.lineWidth = Math.max(6, h * 0.055);
    ctx.strokeRect(6, 6, w - 12, h - 12);
    ctx.strokeStyle = "#fde68a";
    ctx.lineWidth = Math.max(2, h * 0.018);
    ctx.strokeRect(16, 16, w - 32, h - 32);

    // Corner Mughal Rosette Flourishes
    for (const [cx, cy] of [[28, 28], [w - 28, 28], [28, h - 28], [w - 28, h - 28]]) {
      ctx.fillStyle = "#fbbf24";
      ctx.beginPath(); ctx.arc(cx, cy, Math.min(w, h) * 0.04, 0, Math.PI * 2); ctx.fill();
    }

    // Embossed Metallic Gold Typography
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const mainTitle = kind.includes("surya") ? "SURYA MAHAL HERITAGE GALLERIA"
                    : (kind.includes("zaveri") ? "ZAVERI & SONS · ROYAL JEWELLERS"
                    : (kind.includes("anokhi") ? "ANOKHI SILKS & BRIDAL COUTURE"
                    : (kind.includes("imax") ? "INDRAPRASTHA GRAND IMAX · 70MM"
                    : "DARBAR ROYALE · SWEETS & CHAAT")));
    const subTitle = kind.includes("surya") ? "सूर्य महल हेरिटेज मॉल  ·  NEW DELHI & JAIPUR"
                   : (kind.includes("zaveri") ? "KUNDAN  ·  POLKI DIAMONDS  ·  JADAU HERITAGE GOLD"
                   : (kind.includes("anokhi") ? "HANDLOOM BANARASI  ·  ZARDOZI  ·  ROYAL LEHENGAS"
                   : (kind.includes("imax") ? "LASER PROJECTION  ·  MAHARAJA RECLINER LOUNGE"
                   : "KESAR PISTA HALWA  ·  RAJ KACHORI  ·  KULHAD CHAI")));

    ctx.shadowColor = "rgba(0,0,0,0.90)";
    ctx.shadowBlur = 8;
    ctx.shadowOffsetY = 3;
    ctx.fillStyle = "#fef08a";
    ctx.font = `bold ${Math.round(w * 0.062)}px Georgia, serif`;
    ctx.fillText(mainTitle, w * 0.5, h * 0.40, w * 0.88);

    ctx.shadowBlur = 4;
    ctx.fillStyle = "#fbbf24";
    ctx.font = `bold ${Math.round(w * 0.036)}px sans-serif`;
    ctx.fillText(subTitle, w * 0.5, h * 0.72, w * 0.86);
    ctx.shadowBlur = 0;
  } else if (presetName.startsWith("triad://storefront-") || presetName.startsWith("storefront-")) {
    const kind = presetName.replace("triad://", "");
    // Luxury Illuminated Indian Mall Showroom Window + Fascia Signboard
    ctx.fillStyle = "#1c140d";
    ctx.fillRect(0, 0, w, h);
    // Top Fascia Sign Banner
    const fh = h * 0.24;
    ctx.fillStyle = kind.includes("jewel") ? "#3b0a0a" : (kind.includes("ethnic") ? "#0f2942" : (kind.includes("cinema") ? "#1e1b4b" : "#3f1d0b"));
    ctx.fillRect(0, 0, w, fh);
    ctx.strokeStyle = "#f59e0b";
    ctx.lineWidth = 4;
    ctx.strokeRect(4, 4, w - 8, fh - 6);
    ctx.fillStyle = "#fde68a";
    ctx.font = `bold ${Math.round(fh * 0.40)}px serif`;
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    const title = kind.includes("jewel") ? "✦ ZAVERI royal JEWELLERS ✦"
                : (kind.includes("ethnic") ? "❖ ANOKHI SILKS & COUTURE ❖"
                : (kind.includes("cinema") ? "★ INDRAPRASTHA GRAND IMAX ★" : "♨ ROYAL DARBAR CHAAT & SWEETS ♨"));
    ctx.fillText(title, w * 0.5, fh * 0.42);
    ctx.fillStyle = "#f59e0b";
    ctx.font = `bold ${Math.round(fh * 0.22)}px sans-serif`;
    const sub = kind.includes("jewel") ? "22K HALLMARK GOLD · KUNDAN · POLKI DIAMONDS"
              : (kind.includes("ethnic") ? "HANDLOOM BANARASI · BANDHANI · BRIDAL LEHENGAS"
              : (kind.includes("cinema") ? "70MM LASER PROJECTION · ROYAL RECLINER LOUNGE" : "KESAR JALEBI · RAJ KACHORI · KULHAD MASALA CHAI"));
    ctx.fillText(sub, w * 0.5, fh * 0.78);

    // Warm Golden Backlit Showroom Window Display Below Fascia
    const wy = fh + 4, wh = h - wy - 4;
    const spot = ctx.createRadialGradient(w * 0.5, wy + wh * 0.35, wh * 0.05, w * 0.5, wy + wh * 0.5, w * 0.65);
    spot.addColorStop(0, "#fffbeb");
    spot.addColorStop(0.35, "#fcd34d");
    spot.addColorStop(0.75, "#b45309");
    spot.addColorStop(1, "#291507");
    ctx.fillStyle = spot;
    ctx.fillRect(6, wy, w - 12, wh);

    // Display pedestals / mannequins / arches inside showroom window
    for (let i = 0; i < 3; i++) {
      const bx = w * (0.20 + i * 0.30), by = wy + wh * 0.88;
      // Pedestal
      ctx.fillStyle = "#fef3c7";
      ctx.fillRect(bx - w * 0.08, by - wh * 0.24, w * 0.16, wh * 0.24);
      // Display bust / garment / sweet tier
      ctx.fillStyle = i === 1 ? "#be123c" : (i === 0 ? "#047857" : "#1d4ed8");
      ctx.beginPath();
      ctx.arc(bx, by - wh * 0.38, w * 0.065, 0, Math.PI * 2);
      ctx.fill();
      // Gold necklace / zari trim
      ctx.strokeStyle = "#fde047";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(bx, by - wh * 0.38, w * 0.045, 0.2, Math.PI - 0.2);
      ctx.stroke();
      // Overhead chandelier globe
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(bx, wy + wh * 0.14, w * 0.032, 0, Math.PI * 2);
      ctx.fill();
    }
    // Brass window mullions
    ctx.strokeStyle = "#d97706";
    ctx.lineWidth = 5;
    ctx.strokeRect(4, wy, w - 8, wh);
    ctx.beginPath();
    ctx.moveTo(w * 0.35, wy); ctx.lineTo(w * 0.35, wy + wh);
    ctx.moveTo(w * 0.65, wy); ctx.lineTo(w * 0.65, wy + wh);
    ctx.stroke();
  } else if (presetName === "triad://radar-dial" || presetName === "radar-dial") {
    const cx = w * 0.5, cy = h * 0.5, r = Math.min(w, h) * 0.46;
    const grad = ctx.createRadialGradient(cx, cy, r * 0.05, cx, cy, r);
    grad.addColorStop(0, "rgba(56, 189, 248, 0.42)");
    grad.addColorStop(0.7, "rgba(14, 165, 233, 0.18)");
    grad.addColorStop(1, "rgba(15, 23, 42, 0.92)");
    ctx.fillStyle = grad;
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "#38bdf8";
    for (const frac of [0.28, 0.55, 0.82, 0.98]) {
      ctx.lineWidth = frac > 0.9 ? 4 : 2;
      ctx.beginPath(); ctx.arc(cx, cy, r * frac, 0, Math.PI * 2); ctx.stroke();
    }
    for (let i = 0; i < 24; i++) {
      const a = (i / 24) * Math.PI * 2;
      const r0 = r * (i % 3 === 0 ? 0.80 : 0.88), r1 = r * 0.97;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0);
      ctx.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1);
      ctx.stroke();
    }
    ctx.fillStyle = "#e0f2fe";
    ctx.font = `bold ${Math.round(r * 0.18)}px monospace`;
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText("SECTOR 01 · CONCOURSE", cx, cy);
  } else if (presetName === "triad://hazard-badge" || presetName === "hazard-badge") {
    ctx.fillStyle = "#eab308";
    ctx.beginPath(); ctx.roundRect(0, 0, w, h, Math.min(w, h) * 0.08); ctx.fill();
    ctx.save();
    ctx.beginPath(); ctx.roundRect(w*0.04, h*0.04, w*0.92, h*0.92, Math.min(w, h) * 0.06); ctx.clip();
    ctx.fillStyle = "#111827";
    const sw = w * 0.12;
    for (let sx = -h; sx < w + h; sx += sw * 2) {
      ctx.beginPath();
      ctx.moveTo(sx, 0); ctx.lineTo(sx + sw, 0);
      ctx.lineTo(sx + sw - h, h); ctx.lineTo(sx - h, h);
      ctx.closePath(); ctx.fill();
    }
    ctx.fillStyle = "#111827";
    ctx.fillRect(w * 0.08, h * 0.30, w * 0.84, h * 0.40);
    ctx.fillStyle = "#facc15";
    ctx.font = `bold ${Math.round(h * 0.18)}px sans-serif`;
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText("HIGH VOLTAGE · 25kV", w * 0.5, h * 0.5);
    ctx.restore();
  } else {
    // Default: triad://metro-sign (Wayfinding PNG Decal with Alpha Rounded Frame)
    ctx.fillStyle = "#0f172a";
    ctx.beginPath(); ctx.roundRect(0, 0, w, h, Math.min(w, h) * 0.10); ctx.fill();
    ctx.lineWidth = Math.max(3, Math.min(w, h) * 0.025);
    ctx.strokeStyle = "#38bdf8";
    ctx.stroke();
    ctx.fillStyle = "#0284c7";
    ctx.fillRect(w * 0.06, h * 0.12, w * 0.22, h * 0.76);
    ctx.fillStyle = "#ffffff";
    ctx.font = `bold ${Math.round(h * 0.42)}px sans-serif`;
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText("M1", w * 0.17, h * 0.50);
    ctx.textAlign = "left";
    ctx.fillStyle = "#f8fafc";
    ctx.font = `bold ${Math.round(h * 0.22)}px sans-serif`;
    ctx.fillText("EXPRESS LINE →", w * 0.33, h * 0.38);
    ctx.fillStyle = "#38bdf8";
    ctx.font = `bold ${Math.round(h * 0.15)}px monospace`;
    ctx.fillText("PLATFORM A · CENTRAL", w * 0.33, h * 0.68);
  }
  ctx.restore();
}

function parsePaddingQuad(padStr) {
  if (!padStr) return [0, 0, 0, 0];
  const nums = String(padStr).trim().split(/[\s,]+/).map(tok => {
    if (tok.endsWith("%")) return Math.min(0.46, Math.max(0, parseFloat(tok) / 100.0));
    if (tok.endsWith("px")) return Math.min(0.46, Math.max(0, parseFloat(tok) / 512.0));
    const v = parseFloat(tok);
    return isNaN(v) ? 0 : Math.min(0.46, Math.max(0, v > 1.0 ? v / 100.0 : v));
  });
  if (nums.length === 1) return [nums[0], nums[0], nums[0], nums[0]];
  if (nums.length === 2) return [nums[0], nums[1], nums[0], nums[1]];
  if (nums.length === 3) return [nums[0], nums[1], nums[2], nums[1]];
  return [nums[0], nums[1], nums[2], nums[3]];
}

function extractUrlString(val) {
  if (!val || val === "none") return "";
  const m = String(val).match(/url\(\s*["']?([^"')]+)["']?\s*\)/i);
  return m ? m[1].trim() : String(val).replace(/^["']|["']$/g, "").trim();
}

const UploadedImageStore = new Map(); // name/id -> dataURL or Image or Canvas
const TextureTelemetry = {
  texturesProcessed: 0,
  downscaledCount: 0,
  normalsSkippedCount: 0,
  originalBytesTotal: 0,
  optimizedBytesTotal: 0,
  entries: new Map() // cacheKey -> { url, origW, origH, targetW, targetH, hasNormals, origBytes, optBytes }
};

function resetTextureTelemetry() {
  TextureTelemetry.texturesProcessed = 0;
  TextureTelemetry.downscaledCount = 0;
  TextureTelemetry.normalsSkippedCount = 0;
  TextureTelemetry.originalBytesTotal = 0;
  TextureTelemetry.optimizedBytesTotal = 0;
  TextureTelemetry.entries.clear();
}

function registerUploadedImage(name, dataUrlOrImg, defaultResolution = null) {
  if (!name) return;
  const cleanKey = String(name).trim().replace(/^\.\//, '');
  UploadedImageStore.set(cleanKey, { src: dataUrlOrImg, defaultResolution });
  ExternalImageCache.delete(cleanKey);
  for (const k of Array.from(PaddedTexCache.keys())) {
    if (k.startsWith(cleanKey + '|')) PaddedTexCache.delete(k);
  }
}

function resolveTargetTextureSize(resSpec, origW = 512, origH = 512, maxCap = 2048) {
  if (!resSpec || resSpec === 'auto' || resSpec === 'native') {
    const w = Math.min(maxCap, Math.max(16, origW || 512));
    const h = Math.min(maxCap, Math.max(16, origH || 512));
    return [w, h];
  }
  const s = String(resSpec).trim().toLowerCase();
  const presets = {
    tiny: 64, thumbnail: 64,
    low: 128, quarter: 128,
    medium: 256, half: 256,
    high: 512, standard: 512,
    ultra: 1024, full: 1024, max: 2048
  };
  if (presets[s] !== undefined) {
    const d = Math.min(maxCap, presets[s]);
    return [d, d];
  }
  if (s.endsWith('%')) {
    const pct = Math.max(0.05, Math.min(2.0, parseFloat(s) / 100));
    const tw = Math.min(maxCap, Math.max(16, Math.round((origW || 512) * pct)));
    const th = Math.min(maxCap, Math.max(16, Math.round((origH || 512) * pct)));
    return [tw, th];
  }
  if (s.endsWith('x') && !s.includes(' ') && /^[0-9.]+x$/.test(s)) {
    const mult = Math.max(0.05, Math.min(2.0, parseFloat(s)));
    const tw = Math.min(maxCap, Math.max(16, Math.round((origW || 512) * mult)));
    const th = Math.min(maxCap, Math.max(16, Math.round((origH || 512) * mult)));
    return [tw, th];
  }
  const parts = s.split(/[x\s,]+/).map(Number).filter(n => !isNaN(n) && n > 0);
  if (parts.length >= 2) {
    return [Math.min(maxCap, Math.max(16, Math.round(parts[0]))), Math.min(maxCap, Math.max(16, Math.round(parts[1])))];
  }
  if (parts.length === 1) {
    const d = Math.min(maxCap, Math.max(16, Math.round(parts[0])));
    return [d, d];
  }
  return [512, 512];
}

function getExternalOrPaddedTexture(cs, nodeAttrs, onAsyncLoad, optConfig = {}) {
  const rawTexProp = cs["texture-map"] || cs["surface-texture"] || cs["texture"] || cs["background-image"] || nodeAttrs["surface-texture"] || nodeAttrs["texture"] || nodeAttrs["src"] || "";
  let url = extractUrlString(rawTexProp);
  if (!url || url === "none") return null;

  // Resolution & Optimization settings (Tag Attribute > 3SS Style > Group/Scene <optimize> Config)
  const resSpec = nodeAttrs["texture-resolution"] || nodeAttrs["image-resolution"] || nodeAttrs["resolution"] ||
                  cs["texture-resolution"] || cs["image-resolution"] ||
                  optConfig.textureResolution || optConfig.maxTextureSize || null;
  const maxCap = parseInt(nodeAttrs["max-texture-size"] || cs["max-texture-size"] || optConfig.maxTextureSize || 2048, 10) || 2048;
  const synthNormAttr = nodeAttrs["synthesize-normals"] || cs["synthesize-normals"] || optConfig.synthesizeNormals;
  const synthNormals = synthNormAttr !== "false" && synthNormAttr !== false;
  const filterMode = (nodeAttrs["texture-filter"] || cs["texture-filter"] || optConfig.textureFilter || "linear").toLowerCase();
  const useMipmaps = (nodeAttrs["mipmaps"] || cs["mipmaps"] || optConfig.mipmaps) !== "false";

  if (url.startsWith("#") && DeclarativeCanvasTextures.has(url.slice(1))) {
    const baseTex = DeclarativeCanvasTextures.get(url.slice(1));
    if (!resSpec) return baseTex;
    // Allow tag-level resolution scaling even on <canvas-texture>!
    const srcCv = baseTex.image;
    const [tw, th] = resolveTargetTextureSize(resSpec, srcCv.width, srcCv.height, maxCap);
    const cKey = `canvas:${url}|${tw}x${th}|${synthNormals}|${filterMode}`;
    if (PaddedTexCache.has(cKey)) return PaddedTexCache.get(cKey);
    const scaledCv = document.createElement("canvas");
    scaledCv.width = tw; scaledCv.height = th;
    scaledCv.getContext("2d").drawImage(srcCv, 0, 0, tw, th);
    const scaledTex = new THREE.CanvasTexture(scaledCv);
    scaledTex.wrapS = baseTex.wrapS; scaledTex.wrapT = baseTex.wrapT;
    scaledTex.minFilter = filterMode === "nearest" ? THREE.NearestFilter : THREE.LinearFilter;
    scaledTex.magFilter = filterMode === "nearest" ? THREE.NearestFilter : THREE.LinearFilter;
    scaledTex.generateMipmaps = useMipmaps && filterMode !== "nearest";
    scaledTex._resolvedWidth = tw; scaledTex._resolvedHeight = th;
    scaledTex._originalWidth = srcCv.width; scaledTex._originalHeight = srcCv.height;
    PaddedTexCache.set(cKey, scaledTex);
    return scaledTex;
  }

  // Check if URL matches a registered uploaded image in UploadedImageStore
  const cleanUrlKey = url.replace(/^\.\//, '');
  let uploadedEntry = UploadedImageStore.get(cleanUrlKey) || UploadedImageStore.get(url);
  const effectiveResSpec = resSpec || (uploadedEntry && uploadedEntry.defaultResolution) || "512";

  const padStr = cs["texture-padding"] || cs["padding"] || cs["uv-padding"] || nodeAttrs["texture-padding"] || "0";
  const fitMode = (cs["texture-fit"] || cs["background-size"] || nodeAttrs["texture-fit"] || "contain").toLowerCase();
  const offsetStr = cs["texture-offset"] || "0 0";
  const scaleStr = cs["texture-scale"] || cs["pattern-scale"] || "1 1";
  const rotDeg = parseFloat(cs["texture-rotation"] || "0") || 0;
  const bgFill = cs["texture-bg"] || "transparent";

  const cacheKey = `${url}|res:${effectiveResSpec}|max:${maxCap}|norm:${synthNormals}|filt:${filterMode}|mip:${useMipmaps}|${padStr}|${fitMode}|${offsetStr}|${scaleStr}|${rotDeg}|${bgFill}`;
  if (PaddedTexCache.has(cacheKey)) return PaddedTexCache.get(cacheKey);

  const [initW, initH] = resolveTargetTextureSize(effectiveResSpec, 512, 512, maxCap);
  const cv = document.createElement("canvas");
  cv.width = initW;
  cv.height = initH;
  const ctx = cv.getContext("2d");

  const scaleParts = scaleStr.trim().split(/[\s,]+/).map(Number);
  const sx = scaleParts[0] || 1, sy = scaleParts[1] !== undefined ? scaleParts[1] : sx;
  const offParts = offsetStr.trim().split(/[\s,]+/).map(Number);
  const ox = offParts[0] || 0, oy = offParts[1] || 0;

  const tex = new THREE.CanvasTexture(cv);
  tex._resolvedWidth = initW;
  tex._resolvedHeight = initH;
  tex._originalWidth = 512;
  tex._originalHeight = 512;
  tex._sourceUrl = url;
  tex.minFilter = filterMode === "nearest" ? THREE.NearestFilter : THREE.LinearFilter;
  tex.magFilter = filterMode === "nearest" ? THREE.NearestFilter : THREE.LinearFilter;
  tex.generateMipmaps = useMipmaps && filterMode !== "nearest";

  if (fitMode === "repeat") {
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(sx, sy);
  } else {
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.repeat.set(sx, sy);
  }

  const recordTelemetry = (origW, origH, targW, targH) => {
    const mipFactor = useMipmaps ? 1.33 : 1.0;
    const origMaps = 2; // Albedo + NormalMap at original size
    const optMaps = synthNormals ? 2 : 1;
    const origBytes = Math.round(origW * origH * 4 * origMaps * 1.33);
    const optBytes = Math.round(targW * targH * 4 * optMaps * mipFactor);
    const prev = TextureTelemetry.entries.get(cacheKey);
    if (prev) {
      TextureTelemetry.originalBytesTotal -= prev.origBytes;
      TextureTelemetry.optimizedBytesTotal -= prev.optBytes;
    } else {
      TextureTelemetry.texturesProcessed++;
      if (targW < origW || targH < origH) TextureTelemetry.downscaledCount++;
      if (!synthNormals) TextureTelemetry.normalsSkippedCount++;
    }
    TextureTelemetry.originalBytesTotal += origBytes;
    TextureTelemetry.optimizedBytesTotal += optBytes;
    TextureTelemetry.entries.set(cacheKey, { url, origW, origH, targetW: targW, targetH: targH, hasNormals: synthNormals, origBytes, optBytes });
  };

  const renderComposite = (imgObj) => {
    const natW = (imgObj && (imgObj.naturalWidth || imgObj.width)) || 512;
    const natH = (imgObj && (imgObj.naturalHeight || imgObj.height)) || 512;
    const [tw, th] = resolveTargetTextureSize(effectiveResSpec, natW, natH, maxCap);
    if (cv.width !== tw || cv.height !== th) {
      cv.width = tw;
      cv.height = th;
    }
    tex._resolvedWidth = tw;
    tex._resolvedHeight = th;
    tex._originalWidth = natW;
    tex._originalHeight = natH;
    recordTelemetry(natW, natH, tw, th);

    ctx.clearRect(0, 0, tw, th);
    if (bgFill && bgFill !== "transparent" && bgFill !== "none") {
      ctx.fillStyle = bgFill;
      ctx.fillRect(0, 0, tw, th);
    }
    const [pt, pr, pb, pl] = parsePaddingQuad(padStr);
    const boxX = pl * tw + ox * tw;
    const boxY = pt * th + oy * th;
    const boxW = Math.max(4, (1.0 - pl - pr) * tw);
    const boxH = Math.max(4, (1.0 - pt - pb) * th);

    ctx.save();
    if (rotDeg !== 0) {
      const cx = boxX + boxW * 0.5, cy = boxY + boxH * 0.5;
      ctx.translate(cx, cy);
      ctx.rotate(THREE.MathUtils.degToRad(rotDeg));
      ctx.translate(-cx, -cy);
    }

    if (imgObj && natW > 0 && natH > 0) {
      let drawX = boxX, drawY = boxY, drawW = boxW, drawH = boxH;
      const imgAspect = natW / natH;
      const boxAspect = boxW / boxH;
      if (fitMode === "contain") {
        if (imgAspect > boxAspect) {
          drawW = boxW; drawH = boxW / imgAspect;
          drawY = boxY + (boxH - drawH) * 0.5;
        } else {
          drawH = boxH; drawW = boxH * imgAspect;
          drawX = boxX + (boxW - drawW) * 0.5;
        }
      } else if (fitMode === "cover") {
        ctx.beginPath(); ctx.rect(boxX, boxY, boxW, boxH); ctx.clip();
        if (imgAspect > boxAspect) {
          drawH = boxH; drawW = boxH * imgAspect;
          drawX = boxX + (boxW - drawW) * 0.5;
        } else {
          drawW = boxW; drawH = boxW / imgAspect;
          drawY = boxY + (boxH - drawH) * 0.5;
        }
      }
      ctx.drawImage(imgObj, drawX, drawY, drawW, drawH);
    } else {
      drawBuiltinPresetPNG(ctx, url, boxX, boxY, boxW, boxH);
    }
    ctx.restore();
    tex.needsUpdate = true;

    if (synthNormals && imgObj && natW > 0) {
      try {
        const aData = ctx.getImageData(0, 0, tw, th).data;
        if (!tex._synthNormalCanvas) {
          tex._synthNormalCanvas = document.createElement('canvas');
          tex._synthNormalMap = new THREE.CanvasTexture(tex._synthNormalCanvas);
          tex._synthNormalMap.wrapS = tex.wrapS;
          tex._synthNormalMap.wrapT = tex.wrapT;
          tex._synthNormalMap.repeat.copy(tex.repeat);
        }
        tex._synthNormalCanvas.width = tw;
        tex._synthNormalCanvas.height = th;
        const nCtx = tex._synthNormalCanvas.getContext('2d');
        const nImg = nCtx.createImageData(tw, th);
        const nData = nImg.data;
        const lum = new Float32Array(tw * th);
        for (let i = 0, p = 0; i < lum.length; i++, p += 4) {
          lum[i] = (aData[p] * 0.299 + aData[p+1] * 0.587 + aData[p+2] * 0.114) / 255.0;
        }
        for (let y = 0; y < th; y++) {
          const yU = ((y - 1 + th) % th) * tw, yC = y * tw, yD = ((y + 1) % th) * tw;
          for (let x = 0; x < tw; x++) {
            const xL = (x - 1 + tw) % tw, xR = (x + 1) % tw;
            const dx = (lum[yU + xR] + 2.0 * lum[yC + xR] + lum[yD + xR]) - (lum[yU + xL] + 2.0 * lum[yC + xL] + lum[yD + xL]);
            const dy = (lum[yD + xL] + 2.0 * lum[yD + x]  + lum[yD + xR]) - (lum[yU + xL] + 2.0 * lum[yU + x]  + lum[yU + xR]);
            const nz = 0.35;
            const invL = 1.0 / Math.hypot(dx, dy, nz);
            const idx = (yC + x) * 4;
            nData[idx]     = Math.round((-dx * invL * 0.5 + 0.5) * 255);
            nData[idx + 1] = Math.round(( dy * invL * 0.5 + 0.5) * 255);
            nData[idx + 2] = Math.round(( nz * invL * 0.5 + 0.5) * 255);
            nData[idx + 3] = 255;
          }
        }
        nCtx.putImageData(nImg, 0, 0);
        tex._synthNormalMap.needsUpdate = true;
      } catch (_) {}
    } else if (!synthNormals) {
      tex._synthNormalMap = null;
    }
  };

  if (uploadedEntry && uploadedEntry.src && typeof uploadedEntry.src !== "string") {
    // HTMLImageElement or HTMLCanvasElement directly registered
    renderComposite(uploadedEntry.src);
  } else if (url.startsWith("triad://") || ["metro-sign", "radar-dial", "hazard-badge", "indian-tricolor", "jaali-screen", "oak-foliage-sprig"].includes(url)) {
    renderComposite(null);
  } else {
    const resolvedSrc = (uploadedEntry && typeof uploadedEntry.src === "string") ? uploadedEntry.src : url;
    renderComposite(null);
    let entry = ExternalImageCache.get(resolvedSrc);
    if (!entry) {
      const img = new Image();
      if (!resolvedSrc.startsWith("data:")) img.crossOrigin = "anonymous";
      entry = { status: "loading", img, listeners: [] };
      ExternalImageCache.set(resolvedSrc, entry);
      img.onload = () => {
        entry.status = "loaded";
        entry.listeners.forEach(fn => fn(img));
        entry.listeners = [];
      };
      img.onerror = () => {
        entry.status = "error";
        entry.listeners.forEach(fn => fn(null));
        entry.listeners = [];
      };
      img.src = resolvedSrc;
    }
    if (entry.status === "loaded") {
      renderComposite(entry.img);
    } else if (entry.status === "loading") {
      entry.listeners.push((loadedImg) => {
        if (loadedImg) renderComposite(loadedImg);
        if (onAsyncLoad) onAsyncLoad();
      });
    }
  }

  PaddedTexCache.set(cacheKey, tex);
  return tex;
}

const PatternCache = new Map();
const BasePatternCanvasCache = new Map(); // patternName -> { albCanvas, normCanvas, roughCanvas }
const CustomPatterns = new Map(); // name -> { fn, fnSig, size }

function registerCustomPattern(name, fn, size = 512) {
  if (!name || typeof fn !== 'function') return;
  const cleanName = String(name).trim().toLowerCase();
  const clampedSize = Math.min(1024, Math.max(128, size));
  const fnSig = `${clampedSize}:${fn.toString()}`;
  const prev = CustomPatterns.get(cleanName);
  if (prev && prev.fnSig === fnSig) {
    prev.fn = fn;
    return; // Unchanged pattern source: preserve synthesized 512x512 textures in cache!
  }
  CustomPatterns.set(cleanName, { fn, fnSig, size: clampedSize });
  BasePatternCanvasCache.delete(cleanName);
  for (const k of Array.from(PatternCache.keys())) {
    if (k.startsWith(cleanName + '_')) PatternCache.delete(k);
  }
  const patSel = typeof document !== 'undefined' ? document.getElementById('pbr-pattern') : null;
  if (patSel && !patSel.querySelector(`option[value="${cleanName}"]`)) {
    const opt = document.createElement('option');
    opt.value = cleanName;
    opt.textContent = `${cleanName} (Custom 3JS Pattern)`;
    patSel.appendChild(opt);
  }
}

function _wrapPatternCanvases(base, repeatX, repeatY) {
  const makeTex = (cv) => {
    const t = new THREE.CanvasTexture(cv);
    t.wrapS = THREE.RepeatWrapping;
    t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(repeatX, repeatY);
    t.generateMipmaps = true;
    t.needsUpdate = true;
    return t;
  };
  return {
    map: makeTex(base.albCanvas),
    normalMap: makeTex(base.normCanvas),
    roughnessMap: makeTex(base.roughCanvas)
  };
}

const DeclarativeCanvasTextures = new Map(); // id -> THREE.CanvasTexture

function registerDeclarativeCanvasTexture(id, width, height, drawCode, scope = {}) {
  if (!id || typeof document === 'undefined') return null;
  const w = Math.max(16, Math.min(2048, parseInt(width || 512, 10)));
  const h = Math.max(16, Math.min(2048, parseInt(height || 512, 10)));
  const cv = document.createElement('canvas');
  cv.width = w; cv.height = h;
  const ctx = cv.getContext('2d');
  if (drawCode) {
    try {
      const fn = new Function('ctx', 'w', 'h', 'width', 'height', 'THREE', 'Math', drawCode);
      fn(ctx, w, h, w, h, THREE, Math);
    } catch (err) {
      console.error(`[Triad3D <canvas-texture id="${id}"> Error]`, err);
      logConsole(`<canvas-texture id="${id}"> error: ${err.message}`, 'err');
    }
  }
  const tex = new THREE.CanvasTexture(cv);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.generateMipmaps = true;
  tex.needsUpdate = true;
  if (typeof _synthNormalMapFromCanvas === 'function') {
    tex._synthNormalMap = _synthNormalMapFromCanvas(cv);
  }
  DeclarativeCanvasTextures.set(id.replace(/^#/, ''), tex);
  return tex;
}

// Register architectural patterns (haussmann-stone, paris-cobble, mansard-zinc, french-window)
function _registerArchitecturalPatterns() {
  const reg = (name, fn) => registerCustomPattern(name, fn, 512);
  reg('brick', (ctx, w, h) => {
    ctx.fillStyle = '#8b3a2b'; ctx.fillRect(0, 0, w, h);
    const rows = 8, cols = 4, rh = h / rows, cw = w / cols;
    for (let r = 0; r < rows; r++) {
      const off = (r % 2) * cw * 0.5;
      for (let c = -1; c <= cols; c++) {
        const shade = ((r * 13 + c * 29) & 15) - 8;
        ctx.fillStyle = `rgb(${139 + shade},${58 + Math.round(shade * 0.5)},${43 + Math.round(shade * 0.4)})`;
        ctx.fillRect(c * cw + off + 3, r * rh + 3, cw - 6, rh - 6);
      }
      ctx.fillStyle = '#c8bfb2'; ctx.fillRect(0, r * rh, w, 4);
    }
  });
  reg('cobble', (ctx, w, h) => {
    ctx.fillStyle = '#2d3138'; ctx.fillRect(0, 0, w, h);
    const rows = 8, cols = 10, rh = h / rows, cw = w / cols;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const v = 72 + ((r * 19 + c * 37) % 34);
        ctx.fillStyle = `rgb(${v},${v+2},${v+5})`;
        ctx.beginPath(); ctx.roundRect(((c + (r % 2) * 0.5) * cw % w) + 2, r * rh + 2, cw - 4, rh - 4, 6); ctx.fill();
      }
    }
  });
  reg('wood', (ctx, w, h) => {
    ctx.fillStyle = '#7c4d2b'; ctx.fillRect(0, 0, w, h);
    for (let p = 0; p < 6; p++) {
      const py = p * (h / 6);
      ctx.fillStyle = p % 2 === 0 ? '#855330' : '#734626';
      ctx.fillRect(0, py + 2, w, h / 6 - 3);
      ctx.strokeStyle = 'rgba(42,22,10,0.28)'; ctx.lineWidth = 2;
      for (let g = 0; g < 5; g++) {
        ctx.beginPath();
        ctx.moveTo(0, py + 12 + g * 14);
        ctx.bezierCurveTo(w * 0.33, py + 8 + g * 14, w * 0.66, py + 18 + g * 14, w, py + 12 + g * 14);
        ctx.stroke();
      }
      ctx.fillStyle = '#3b2212'; ctx.fillRect(0, py, w, 3);
    }
  });
  reg('marble', (ctx, w, h) => {
    ctx.fillStyle = '#f1efe9'; ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = 'rgba(148,144,138,0.45)';
    for (let i = 0; i < 14; i++) {
      ctx.lineWidth = 1 + (i % 3);
      ctx.beginPath();
      let x = (i * 41) % w, y = 0;
      ctx.moveTo(x, y);
      for (let s = 1; s <= 8; s++) {
        x += Math.sin(i * 2.1 + s * 1.4) * 34;
        y = (s / 8) * h;
        ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
  });
  reg('grid', (ctx, w, h) => {
    ctx.fillStyle = '#1e293b'; ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = '#38bdf8'; ctx.lineWidth = 2;
    const step = w / 8;
    for (let i = 0; i <= 8; i++) {
      ctx.beginPath(); ctx.moveTo(i * step, 0); ctx.lineTo(i * step, h); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, i * step); ctx.lineTo(w, i * step); ctx.stroke();
    }
  });
  reg('stone', (ctx, w, h) => {
    ctx.fillStyle = '#78756e'; ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 400; i++) {
      const x = (i * 73) % w, y = (i * 137) % h, sz = 4 + (i % 12);
      const v = 100 + (i % 45);
      ctx.fillStyle = `rgba(${v},${v-2},${v-6},0.35)`;
      ctx.fillRect(x, y, sz, sz);
    }
  });
  reg('concrete', (ctx, w, h) => {
    ctx.fillStyle = '#9ca3af'; ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 600; i++) {
      const x = (i * 97) % w, y = (i * 53) % h, v = 130 + (i % 40);
      ctx.fillStyle = `rgba(${v},${v},${v+2},0.25)`;
      ctx.fillRect(x, y, 6, 6);
    }
  });
  reg('asphalt', (ctx, w, h) => {
    ctx.fillStyle = '#262930'; ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 900; i++) {
      const x = (i * 113) % w, y = (i * 67) % h, v = 28 + (i % 35);
      ctx.fillStyle = `rgb(${v},${v+1},${v+3})`;
      ctx.fillRect(x, y, 3, 3);
    }
  });
  reg('tiles', (ctx, w, h) => {
    ctx.fillStyle = '#e2e8f0'; ctx.fillRect(0, 0, w, h);
    const n = 4, s = w / n;
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) {
      ctx.fillStyle = (r + c) % 2 === 0 ? '#cbd5e1' : '#f1f5f9';
      ctx.fillRect(c * s + 3, r * s + 3, s - 6, s - 6);
    }
  });
  reg('metal', (ctx, w, h) => {
    ctx.fillStyle = '#64748b'; ctx.fillRect(0, 0, w, h);
    for (let y = 0; y < h; y += 2) {
      const v = 95 + ((y * 17) % 24);
      ctx.fillStyle = `rgb(${v},${v+4},${v+10})`;
      ctx.fillRect(0, y, w, 1);
    }
  });
  reg('grass', (ctx, w, h) => {
    ctx.fillStyle = '#2e5e2e'; ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 700; i++) {
      const x = (i * 89) % w, y = (i * 149) % h;
      ctx.fillStyle = i % 2 === 0 ? '#3a7a38' : '#244d24';
      ctx.fillRect(x, y, 3, 9);
    }
  });
  reg('water', (ctx, w, h) => {
    ctx.fillStyle = '#164e63'; ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = 'rgba(125,211,252,0.28)'; ctx.lineWidth = 3;
    for (let y = 16; y < h; y += 32) {
      ctx.beginPath();
      for (let x = 0; x <= w; x += 16) ctx.lineTo(x, y + Math.sin(x * 0.05 + y) * 6);
      ctx.stroke();
    }
  });

  registerCustomPattern('haussmann-stone', (ctx, w, h) => {
    ctx.fillStyle = '#e6dac6';
    ctx.fillRect(0, 0, w, h);
    const rows = 8, rowH = h / rows;
    for (let r = 0; r < rows; r++) {
      const y = r * rowH;
      ctx.fillStyle = r % 2 === 0 ? '#eadfce' : '#dfd2bc';
      ctx.fillRect(0, y + 2, w, rowH - 4);
      ctx.fillStyle = '#b5a48b';
      ctx.fillRect(0, y, w, 3);
      const cols = 4;
      const colW = w / cols;
      const off = (r % 2) * (colW * 0.5);
      for (let c = 0; c <= cols; c++) {
        const x = (c * colW + off) % w;
        ctx.fillRect(x, y, 2, rowH);
      }
    }
  }, 512);

  registerCustomPattern('paris-cobble', (ctx, w, h) => {
    ctx.fillStyle = '#242830';
    ctx.fillRect(0, 0, w, h);
    const rows = 10, cols = 14;
    const rw = w / cols, rh = h / rows;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const ox = ((r % 2) * 0.5 + c) * rw;
        const oy = r * rh;
        const shade = 48 + ((r * 17 + c * 31) % 28);
        ctx.fillStyle = `rgb(${shade},${shade+2},${shade+7})`;
        ctx.beginPath();
        ctx.roundRect((ox + 2) % w, oy + 2, rw - 4, rh - 4, 4);
        ctx.fill();
      }
    }
  }, 512);

  registerCustomPattern('mansard-zinc', (ctx, w, h) => {
    ctx.fillStyle = '#3b4352';
    ctx.fillRect(0, 0, w, h);
    const seams = 12, sw = w / seams;
    for (let i = 0; i < seams; i++) {
      const x = i * sw;
      ctx.fillStyle = i % 2 === 0 ? '#404959' : '#363e4c';
      ctx.fillRect(x + 2, 0, sw - 4, h);
      ctx.fillStyle = '#222730';
      ctx.fillRect(x, 0, 3, h);
      ctx.fillStyle = '#566175';
      ctx.fillRect(x + 3, 0, 2, h);
    }
  }, 512);
}

function getProceduralPatternTextures(patternName, repeatX = 4, repeatY = 4) {
  if (!patternName || patternName === 'none') return null;
  const key = `${patternName}_${repeatX}_${repeatY}`;
  if (PatternCache.has(key)) return PatternCache.get(key);
  if (BasePatternCanvasCache.has(patternName)) {
    const bundle = _wrapPatternCanvases(BasePatternCanvasCache.get(patternName), repeatX, repeatY);
    PatternCache.set(key, bundle);
    return bundle;
  }

  if (CustomPatterns.has(patternName)) {
    const { fn, size } = CustomPatterns.get(patternName);
    const albCanvas = document.createElement('canvas');
    const normCanvas = document.createElement('canvas');
    const roughCanvas = document.createElement('canvas');
    albCanvas.width = normCanvas.width = roughCanvas.width = size;
    albCanvas.height = normCanvas.height = roughCanvas.height = size;
    const aCtx = albCanvas.getContext('2d');
    const nCtx = normCanvas.getContext('2d');
    const rCtx = roughCanvas.getContext('2d');
    aCtx.fillStyle = '#ffffff';
    aCtx.fillRect(0, 0, size, size);
    try {
      fn(aCtx, size, size);
    } catch (_) {}
    const aImg = aCtx.getImageData(0, 0, size, size);
    const nImg = nCtx.createImageData(size, size);
    const rImg = rCtx.createImageData(size, size);
    const aData = aImg.data, nData = nImg.data, rData = rImg.data;
    const lumGrid = new Float32Array(size * size);
    const inv255 = 1.0 / 255.0;
    for (let i = 0, p = 0; i < lumGrid.length; i++, p += 4) {
      lumGrid[i] = (aData[p] * 0.299 + aData[p + 1] * 0.587 + aData[p + 2] * 0.114) * inv255;
    }
    const mask = size - 1;
    const isPow2 = (size & mask) === 0;
    for (let y = 0; y < size; y++) {
      const yUp = (isPow2 ? ((y + 1) & mask) : ((y + 1) % size)) * size;
      const yDn = (isPow2 ? ((y - 1 + size) & mask) : ((y - 1 + size) % size)) * size;
      const yRow = y * size;
      for (let x = 0; x < size; x++) {
        const xR = isPow2 ? ((x + 1) & mask) : ((x + 1) % size);
        const xL = isPow2 ? ((x - 1 + size) & mask) : ((x - 1 + size) % size);
        const h = lumGrid[yRow + x];
        const hx = lumGrid[yRow + xR] - lumGrid[yRow + xL];
        const hy = lumGrid[yUp + x] - lumGrid[yDn + x];
        const nx = -hx * 2.5, ny = -hy * 2.5;
        const invNl = 1.0 / Math.sqrt(nx * nx + ny * ny + 1.0);
        const idx = (yRow + x) * 4;
        nData[idx]     = ((nx * invNl * 0.5 + 0.5) * 255) | 0;
        nData[idx + 1] = ((ny * invNl * 0.5 + 0.5) * 255) | 0;
        nData[idx + 2] = ((invNl * 0.5 + 0.5) * 255) | 0;
        nData[idx + 3] = 255;
        const rv = Math.max(25, Math.min(240, ((0.65 - (h - 0.5) * 0.45) * 255) | 0));
        rData[idx] = rData[idx + 1] = rData[idx + 2] = rv;
        rData[idx + 3] = 255;
      }
    }
    nCtx.putImageData(nImg, 0, 0);
    rCtx.putImageData(rImg, 0, 0);
    const base = { albCanvas, normCanvas, roughCanvas };
    BasePatternCanvasCache.set(patternName, base);
    const bundle = _wrapPatternCanvases(base, repeatX, repeatY);
    PatternCache.set(key, bundle);
    return bundle;
  }

  const size = 512;
  const albCanvas = document.createElement('canvas');
  const normCanvas = document.createElement('canvas');
  const roughCanvas = document.createElement('canvas');
  albCanvas.width = normCanvas.width = roughCanvas.width = size;
  albCanvas.height = normCanvas.height = roughCanvas.height = size;

  const aCtx = albCanvas.getContext('2d');
  const nCtx = normCanvas.getContext('2d');
  const rCtx = roughCanvas.getContext('2d');

  const aImg = aCtx.createImageData(size, size);
  const nImg = nCtx.createImageData(size, size);
  const rImg = rCtx.createImageData(size, size);

  const hash2 = (gx, gy) => {
    const s = Math.sin(gx * 127.1 + gy * 311.7) * 43758.5453;
    return s - Math.floor(s);
  };

  const sampleSurface = (x, y) => {
    const u = ((x % size) + size) % size / size;
    const v = ((y % size) + size) % size / size;
    const fineNoise = Math.sin(u * Math.PI * 48) * Math.cos(v * Math.PI * 48) * 0.03
                    + Math.sin((u * 112 + v * 84)) * 0.02;

    if (patternName === 'red-sandstone') {
      // Authentic Agra / Dholpur Red-Buff Ashlar Sandstone Masonry with subtle block-to-block chromatic tones
      const rows = 8, cols = 4;
      const row = Math.floor(v * rows);
      const uShift = (u * cols + (row % 2) * 0.5);
      const col = Math.floor(uShift) % cols;
      const fx = uShift % 1;
      const fy = (v * rows) % 1;
      const bHash = hash2(col + (row % 2) * 7, row);
      const bHash2 = hash2(col * 3 + 11, row * 5 + 3);
      // Soft bevel near mortar joint (no harsh black lines!)
      const edgeX = Math.min(fx, 1.0 - fx) * cols;
      const edgeY = Math.min(fy, 1.0 - fy) * rows;
      const jointDist = Math.min(edgeX, edgeY);
      const isMortar = jointDist < 0.085;
      const bevel = Math.min(1.0, jointDist / 0.18);
      // Sedimentary bedding ripples inside each sandstone block
      const strata = Math.sin((v * rows * 3.5 + bHash * 6.0 + 0.25 * Math.sin(u * Math.PI * 8)) * Math.PI * 2) * 0.045;
      const h = (isMortar ? 0.32 : (0.62 + 0.26 * bevel + (bHash - 0.5) * 0.08 + strata)) + fineNoise;
      // Chromatic RGB multiplier (centered around white so 3SS base color tints naturally, while adding authentic multi-block warmth)
      const rMul = isMortar ? 0.84 : (0.94 + (bHash - 0.45) * 0.16 + strata * 0.8);
      const gMul = isMortar ? 0.78 : (0.92 + (bHash2 - 0.5) * 0.14 + strata * 0.5);
      const bMul = isMortar ? 0.72 : (0.90 + (bHash - 0.5) * 0.10);
      const rough = isMortar ? 0.92 : (0.68 - strata * 0.25 + (bHash2 - 0.5) * 0.12);
      return { h, r: rMul, g: gMul, b: bMul, rough };
    } else if (patternName === 'jaisalmer-sandstone') {
      const rows = 6, cols = 3;
      const row = Math.floor(v * rows);
      const uShift = (u * cols + (row % 2) * 0.5);
      const col = Math.floor(uShift) % cols;
      const fx = uShift % 1, fy = (v * rows) % 1;
      const bHash = hash2(col + 19, row + 7);
      const jointDist = Math.min(Math.min(fx, 1 - fx) * cols, Math.min(fy, 1 - fy) * rows);
      const bevel = Math.min(1.0, jointDist / 0.15);
      const h = (jointDist < 0.07 ? 0.38 : 0.68 + 0.24 * bevel + (bHash - 0.5) * 0.06) + fineNoise;
      const tint = 0.94 + (bHash - 0.5) * 0.12;
      return { h, r: tint * 1.02, g: tint, b: tint * 0.95, rough: 0.58 };
    } else if (patternName === 'makrana-marble') {
      // Polished Ivory-White Makrana Marble Slabs with warm Calacatta gold-grey veins
      const slabs = 2;
      const fx = (u * slabs) % 1, fy = (v * slabs) % 1;
      const joint = Math.min(Math.min(fx, 1 - fx), Math.min(fy, 1 - fy));
      const isGroove = joint < 0.018;
      const warp = 0.35 * Math.sin(u * Math.PI * 4 + v * Math.PI * 2) + 0.18 * Math.cos(u * Math.PI * 10 - v * Math.PI * 8);
      const vein1 = Math.exp(-Math.pow(Math.sin((u * 2.5 + v * 1.8 + warp) * Math.PI), 2.0) * 18.0);
      const vein2 = Math.exp(-Math.pow(Math.cos((u * 4.0 - v * 3.2 + warp * 1.4) * Math.PI), 2.0) * 28.0) * 0.65;
      const vStrength = Math.min(1.0, vein1 + vein2);
      const h = isGroove ? 0.35 : (0.88 - vStrength * 0.04 + fineNoise * 0.25);
      const r = isGroove ? 0.82 : (1.0 - vStrength * 0.06);
      const g = isGroove ? 0.80 : (0.99 - vStrength * 0.08);
      const b = isGroove ? 0.77 : (0.97 - vStrength * 0.12);
      const rough = isGroove ? 0.65 : (0.14 + vStrength * 0.12);
      return { h, r, g, b, rough };
    } else if (patternName === 'terracotta-tiles') {
      // Interlocking Courtyard Sandstone & Terracotta Pavers with natural stone block tones
      const cols = 8, rows = 8;
      const row = Math.floor(v * rows);
      const uShift = u * cols + (row % 2) * 0.5;
      const col = Math.floor(uShift) % cols;
      const fx = uShift % 1, fy = (v * rows) % 1;
      const bHash = hash2(col + 3, row + 13);
      const bHash2 = hash2(col * 7, row * 3);
      const edge = Math.min(Math.min(fx, 1 - fx), Math.min(fy, 1 - fy));
      const isGrout = edge < 0.055;
      const bevel = Math.min(1.0, edge / 0.14);
      const h = (isGrout ? 0.28 : 0.64 + 0.26 * bevel + (bHash - 0.5) * 0.07) + fineNoise;
      const r = isGrout ? 0.72 : (0.93 + (bHash - 0.45) * 0.15);
      const g = isGrout ? 0.68 : (0.91 + (bHash2 - 0.5) * 0.12);
      const b = isGrout ? 0.64 : (0.88 + (bHash - 0.5) * 0.10);
      return { h, r, g, b, rough: isGrout ? 0.88 : (0.46 + bHash * 0.16) };
    } else if (patternName === 'boulevard-asphalt') {
      const spk = hash2(Math.floor(u * 256), Math.floor(v * 256));
      const macro = Math.sin(u * Math.PI * 4) * Math.cos(v * Math.PI * 4) * 0.06;
      const h = 0.45 + (spk - 0.5) * 0.22 + macro;
      const c = 0.90 + (spk - 0.5) * 0.14 + macro;
      return { h, r: c, g: c, b: c * 1.03, rough: 0.55 - macro * 1.2 + (spk - 0.5) * 0.2 };
    }

    // Legacy procedural patterns
    let h = 0.5;
    if (patternName === 'brushed-metal') {
      h = 0.5 + 0.25 * Math.sin(v * Math.PI * 64 + Math.sin(u * Math.PI * 8) * 0.4)
              + 0.15 * Math.cos(v * Math.PI * 140 + u * 12.0);
    } else if (patternName === 'carbon-fiber') {
      const gx = Math.floor(u * 16), gy = Math.floor(v * 16);
      const phase = ((gx + gy) % 4) / 4.0;
      const lu = (u * 16) % 1, lv = (v * 16) % 1;
      const ridge = Math.sin(lu * Math.PI) * Math.sin(lv * Math.PI);
      h = 0.35 + 0.55 * ridge * (0.6 + 0.4 * Math.cos(phase * Math.PI * 2));
    } else if (patternName === 'fluted-stone') {
      const flute = Math.abs(Math.sin(u * Math.PI * 12));
      const mortarY = (v * 4) % 1 < 0.04 ? 0.42 : 1.0;
      h = (0.52 + 0.38 * flute + fineNoise) * mortarY;
    } else if (patternName === 'hex-grid') {
      const sx = u * 10, sy = v * 10 * 1.1547;
      const row = Math.floor(sy);
      const cx = (sx + (row % 2) * 0.5) % 1 - 0.5;
      const cy = (sy % 1) - 0.5;
      const d = Math.hypot(cx, cy);
      h = d > 0.42 ? 0.25 : 0.85 - d * 0.4;
    } else if (patternName === 'skyscraper-glass') {
      const cols = 16, rows = 32;
      const fx = (u * cols) % 1, fy = (v * rows) % 1;
      const gx = Math.floor(u * cols), gy = Math.floor(v * rows);
      const isMullion = fx < 0.12 || fy < 0.15;
      const litHash = hash2(gx, gy);
      h = isMullion ? 0.90 : (litHash > 0.42 ? 0.78 : 0.32);
    } else if (patternName === 'art-deco-facade') {
      const cols = 12, rows = 24;
      const fx = (u * cols) % 1, fy = (v * rows) % 1;
      h = (fx < 0.24 || fx > 0.84) ? 0.92 : (fy < 0.20 ? 0.76 : 0.30);
    } else if (patternName === 'checker') {
      h = ((Math.floor(u * 8) + Math.floor(v * 8)) % 2) ? 0.92 : 0.55;
    }
    const isArch = (patternName === 'skyscraper-glass' || patternName === 'art-deco-facade');
    const c = isArch ? (0.30 + h * 0.70) : (0.78 + (h - 0.5) * 0.34);
    return { h, r: c, g: c, b: c, rough: 1.0 - h * 0.45 };
  };

  // Precompute height grid for fast central-difference normal map generation
  const hGrid = new Float32Array(size * size);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (y * size + x) * 4;
      const s = sampleSurface(x, y);
      hGrid[y * size + x] = s.h;
      aImg.data[idx]     = Math.max(0, Math.min(255, Math.floor(s.r * 255)));
      aImg.data[idx + 1] = Math.max(0, Math.min(255, Math.floor(s.g * 255)));
      aImg.data[idx + 2] = Math.max(0, Math.min(255, Math.floor(s.b * 255)));
      aImg.data[idx + 3] = 255;

      const rVal = Math.max(20, Math.min(255, Math.floor(s.rough * 255)));
      rImg.data[idx] = rImg.data[idx + 1] = rImg.data[idx + 2] = rVal;
      rImg.data[idx + 3] = 255;
    }
  }

  for (let y = 0; y < size; y++) {
    const yUp = ((y + 1) % size) * size;
    const yDn = ((y - 1 + size) % size) * size;
    const yRow = y * size;
    for (let x = 0; x < size; x++) {
      const idx = (yRow + x) * 4;
      const hx = hGrid[yRow + ((x + 1) % size)] - hGrid[yRow + ((x - 1 + size) % size)];
      const hy = hGrid[yUp + x] - hGrid[yDn + x];
      const nx = -hx * 3.2, ny = -hy * 3.2, nz = 1.0;
      const nl = Math.hypot(nx, ny, nz) || 1.0;
      nImg.data[idx]     = Math.floor(((nx / nl) * 0.5 + 0.5) * 255);
      nImg.data[idx + 1] = Math.floor(((ny / nl) * 0.5 + 0.5) * 255);
      nImg.data[idx + 2] = Math.floor(((nz / nl) * 0.5 + 0.5) * 255);
      nImg.data[idx + 3] = 255;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  nCtx.putImageData(nImg, 0, 0);
  rCtx.putImageData(rImg, 0, 0);

  const base = { albCanvas, normCanvas, roughCanvas };
  BasePatternCanvasCache.set(patternName, base);
  const bundle = _wrapPatternCanvases(base, repeatX, repeatY);
  PatternCache.set(key, bundle);
  return bundle;
}

// ============================================================================
// 2. TRIAD.NOISE & TRIAD.MESHBUILDER (General-Purpose Constructive & Organic Kernel)
// ============================================================================
const TriadNoise = {
  hash(n) {
    const s = Math.sin(n * 127.1 + 311.7) * 43758.5453123;
    return s - Math.floor(s);
  },
  hash3(x, y, z) {
    const s = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453123;
    return s - Math.floor(s);
  },
  hash2(x, y) {
    const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453123;
    return s - Math.floor(s);
  },
  noise2(x, y) {
    const ix = Math.floor(x), iy = Math.floor(y);
    const fx = x - ix, fy = y - iy;
    const ux = fx * fx * (3.0 - 2.0 * fx);
    const uy = fy * fy * (3.0 - 2.0 * fy);
    const a = this.hash2(ix, iy), b = this.hash2(ix + 1, iy);
    const c = this.hash2(ix, iy + 1), d = this.hash2(ix + 1, iy + 1);
    const lerp = (p, q, t) => p + (q - p) * t;
    return lerp(lerp(a, b, ux), lerp(c, d, ux), uy) * 2.0 - 1.0;
  },
  fbm2(x, y, octaves = 4) {
    let v = 0.0, amp = 0.5, freq = 1.0;
    for (let i = 0; i < octaves; i++) {
      v += amp * this.noise2(x * freq, y * freq);
      freq *= 2.03;
      amp *= 0.5;
    }
    return v;
  },
  ridge2(x, y, octaves = 4) {
    let v = 0.0, amp = 0.5, freq = 1.0;
    for (let i = 0; i < octaves; i++) {
      const n = 1.0 - Math.abs(this.noise2(x * freq, y * freq));
      v += amp * n * n;
      freq *= 2.05;
      amp *= 0.5;
    }
    return v;
  },
  noise3(x, y, z) {
    const ix = Math.floor(x), iy = Math.floor(y), iz = Math.floor(z);
    const fx = x - ix, fy = y - iy, fz = z - iz;
    const ux = fx * fx * (3.0 - 2.0 * fx);
    const uy = fy * fy * (3.0 - 2.0 * fy);
    const uz = fz * fz * (3.0 - 2.0 * fz);
    const lerp = (a, b, t) => a + (b - a) * t;
    const n000 = this.hash3(ix, iy, iz),     n100 = this.hash3(ix+1, iy, iz);
    const n010 = this.hash3(ix, iy+1, iz),   n110 = this.hash3(ix+1, iy+1, iz);
    const n001 = this.hash3(ix, iy, iz+1),   n101 = this.hash3(ix+1, iy, iz+1);
    const n011 = this.hash3(ix, iy+1, iz+1), n111 = this.hash3(ix+1, iy+1, iz+1);
    return lerp(
      lerp(lerp(n000, n100, ux), lerp(n010, n110, ux), uy),
      lerp(lerp(n001, n101, ux), lerp(n011, n111, ux), uy),
      uz
    ) * 2.0 - 1.0;
  },
  fbm3(x, y, z, octaves = 4) {
    let v = 0.0, amp = 0.5, freq = 1.0;
    for (let i = 0; i < octaves; i++) {
      v += amp * this.noise3(x * freq, y * freq, z * freq);
      freq *= 2.03;
      amp *= 0.5;
    }
    return v;
  },
  ridge3(x, y, z, octaves = 4) {
    let v = 0.0, amp = 0.5, freq = 1.0;
    for (let i = 0; i < octaves; i++) {
      const n = 1.0 - Math.abs(this.noise3(x * freq, y * freq, z * freq));
      v += amp * n * n;
      freq *= 2.05;
      amp *= 0.5;
    }
    return v;
  }
};

class TriadMeshBuilder {
  constructor() {
    this.parts = [];
    this.hasVertexColors = false;
  }
  addGeometry(geo, pos = [0,0,0], rotDeg = [0,0,0], scale = [1,1,1], colorHex = null, _isFresh = false) {
    const g = _isFresh ? geo : geo.clone();
    if (!g.attributes.normal) g.computeVertexNormals();
    if (scale && (scale[0] !== 1 || scale[1] !== 1 || scale[2] !== 1)) g.scale(scale[0], scale[1], scale[2]);
    if (rotDeg && rotDeg[0]) g.rotateX(THREE.MathUtils.degToRad(rotDeg[0]));
    if (rotDeg && rotDeg[1]) g.rotateY(THREE.MathUtils.degToRad(rotDeg[1]));
    if (rotDeg && rotDeg[2]) g.rotateZ(THREE.MathUtils.degToRad(rotDeg[2]));
    if (pos && (pos[0] || pos[1] || pos[2])) g.translate(pos[0], pos[1], pos[2]);

    const vCount = g.attributes.position.count;
    if (colorHex !== null && colorHex !== undefined) {
      this.hasVertexColors = true;
      const col = new THREE.Color(colorHex);
      const cArr = new Float32Array(vCount * 3);
      for (let i = 0; i < vCount; i++) {
        cArr[i * 3] = col.r;
        cArr[i * 3 + 1] = col.g;
        cArr[i * 3 + 2] = col.b;
      }
      g.setAttribute('color', new THREE.Float32BufferAttribute(cArr, 3));
    } else if (!g.attributes.color) {
      const cArr = new Float32Array(vCount * 3);
      cArr.fill(1.0);
      g.setAttribute('color', new THREE.Float32BufferAttribute(cArr, 3));
    }
    this.parts.push(g);
    return this;
  }
  addLathe(profilePairs, segments = 32, pos = [0,0,0], colorHex = null) {
    const pts = profilePairs.map(([r, y]) => new THREE.Vector2(Math.max(0.001, r), y));
    return this.addGeometry(new THREE.LatheGeometry(pts, segments), pos, [0,0,0], [1,1,1], colorHex, true);
  }
  addTube(pathPoints, radius = 0.04, tubularSegs = 32, radialSegs = 12, colorHex = null) {
    const vecs = pathPoints.map(([x, y, z]) => new THREE.Vector3(x, y, z));
    const curve = new THREE.CatmullRomCurve3(vecs);
    return this.addGeometry(new THREE.TubeGeometry(curve, tubularSegs, radius, radialSegs, false), [0,0,0], [0,0,0], [1,1,1], colorHex, true);
  }
  addBox(a = [1, 1, 1], b = [0, 0, 0], c = [0, 0, 0], d = null, e = null, f = null, g = null) {
    if (typeof a === "number") {
      return this.addGeometry(new THREE.BoxGeometry(d || 1, e || 1, f || 1), [a, b, c], [0, 0, 0], [1, 1, 1], g, true);
    }
    return this.addGeometry(new THREE.BoxGeometry(a[0], a[1], a[2]), b, c, [1, 1, 1], d, true);
  }
  addCylinder(rTop = 0.5, rBot = 0.5, height = 1.0, segs = 16, pos = [0, 0, 0], rotDeg = [0, 0, 0], colorHex = null) {
    return this.addGeometry(new THREE.CylinderGeometry(rTop, rBot, height, segs), pos, rotDeg, [1, 1, 1], colorHex, true);
  }
  addSphere(radius = 0.5, wSegs = 16, hSegs = 12, pos = [0, 0, 0], scale = [1, 1, 1], colorHex = null) {
    return this.addGeometry(new THREE.SphereGeometry(radius, wSegs, hSegs), pos, [0, 0, 0], scale, colorHex, true);
  }
  addTorus(radius = 0.5, tube = 0.1, rSegs = 12, tSegs = 24, pos = [0, 0, 0], rotDeg = [0, 0, 0], colorHex = null) {
    return this.addGeometry(new THREE.TorusGeometry(radius, tube, rSegs, tSegs), pos, rotDeg, [1, 1, 1], colorHex, true);
  }
  addCone(radius = 0.5, height = 1.0, segs = 16, pos = [0, 0, 0], rotDeg = [0, 0, 0], colorHex = null) {
    return this.addGeometry(new THREE.ConeGeometry(radius, height, segs), pos, rotDeg, [1, 1, 1], colorHex, true);
  }

  // General-Purpose Organic Spline Sweep with Continuous Radius Taper & Bark/Flute Furrows
  addTaperedTube(pathPoints, rStart = 0.35, rEnd = 0.08, tubularSegs = 24, radialSegs = 14, colorHex = null, furrowAmp = 0.0, furrowFreq = 8) {
    if (!pathPoints || pathPoints.length < 2) return this;
    const vecs = pathPoints.map(([x, y, z]) => new THREE.Vector3(x, y, z));
    const curve = new THREE.CatmullRomCurve3(vecs);
    const tSegs = Math.max(2, tubularSegs);
    const rSegs = Math.max(4, radialSegs);
    const pos = [], norm = [], uv = [], indices = [];

    let prevT = new THREE.Vector3(0, 1, 0);
    let prevN = new THREE.Vector3(1, 0, 0);
    const t0 = curve.getTangent(0).normalize();
    prevT.copy(t0);
    const upRef = Math.abs(t0.y) < 0.9 ? new THREE.Vector3(0, 1, 0) : new THREE.Vector3(1, 0, 0);
    prevN.crossVectors(t0, upRef).normalize();

    for (let i = 0; i <= tSegs; i++) {
      const u = i / tSegs;
      const pt = curve.getPoint(u);
      const tang = curve.getTangent(u).normalize();
      // Parallel-transport frame propagation (twist-free along 3D curves)
      const axis = new THREE.Vector3().crossVectors(prevT, tang);
      if (axis.lengthSq() > 1e-6) {
        const angle = Math.acos( Math.max(-1, Math.min(1, prevT.dot(tang))) );
        axis.normalize();
        const q = new THREE.Quaternion().setFromAxisAngle(axis, angle);
        prevN.applyQuaternion(q).normalize();
      }
      prevT.copy(tang);
      const binorm = new THREE.Vector3().crossVectors(tang, prevN).normalize();

      const baseR = rStart + (rEnd - rStart) * Math.pow(u, 0.85);
      // Root/base flare near u = 0
      const flare = (u < 0.18 && furrowAmp > 0) ? (1.0 + Math.pow((0.18 - u) / 0.18, 2.0) * 0.28) : 1.0;

      for (let j = 0; j <= rSegs; j++) {
        const v = j / rSegs;
        const theta = v * Math.PI * 2;
        const c = Math.cos(theta), s = Math.sin(theta);
        let rMod = 1.0;
        if (furrowAmp > 0.0) {
          const twistTheta = theta + u * 2.4;
          const furrow = Math.sin(twistTheta * furrowFreq) * 0.65 + Math.cos(twistTheta * (furrowFreq * 2 - 1) + u * 9.0) * 0.35;
          rMod = 1.0 + furrowAmp * furrow * (1.0 - 0.35 * u);
        }
        const r = Math.max(0.004, baseR * flare * rMod);
        const nx = prevN.x * c + binorm.x * s;
        const ny = prevN.y * c + binorm.y * s;
        const nz = prevN.z * c + binorm.z * s;
        pos.push(pt.x + nx * r, pt.y + ny * r, pt.z + nz * r);
        norm.push(nx, ny, nz);
        uv.push(v * 2.0, u * 4.0);
      }
    }

    const stride = rSegs + 1;
    for (let i = 0; i < tSegs; i++) {
      for (let j = 0; j < rSegs; j++) {
        const a = i * stride + j;
        const b = (i + 1) * stride + j;
        const c = (i + 1) * stride + (j + 1);
        const d = i * stride + (j + 1);
        indices.push(a, b, d, b, c, d);
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('normal', new THREE.Float32BufferAttribute(norm, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    geo.setIndex(indices);
    geo.computeVertexNormals();
    return this.addGeometry(geo, [0, 0, 0], [0, 0, 0], [1, 1, 1], colorHex, true);
  }

  // General-Purpose Cross-Section Lofting Across Arbitrary 3D Rings
  addLoft(rings, closed = true, colorHex = null) {
    if (!rings || rings.length < 2) return this;
    const nRings = rings.length;
    const nPts = rings[0].length;
    if (nPts < 3) return this;
    const pos = [], uv = [], indices = [];
    const cols = closed ? nPts + 1 : nPts;
    for (let r = 0; r < nRings; r++) {
      const v = r / (nRings - 1);
      const ring = rings[r];
      for (let p = 0; p < cols; p++) {
        const u = p / (cols - 1);
        const pt = ring[p % nPts];
        pos.push(pt[0], pt[1], pt[2]);
        uv.push(u, v);
      }
    }
    for (let r = 0; r < nRings - 1; r++) {
      for (let p = 0; p < cols - 1; p++) {
        const a = r * cols + p, b = (r + 1) * cols + p, c = (r + 1) * cols + (p + 1), d = r * cols + (p + 1);
        indices.push(a, b, d, b, c, d);
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    geo.setIndex(indices);
    geo.computeVertexNormals();
    return this.addGeometry(geo, [0, 0, 0], [0, 0, 0], [1, 1, 1], colorHex, true);
  }

  // General-Purpose FBM Noise-Displaced Boulder / Organic Mass
  addDisplacedSphere(radius = 0.5, segs = 20, pos = [0, 0, 0], scale = [1, 1, 1], noiseAmp = 0.22, noiseFreq = 2.2, colorHex = null) {
    const geo = new THREE.SphereGeometry(radius, segs, Math.max(8, Math.floor(segs * 0.75)));
    const pAttr = geo.attributes.position;
    for (let i = 0; i < pAttr.count; i++) {
      const vx = pAttr.getX(i), vy = pAttr.getY(i), vz = pAttr.getZ(i);
      const n = TriadNoise.fbm3(vx * noiseFreq + pos[0], vy * noiseFreq + pos[1], vz * noiseFreq + pos[2], 3);
      const d = 1.0 + noiseAmp * n;
      pAttr.setXYZ(i, vx * d, vy * d, vz * d);
    }
    geo.computeVertexNormals();
    return this.addGeometry(geo, pos, [0, 0, 0], scale, colorHex, true);
  }

  // General-Purpose Botanical Canopy Billow with Hemispherical Sub-Dome Normal Transfer & Canopy Depth AO
  addCanopyBillow(center = [0, 4, 0], radii = [1.2, 0.9, 1.2], cardCount = 14, cardSize = 1.05, colorHex = '#4d7c28', seed = 1.0) {
    const [cx, cy, cz] = center;
    const [rx, ry, rz] = radii;
    const pos = [], norm = [], uv = [], colArr = [], indices = [];
    const baseCol = new THREE.Color(colorHex);
    let vOffset = 0;

    for (let k = 0; k < cardCount; k++) {
      // Golden-ratio Fibonacci sphere distribution + shell layering
      const t = (k + 0.5) / cardCount;
      const phi = Math.acos(1.0 - 2.0 * t);
      const theta = Math.PI * (1.0 + Math.sqrt(5.0)) * k + seed * 3.7;
      const shell = 0.42 + 0.58 * TriadNoise.hash(k * 13.7 + seed * 9.1);

      const lx = Math.sin(phi) * Math.cos(theta) * rx * shell;
      const ly = Math.cos(phi) * ry * shell;
      const lz = Math.sin(phi) * Math.sin(theta) * rz * shell;
      const px = cx + lx, py = cy + ly, pz = cz + lz;

      // Outward sub-dome radial direction
      let dx = lx / (rx || 1), dy = (ly / (ry || 1)) + 0.25, dz = lz / (rz || 1);
      const dl = Math.hypot(dx, dy, dz) || 1.0;
      dx /= dl; dy /= dl; dz /= dl;

      // Build a slightly curved 2x2 quad card tangent to the sub-dome with randomized roll
      const roll = (TriadNoise.hash(k * 7.3 + seed * 5.3) - 0.5) * 1.4;
      const upVec = Math.abs(dy) < 0.9 ? new THREE.Vector3(0, 1, 0) : new THREE.Vector3(1, 0, 0);
      const right = new THREE.Vector3().crossVectors(upVec, new THREE.Vector3(dx, dy, dz)).normalize();
      const up = new THREE.Vector3().crossVectors(new THREE.Vector3(dx, dy, dz), right).normalize();
      const cr = Math.cos(roll), sr = Math.sin(roll);
      const tx = right.x * cr + up.x * sr, ty = right.y * cr + up.y * sr, tz = right.z * cr + up.z * sr;
      const bx = -right.x * sr + up.x * cr, by = -right.y * sr + up.y * cr, bz = -right.z * sr + up.z * cr;

      const s = cardSize * (0.82 + 0.36 * TriadNoise.hash(k * 19.1 + seed));
      const corners = [
        [-0.5 * s, -0.5 * s, 0, 0],
        [ 0.5 * s, -0.5 * s, 1, 0],
        [ 0.5 * s,  0.5 * s, 1, 1],
        [-0.5 * s,  0.5 * s, 0, 1]
      ];

      // Interior canopy ambient occlusion + sunward zenith warmth
      const ao = Math.max(0.42, Math.min(1.18, 0.58 + 0.36 * shell + 0.22 * dy));
      const warmShift = Math.max(0, dy) * 0.08;
      const vr = Math.min(1.0, baseCol.r * ao + warmShift);
      const vg = Math.min(1.0, baseCol.g * ao + warmShift * 0.7);
      const vb = Math.min(1.0, baseCol.b * ao * 0.92);

      for (let c = 0; c < 4; c++) {
        const [uX, uY, uCoord, vCoord] = corners[c];
        // Slight outward cup curvature so cards never look flat from edge-on angles
        const cup = -0.14 * s * (uX * uX + uY * uY) / (s * s);
        const vx = px + tx * uX + bx * uY + dx * cup;
        const vy = py + ty * uX + by * uY + dy * cup;
        const vz = pz + tz * uX + bz * uY + dz * cup;
        pos.push(vx, vy, vz);

        // Hemispherical sub-dome normal transfer!
        let vnx = (vx - cx) / (rx || 1) + dx * 0.45;
        let vny = (vy - cy) / (ry || 1) + 0.38;
        let vnz = (vz - cz) / (rz || 1) + dz * 0.45;
        const vnl = Math.hypot(vnx, vny, vnz) || 1.0;
        norm.push(vnx / vnl, vny / vnl, vnz / vnl);
        uv.push(uCoord, vCoord);
        colArr.push(vr, vg, vb);
      }

      // Double-sided indices so backfaces also render in shadow pass
      indices.push(
        vOffset, vOffset + 1, vOffset + 2,
        vOffset, vOffset + 2, vOffset + 3,
        vOffset, vOffset + 2, vOffset + 1,
        vOffset, vOffset + 3, vOffset + 2
      );
      vOffset += 4;
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('normal', new THREE.Float32BufferAttribute(norm, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colArr, 3));
    geo.setIndex(indices);
    this.hasVertexColors = true;
    this._preserveNormals = true;
    this.parts.push(geo);
    return this;
  }
  build(preserveCustomNormals = false) {
    if (!this.parts.length) return new THREE.BoxGeometry(0.5, 0.5, 0.5);
    const merged = THREE.mergeGeometries(this.parts);
    if (!this.hasVertexColors) merged.deleteAttribute('color');
    else merged._hasMultiColor = true;
    if (!preserveCustomNormals && !this._preserveNormals) merged.computeVertexNormals();
    return merged;
  }
}

const BuiltinGenerators = new Map();

function registerDefaultGenerators() {
  BuiltinGenerators.set('ergonomic-seat', (attrs) => {
    const width = parseFloat(attrs.width || 0.52);
    const segsX = 14, segsT = 28;
    const spine = [
      new THREE.Vector3(0, 0.36, 0.24),
      new THREE.Vector3(0, 0.43, 0.22),
      new THREE.Vector3(0, 0.42, 0.02),
      new THREE.Vector3(0, 0.44, -0.14),
      new THREE.Vector3(0, 0.62, -0.20),
      new THREE.Vector3(0, 0.85, -0.17),
      new THREE.Vector3(0, 1.04, -0.22)
    ];
    const curve = new THREE.CatmullRomCurve3(spine);
    const pos = [], norm = [], uv = [], indices = [];
    const halfW = width * 0.5, thick = 0.042;

    for (let j = 0; j <= segsT; j++) {
      const v = j / segsT;
      const p = curve.getPoint(v);
      const tang = new THREE.Vector3().subVectors(curve.getPoint(Math.min(1, v + 0.01)), curve.getPoint(Math.max(0, v - 0.01))).normalize();
      const nVec = new THREE.Vector3(0, tang.z, -tang.y).normalize();
      const taper = 1.0 - 0.18 * Math.pow(Math.max(0, v - 0.55) / 0.45, 1.5);
      for (let i = 0; i <= segsX; i++) {
        const u = i / segsX;
        const xNorm = (u - 0.5) * 2.0;
        const bolster = Math.pow(Math.abs(xNorm), 2.4) * 0.038 * (v > 0.1 && v < 0.88 ? 1 : 0.3);
        pos.push(xNorm * halfW * taper, p.y + nVec.y * bolster, p.z + nVec.z * bolster);
        const nx = -xNorm * 0.22, nl = Math.hypot(nx, nVec.y, nVec.z) || 1;
        norm.push(nx / nl, nVec.y / nl, nVec.z / nl);
        uv.push(u, v);
      }
    }
    const frontVertCount = (segsT + 1) * (segsX + 1);
    for (let j = 0; j <= segsT; j++) {
      const v = j / segsT;
      const p = curve.getPoint(v);
      const tang = new THREE.Vector3().subVectors(curve.getPoint(Math.min(1, v + 0.01)), curve.getPoint(Math.max(0, v - 0.01))).normalize();
      const nVec = new THREE.Vector3(0, tang.z, -tang.y).normalize();
      const taper = 1.0 - 0.18 * Math.pow(Math.max(0, v - 0.55) / 0.45, 1.5);
      for (let i = 0; i <= segsX; i++) {
        const u = i / segsX;
        const xNorm = (u - 0.5) * 2.0;
        pos.push(xNorm * halfW * taper, p.y - nVec.y * thick, p.z - nVec.z * thick);
        norm.push(0, -nVec.y, -nVec.z);
        uv.push(u, v);
      }
    }
    const rowLen = segsX + 1;
    for (let j = 0; j < segsT; j++) {
      for (let i = 0; i < segsX; i++) {
        const a = j * rowLen + i, b = (j + 1) * rowLen + i, c = (j + 1) * rowLen + (i + 1), d = j * rowLen + (i + 1);
        indices.push(a, d, b, b, d, c);
        const ba = frontVertCount + a, bb = frontVertCount + b, bc = frontVertCount + c, bd = frontVertCount + d;
        indices.push(ba, bb, bd, bb, bc, bd);
      }
    }
    const shellGeo = new THREE.BufferGeometry();
    shellGeo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    shellGeo.setAttribute('normal', new THREE.Float32BufferAttribute(norm, 3));
    shellGeo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    shellGeo.setIndex(indices);
    shellGeo.computeVertexNormals();

    const ped = new THREE.CylinderGeometry(0.045, 0.065, 0.40, 16).translate(0, 0.20, -0.04);
    const foot = new THREE.CylinderGeometry(0.14, 0.16, 0.03, 20).translate(0, 0.015, -0.04);
    const handleCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-halfW * 0.55, 1.01, -0.22),
      new THREE.Vector3(-halfW * 0.48, 1.11, -0.24),
      new THREE.Vector3(halfW * 0.48, 1.11, -0.24),
      new THREE.Vector3(halfW * 0.55, 1.01, -0.22)
    ]);
    const handle = new THREE.TubeGeometry(handleCurve, 20, 0.016, 10, false);
    return THREE.mergeGeometries([shellGeo, ped, foot, handle]);
  });

  BuiltinGenerators.set('involute-gear', (attrs) => {
    const teeth = Math.max(6, parseInt(attrs.teeth || 20, 10));
    const pitchR = parseFloat(attrs.radius || 0.8);
    const thickness = parseFloat(attrs.thickness || 0.12);
    const boreR = parseFloat(attrs.bore || pitchR * 0.18);
    const addendum = pitchR / teeth * 1.1;
    const dedendum = pitchR / teeth * 1.25;
    const outerR = pitchR + addendum;
    const rootR = Math.max(boreR + 0.05, pitchR - dedendum);

    const shape = new THREE.Shape();
    const stepsPerTooth = 6;
    const totalSteps = teeth * stepsPerTooth;
    for (let i = 0; i <= totalSteps; i++) {
      const toothIdx = i % stepsPerTooth;
      const baseAngle = (Math.floor(i / stepsPerTooth) / teeth) * Math.PI * 2;
      const pitchStep = (Math.PI * 2) / teeth;
      let r = rootR, angOffset = 0;
      if (toothIdx === 0) { r = rootR; angOffset = 0; }
      else if (toothIdx === 1) { r = rootR; angOffset = pitchStep * 0.18; }
      else if (toothIdx === 2) { r = pitchR; angOffset = pitchStep * 0.26; }
      else if (toothIdx === 3) { r = outerR; angOffset = pitchStep * 0.34; }
      else if (toothIdx === 4) { r = outerR; angOffset = pitchStep * 0.54; }
      else if (toothIdx === 5) { r = pitchR; angOffset = pitchStep * 0.62; }
      const a = baseAngle + angOffset;
      if (i === 0) shape.moveTo(Math.cos(a) * r, Math.sin(a) * r);
      else shape.lineTo(Math.cos(a) * r, Math.sin(a) * r);
    }
    const rimGeo = new THREE.ExtrudeGeometry(shape, { depth: thickness, bevelEnabled: true, bevelThickness: thickness * 0.12, bevelSize: thickness * 0.1 });
    rimGeo.rotateX(-Math.PI / 2);
    rimGeo.translate(0, -thickness * 0.5, 0);
    const hub = new THREE.CylinderGeometry(boreR * 1.8, boreR * 1.8, thickness * 1.6, 24);
    const boss = new THREE.CylinderGeometry(boreR * 0.9, boreR * 0.9, thickness * 2.2, 20);
    return THREE.mergeGeometries([rimGeo, hub, boss]);
  });

  BuiltinGenerators.set('cloth-flag', (attrs) => {
    const w = parseFloat(attrs.width || 1.8), h = parseFloat(attrs.height || 1.15);
    const geo = new THREE.PlaneGeometry(w, h, 44, 26);
    const pos = geo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i) + w * 0.5, y = pos.getY(i);
      const u = Math.max(0, x / w);
      const wave = (Math.sin(u * Math.PI * 2.8 + y * 1.2) * 0.12 + Math.cos(u * Math.PI * 5.5 - y * 2.0) * 0.03) * Math.pow(u, 1.1);
      pos.setXYZ(i, x, y - 0.06 * Math.pow(u, 1.3), wave);
    }
    geo.computeVertexNormals();
    return geo;
  });

  BuiltinGenerators.set('fluted-column', (attrs) => {
    const radius = parseFloat(attrs.radius || 0.34);
    const height = parseFloat(attrs.height || 4.2);
    const flutes = parseInt(attrs.flutes || 20, 10);
    const shaftH = height - 0.58;
    const shaft = new THREE.CylinderGeometry(radius * 0.88, radius, shaftH, flutes * 3, 20, false);
    const pos = shaft.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const vx = pos.getX(i), vy = pos.getY(i), vz = pos.getZ(i);
      const r = Math.hypot(vx, vz);
      if (r > 0.01 && Math.abs(vy) < shaftH * 0.48) {
        const groove = Math.max(0, Math.cos(Math.atan2(vz, vx) * flutes)) * 0.022;
        const s = (r - groove) / r;
        pos.setXYZ(i, vx * s, vy, vz * s);
      }
    }
    shaft.computeVertexNormals();
    shaft.translate(0, 0.32 + shaftH * 0.5, 0);
    const baseGeo = new THREE.LatheGeometry([
      new THREE.Vector2(0.01, 0.0), new THREE.Vector2(radius * 1.38, 0.0),
      new THREE.Vector2(radius * 1.38, 0.11), new THREE.Vector2(radius * 1.24, 0.16),
      new THREE.Vector2(radius * 1.12, 0.24), new THREE.Vector2(radius * 1.02, 0.32),
      new THREE.Vector2(0.01, 0.32)
    ], 32);
    const capY = 0.32 + shaftH;
    const capGeo = new THREE.LatheGeometry([
      new THREE.Vector2(0.01, capY), new THREE.Vector2(radius * 0.90, capY),
      new THREE.Vector2(radius * 1.08, capY + 0.08), new THREE.Vector2(radius * 1.28, capY + 0.18),
      new THREE.Vector2(radius * 1.35, capY + 0.26), new THREE.Vector2(0.01, capY + 0.26)
    ], 32);
    return THREE.mergeGeometries([baseGeo, shaft, capGeo]);
  });
}
registerDefaultGenerators();

// ============================================================================
// 3. 3SS 2.0 ENGINE (Supports @import, @mixin, @include, anchor, specificity)
// ============================================================================
class SpatialStyleSheet {
  constructor() {
    this.variables = new Map();
    this.mixins = new Map();
    this.rules = [];
    this.keyframes = new Map();
  }

  parse(cssText, vfsFiles = {}) {
    this.variables.clear();
    this.mixins.clear();
    this.rules = [];
    this.keyframes.clear();

    // 1. Expand @import "path.3ss"; from project VFS
    let mergedCss = cssText.replace(/@import\s+["']([^"']+)["']\s*;/g, (_, path) => {
      return vfsFiles[path] || '';
    });

    const clean = mergedCss.replace(/\/\*[\s\S]*?\*\//g, '');

    // 2. Extract @mixin name { ... }
    const mixinRx = /@mixin\s+([a-zA-Z0-9_-]+)\s*\{([^}]*)\}/g;
    let mm;
    while ((mm = mixinRx.exec(clean)) !== null) {
      this.mixins.set(mm[1].trim(), this._parseDeclarations(mm[2]));
    }
    const withoutMixins = clean.replace(mixinRx, '');

    // 3. Extract @keyframes
    const kfRegex = /@keyframes\s+([a-zA-Z0-9_-]+)\s*\{([\s\S]*?\}\s*)\}/g;
    let match;
    while ((match = kfRegex.exec(withoutMixins)) !== null) {
      const name = match[1].trim();
      const body = match[2];
      const frames = [];
      const stepRegex = /([0-9.]+%|from|to)\s*\{([^}]*)\}/g;
      let sm;
      while ((sm = stepRegex.exec(body)) !== null) {
        let pct = sm[1].trim();
        const t = pct === 'from' ? 0 : (pct === 'to' ? 1 : parseFloat(pct) / 100.0);
        frames.push({ t, props: this._parseDeclarations(sm[2]) });
      }
      frames.sort((a, b) => a.t - b.t);
      this.keyframes.set(name, frames);
    }

    const withoutKf = withoutMixins.replace(kfRegex, '');
    const ruleRegex = /([^{]+)\{([^}]*)\}/g;
    let order = 0;
    while ((match = ruleRegex.exec(withoutKf)) !== null) {
      const selectorGroup = match[1].trim();
      const decls = this._parseDeclarations(match[2]);
      if (!selectorGroup) continue;
      const selectors = selectorGroup.split(',').map(s => s.trim()).filter(Boolean);
      for (const sel of selectors) {
        if (sel === ':root') {
          for (const [k, v] of Object.entries(decls)) {
            if (k.startsWith('--')) this.variables.set(k, v);
          }
          continue;
        }
        this.rules.push({
          selector: sel,
          specificity: this._computeSpecificity(sel),
          order: order++,
          declarations: decls
        });
      }
    }
  }

  _splitDeclarationsSafe(block) {
    const parts = [];
    let cur = '', depth = 0, quote = '';
    for (let i = 0; i < block.length; i++) {
      const ch = block[i];
      if (quote) {
        if (ch === quote && block[i - 1] !== '\\') quote = '';
        cur += ch;
      } else if (ch === '"' || ch === "'") {
        quote = ch;
        cur += ch;
      } else if (ch === '(') {
        depth++;
        cur += ch;
      } else if (ch === ')') {
        depth = Math.max(0, depth - 1);
        cur += ch;
      } else if (ch === ';' && depth === 0) {
        if (cur.trim()) parts.push(cur);
        cur = '';
      } else {
        cur += ch;
      }
    }
    if (cur.trim()) parts.push(cur);
    return parts;
  }

  _parseDeclarations(block) {
    const decls = {};
    const parts = this._splitDeclarationsSafe(block);
    for (const part of parts) {
      const trimmed = part.trim();
      if (trimmed.startsWith('@include ')) {
        const mixinName = trimmed.slice(9).trim();
        const mixinDecls = this.mixins.get(mixinName);
        if (mixinDecls) Object.assign(decls, mixinDecls);
        continue;
      }
      const colon = trimmed.indexOf(':');
      if (colon === -1) continue;
      const key = trimmed.slice(0, colon).trim().toLowerCase();
      const val = trimmed.slice(colon + 1).trim();
      if (key && val) decls[key] = val;
    }
    return decls;
  }

  resolveValue(val) {
    if (typeof val !== 'string') return val;
    return val.replace(/var\(\s*(--[a-zA-Z0-9_-]+)\s*(?:,\s*([^)]+))?\)/g, (_, varName, fallback) => {
      return this.variables.get(varName) || (fallback ? fallback.trim() : '');
    });
  }

  _computeSpecificity(selector) {
    const ids = (selector.match(/#[a-zA-Z0-9_-]+/g) || []).length;
    const classes = (selector.match(/\.[a-zA-Z0-9_-]+/g) || []).length;
    const pseudos = (selector.match(/:[a-zA-Z0-9_()+-]+/g) || []).length;
    const stripped = selector
      .replace(/#[a-zA-Z0-9_-]+/g, ' ')
      .replace(/\.[a-zA-Z0-9_-]+/g, ' ')
      .replace(/:[a-zA-Z0-9_()+-]+/g, ' ')
      .replace(/[>+~]/g, ' ')
      .trim();
    const tags = stripped ? stripped.split(/\s+/).filter(Boolean).length : 0;
    return [ids, classes + pseudos, tags];
  }

  matchesNode(node, selector) {
    const tokens = selector.replace(/\s*>\s*/g, ' > ').trim().split(/\s+/);
    let idx = tokens.length - 1;
    if (!this._matchesCompound(node, tokens[idx])) return false;
    idx--;
    let curr = node;
    while (idx >= 0) {
      const tok = tokens[idx];
      if (tok === '>') {
        idx--;
        if (idx < 0) return false;
        curr = curr.parent;
        if (!curr || !this._matchesCompound(curr, tokens[idx])) return false;
        idx--;
      } else {
        curr = curr.parent;
        while (curr && !this._matchesCompound(curr, tok)) curr = curr.parent;
        if (!curr) return false;
        idx--;
      }
    }
    return true;
  }

  _matchesCompound(node, compound) {
    if (!node || !node.tagName) return false;
    if (compound === '*') return true;
    let rem = compound;
    const pseudos = rem.match(/:[a-zA-Z0-9_()+-]+/g) || [];
    for (const p of pseudos) {
      if (p === ':hover' && !node._isHovered) return false;
      if (p === ':selected' && !node._isSelected) return false;
      if (p === ':active' && !node._isActive) return false;
      if (p === ':nth-child(even)' && node.parent) {
        if ((node.parent.children.indexOf(node) + 1) % 2 !== 0) return false;
      }
      if (p === ':nth-child(odd)' && node.parent) {
        if ((node.parent.children.indexOf(node) + 1) % 2 !== 1) return false;
      }
    }
    rem = rem.replace(/:[a-zA-Z0-9_()+-]+/g, '');
    const idMatch = rem.match(/#([a-zA-Z0-9_-]+)/);
    if (idMatch) {
      if (node.id !== idMatch[1]) return false;
      rem = rem.replace(/#[a-zA-Z0-9_-]+/g, '');
    }
    const classMatches = rem.match(/\.([a-zA-Z0-9_-]+)/g) || [];
    for (const cm of classMatches) {
      if (!node.classList.contains(cm.slice(1))) return false;
    }
    rem = rem.replace(/\.[a-zA-Z0-9_-]+/g, '').trim();
    if (rem && rem.toLowerCase() !== node.tagName.toLowerCase()) return false;
    return true;
  }

  computeCascadeForNode(node) {
    const matched = [];
    for (const rule of this.rules) {
      if (this.matchesNode(node, rule.selector)) {
        const resolvedDecls = {};
        for (const [k, v] of Object.entries(rule.declarations)) {
          resolvedDecls[k] = this.resolveValue(v);
        }
        matched.push({
          selector: rule.selector,
          specificity: rule.specificity,
          order: rule.order,
          declarations: resolvedDecls
        });
      }
    }
    matched.sort((a, b) => {
      for (let i = 0; i < 3; i++) {
        if (a.specificity[i] !== b.specificity[i]) return a.specificity[i] - b.specificity[i];
      }
      return a.order - b.order;
    });

    const computed = {};
    const winningRuleIndex = {};
    matched.forEach((m, rIdx) => {
      for (const [k, v] of Object.entries(m.declarations)) {
        computed[k] = v;
        winningRuleIndex[k] = rIdx;
      }
    });
    const inlineDecls = {};
    // 1. Parse SML inline style="..." attribute (just like HTML inline style!)
    if (node.attributes && node.attributes.style) {
      const parsedAttrStyle = this._parseDeclarations(node.attributes.style);
      for (const [k, v] of Object.entries(parsedAttrStyle)) {
        const resolved = this.resolveValue(v);
        inlineDecls[k] = resolved;
        computed[k] = resolved;
        winningRuleIndex[k] = matched.length;
      }
    }
    // 2. Apply runtime 3JS / Inspector node.style overrides
    for (const [k, v] of Object.entries(node._inlineStyle || {})) {
      if (v !== undefined && v !== null && v !== '') {
        const propName = k.replace(/[A-Z]/g, m => '-' + m.toLowerCase());
        const resolved = this.resolveValue(String(v));
        inlineDecls[propName] = resolved;
        computed[propName] = resolved;
        winningRuleIndex[propName] = matched.length;
      }
    }
    if (Object.keys(inlineDecls).length > 0) {
      matched.push({
        selector: 'element.style (Inline SML / 3JS)',
        specificity: [9, 9, 9],
        order: 99999,
        declarations: inlineDecls
      });
    }
    return { matched, computed, winningRuleIndex };
  }
}

// ============================================================================
// 4. SML 2.0 COMPILER (Multi-file <import>, <component>, {expr}, <for>, <if>, <csg>, <modifier>)
// ============================================================================
let NextUid = 1;

class SMLNode {
  constructor(tagName, attributes = {}, sourceLine = 1, sourceFile = 'main.sml') {
    this.uid = NextUid++;
    this.tagName = tagName.toLowerCase();
    this.attributes = { ...attributes };
    this.sourceLine = sourceLine;
    this.sourceFile = sourceFile;
    this.parent = null;
    this.children = [];
    this.object3D = null;
    this._basePos = new THREE.Vector3();
    this._baseRot = new THREE.Vector3();
    this._baseScale = new THREE.Vector3(1, 1, 1);
    this._anchorYOffset = 0;
    this._inlineStyle = {};
    this._listeners = new Map();
    this._isHovered = false;
    this._isSelected = false;
    this._isActive = false;
    this._expanded = true;
    this._computedStyle = {};
    this._matchedCascade = null;

    const self = this;
    this.classList = {
      _set() { return new Set((self.attributes.class || '').split(/\s+/).filter(Boolean)); },
      _save(s) {
        self.attributes.class = Array.from(s).join(' ');
        if (self._sceneRef) self._sceneRef.refreshStyles();
      },
      contains(c) { return this._set().has(c); },
      add(...cs) { const s = this._set(); cs.forEach(c => s.add(c)); this._save(s); },
      remove(...cs) { const s = this._set(); cs.forEach(c => s.delete(c)); this._save(s); },
      toggle(c) {
        const s = this._set();
        const has = s.has(c);
        if (has) s.delete(c); else s.add(c);
        this._save(s);
        return !has;
      }
    };

    this.style = new Proxy(this._inlineStyle, {
      set(target, prop, value) {
        target[prop] = value;
        if (self._sceneRef) self._sceneRef.applyStyleToNode(self);
        return true;
      },
      get(target, prop) { return target[prop]; }
    });
  }

  get id() { return this.attributes.id || ''; }
  set id(v) { this.attributes.id = v; }

  getAttribute(name) { return this.attributes[name]; }
  setAttribute(name, val) {
    const k = name.toLowerCase();
    this.attributes[k] = String(val);
    if (k === 'style') this._inlineStyle = {};
    if (this._sceneRef) this._sceneRef.rebuildNodeGeometryAndTransform(this);
    return this;
  }
  setAttr(name, val) { return this.setAttribute(name, val); }
  setStyle(prop, val) {
    this.style[prop] = val;
    return this;
  }
  get scaleX() { return this.object3D ? this.object3D.scale.x : 1; }
  set scaleX(v) { if (this.object3D) { this.object3D.scale.x = v; this._baseScale.x = v; } }
  get scaleY() { return this.object3D ? this.object3D.scale.y : 1; }
  set scaleY(v) { if (this.object3D) { this.object3D.scale.y = v; this._baseScale.y = v; } }
  get scaleZ() { return this.object3D ? this.object3D.scale.z : 1; }
  set scaleZ(v) { if (this.object3D) { this.object3D.scale.z = v; this._baseScale.z = v; } }

  appendChild(child) {
    if (child.parent) {
      const idx = child.parent.children.indexOf(child);
      if (idx >= 0) child.parent.children.splice(idx, 1);
    }
    child.parent = this;
    child._sceneRef = this._sceneRef;
    this.children.push(child);
    if (this.object3D && child.object3D) this.object3D.add(child.object3D);
    return child;
  }

  addEventListener(type, fn) {
    if (!this._listeners.has(type)) this._listeners.set(type, []);
    this._listeners.get(type).push(fn);
  }

  dispatchEvent(type, payload = {}) {
    const list = this._listeners.get(type);
    if (list) {
      for (const fn of list) {
        try { fn({ type, target: this, ...payload }); }
        catch (err) { logConsole(`Event Error (${type}): ${err.message}`, 'err'); }
      }
    }
  }

  get posX() { return this.object3D ? this.object3D.position.x : 0; }
  set posX(v) { if (this.object3D) this.object3D.position.x = v; }
  get posY() { return this.object3D ? this.object3D.position.y : 0; }
  set posY(v) { if (this.object3D) this.object3D.position.y = v; }
  get posZ() { return this.object3D ? this.object3D.position.z : 0; }
  set posZ(v) { if (this.object3D) this.object3D.position.z = v; }

  get rotX() { return this.object3D ? THREE.MathUtils.radToDeg(this.object3D.rotation.x) : 0; }
  set rotX(v) { if (this.object3D) this.object3D.rotation.x = THREE.MathUtils.degToRad(v); }
  get rotY() { return this.object3D ? THREE.MathUtils.radToDeg(this.object3D.rotation.y) : 0; }
  set rotY(v) { if (this.object3D) this.object3D.rotation.y = THREE.MathUtils.degToRad(v); }
  get rotZ() { return this.object3D ? THREE.MathUtils.radToDeg(this.object3D.rotation.z) : 0; }
  set rotZ(v) { if (this.object3D) this.object3D.rotation.z = THREE.MathUtils.degToRad(v); }

  querySelector(sel) {
    let found = null;
    const visit = (n) => {
      if (found) return;
      if (n !== this && this._sceneRef.styleSheet.matchesNode(n, sel)) { found = n; return; }
      for (const c of n.children) visit(c);
    };
    visit(this);
    return found;
  }

  querySelectorAll(sel) {
    const results = [];
    const visit = (n) => {
      if (n !== this && this._sceneRef.styleSheet.matchesNode(n, sel)) results.push(n);
      for (const c of n.children) visit(c);
    };
    visit(this);
    return results;
  }

  getEffectiveOptimizationConfig() {
    if (this._cachedOptConfig) return this._cachedOptConfig;
    const chain = [];
    let curr = this;
    while (curr) {
      chain.unshift(curr);
      curr = curr.parent;
    }
    const cfg = {
      textureResolution: null,
      maxTextureSize: 2048,
      synthesizeNormals: true,
      textureFilter: 'linear',
      mipmaps: true,
      mergeMeshes: false,
      autoInstance: false,
      segmentScale: 1.0,
      vertexWeld: 0.0,
      cullDistance: 0.0,
      shadowCullDistance: 0.0,
      smallObjectCull: 0.0,
      freezeMatrices: false,
      pomCullDistance: 0.0,
      shaderTier: 'high'
    };
    for (const n of chain) {
      const a = n.attributes || {};
      const res = a['texture-resolution'] || a['image-resolution'] || a['resolution'];
      if (res !== undefined) cfg.textureResolution = res;
      if (a['max-texture-size'] !== undefined) cfg.maxTextureSize = parseInt(a['max-texture-size'], 10) || 2048;
      if (a['synthesize-normals'] !== undefined) cfg.synthesizeNormals = a['synthesize-normals'] !== 'false';
      if (a['texture-filter'] !== undefined) cfg.textureFilter = a['texture-filter'];
      if (a['mipmaps'] !== undefined) cfg.mipmaps = a['mipmaps'] !== 'false';
      if (a['merge-meshes'] !== undefined) cfg.mergeMeshes = a['merge-meshes'] === 'true';
      if (a['auto-instance'] !== undefined) cfg.autoInstance = a['auto-instance'] === 'true';
      if (a['segment-scale'] !== undefined || a['geometry-lod'] !== undefined || a['simplify'] !== undefined) {
        cfg.segmentScale = Math.max(0.15, Math.min(2.0, parseFloat(a['segment-scale'] || a['geometry-lod'] || a['simplify']) || 1.0));
      }
      if (a['vertex-weld'] !== undefined) cfg.vertexWeld = parseFloat(a['vertex-weld']) || 0.0;
      if (a['cull-distance'] !== undefined || a['max-distance'] !== undefined) {
        cfg.cullDistance = parseFloat(a['cull-distance'] || a['max-distance']) || 0.0;
      }
      if (a['shadow-cull'] !== undefined) cfg.shadowCullDistance = parseFloat(a['shadow-cull']) || 0.0;
      if (a['small-object-cull'] !== undefined) cfg.smallObjectCull = parseFloat(a['small-object-cull']) || 0.0;
      if (a['freeze-matrices'] !== undefined) cfg.freezeMatrices = a['freeze-matrices'] === 'true';
      if (a['pom-cull-distance'] !== undefined) cfg.pomCullDistance = parseFloat(a['pom-cull-distance']) || 0.0;
      if (a['shader-tier'] !== undefined) cfg.shaderTier = a['shader-tier'].toLowerCase();
      if (a.optimize) {
        const tokens = String(a.optimize).toLowerCase().split(/[\s,]+/);
        if (tokens.includes('merge') || tokens.includes('batch')) cfg.mergeMeshes = true;
        if (tokens.includes('instance')) cfg.autoInstance = true;
        if (tokens.includes('freeze')) cfg.freezeMatrices = true;
        if (tokens.includes('low-tex')) cfg.textureResolution = '128';
        if (tokens.includes('med-tex')) cfg.textureResolution = '256';
        if (tokens.includes('fast-shader')) cfg.shaderTier = 'fast';
      }
    }
    this._cachedOptConfig = cfg;
    return cfg;
  }
  getSelectorLabel() {
    let s = this.tagName;
    if (this.id) s += `#${this.id}`;
    const cls = (this.attributes.class || '').trim().split(/\s+/).filter(Boolean);
    if (cls.length) s += '.' + cls.join('.');
    return s;
  }
}

// Safe expression evaluator for SML 2.0 `{expr}` attributes
function evalSMLExpression(exprStr, scope = {}) {
  try {
    const keys = Object.keys(scope);
    const vals = Object.values(scope);
    const fn = new Function(...keys, 'Math', `return (${exprStr});`);
    const res = fn(...vals, Math);
    return typeof res === 'number' && !Number.isInteger(res) ? Number(res.toFixed(4)) : res;
  } catch (_) {
    return 0;
  }
}

function interpolateAttrString(str, scope = {}) {
  if (typeof str !== 'string') return str;
  let out = str;
  if (out.includes('{')) {
    out = out.replace(/\{([^}]+)\}/g, (_, expr) => String(evalSMLExpression(expr.replace(/\$([a-zA-Z_][a-zA-Z0-9_]*)/g, '$1'), scope)));
  }
  if (out.includes('$') && Object.keys(scope).length > 0) {
    out = out.replace(/\$([a-zA-Z_][a-zA-Z0-9_]*)/g, (m, vName) => (vName in scope ? String(scope[vName]) : m));
  }
  return out;
}

function parseSMLFileToRawAST(smlText, sourceFile = 'main.sml') {
  let clean = smlText.replace(/<!--[\s\S]*?-->/g, (m) => '\n'.repeat((m.match(/\n/g) || []).length));
  const embeddedStyles = [];
  const embeddedScripts = [];

  // Extract inline <style>...<\/style> blocks while preserving exact line numbers
  clean = clean.replace(/<style\b[^>]*>([\s\S]*?)<\/style>/gi, (full, cssContent) => {
    if (cssContent && cssContent.trim()) embeddedStyles.push(cssContent);
    return '\n'.repeat((full.match(/\n/g) || []).length);
  });

  // Extract inline script blocks (without src="...") while preserving exact line numbers
  clean = clean.replace(/<script\b(?![^>]*\bsrc\s*=)[^>]*>([\s\S]*?)<\/script>/gi, (full, jsContent) => {
    if (jsContent && jsContent.trim()) embeddedScripts.push(jsContent);
    return '\n'.repeat((full.match(/\n/g) || []).length);
  });

  const tagRegex = /<\/?([a-zA-Z0-9_-]+)((?:"[^"]*"|'[^']*'|[^>"'])*?)(\/?)>/g;
  const root = new SMLNode('scene', { id: 'root' }, 1, sourceFile);
  root._embeddedStyles = embeddedStyles;
  root._embeddedScripts = embeddedScripts;
  let stack = [root];
  let match;

  const parseAttrs = (attrStr) => {
    const attrs = {};
    const rx = /([a-zA-Z0-9_:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+))/g;
    let am;
    while ((am = rx.exec(attrStr)) !== null) {
      attrs[am[1].toLowerCase()] = am[2] !== undefined ? am[2] : (am[3] !== undefined ? am[3] : am[4]);
    }
    return attrs;
  };

  const voidTags = new Set([
    'box','sphere','cylinder','cone','torus','circle','ring','plane','radial-plane','disc',
    'lathe','extrude','tube','surface','mesh','light','camera','use',
    'instance','import','link','script','modifier','loft'
  ]);

  while ((match = tagRegex.exec(clean)) !== null) {
    const full = match[0];
    const isClosing = full.startsWith('</');
    const tag = match[1].toLowerCase();
    const attrStr = match[2] || '';
    const isSelfClosing = full.endsWith('/>') || voidTags.has(tag);
    const lineNum = clean.slice(0, match.index).split('\n').length;

    if (isClosing) {
      if (stack.length > 1 && stack[stack.length - 1].tagName === tag) {
        stack.pop();
      }
      continue;
    }

    const attrs = parseAttrs(attrStr);
    if (tag === 'scene' && stack.length === 1) {
      root.attributes = { ...root.attributes, ...attrs };
      root.sourceLine = lineNum;
      continue;
    }

    const node = new SMLNode(tag, attrs, lineNum, sourceFile);
    stack[stack.length - 1].appendChild(node);
    if (!isSelfClosing) stack.push(node);
  }
  return root;
}

// Full SML 2.0 Multi-file & Macro Expander (<import>, <component>, <prefab>, <for>, <if>, {expr})
function compileSML20(entryFile, vfsFiles) {
  const smlText = vfsFiles[entryFile] || '';
  const rawRoot = parseSMLFileToRawAST(smlText, entryFile);
  const components = new Map(); // name -> { propsDefaults, templateNode }
  const linkedStyles = [];
  const linkedScripts = [];
  const embeddedStyles = [...(rawRoot._embeddedStyles || [])];
  const embeddedScripts = [...(rawRoot._embeddedScripts || [])];

  const registerComponentDef = (compNode) => {
    const name = (compNode.attributes.name || '').toLowerCase();
    if (!name) return;
    const propsDefaults = {};
    if (compNode.attributes.props) {
      compNode.attributes.props.split(',').forEach(pair => {
        const [k, v] = pair.split('=').map(s => s.trim());
        if (k) propsDefaults[k.toLowerCase()] = isNaN(Number(v)) ? (v || '') : Number(v);
      });
    }
    components.set(name, { propsDefaults, templateNode: compNode });
  };

  // 1. Scan top-level <import>, <link>, <script>, <component>, <prefab>
  const scanImportsAndComponents = (node) => {
    for (let i = 0; i < node.children.length; i++) {
      const ch = node.children[i];
      if (ch.tagName === 'import' && ch.attributes.src) {
        const srcPath = ch.attributes.src;
        const importedText = vfsFiles[srcPath];
        if (importedText) {
          const impAst = parseSMLFileToRawAST(importedText, srcPath);
          if (impAst._embeddedStyles && impAst._embeddedStyles.length) embeddedStyles.push(...impAst._embeddedStyles);
          if (impAst._embeddedScripts && impAst._embeddedScripts.length) embeddedScripts.push(...impAst._embeddedScripts);
          if (ch.attributes.as) {
            impAst.attributes.name = ch.attributes.as;
            registerComponentDef(impAst);
          }
          scanImportsAndComponents(impAst);
        }
      } else if (ch.tagName === 'link' && ch.attributes.src) {
        linkedStyles.push(ch.attributes.src);
      } else if (ch.tagName === 'script' && ch.attributes.src) {
        linkedScripts.push(ch.attributes.src);
      } else if (ch.tagName === 'component' || ch.tagName === 'prefab') {
        registerComponentDef(ch);
      }
    }
  };
  scanImportsAndComponents(rawRoot);

  // 2. Recursively expand <for>, <if>, <use>, custom <component-tag>, and {expr}
  const expandNodeList = (nodes, scope) => {
    const out = [];
    for (const n of nodes) {
      if (['import', 'link', 'script', 'component', 'prefab'].includes(n.tagName)) continue;

      if (n.tagName === 'canvas-texture' || n.tagName === 'procedural-texture') {
        const texId = interpolateAttrString(n.attributes.id || n.attributes.name || '', scope);
        const drawCode = n.attributes.draw || n.attributes.code || '';
        registerDeclarativeCanvasTexture(texId, n.attributes.width, n.attributes.height, drawCode, scope);
        continue;
      }

      if (n.tagName === 'for') {
        const varName = (n.attributes.var || 'i').replace(/^\$/, '');
        const countAttr = n.attributes.count !== undefined ? Number(evalSMLExpression(interpolateAttrString(n.attributes.count, scope), scope)) : null;
        const fromVal = Number(evalSMLExpression(interpolateAttrString(n.attributes.from || '0', scope), scope)) || 0;
        const toVal = countAttr !== null ? (fromVal + countAttr - 1) : (Number(evalSMLExpression(interpolateAttrString(n.attributes.to || '0', scope), scope)) || 0);
        const stepVal = Math.max(0.001, Math.abs(Number(evalSMLExpression(interpolateAttrString(n.attributes.step || '1', scope), scope)) || 1));
        const expandedLoop = [];
        for (let val = fromVal; val <= toVal + 1e-6; val += stepVal) {
          const loopScope = { ...scope, [varName]: val, ['$' + varName]: val };
          expandedLoop.push(...expandNodeList(n.children, loopScope));
        }
        if (n.attributes.batch === 'true') {
          const bNode = new SMLNode('batch', { id: n.attributes.id || '', pos: n.attributes.pos || '0 0 0', rot: n.attributes.rot || '0 0 0' }, n.sourceLine, n.sourceFile);
          for (const ec of expandedLoop) bNode.appendChild(ec);
          out.push(bNode);
        } else {
          out.push(...expandedLoop);
        }
        continue;
      }

      if (n.tagName === 'repeat') {
        const varName = (n.attributes.var || 'i').replace(/^\$/, '');
        const count = Math.max(1, parseInt(evalSMLExpression(interpolateAttrString(n.attributes.count || '1', scope), scope), 10) || 1);
        const stepVec = parseVec3Attr(interpolateAttrString(n.attributes.step || n.attributes.offset || '0 0 0', scope), 0, 0, 0);
        const rotStep = parseVec3Attr(interpolateAttrString(n.attributes['rot-step'] || '0 0 0', scope), 0, 0, 0);
        const wrapperTag = n.attributes.batch === 'false' ? 'group' : 'batch';
        const wrapper = new SMLNode(wrapperTag, {
          id: n.attributes.id || '',
          class: n.attributes.class || '',
          pos: interpolateAttrString(n.attributes.pos || '0 0 0', scope),
          rot: interpolateAttrString(n.attributes.rot || '0 0 0', scope),
          scale: interpolateAttrString(n.attributes.scale || '1 1 1', scope)
        }, n.sourceLine, n.sourceFile);
        for (let idx = 0; idx < count; idx++) {
          const loopScope = {
            ...scope,
            [varName]: idx,
            ['$' + varName]: idx,
            t: count > 1 ? idx / (count - 1) : 0,
            $t: count > 1 ? idx / (count - 1) : 0
          };
          const kids = expandNodeList(n.children, loopScope);
          for (const kNode of kids) {
            const kp = parseVec3Attr(kNode.attributes.pos, 0, 0, 0);
            const kr = parseVec3Attr(kNode.attributes.rot, 0, 0, 0);
            kNode.attributes.pos = `${(kp.x + stepVec.x * idx).toFixed(4)} ${(kp.y + stepVec.y * idx).toFixed(4)} ${(kp.z + stepVec.z * idx).toFixed(4)}`;
            if (rotStep.x !== 0 || rotStep.y !== 0 || rotStep.z !== 0) {
              kNode.attributes.rot = `${(kr.x + rotStep.x * idx).toFixed(2)} ${(kr.y + rotStep.y * idx).toFixed(2)} ${(kr.z + rotStep.z * idx).toFixed(2)}`;
            }
            wrapper.appendChild(kNode);
          }
        }
        out.push(wrapper);
        continue;
      }

      if (n.tagName === 'if') {
        const cond = evalSMLExpression(interpolateAttrString(n.attributes.test || 'true', scope), scope);
        if (cond) out.push(...expandNodeList(n.children, scope));
        continue;
      }

      // Interpolate attributes against current scope
      const evaledAttrs = {};
      for (const [k, v] of Object.entries(n.attributes)) {
        evaledAttrs[k] = interpolateAttrString(v, scope);
      }

      // Check if tag is `<use prefab="name">` or a direct custom `<component-name>` tag!
      const compName = (n.tagName === 'use' || n.tagName === 'instance')
        ? (evaledAttrs.prefab || evaledAttrs.component || '').toLowerCase()
        : (components.has(n.tagName) ? n.tagName : '');

      if (compName && components.has(compName)) {
        const compDef = components.get(compName);
        const childScope = { ...scope, ...compDef.propsDefaults };
        for (const [k, v] of Object.entries(evaledAttrs)) {
          const numV = Number(v);
          childScope[k] = (!isNaN(numV) && v.trim() !== '') ? numV : v;
        }
        const wrapper = new SMLNode('group', evaledAttrs, n.sourceLine, n.sourceFile);
        const expandedChildren = expandNodeList(compDef.templateNode.children, childScope);
        for (const ec of expandedChildren) {
          if (ec.id && wrapper.id) ec.id = `${wrapper.id}-${ec.id}`;
          wrapper.appendChild(ec);
        }
        out.push(wrapper);
        continue;
      }

      const cloned = new SMLNode(n.tagName, evaledAttrs, n.sourceLine, n.sourceFile);
      const expandedKids = expandNodeList(n.children, scope);
      for (const ek of expandedKids) cloned.appendChild(ek);
      out.push(cloned);
    }
    return out;
  };

  const finalRoot = new SMLNode('scene', { ...rawRoot.attributes }, rawRoot.sourceLine, entryFile);
  const topExpanded = expandNodeList(rawRoot.children, {});
  for (const ch of topExpanded) finalRoot.appendChild(ch);

  return { root: finalRoot, linkedStyles, linkedScripts, embeddedStyles, embeddedScripts };
}

// ============================================================================
// 5. GEOMETRY, MODIFIER STACK & CSG BUILDER
// ============================================================================
function parseVec3Attr(str, defX = 0, defY = 0, defZ = 0) {
  if (!str) return new THREE.Vector3(defX, defY, defZ);
  const parts = String(str).trim().split(/[\s,]+/).map(Number);
  if (parts.length === 1 && !isNaN(parts[0])) return new THREE.Vector3(parts[0], parts[0], parts[0]);
  return new THREE.Vector3(
    isNaN(parts[0]) ? defX : parts[0],
    isNaN(parts[1]) ? defY : parts[1],
    isNaN(parts[2]) ? defZ : parts[2]
  );
}

function parseSVGShape(shapeStr) {
  const shape = new THREE.Shape();
  if (!shapeStr) {
    shape.moveTo(-0.5, -0.5).lineTo(0.5, -0.5).lineTo(0.5, 0.5).lineTo(-0.5, 0.5);
    return shape;
  }
  if (shapeStr.includes(':')) {
    const pts = shapeStr.split(',').map(s => s.trim().split(':').map(Number));
    pts.forEach(([x, y], i) => {
      if (i === 0) shape.moveTo(x || 0, y || 0);
      else shape.lineTo(x || 0, y || 0);
    });
    return shape;
  }
  const tokens = shapeStr.match(/[a-zA-Z]|[-+]?\d*\.?\d+/g) || [];
  let i = 0;
  while (i < tokens.length) {
    const cmd = tokens[i++];
    if (cmd === 'M' || cmd === 'm') shape.moveTo(parseFloat(tokens[i++]) || 0, parseFloat(tokens[i++]) || 0);
    else if (cmd === 'L' || cmd === 'l') shape.lineTo(parseFloat(tokens[i++]) || 0, parseFloat(tokens[i++]) || 0);
    else if (cmd === 'Q' || cmd === 'q') {
      shape.quadraticCurveTo(parseFloat(tokens[i++]) || 0, parseFloat(tokens[i++]) || 0, parseFloat(tokens[i++]) || 0, parseFloat(tokens[i++]) || 0);
    } else if (cmd === 'Z' || cmd === 'z') shape.closePath();
  }
  return shape;
}

// Apply non-destructive SML 2.0 <modifier> deformations (taper, twist, bend, mirror)
function applyGeometryModifiers(geo, modifierNodes) {
  if (!modifierNodes || !modifierNodes.length) return geo;
  let outGeo = geo;
  for (const mod of modifierNodes) {
    const type = (mod.attributes.type || '').toLowerCase();
    const axis = (mod.attributes.axis || 'y').toLowerCase();
    const amount = parseFloat(mod.attributes.amount || mod.attributes.angle || mod.attributes.factor || 0.35);
    const pos = outGeo.attributes.position;
    if (!pos) continue;

    // Compute bounds along axis
    let minA = Infinity, maxA = -Infinity;
    for (let i = 0; i < pos.count; i++) {
      const v = axis === 'x' ? pos.getX(i) : (axis === 'z' ? pos.getZ(i) : pos.getY(i));
      if (v < minA) minA = v;
      if (v > maxA) maxA = v;
    }
    const span = Math.max(0.001, maxA - minA);

    if (type === 'taper') {
      for (let i = 0; i < pos.count; i++) {
        let x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
        const t = ((axis === 'y' ? y : (axis === 'x' ? x : z)) - minA) / span;
        const s = 1.0 - amount * t;
        if (axis === 'y') { x *= s; z *= s; }
        else if (axis === 'x') { y *= s; z *= s; }
        else { x *= s; y *= s; }
        pos.setXYZ(i, x, y, z);
      }
      outGeo.computeVertexNormals();
    } else if (type === 'twist') {
      const maxRad = THREE.MathUtils.degToRad(amount);
      for (let i = 0; i < pos.count; i++) {
        let x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
        const t = ((axis === 'y' ? y : z) - minA) / span - 0.5;
        const ang = t * maxRad;
        const c = Math.cos(ang), s = Math.sin(ang);
        pos.setXYZ(i, x * c - z * s, y, x * s + z * c);
      }
      outGeo.computeVertexNormals();
    } else if (type === 'mirror') {
      const offset = parseFloat(mod.attributes.offset || 0);
      const copy = outGeo.clone();
      if (offset) {
        outGeo.translate(axis === 'x' ? -offset : 0, axis === 'y' ? -offset : 0, axis === 'z' ? -offset : 0);
        copy.translate(axis === 'x' ? offset : 0, axis === 'y' ? offset : 0, axis === 'z' ? offset : 0);
      }
      outGeo = THREE.mergeGeometries([outGeo, copy]);
    }
  }
  return outGeo;
}

// Constructive CSG Arch/Portal/Hole Builder for <csg mode="subtract|union">
function buildCSGGeometry(node, customGenerators) {
  const mode = (node.attributes.mode || 'subtract').toLowerCase();
  const meshKids = node.children.filter(c => c.tagName !== 'modifier');
  if (meshKids.length === 0) return new THREE.BoxGeometry(1, 1, 1);

  if (mode === 'subtract' && meshKids.length >= 2 && meshKids[0].tagName === 'box') {
    // Manifold quad-strip CSG boolean arch/portal builder (zero concave fan artifacts!)
    const baseSize = parseVec3Attr(meshKids[0].attributes.size, 2.2, 2.4, 0.36);
    const cutter = meshKids[1];
    const hw = baseSize.x * 0.5, hh = baseSize.y * 0.5, hd = baseSize.z * 0.5;
    const holeR = Math.min(hw * 0.72, parseFloat(cutter.attributes.radius || 0.68));
    const springY = 0.15; // arch springline height relative to center

    const steps = 24;
    const pos = [], norm = [], uv = [], indices = [];
    let vIdx = 0;
    const addQuad = (p0, p1, p2, p3, nx, ny, nz) => {
      pos.push(...p0, ...p1, ...p2, ...p3);
      for (let k = 0; k < 4; k++) norm.push(nx, ny, nz);
      uv.push(0,0, 1,0, 1,1, 0,1);
      indices.push(vIdx, vIdx+1, vIdx+2, vIdx, vIdx+2, vIdx+3);
      vIdx += 4;
    };

    // Left & right pier blocks below springline
    const pierW = hw - holeR;
    const pierH = springY - (-hh);
    const leftPier = new THREE.BoxGeometry(pierW, pierH, baseSize.z).translate(-hw + pierW * 0.5, -hh + pierH * 0.5, 0);
    const rightPier = new THREE.BoxGeometry(pierW, pierH, baseSize.z).translate(hw - pierW * 0.5, -hh + pierH * 0.5, 0);

    // Upper spandrel & barrel-vaulted arch ring above springline (y from springY to hh)
    for (let i = 0; i < steps; i++) {
      const a0 = Math.PI - (i / steps) * Math.PI;
      const a1 = Math.PI - ((i + 1) / steps) * Math.PI;
      const ix0 = Math.cos(a0) * holeR, iy0 = springY + Math.sin(a0) * holeR;
      const ix1 = Math.cos(a1) * holeR, iy1 = springY + Math.sin(a1) * holeR;
      // Project radially to the outer rectangular boundary ([-hw..hw] x [springY..hh])
      const ox0 = (i < steps / 2) ? Math.max(-hw, ix0 * 1.45) : Math.min(hw, ix0 * 1.45);
      const ox1 = (i + 1 <= steps / 2) ? Math.max(-hw, ix1 * 1.45) : Math.min(hw, ix1 * 1.45);
      const oy0 = (i === 0) ? springY : ((i === steps) ? springY : hh);
      const oy1 = (i + 1 === steps) ? springY : hh;

      // Front face (+hd), Back face (-hd), and Inner Barrel Vault Intrados
      addQuad([ix0, iy0, hd], [ix1, iy1, hd], [ox1, oy1, hd], [ox0, oy0, hd], 0, 0, 1);
      addQuad([ix1, iy1, -hd], [ix0, iy0, -hd], [ox0, oy0, -hd], [ox1, oy1, -hd], 0, 0, -1);
      const midA = (a0 + a1) * 0.5;
      addQuad([ix0, iy0, -hd], [ix1, iy1, -hd], [ix1, iy1, hd], [ix0, iy0, hd], -Math.cos(midA), -Math.sin(midA), 0);
    }
    // Left & right upper spandrel cheek fills
    addQuad([-hw, springY, hd], [-holeR, springY, hd], [-hw, hh, hd], [-hw, hh, hd], 0, 0, 1);
    addQuad([holeR, springY, hd], [hw, springY, hd], [hw, hh, hd], [hw, hh, hd], 0, 0, 1);
    addQuad([-holeR, springY, -hd], [-hw, springY, -hd], [-hw, hh, -hd], [-hw, hh, -hd], 0, 0, -1);
    addQuad([hw, springY, -hd], [holeR, springY, -hd], [hw, hh, -hd], [hw, hh, -hd], 0, 0, -1);

    // Outer top, left, and right walls above springline
    addQuad([-hw, hh, hd], [hw, hh, hd], [hw, hh, -hd], [-hw, hh, -hd], 0, 1, 0);
    addQuad([-hw, springY, -hd], [-hw, springY, hd], [-hw, hh, hd], [-hw, hh, -hd], -1, 0, 0);
    addQuad([hw, springY, hd], [hw, springY, -hd], [hw, hh, -hd], [hw, hh, hd], 1, 0, 0);

    const archGeo = new THREE.BufferGeometry();
    archGeo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    archGeo.setAttribute('normal', new THREE.Float32BufferAttribute(norm, 3));
    archGeo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    archGeo.setIndex(indices);
    const cornice = new THREE.BoxGeometry(baseSize.x + 0.16, 0.12, baseSize.z + 0.12).translate(0, hh + 0.06, 0);
    return THREE.mergeGeometries([leftPier, rightPier, archGeo, cornice]);
  }

  // Union mode: merge all child geometries with their local transforms
  const geos = [];
  for (const ch of meshKids) {
    const g = buildGeometryForSMLNode(ch, customGenerators);
    if (g) {
      const p = parseVec3Attr(ch.attributes.pos, 0, 0, 0);
      const r = parseVec3Attr(ch.attributes.rot, 0, 0, 0);
      const s = parseVec3Attr(ch.attributes.scale, 1, 1, 1);
      g.scale(s.x, s.y, s.z);
      if (r.x) g.rotateX(THREE.MathUtils.degToRad(r.x));
      if (r.y) g.rotateY(THREE.MathUtils.degToRad(r.y));
      if (r.z) g.rotateZ(THREE.MathUtils.degToRad(r.z));
      g.translate(p.x, p.y, p.z);
      geos.push(g);
    }
  }
  return geos.length ? THREE.mergeGeometries(geos) : new THREE.BoxGeometry(1, 1, 1);
}


// Parse 1-to-4 CSS border-radius values (supports %, m, or float meters)
function parseBorderRadiusCorners(brStr, w, d) {
  if (!brStr || brStr === "0" || brStr === "none") return [0, 0, 0, 0, false];
  const halfMin = Math.min(w, d) * 0.5;
  const rawTokens = String(brStr).trim().split(/[\s,]+/);
  let isFullRadial = false;
  const vals = rawTokens.map(tok => {
    if (tok.endsWith("%")) {
      const pct = parseFloat(tok);
      if (pct >= 49.5) isFullRadial = true;
      return Math.min(halfMin, Math.max(0, (pct / 100.0) * Math.min(w, d)));
    }
    const v = parseFloat(tok);
    if (isNaN(v)) return 0;
    if (v >= halfMin * 0.99) isFullRadial = true;
    return Math.min(halfMin, Math.max(0, v));
  });
  if (vals.length === 1) return [vals[0], vals[0], vals[0], vals[0], isFullRadial];
  if (vals.length === 2) return [vals[0], vals[1], vals[0], vals[1], isFullRadial];
  if (vals.length === 3) return [vals[0], vals[1], vals[2], vals[1], isFullRadial];
  return [vals[0], vals[1], vals[2], vals[3], isFullRadial];
}

// High-precision Radial Plane (Disc / Ring / Sector) & CSS Rounded-Corner Plane Builder
function buildRoundedOrRadialPlaneGeometry(w, d, brStr, innerRStr, segs = 36, thetaStartDeg = 0, thetaLenDeg = 360, uvMode = "planar", orient = "xz") {
  const halfMin = Math.min(w, d) * 0.5;
  const [rTL, rTR, rBR, rBL, isFullRadial] = parseBorderRadiusCorners(brStr, w, d);
  let innerR = 0;
  if (innerRStr) {
    const s = String(innerRStr).trim();
    innerR = s.endsWith("%") ? (parseFloat(s) / 100.0) * halfMin : (parseFloat(s) || 0);
    innerR = Math.max(0, Math.min(halfMin * 0.94, innerR));
  }

  const maxCorner = Math.max(rTL, rTR, rBR, rBL);
  // Case A: Standard sharp rectangular plane
  if (maxCorner <= 1e-4 && innerR <= 1e-4 && Math.abs(thetaLenDeg - 360) < 0.1) {
    const g = new THREE.PlaneGeometry(w, d, Math.max(1, Math.min(32, segs)), Math.max(1, Math.min(32, segs)));
    if (orient !== "xy") g.rotateX(-Math.PI / 2);
    return g;
  }

  const pos = [], norm = [], uv = [], indices = [];
  const rx = w * 0.5, rz = d * 0.5;

  // Case B: Radial Plane / Disc / Ring / Sector (`border-radius: 50%` or `Math.abs(thetaLenDeg - 360) >= 0.5`)
  if (isFullRadial || Math.abs(thetaLenDeg - 360) >= 0.5) {
    const angularSegs = Math.max(20, segs);
    const ringSegs = Math.max(16, Math.min(64, Math.round(segs * 0.75)));
    const t0 = THREE.MathUtils.degToRad(thetaStartDeg);
    const tSpan = THREE.MathUtils.degToRad(thetaLenDeg);
    const innerFrac = innerR / Math.max(1e-4, halfMin);

    for (let j = 0; j <= ringSegs; j++) {
      const rf = innerFrac + (1.0 - innerFrac) * (j / ringSegs);
      for (let i = 0; i <= angularSegs; i++) {
        const uf = i / angularSegs;
        const ang = t0 + uf * tSpan;
        const cx = Math.cos(ang) * rx * rf;
        const cz = Math.sin(ang) * rz * rf;
        if (orient === "xy") {
          pos.push(cx, cz, 0);
          norm.push(0, 0, 1);
        } else {
          pos.push(cx, 0, cz);
          norm.push(0, 1, 0);
        }
        if (uvMode === "polar" || uvMode === "radial") {
          uv.push(uf, j / ringSegs);
        } else {
          uv.push(cx / w + 0.5, 0.5 - cz / d);
        }
      }
    }
    const row = angularSegs + 1;
    for (let j = 0; j < ringSegs; j++) {
      for (let i = 0; i < angularSegs; i++) {
        const a = j * row + i, b = (j + 1) * row + i, c = (j + 1) * row + (i + 1), dIdx = j * row + (i + 1);
        if (orient === "xy") indices.push(a, dIdx, b, b, dIdx, c);
        else indices.push(a, b, dIdx, b, c, dIdx);
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute("normal", new THREE.Float32BufferAttribute(norm, 3));
    geo.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
    geo.setIndex(indices);
    return geo;
  }

  // Case C: CSS Rounded-Corner Plane (`0 <= border-radius < 50%`, with optional inner-radius & multi-ring interior grid for wave displacement!)
  const cSegs = Math.max(6, Math.floor(segs / 4));
  const perim = [];
  const corners = [
    { cx:  rx - rTR, cz: -rz + rTR, r: rTR, a0: -Math.PI * 0.5, a1: 0 },
    { cx:  rx - rBR, cz:  rz - rBR, r: rBR, a0: 0,              a1: Math.PI * 0.5 },
    { cx: -rx + rBL, cz:  rz - rBL, r: rBL, a0: Math.PI * 0.5,  a1: Math.PI },
    { cx: -rx + rTL, cz: -rz + rTL, r: rTL, a0: Math.PI,        a1: Math.PI * 1.5 }
  ];
  for (let cIdx = 0; cIdx < 4; cIdx++) {
    const c = corners[cIdx];
    const nextC = corners[(cIdx + 1) % 4];
    if (c.r <= 1e-4) {
      perim.push([c.cx, c.cz]);
    } else {
      for (let i = 0; i <= cSegs; i++) {
        const a = c.a0 + (i / cSegs) * (c.a1 - c.a0);
        perim.push([c.cx + Math.cos(a) * c.r, c.cz + Math.sin(a) * c.r]);
      }
    }
    // Subdivide straight edge between corners so wave displacement is smooth along edges too
    const pLast = perim[perim.length - 1];
    const pNextStart = nextC.r <= 1e-4 ? [nextC.cx, nextC.cz] : [nextC.cx + Math.cos(nextC.a0) * nextC.r, nextC.cz + Math.sin(nextC.a0) * nextC.r];
    const edgeSteps = segs <= 14 ? 1 : Math.max(3, Math.floor(segs / 6));
    for (let s = 1; s < edgeSteps; s++) {
      const f = s / edgeSteps;
      perim.push([pLast[0] + (pNextStart[0] - pLast[0]) * f, pLast[1] + (pNextStart[1] - pLast[1]) * f]);
    }
  }
  // Close perimeter loop
  perim.push([perim[0][0], perim[0][1]]);

  const nCols = perim.length - 1;
  const ringSegs = segs <= 14 ? (innerR > 1e-4 ? 2 : 1) : Math.max(12, Math.min(40, Math.round(segs * 0.55)));
  const innerFrac = innerR / Math.max(1e-4, halfMin);

  for (let j = 0; j <= ringSegs; j++) {
    const rf = innerFrac + (1.0 - innerFrac) * (j / ringSegs);
    for (let i = 0; i <= nCols; i++) {
      const [px, pz] = perim[i];
      const cx = px * rf, cz = pz * rf;
      if (orient === "xy") {
        pos.push(cx, -cz, 0);
        norm.push(0, 0, 1);
      } else {
        pos.push(cx, 0, cz);
        norm.push(0, 1, 0);
      }
      if (uvMode === "polar" || uvMode === "radial") {
        uv.push(i / nCols, j / ringSegs);
      } else {
        uv.push(cx / w + 0.5, 0.5 - cz / d);
      }
    }
  }
  const row = nCols + 1;
  for (let j = 0; j < ringSegs; j++) {
    for (let i = 0; i < nCols; i++) {
      const a = j * row + i, b = (j + 1) * row + i, c = (j + 1) * row + (i + 1), dIdx = j * row + (i + 1);
      if (orient === "xy") indices.push(a, b, dIdx, b, c, dIdx);
      else indices.push(a, dIdx, b, b, dIdx, c);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute("normal", new THREE.Float32BufferAttribute(norm, 3));
  geo.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
  geo.setIndex(indices);
  return geo;
}

// 3D Rounded-Corner Box Builder when `border-radius` is used on <box>
function buildRoundedBoxGeometry(w, h, d, brStr, segs = 24) {
  const [rTL, rTR, rBR, rBL] = parseBorderRadiusCorners(brStr, w, d);
  const maxR = Math.max(rTL, rTR, rBR, rBL);
  if (maxR <= 1e-4) return new THREE.BoxGeometry(w, h, d);

  const topCap = buildRoundedOrRadialPlaneGeometry(w, d, brStr, 0, segs, 0, 360, "planar", "xz");
  topCap.translate(0, h * 0.5, 0);
  const botCap = buildRoundedOrRadialPlaneGeometry(w, d, brStr, 0, segs, 0, 360, "planar", "xz");
  botCap.translate(0, -h * 0.5, 0);
  const bNorm = botCap.attributes.normal.array;
  for (let i = 1; i < bNorm.length; i += 3) bNorm[i] = -1;
  if (botCap.index) {
    const bIdx = botCap.index.array;
    for (let i = 0; i < bIdx.length; i += 3) {
      const tmp = bIdx[i + 1]; bIdx[i + 1] = bIdx[i + 2]; bIdx[i + 2] = tmp;
    }
  }

  // Build smooth perimeter side wall strip with outward normals
  const rx = w * 0.5, rz = d * 0.5, hh = h * 0.5;
  const cSegs = Math.max(6, Math.floor(segs / 4));
  const perim = [];
  const corners = [
    { cx:  rx - rTR, cz: -rz + rTR, r: rTR, a0: -Math.PI * 0.5, a1: 0 },
    { cx:  rx - rBR, cz:  rz - rBR, r: rBR, a0: 0,              a1: Math.PI * 0.5 },
    { cx: -rx + rBL, cz:  rz - rBL, r: rBL, a0: Math.PI * 0.5,  a1: Math.PI },
    { cx: -rx + rTL, cz: -rz + rTL, r: rTL, a0: Math.PI,        a1: Math.PI * 1.5 }
  ];
  for (const c of corners) {
    for (let i = 0; i <= cSegs; i++) {
      const a = c.a0 + (i / cSegs) * (c.a1 - c.a0);
      perim.push([c.cx + Math.cos(a) * c.r, c.cz + Math.sin(a) * c.r]);
    }
  }
  // Compute total perimeter arc length for distortion-free UVs & outward smooth normals
  let totalPerim = 0;
  const segLens = [];
  for (let i = 0; i < perim.length; i++) {
    const [x0, z0] = perim[i];
    const [x1, z1] = perim[(i + 1) % perim.length];
    const len = Math.hypot(x1 - x0, z1 - z0);
    segLens.push(len);
    totalPerim += len;
  }
  totalPerim = Math.max(totalPerim, 1e-5);
  const pos = [], norm = [], uv = [], indices = [];
  let vIdx = 0, acc = 0;
  for (let i = 0; i < perim.length; i++) {
    const len = segLens[i];
    if (len < 1e-5) continue;
    const [x0, z0] = perim[i];
    const [x1, z1] = perim[(i + 1) % perim.length];
    const dx = x1 - x0, dz = z1 - z0;
    // Outward normal for clockwise perimeter in XZ plane: (dz, 0, -dx)
    const nx = dz / len, nz = -dx / len;
    const u0 = acc / totalPerim, u1 = (acc + len) / totalPerim;
    acc += len;
    pos.push(x0, -hh, z0,  x1, -hh, z1,  x1, hh, z1,  x0, hh, z0);
    norm.push(nx, 0, nz,   nx, 0, nz,    nx, 0, nz,   nx, 0, nz);
    uv.push(u0, 0,  u1, 0,  u1, 1,  u0, 1);
    // Outward counter-clockwise winding when viewed from outside!
    indices.push(vIdx, vIdx+2, vIdx+1, vIdx, vIdx+3, vIdx+2);
    vIdx += 4;
  }
  const sideGeo = new THREE.BufferGeometry();
  sideGeo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  sideGeo.setAttribute("normal", new THREE.Float32BufferAttribute(norm, 3));
  sideGeo.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
  sideGeo.setIndex(indices);
  return THREE.mergeGeometries([topCap, botCap, sideGeo]);
}


function buildProceduralTerrainGeometry(a) {
  const w = parseFloat(a.width || a.w || 60);
  const d = parseFloat(a.depth || a.d || a.height || 60);
  const segX = Math.max(2, Math.min(256, parseInt(a.segments || a['width-segments'] || 64, 10)));
  const segZ = Math.max(2, Math.min(256, parseInt(a['depth-segments'] || a.segments || 64, 10)));
  const amp = parseFloat(a.amplitude !== undefined ? a.amplitude : (a.amp !== undefined ? a.amp : 2.5));
  const freq = parseFloat(a.frequency !== undefined ? a.frequency : (a.freq !== undefined ? a.freq : 0.06));
  const seed = parseFloat(a.seed || 0);
  const exprStr = a['height-expr'] || a.expr || null;
  let exprFn = null;
  if (exprStr) {
    try { exprFn = new Function('x', 'z', 'r', 'Math', 'noise', `return (${exprStr});`); } catch (_) {}
  }
  const geo = new THREE.PlaneGeometry(w, d, segX, segZ);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i);
    let y = 0;
    if (exprFn) {
      try { y = Number(exprFn(x, z, Math.hypot(x, z), Math, TriadNoise)) || 0; } catch (_) { y = 0; }
    } else {
      y = TriadNoise.fbm2((x + seed * 17.3) * freq, (z + seed * 31.7) * freq, 4) * amp;
    }
    pos.setY(i, y);
  }
  geo.computeVertexNormals();
  return geo;
}

function buildGeometryForSMLNode(node, customGenerators, computedStyle = {}) {
  const tag = node.tagName;
  const rawA = node.attributes || {};
  const optCfg = typeof node.getEffectiveOptimizationConfig === 'function' ? node.getEffectiveOptimizationConfig() : { segmentScale: 1.0, vertexWeld: 0.0 };
  const segMult = optCfg.segmentScale || 1.0;
  const a = segMult !== 1.0 ? new Proxy(rawA, {
    get(target, prop) {
      if (prop === 'segments' || prop === 'segs' || prop === 'width-segments' || prop === 'height-segments' || prop === 'radial-segments' || prop === 'tubular-segments' || prop === 'corner-segments') {
        const base = parseInt(target[prop] || 24, 10);
        return String(Math.max(4, Math.round(base * segMult)));
      }
      return target[prop];
    }
  }) : rawA;
  let geo = null;

  if (tag === 'csg') {
    geo = buildCSGGeometry(node, customGenerators);
  } else if (tag === 'box') {
    const s = parseVec3Attr(a.size || `${a.width || 1} ${a.height || 1} ${a.depth || 1}`, 1, 1, 1);
    const br = a['border-radius'] || computedStyle['border-radius'] || '0';
    const segs = parseInt(a['corner-segments'] || computedStyle['corner-segments'] || a.segments || 12, 10);
    geo = buildRoundedBoxGeometry(s.x, s.y, s.z, br, segs);
  } else if (tag === 'sphere') {
    geo = new THREE.SphereGeometry(
      parseFloat(a.radius || 0.5),
      parseInt(a['width-segments'] || a.segments || 28, 10),
      parseInt(a['height-segments'] || 20, 10),
      0, Math.PI * 2,
      parseFloat(a['theta-start'] || 0) * Math.PI / 180,
      parseFloat(a['theta-length'] || 180) * Math.PI / 180
    );
  } else if (tag === 'cylinder') {
    const r = parseFloat(a.radius || 0.5);
    geo = new THREE.CylinderGeometry(
      parseFloat(a['radius-top'] !== undefined ? a['radius-top'] : r),
      parseFloat(a['radius-bottom'] !== undefined ? a['radius-bottom'] : r),
      parseFloat(a.height || 1.0),
      parseInt(a.segments || 28, 10),
      parseInt(a['height-segments'] || 1, 10),
      a['open-ended'] === 'true'
    );
  } else if (tag === 'cone') {
    geo = new THREE.ConeGeometry(parseFloat(a.radius || 0.5), parseFloat(a.height || 1.0), parseInt(a.segments || 28, 10));
  } else if (tag === 'torus') {
    geo = new THREE.TorusGeometry(
      parseFloat(a.radius || 0.6),
      parseFloat(a.tube || 0.14),
      parseInt(a['radial-segments'] || 18, 10),
      parseInt(a['tubular-segments'] || 36, 10),
      THREE.MathUtils.degToRad(parseFloat(a.arc || 360))
    );
    if (a.orient !== 'xy') geo.rotateX(Math.PI / 2);
  } else if (tag === 'ring' || tag === 'circle' || tag === 'disc' || tag === 'radial-plane') {
    const outerR = parseFloat(a.radius || a['outer-radius'] || 1.2);
    const w = parseFloat(a.width || outerR * 2), d = parseFloat(a.depth || a.height || outerR * 2);
    const innerR = a['inner-radius'] || computedStyle['inner-radius'] || (tag === 'ring' ? '0.45' : '0');
    const segs = parseInt(a.segments || a['radial-segments'] || computedStyle['corner-segments'] || 48, 10);
    const tStart = parseFloat(a['theta-start'] || computedStyle['theta-start'] || 0);
    const tLen = parseFloat(a['theta-length'] || a.theta || computedStyle['theta-length'] || 360);
    const uvMode = (a['uv-mode'] || computedStyle['uv-mode'] || 'planar').toLowerCase();
    const orient = (a.orient || computedStyle.orient || 'xz').toLowerCase();
    geo = buildRoundedOrRadialPlaneGeometry(w, d, '50%', innerR, segs, tStart, tLen, uvMode, orient);
  } else if (tag === 'plane') {
    const rAttr = a.radius ? parseFloat(a.radius) * 2 : null;
    const w = parseFloat(a.width || a.w || computedStyle.width || rAttr || 2);
    const d = parseFloat(a.depth || a.d || a.height || a.h || computedStyle.depth || rAttr || 2);
    const isRad = a.radial === 'true' || a.shape === 'radial';
    const br = isRad ? '50%' : (a['border-radius'] || computedStyle['border-radius'] || '0');
    const innerR = a['inner-radius'] || computedStyle['inner-radius'] || '0';
    const segs = parseInt(a.segments || a.segs || computedStyle['corner-segments'] || 36, 10);
    const tStart = parseFloat(a['theta-start'] || computedStyle['theta-start'] || 0);
    const tLen = parseFloat(a['theta-length'] || a.theta || computedStyle['theta-length'] || 360);
    const uvMode = (a['uv-mode'] || computedStyle['uv-mode'] || 'planar').toLowerCase();
    const orient = (a.orient || computedStyle.orient || 'xz').toLowerCase();
    geo = buildRoundedOrRadialPlaneGeometry(w, d, br, innerR, segs, tStart, tLen, uvMode, orient);
    const waveAmp = parseFloat(a.amp !== undefined ? a.amp : (computedStyle['wave-amp'] || 0));
    if (Math.abs(waveAmp) > 1e-4) {
      const freq = parseFloat(a.freq || computedStyle['wave-freq'] || 3.0);
      const pos = geo.attributes.position;
      const baseXZ = new Float32Array(pos.count * 2);
      for (let i = 0; i < pos.count; i++) {
        const x = pos.getX(i), z = orient === 'xy' ? pos.getY(i) : pos.getZ(i);
        baseXZ[i * 2] = x; baseXZ[i * 2 + 1] = z;
        const r = Math.hypot(x, z);
        const disp = Math.sin(r * freq * 2.0) * Math.cos(x * freq * 0.65) * waveAmp / (1.0 + r * 0.35);
        if (orient === 'xy') pos.setZ(i, disp); else pos.setY(i, disp);
      }
      geo._surfaceWave = { baseXZ, amp: waveAmp, freq, orient };
      geo.computeVertexNormals();
    }
  } else if (tag === 'lathe') {
    const profStr = a.profile || a.points || '0.01:0, 0.5:0, 0.35:0.4, 0.45:0.9, 0.01:1.0';
    const pts = profStr.split(',').map(p => {
      const [r, y] = p.trim().split(/[:\s]+/).map(Number);
      return new THREE.Vector2(Math.max(0.001, r || 0), y || 0);
    });
    geo = new THREE.LatheGeometry(pts, parseInt(a.segments || 32, 10), 0, THREE.MathUtils.degToRad(parseFloat(a.phi || 360)));
  } else if (tag === 'extrude') {
    const shape = parseSVGShape(a.shape);
    const depth = parseFloat(a.depth || 0.3);
    const bevel = parseFloat(a.bevel || 0.02);
    geo = new THREE.ExtrudeGeometry(shape, { depth, bevelEnabled: bevel > 0, bevelThickness: bevel, bevelSize: bevel });
    if (a.center === 'true') geo.translate(0, 0, -depth * 0.5);
  } else if (tag === 'tube') {
    const pathStr = a.path || '-1 0 0, 0 1 0, 1 0 0';
    let pts = pathStr.split(',').map(s => parseVec3Attr(s.trim()));
    const sag = parseFloat(a.sag || 0);
    if (pts.length === 2 && Math.abs(sag) > 1e-4) {
      const p0 = pts[0], p1 = pts[1];
      pts = [
        p0,
        new THREE.Vector3(THREE.MathUtils.lerp(p0.x, p1.x, 0.25), THREE.MathUtils.lerp(p0.y, p1.y, 0.25) - sag * 0.75, THREE.MathUtils.lerp(p0.z, p1.z, 0.25)),
        new THREE.Vector3(THREE.MathUtils.lerp(p0.x, p1.x, 0.50), THREE.MathUtils.lerp(p0.y, p1.y, 0.50) - sag,        THREE.MathUtils.lerp(p0.z, p1.z, 0.50)),
        new THREE.Vector3(THREE.MathUtils.lerp(p0.x, p1.x, 0.75), THREE.MathUtils.lerp(p0.y, p1.y, 0.75) - sag * 0.75, THREE.MathUtils.lerp(p0.z, p1.z, 0.75)),
        p1
      ];
    }
    const curve = new THREE.CatmullRomCurve3(pts);
    geo = new THREE.TubeGeometry(curve, parseInt(a['tubular-segments'] || a.segments || 36, 10), parseFloat(a.radius || 0.05), parseInt(a['radial-segments'] || 12, 10), a.closed === 'true');
  } else if (tag === 'surface') {
    const w = parseFloat(a.width || a.w || computedStyle.width || 4);
    const d = parseFloat(a.depth || a.d || a.height || a.h || computedStyle.depth || 4);
    const segs = parseInt(a.segs || a.segments || computedStyle['corner-segments'] || 40, 10);
    const amp = parseFloat(a.amp !== undefined ? a.amp : (computedStyle['wave-amp'] !== undefined ? computedStyle['wave-amp'] : 0.15));
    const freq = parseFloat(a.freq !== undefined ? a.freq : (computedStyle['wave-freq'] !== undefined ? computedStyle['wave-freq'] : 2.2));
    const isRad = a.radial === 'true' || a.shape === 'radial';
    const br = isRad ? '50%' : (a['border-radius'] || computedStyle['border-radius'] || '0');
    const innerR = a['inner-radius'] || computedStyle['inner-radius'] || '0';
    const tStart = parseFloat(a['theta-start'] || computedStyle['theta-start'] || 0);
    const tLen = parseFloat(a['theta-length'] || a.theta || computedStyle['theta-length'] || 360);
    const uvMode = (a['uv-mode'] || computedStyle['uv-mode'] || 'planar').toLowerCase();
    const orient = (a.orient || computedStyle.orient || 'xz').toLowerCase();
    geo = buildRoundedOrRadialPlaneGeometry(w, d, br, innerR, segs, tStart, tLen, uvMode, orient);
    const pos = geo.attributes.position;
    const baseXZ = new Float32Array(pos.count * 2);
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), z = orient === 'xy' ? pos.getY(i) : pos.getZ(i);
      baseXZ[i * 2] = x; baseXZ[i * 2 + 1] = z;
      const r = Math.hypot(x, z);
      const disp = Math.sin(r * freq * 2.0) * Math.cos(x * freq * 0.65) * amp / (1.0 + r * 0.35);
      if (orient === 'xy') pos.setZ(i, disp); else pos.setY(i, disp);
    }
    geo._surfaceWave = { baseXZ, amp, freq, orient };
    geo.computeVertexNormals();
  } else if (tag === 'terrain' || tag === 'heightfield') {
    geo = buildProceduralTerrainGeometry(a);
  } else if (tag === 'capsule') {
    geo = new THREE.CapsuleGeometry(parseFloat(a.radius || 0.4), parseFloat(a.length || a.height || 1.0), parseInt(a['cap-segments'] || 8, 10), parseInt(a.segments || 16, 10));
  } else if (tag === 'mesh' || customGenerators.has(tag) || BuiltinGenerators.has(tag)) {
    const genName = tag === 'mesh' ? (a.generator || 'box') : tag;
    const fn = customGenerators.get(genName) || BuiltinGenerators.get(genName);
    if (fn) {
      // Compute canonical geometry-shaping attribute key (ignoring transform/id/class/event attrs)
      const skipKeys = new Set(['id', 'class', 'pos', 'rot', 'scale', 'style', 'anchor', 'cast-shadow', 'receive-shadow', 'oninit', 'onupdate', 'ontick', 'onclick', 'onhover']);
      const geoAttrPairs = Object.keys(a).filter(k => !skipKeys.has(k)).sort().map(k => `${k}=${a[k]}`).join('&');
      const cacheKey = `${genName}|${geoAttrPairs}`;
      const hasMods = node.children && node.children.some(c => c.tagName === 'modifier');
      if (!hasMods && customGenerators._geoCache && customGenerators._geoCache.has(cacheKey)) {
        geo = customGenerators._geoCache.get(cacheKey);
      } else {
        try {
          const g = fn(a, THREE, TriadMeshBuilder);
          if (g && g.attributes && g.attributes.position) {
            if (!g.boundingSphere) g.computeBoundingSphere();
            geo = g;
            if (!hasMods && customGenerators._geoCache) {
              g._isShared = true;
              customGenerators._geoCache.set(cacheKey, g);
            }
          }
        } catch (e) { logConsole(`Generator '${genName}' error: ${e.message}`, 'err'); }
      }
    }
    if (!geo) geo = new THREE.BoxGeometry(0.5, 0.5, 0.5);
  }

  if (geo) {
    const mods = node.children.filter(c => c.tagName === 'modifier');
    if (mods.length) geo = applyGeometryModifiers(geo, mods);
    if (optCfg.vertexWeld > 0 && typeof geo.weldVertices === 'function') {
      geo.weldVertices(optCfg.vertexWeld);
    }
  }
  return geo;
}

// ============================================================================
// 6. TRIAD3D 2.0 SCENE RUNTIME & `Triad.gui` PARAMETRIC CONTROLLER
// ============================================================================

// ============================================================================

// ============================================================================
// 5C. TRIAD NAVMESH & AGENT / NPC BEHAVIOR SYSTEM (`<navmesh>`, `<agent>`, `Triad.agents`)
// ============================================================================
class TriadNavMesh {
  constructor(boundsMin = [-30, -30], boundsMax = [30, 30], cellSize = 1.5) {
    this.minX = boundsMin[0]; this.minZ = boundsMin[1];
    this.maxX = boundsMax[0]; this.maxZ = boundsMax[1];
    this.cellSize = Math.max(0.4, cellSize);
    this.cols = Math.max(4, Math.ceil((this.maxX - this.minX) / this.cellSize));
    this.rows = Math.max(4, Math.ceil((this.maxZ - this.minZ) / this.cellSize));
    this.grid = new Uint8Array(this.cols * this.rows); // 0 = walkable, 1 = blocked
  }

  bakeFromPhysics(physics, agentRadius = 0.4) {
    this.grid.fill(0);
    if (!physics || !physics.colliders) return;
    for (let rz = 0; rz < this.rows; rz++) {
      const wz = this.minZ + (rz + 0.5) * this.cellSize;
      for (let cx = 0; cx < this.cols; cx++) {
        const wx = this.minX + (cx + 0.5) * this.cellSize;
        for (const col of physics.colliders) {
          if (col.type !== 'solid') continue;
          if (col.shape === 'cylinder' || col.shape === 'sphere') {
            const r = (col.radius || 0.5) + agentRadius;
            if (Math.hypot(wx - col.pos.x, wz - col.pos.z) < r) {
              this.grid[rz * this.cols + cx] = 1;
              break;
            }
          } else {
            const hx = (col.size ? col.size.x * 0.5 : 0.5) + agentRadius;
            const hz = (col.size ? col.size.z * 0.5 : 0.5) + agentRadius;
            if (Math.abs(wx - col.pos.x) < hx && Math.abs(wz - col.pos.z) < hz) {
              this.grid[rz * this.cols + cx] = 1;
              break;
            }
          }
        }
      }
    }
  }

  worldToCell(x, z) {
    const cx = THREE.MathUtils.clamp(Math.floor((x - this.minX) / this.cellSize), 0, this.cols - 1);
    const rz = THREE.MathUtils.clamp(Math.floor((z - this.minZ) / this.cellSize), 0, this.rows - 1);
    return [cx, rz];
  }

  cellToWorld(cx, rz) {
    return new THREE.Vector3(this.minX + (cx + 0.5) * this.cellSize, 0, this.minZ + (rz + 0.5) * this.cellSize);
  }

  findPath(startPos, goalPos) {
    const [sx, sz] = this.worldToCell(startPos.x, startPos.z);
    let [gx, gz] = this.worldToCell(goalPos.x, goalPos.z);
    // If goal cell is blocked, find nearest walkable neighbor
    if (this.grid[gz * this.cols + gx] === 1) {
      let best = null, bestD = Infinity;
      for (let dz = -3; dz <= 3; dz++) for (let dx = -3; dx <= 3; dx++) {
        const nx = gx + dx, nz = gz + dz;
        if (nx >= 0 && nx < this.cols && nz >= 0 && nz < this.rows && this.grid[nz * this.cols + nx] === 0) {
          const d = dx * dx + dz * dz;
          if (d < bestD) { bestD = d; best = [nx, nz]; }
        }
      }
      if (best) { gx = best[0]; gz = best[1]; }
    }

    const total = this.cols * this.rows;
    const gScore = new Float32Array(total).fill(Infinity);
    const fScore = new Float32Array(total).fill(Infinity);
    const parent = new Int32Array(total).fill(-1);
    const closed = new Uint8Array(total);
    const startIdx = sz * this.cols + sx;
    const goalIdx = gz * this.cols + gx;
    gScore[startIdx] = 0;
    fScore[startIdx] = Math.hypot(gx - sx, gz - sz);
    const open = [startIdx];
    const dirs = [[1,0,1],[-1,0,1],[0,1,1],[0,-1,1],[1,1,1.414],[-1,1,1.414],[1,-1,1.414],[-1,-1,1.414]];

    while (open.length > 0) {
      let bestPos = 0;
      for (let i = 1; i < open.length; i++) if (fScore[open[i]] < fScore[open[bestPos]]) bestPos = i;
      const curr = open[bestPos];
      open.splice(bestPos, 1);
      if (curr === goalIdx) {
        const path = [];
        let p = curr;
        while (p !== -1) {
          const cx = p % this.cols, rz = Math.floor(p / this.cols);
          path.unshift(this.cellToWorld(cx, rz));
          p = parent[p];
        }
        return path;
      }
      closed[curr] = 1;
      const cx = curr % this.cols, rz = Math.floor(curr / this.cols);
      for (const [dx, dz, cost] of dirs) {
        const nx = cx + dx, nz = rz + dz;
        if (nx < 0 || nx >= this.cols || nz < 0 || nz >= this.rows) continue;
        const nIdx = nz * this.cols + nx;
        if (closed[nIdx] || this.grid[nIdx] === 1) continue;
        const tentG = gScore[curr] + cost;
        if (tentG < gScore[nIdx]) {
          parent[nIdx] = curr;
          gScore[nIdx] = tentG;
          fScore[nIdx] = tentG + Math.hypot(gx - nx, gz - nz);
          if (!open.includes(nIdx)) open.push(nIdx);
        }
      }
    }
    return [new THREE.Vector3(goalPos.x, startPos.y, goalPos.z)];
  }
}

class TriadAgentManager {
  constructor(runtime) {
    this.runtime = runtime;
    this.navMesh = new TriadNavMesh([-40, -40], [40, 40], 1.5);
    this.agents = [];
  }

  clear() {
    this.agents = [];
    this.navMesh = new TriadNavMesh([-40, -40], [40, 40], 1.5);
  }

  configureNavMesh(boundsMin, boundsMax, cellSize = 1.5) {
    this.navMesh = new TriadNavMesh(boundsMin, boundsMax, cellSize);
    this.navMesh.bakeFromPhysics(this.runtime.physics);
    return this.navMesh;
  }

  addAgent(obj3D, opts = {}) {
    const rec = {
      id: opts.id || `agent-${this.agents.length + 1}`,
      object3D: obj3D,
      behavior: (opts.behavior || 'patrol').toLowerCase(),
      speed: opts.speed !== undefined ? opts.speed : 2.8,
      radius: opts.radius !== undefined ? opts.radius : 0.45,
      waypoints: opts.waypoints || [],
      waypointIdx: 0,
      target: opts.target || null,
      path: [],
      pathIdx: 0,
      wanderCenter: obj3D.position.clone(),
      wanderRadius: opts.wanderRadius || 8.0,
      repathTimer: 0,
      onUpdate: opts.onUpdate || null,
      onArrive: opts.onArrive || null
    };
    this.agents.push(rec);
    return rec;
  }

  setBehavior(idOrAgent, behavior, opts = {}) {
    const ag = typeof idOrAgent === 'string' ? this.agents.find(a => a.id === idOrAgent) : idOrAgent;
    if (!ag) return null;
    ag.behavior = behavior.toLowerCase();
    if (opts.target !== undefined) ag.target = opts.target;
    if (opts.waypoints !== undefined) { ag.waypoints = opts.waypoints; ag.waypointIdx = 0; }
    if (opts.speed !== undefined) ag.speed = opts.speed;
    ag.path = [];
    return ag;
  }

  step(dt, elapsed) {
    if (this.agents.length === 0) return;
    for (const ag of this.agents) {
      const obj = ag.object3D;
      if (!obj) continue;
      if (ag.onUpdate) ag.onUpdate(ag, dt, elapsed);
      if (ag.behavior === 'idle') continue;

      let goal = null;
      if (ag.behavior === 'patrol' && ag.waypoints.length > 0) {
        goal = ag.waypoints[ag.waypointIdx];
        if (Math.hypot(goal.x - obj.position.x, goal.z - obj.position.z) < 0.6) {
          ag.waypointIdx = (ag.waypointIdx + 1) % ag.waypoints.length;
          goal = ag.waypoints[ag.waypointIdx];
          if (ag.onArrive) ag.onArrive(ag);
        }
      } else if (ag.behavior === 'follow' && ag.target) {
        const tp = ag.target.position || (ag.target.object3D && ag.target.object3D.position);
        if (tp) goal = tp;
      } else if (ag.behavior === 'flee' && ag.target) {
        const tp = ag.target.position || (ag.target.object3D && ag.target.object3D.position);
        if (tp) {
          const away = new THREE.Vector3().subVectors(obj.position, tp).setY(0).normalize().multiplyScalar(8.0);
          goal = obj.position.clone().add(away);
        }
      } else if (ag.behavior === 'wander') {
        if (ag.path.length === 0 || ag.pathIdx >= ag.path.length) {
          const ang = Math.random() * Math.PI * 2;
          const rad = 2.0 + Math.random() * ag.wanderRadius;
          goal = new THREE.Vector3(ag.wanderCenter.x + Math.cos(ang) * rad, obj.position.y, ag.wanderCenter.z + Math.sin(ang) * rad);
        }
      }

      ag.repathTimer -= dt;
      if (goal && (ag.path.length === 0 || ag.repathTimer <= 0)) {
        ag.path = this.navMesh.findPath(obj.position, goal);
        ag.pathIdx = 0;
        ag.repathTimer = 0.45;
      }

      if (ag.path.length > 0 && ag.pathIdx < ag.path.length) {
        const wp = ag.path[ag.pathIdx];
        const dx = wp.x - obj.position.x, dz = wp.z - obj.position.z;
        const dist = Math.hypot(dx, dz);
        if (dist < 0.45) {
          ag.pathIdx++;
        } else {
          const stepD = Math.min(dist, ag.speed * dt);
          obj.position.x += (dx / dist) * stepD;
          obj.position.z += (dz / dist) * stepD;
          obj.rotation.y = Math.atan2(dx, dz);
        }
      }

      // Agent-to-agent separation steering
      for (const other of this.agents) {
        if (other === ag || !other.object3D) continue;
        const sdx = obj.position.x - other.object3D.position.x;
        const sdz = obj.position.z - other.object3D.position.z;
        const sd = Math.hypot(sdx, sdz);
        const minD = ag.radius + other.radius;
        if (sd > 0.001 && sd < minD) {
          const push = (minD - sd) * 0.5;
          obj.position.x += (sdx / sd) * push;
          obj.position.z += (sdz / sd) * push;
        }
      }
    }
  }
}

// 5B. ASYNC CHUNK SPATIAL STREAMING MANAGER (`<chunk>` + `Triad.chunks`)
// ============================================================================
class TriadChunkManager {
  constructor(runtime) {
    this.runtime = runtime;
    this.chunks = new Map(); // id -> chunkRecord
    this.vfsFiles = {};
    this.autoStream = true;
    this.onChunkStateChange = null;
  }

  clear() {
    for (const [, ch] of this.chunks) {
      this._disposeChunkMeshes(ch);
      if (ch.container && ch.container.parent) ch.container.parent.remove(ch.container);
    }
    this.chunks.clear();
  }

  registerDeclarativeChunk(smlNode, parentObj3D, vfsFiles = {}) {
    this.vfsFiles = vfsFiles || this.vfsFiles;
    const a = smlNode.attributes || {};
    const id = a.id || a.name || `chunk-${this.chunks.size + 1}`;
    const center = parseVec3Attr(a.center || a.pos || '0 0 0', 0, 0, 0);
    const size = parseVec3Attr(a.size || a.bounds || '24 14 24', 24, 14, 24);
    const loadDist = parseFloat(a['load-distance'] || a['stream-in'] || 65);
    const unloadDist = parseFloat(a['unload-distance'] || a['stream-out'] || Math.max(loadDist + 20, loadDist * 1.35));
    const priority = parseInt(a.priority || 1, 10);
    const src = a.src || null;
    const preload = a.preload === 'true' || a.defer === 'false';
    const placeholderType = (a.placeholder || 'wireframe').toLowerCase();

    const container = new THREE.Group();
    container.name = id;
    container.position.copy(parseVec3Attr(a.pos, 0, 0, 0));
    const rot = parseVec3Attr(a.rot, 0, 0, 0);
    container.rotation.set(THREE.MathUtils.degToRad(rot.x), THREE.MathUtils.degToRad(rot.y), THREE.MathUtils.degToRad(rot.z));
    if (parentObj3D) parentObj3D.add(container);
    smlNode.object3D = container;

    // Optional lightweight 3D placeholder cage while chunk is unloaded
    let placeholderMesh = null;
    if (placeholderType !== 'none' && placeholderType !== 'false') {
      const wfGeo = buildWireframeBoxGeometry(size.x, size.y, size.z);
      wfGeo.translate(0, size.y * 0.5, 0);
      placeholderMesh = new THREE.LineSegments(wfGeo, new THREE.LineBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.35 }));
      placeholderMesh.userData._isHelper = true;
      container.add(placeholderMesh);
    }

    const templateChildren = [...smlNode.children];
    smlNode.children = []; // detach children so initial blocking buildTree skips them!

    const rec = {
      id,
      node: smlNode,
      container,
      placeholderMesh,
      center,
      size,
      loadDistance: loadDist,
      unloadDistance: unloadDist,
      priority,
      src,
      templateChildren,
      state: 'UNLOADED', // 'UNLOADED' | 'LOADING' | 'LOADED'
      loadedNodes: [],
      triangleCount: 0,
      drawCount: 0,
      loadTimeMs: 0,
      autoUnload: a['auto-unload'] !== 'false'
    };
    this.chunks.set(id, rec);

    if (preload) {
      this.loadChunk(id);
    }
    return rec;
  }

  register(id, opts = {}) {
    const dummyNode = new SMLNode('chunk', {
      id,
      pos: opts.pos ? `${opts.pos[0]} ${opts.pos[1]} ${opts.pos[2]}` : '0 0 0',
      center: opts.center ? `${opts.center[0]} ${opts.center[1]} ${opts.center[2]}` : (opts.pos ? `${opts.pos[0]} ${opts.pos[1]} ${opts.pos[2]}` : '0 0 0'),
      size: opts.size ? `${opts.size[0]} ${opts.size[1]} ${opts.size[2]}` : '24 14 24',
      'load-distance': String(opts.loadDistance || 65),
      'unload-distance': String(opts.unloadDistance || 95),
      priority: String(opts.priority || 1),
      src: opts.src || '',
      placeholder: opts.placeholder || 'wireframe',
      'texture-resolution': opts.textureResolution ? String(opts.textureResolution) : undefined,
      'merge-meshes': opts.mergeMeshes ? 'true' : undefined
    });
    dummyNode._sceneRef = this.runtime;
    if (opts.sml) {
      const parsed = parseSMLFileToRawAST(opts.sml, `${id}.sml`);
      dummyNode.children = parsed.children;
    }
    return this.registerDeclarativeChunk(dummyNode, this.runtime.rootContainer, this.vfsFiles);
  }

  async loadChunk(id) {
    const ch = this.chunks.get(id);
    if (!ch || ch.state === 'LOADED' || ch.state === 'LOADING') return ch;
    ch.state = 'LOADING';
    const t0 = performance.now();
    if (this.onChunkStateChange) this.onChunkStateChange(ch);

    let childNodes = ch.templateChildren.map(n => this.runtime._cloneNodeDeep(n, ch.id));
    if (ch.src && childNodes.length === 0) {
      let smlText = this.vfsFiles[ch.src] || null;
      if (!smlText && typeof fetch === 'function') {
        try {
          const res = await fetch(ch.src);
          if (res.ok) smlText = await res.text();
        } catch (_) {}
      }
      if (smlText) {
        const comp = compileSML20(ch.src, { ...this.vfsFiles, [ch.src]: smlText });
        if (comp.embeddedStyles && comp.embeddedStyles.length) {
          this.runtime.styleSheet.parse(comp.embeddedStyles.join('\n'), this.vfsFiles);
        }
        childNodes = comp.root.children;
      }
    }

    // Time-sliced non-blocking instantiation (yields every 12 nodes so frame rate stays smooth!)
    const createdNodes = [];
    const optNodes = [];
    const buildSubtreeAsync = async (nodes, parent3D) => {
      for (let i = 0; i < nodes.length; i++) {
        const n = nodes[i];
        if (n.tagName === 'modifier') continue;
        if (n.parent && n.parent.tagName === 'csg') continue;
        n._sceneRef = this.runtime;
        n.parent = n.parent || ch.node;
        this.runtime.allNodes.push(n);
        this.runtime.uidMap.set(n.uid, n);
        if (n.id) this.runtime.idMap.set(n.id, n);
        createdNodes.push(n);

        this.runtime._instantiateNodeObject(n);
        if (n.object3D && parent3D) parent3D.add(n.object3D);
        const effOpt = n.getEffectiveOptimizationConfig();
        if (n.tagName === 'batch' || n.tagName === 'optimize' || n.attributes.batch === 'true' || effOpt.mergeMeshes || effOpt.autoInstance || effOpt.freezeMatrices) {
          optNodes.push(n);
        }
        if (n.children && n.children.length > 0) {
          await buildSubtreeAsync(n.children, n.object3D);
        }
        this.runtime._applyLayoutContainer(n);
        if (createdNodes.length % 16 === 0) {
          await new Promise(r => setTimeout(r, 0));
        }
      }
    };

    await buildSubtreeAsync(childNodes, ch.container);
    for (const cn of createdNodes) {
      this.runtime.applyStyleToNode(cn);
    }

    // Apply chunk-level or sub-group optimizations (merge-meshes, auto-instance, freeze-matrices)
    const chOpt = ch.node.getEffectiveOptimizationConfig();
    if (chOpt.autoInstance) this.runtime._applyAutoInstancing(ch.node);
    if (chOpt.mergeMeshes || ch.node.attributes.batch === 'true') this.runtime._mergeBatchContainer(ch.node);
    for (const on of optNodes) {
      const oCfg = on.getEffectiveOptimizationConfig();
      if (oCfg.autoInstance) this.runtime._applyAutoInstancing(on);
      if (oCfg.mergeMeshes || on.tagName === 'batch' || on.attributes.batch === 'true') this.runtime._mergeBatchContainer(on);
    }
    if (chOpt.freezeMatrices) this.runtime._freezeSubtreeMatrices(ch.container);

    this.runtime.physics.extractDeclarativeCollidersFromSML(createdNodes, ch.node);
    if (ch.placeholderMesh) ch.placeholderMesh.visible = false;

    let tris = 0, draws = 0;
    ch.container.traverse(o => {
      if (o.isMesh && !o.userData._isHelper && o.geometry && o.geometry.attributes.position) {
        draws++;
        const cnt = o.geometry.index ? o.geometry.index.count / 3 : o.geometry.attributes.position.count / 3;
        tris += o.isInstancedMesh ? cnt * o.count : cnt;
      }
    });
    ch.loadedNodes = createdNodes;
    ch.triangleCount = Math.round(tris);
    ch.drawCount = draws;
    ch.loadTimeMs = Number((performance.now() - t0).toFixed(1));
    ch.state = 'LOADED';

    this.runtime.renderer.shadowMap.needsUpdate = true;
    if (this.runtime.viewer) this.runtime.viewer.renderFrame();
    if (this.onChunkStateChange) this.onChunkStateChange(ch);
    return ch;
  }

  unloadChunk(id) {
    const ch = this.chunks.get(id);
    if (!ch || ch.state !== 'LOADED') return ch;
    this._disposeChunkMeshes(ch);
    const unloadedSet = new Set(ch.loadedNodes);
    if (this.runtime.physics && this.runtime.physics.colliders) {
      this.runtime.physics.colliders = this.runtime.physics.colliders.filter(c => !c.node || !unloadedSet.has(c.node));
    }
    for (const cn of ch.loadedNodes) {
      const idx = this.runtime.allNodes.indexOf(cn);
      if (idx !== -1) this.runtime.allNodes.splice(idx, 1);
      this.runtime.uidMap.delete(cn.uid);
      if (cn.id) this.runtime.idMap.delete(cn.id);
    }
    ch.loadedNodes = [];
    ch.triangleCount = 0;
    ch.drawCount = 0;
    ch.state = 'UNLOADED';
    if (ch.placeholderMesh) ch.placeholderMesh.visible = true;
    this.runtime.renderer.shadowMap.needsUpdate = true;
    if (this.runtime.viewer) this.runtime.viewer.renderFrame();
    if (this.onChunkStateChange) this.onChunkStateChange(ch);
    return ch;
  }

  async loadAll() {
    const sorted = Array.from(this.chunks.values()).sort((a, b) => a.priority - b.priority);
    for (const ch of sorted) {
      await this.loadChunk(ch.id);
    }
    return this.getStats();
  }

  _disposeChunkMeshes(ch) {
    if (!ch || !ch.container) return;
    const toRemove = [];
    for (const child of ch.container.children) {
      if (child !== ch.placeholderMesh) toRemove.push(child);
    }
    for (const obj of toRemove) {
      obj.traverse(o => {
        if (o.geometry && typeof o.geometry.dispose === 'function') o.geometry.dispose();
      });
      ch.container.remove(obj);
    }
  }

  updateForCamera(camPos) {
    if (!this.autoStream || !camPos || this.chunks.size === 0) return;
    const candidatesToLoad = [];
    for (const [, ch] of this.chunks) {
      const dist = Math.hypot(ch.center.x - camPos.x, ch.center.z - camPos.z);
      ch.lastCameraDistance = Number(dist.toFixed(1));
      if (ch.state === 'UNLOADED' && dist <= ch.loadDistance) {
        candidatesToLoad.push(ch);
      } else if (ch.state === 'LOADED' && ch.autoUnload && dist > ch.unloadDistance) {
        this.unloadChunk(ch.id);
      }
    }
    if (candidatesToLoad.length > 0) {
      candidatesToLoad.sort((a, b) => (a.priority - b.priority) || (a.lastCameraDistance - b.lastCameraDistance));
      for (const c of candidatesToLoad) {
        this.loadChunk(c.id);
      }
    }
  }

  getStats() {
    let loaded = 0, loading = 0, unloaded = 0, activeTris = 0, activeDraws = 0;
    const list = [];
    for (const [, ch] of this.chunks) {
      if (ch.state === 'LOADED') { loaded++; activeTris += ch.triangleCount; activeDraws += ch.drawCount; }
      else if (ch.state === 'LOADING') loading++;
      else unloaded++;
      list.push({
        id: ch.id,
        state: ch.state,
        center: [ch.center.x, ch.center.y, ch.center.z],
        loadDistance: ch.loadDistance,
        unloadDistance: ch.unloadDistance,
        triangles: ch.triangleCount,
        draws: ch.drawCount,
        loadTimeMs: ch.loadTimeMs
      });
    }
    return { total: this.chunks.size, loaded, loading, unloaded, activeTriangles: activeTris, activeDraws, chunks: list };
  }
}

class TriadSceneRuntime {
  constructor(threeScene, renderer) {
    this.threeScene = threeScene;
    this.renderer = renderer;
    this.rootContainer = new THREE.Group();
    this.threeScene.add(this.rootContainer);

    this.smlRoot = null;
    this.styleSheet = new SpatialStyleSheet();
    this.customGenerators = new Map();
    this.tickCallbacks = [];
    this.allNodes = [];
    this.uidMap = new Map();
    this.idMap = new Map();
    this.animatedNodes = [];
    this.guiControls = new Map(); // label -> { value, type, min, max }
    this.chunks = new TriadChunkManager(this);
    this.agents = new TriadAgentManager(this);
    this.optStats = { mergedGroups: 0, instancedGroups: 0, frozenMatrices: 0, lodGroups: 0, drawsBeforeOpt: 0, drawsAfterOpt: 0 };
    this.bakeConfig = { enabled: false, title: 'TRIAD3D v9.5 · SCENE & TEXTURE BAKE', subtitle: 'Compiling AST, Downscaling Textures, Merging Batches & Streaming Chunks...', hold: false };
    this.physics = new TriadPhysicsWorld(this);
    this.threeScene.add(this.physics.markersGroup);
  }

  clear() {
    while (this.rootContainer.children.length > 0) {
      this.rootContainer.remove(this.rootContainer.children[0]);
    }
    this.customGenerators.clear();
    this.customGenerators._geoCache = new Map();
    if (this.physics) this.physics.clear();
    if (this.chunks) this.chunks.clear();
    if (this.agents) this.agents.clear();
    this.activeCameraNode = null;
    resetTextureTelemetry();
    this.optStats = { mergedGroups: 0, instancedGroups: 0, frozenMatrices: 0, lodGroups: 0, drawsBeforeOpt: 0, drawsAfterOpt: 0 };
    this.wetReflectors = [];
    this.particleSystems = [];
    this.warnings = [];
    this.lastError = null;
    this.postConfig = { bloom: 0.0, bloomThreshold: 0.72, bloomRadius: 0.4, dof: false, dofBlur: 0.0014 };
    this.tickCallbacks = [];
    this.allNodes = [];
    this.uidMap.clear();
    this.idMap.clear();
    this.animatedNodes = [];
    NextUid = 1;
  }

  getElementById(id) { return this.idMap.get(id) || null; }
  querySelector(sel) { return this.smlRoot ? this.smlRoot.querySelector(sel) : null; }
  querySelectorAll(sel) { return this.smlRoot ? this.smlRoot.querySelectorAll(sel) : []; }

  createElement(tagName, attrs = {}) {
    const node = new SMLNode(tagName, attrs, 0, 'runtime.3js');
    node._sceneRef = this;
    this._instantiateNodeObject(node);
    this.applyStyleToNode(node);
    this.allNodes.push(node);
    this.uidMap.set(node.uid, node);
    if (node.id) this.idMap.set(node.id, node);
    return node;
  }

  compileVFSProject(vfsFiles) {
    const t0 = performance.now();
    this.clear();

    // Find entry .sml file (prefer main.sml or structure.sml)
    const fileNames = Object.keys(vfsFiles);
    const entrySml = fileNames.find(f => f === 'main.sml' || f === 'structure.sml') ||
                     fileNames.find(f => f.endsWith('.sml')) || 'main.sml';

    // Compile SML 3.0 with <import>, <component>, <for>, <if>, {expr}, <style>, <script>
    const { root, linkedStyles, linkedScripts, embeddedStyles, embeddedScripts } = compileSML20(entrySml, vfsFiles);
    this.smlRoot = root;

    // Combine all .3ss files in VFS + any embedded <style>...<\/style> blocks inside .sml files
    const allCssFiles = Array.from(new Set([...linkedStyles, ...fileNames.filter(f => f.endsWith('.3ss'))]));
    const combinedCss = [
      ...allCssFiles.map(f => vfsFiles[f] || ''),
      ...(embeddedStyles || [])
    ].join('\n');
    this.styleSheet.parse(combinedCss, vfsFiles);

    // Combine all .3js files in VFS + any embedded <script>...<\/script> blocks inside .sml files
    const allJsFiles = Array.from(new Set([...linkedScripts, ...fileNames.filter(f => f.endsWith('.3js'))]));
    const combinedJs = [
      ...allJsFiles.map(f => vfsFiles[f] || ''),
      ...(embeddedScripts || [])
    ].join('\n');

    // Clear & rebuild `Triad.gui` panel UI (supports both Studio IDE & standalone triad3d.js library)
    const guiContainer = this.guiRowsEl !== undefined ? this.guiRowsEl : (typeof document !== 'undefined' ? document.getElementById('triad-gui-rows') : null);
    if (guiContainer) guiContainer.innerHTML = '';
    const activeGuiLabels = new Set();

    const guiBuilder = {
      slider: (label, min = 0, max = 1, initial = 0.5, onChange = null) => {
        activeGuiLabels.add(label);
        if (!this.guiControls.has(label)) {
          this.guiControls.set(label, { value: initial });
        }
        const ctrl = this.guiControls.get(label);
        const row = document.createElement('div');
        row.className = 'gui-row';
        row.innerHTML = `
          <span title="${escapeHtml(label)}" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(label)}</span>
          <input type="range" min="${min}" max="${max}" step="${(max - min) / 100}" value="${ctrl.value}" />
          <span style="font-family:var(--font-mono);text-align:right;">${Number(ctrl.value).toFixed(2)}</span>
        `;
        const inp = row.querySelector('input');
        const valSpan = row.querySelectorAll('span')[1];
        inp.addEventListener('input', () => {
          ctrl.value = parseFloat(inp.value);
          valSpan.textContent = ctrl.value.toFixed(2);
          if (onChange) onChange(ctrl.value);
          this.renderer.shadowMap.needsUpdate = true;
        });
        if (guiContainer) guiContainer.appendChild(row);
        return ctrl;
      },
      toggle: (label, initial = false, onChange = null) => {
        activeGuiLabels.add(label);
        if (!this.guiControls.has(label)) {
          this.guiControls.set(label, { value: !!initial });
        }
        const ctrl = this.guiControls.get(label);
        const row = document.createElement('div');
        row.className = 'gui-row';
        row.innerHTML = `
          <span>${escapeHtml(label)}</span>
          <input type="checkbox" ${ctrl.value ? 'checked' : ''} style="cursor:pointer;" />
          <span style="font-family:var(--font-mono);text-align:right;">${ctrl.value ? 'ON' : 'OFF'}</span>
        `;
        const chk = row.querySelector('input');
        const valSpan = row.querySelectorAll('span')[1];
        chk.addEventListener('change', () => {
          ctrl.value = chk.checked;
          valSpan.textContent = ctrl.value ? 'ON' : 'OFF';
          if (onChange) onChange(ctrl.value);
        });
        if (guiContainer) guiContainer.appendChild(row);
        return ctrl;
      }
    };

    const TriadAPI = {
      THREE,
      MeshBuilder: TriadMeshBuilder,
      noise: TriadNoise,
      physics: this.physics,
      collision: this.physics,
      chunks: this.chunks,
      agents: this.agents,
      images: {
        register: registerUploadedImage,
        getTelemetry: () => TextureTelemetry
      },
      optimize: {
        getStats: () => ({ ...this.optStats, textures: { ...TextureTelemetry, entries: Array.from(TextureTelemetry.entries.values()) }, chunks: this.chunks.getStats() }),
        mergeSubtree: (selOrNode) => {
          const t = typeof selOrNode === 'string' ? this.querySelector(selOrNode) : (selOrNode || this.smlRoot);
          if (t) this._mergeBatchContainer(t);
        },
        freezeSubtree: (selOrNode) => {
          const t = typeof selOrNode === 'string' ? this.querySelector(selOrNode) : (selOrNode || this.smlRoot);
          if (t && t.object3D) this._freezeSubtreeMatrices(t.object3D);
        }
      },
      mode: {
        get current() { return this._mode || 'edit'; },
        set: (modeName, opts) => this.setRenderMode(modeName, opts),
        rebakeShadows: () => {
          this.renderer.shadowMap.needsUpdate = true;
          if (this.wetReflectors) this.wetReflectors.forEach(r => { r._forceReflUpdate = true; });
        },
        getStats: () => ({ ...(this._exploreStats || { mode: 'edit' }), drawCalls: this.renderer.info.render.calls, triangles: this.renderer.info.render.triangles })
      },
      lighting: {
        setShadowEdgeContrast: (opts = {}) => {
          if (opts.boost !== undefined) this.renderer._shadowEdgeBoost = opts.boost;
          if (opts.saturation !== undefined) this.renderer._shadowEdgeSat = opts.saturation;
          if (opts.darkness !== undefined) this.renderer._shadowDarkness = opts.darkness;
        }
      },
      post: {
        setBloom: (strength, threshold = 0.72) => {
          this.postConfig.bloom = strength;
          this.postConfig.bloomThreshold = threshold;
        },
        setDOF: (enabled, blur = 0.0014) => {
          this.postConfig.dof = !!enabled;
          this.postConfig.dofBlur = blur;
        },
        addWetReflector: (w = 14, d = 52, opts = {}) => {
          const r = new THREE.WetFloorReflector(w, d, opts);
          this.rootContainer.add(r.mesh);
          this.wetReflectors.push(r);
          return r;
        }
      },
      gui: guiBuilder,
      setGameMode: (active) => { this.gameModeActive = !!active; },
      camera: {
        setPose: (pos, lookTarget, fov) => {
          const cam = typeof perspCamera !== 'undefined' ? perspCamera : (this.viewer && this.viewer.perspCamera ? this.viewer.perspCamera : null);
          if (!cam) return;
          if (fov) { cam.fov = fov; cam.updateProjectionMatrix(); }
          cam.position.set(pos[0], pos[1], pos[2]);
          cam.lookAt(new THREE.Vector3(lookTarget[0], lookTarget[1], lookTarget[2]));
          cam.updateMatrixWorld(true);
        }
      },
      registerGenerator: (name, fn) => this.customGenerators.set(name, fn),
      registerPattern: (name, fn, sz) => registerCustomPattern(name, fn, sz),
      onTick: (fn) => this.tickCallbacks.push(fn),
      inspect: (selOrNode) => {
        const target = typeof selOrNode === 'string' ? this.querySelector(selOrNode) : selOrNode;
        if (target) selectSMLNode(target, true);
        return target;
      }
    };

    _registerArchitecturalPatterns();

    const formatScriptError = (err, codeStr, contextLabel) => {
      this.lastError = err;
      const stack = (err && err.stack) ? String(err.stack) : String(err);
      let lineHint = '';
      const lineMatch = stack.match(/<anonymous>:(\d+):(\d+)/) || stack.match(/Function:(\d+):(\d+)/);
      if (lineMatch && codeStr) {
        const rawLine = parseInt(lineMatch[1], 10) - 2;
        const srcLines = codeStr.split('\n');
        if (rawLine >= 1 && rawLine <= srcLines.length) {
          const snippet = [];
          for (let ln = Math.max(1, rawLine - 1); ln <= Math.min(srcLines.length, rawLine + 1); ln++) {
            const prefix = ln === rawLine ? '>> ' : '   ';
            snippet.push(`${prefix}L${ln}: ${srcLines[ln - 1]}`);
          }
          lineHint = `\nAt line ${rawLine}:\n${snippet.join('\n')}`;
        }
      }
      const fullMsg = `[Triad3D ${contextLabel}] ${err ? err.message : err}${lineHint}\n${stack}`;
      console.error(fullMsg);
      logConsole(fullMsg, 'err');
      return fullMsg;
    };

    // Validate <scene> and node attributes so typos or unknown attributes are never silently ignored
    const KNOWN_SCENE_ATTRS = new Set([
      'id', 'class', 'name', 'sky', 'background', 'horizon', 'horizon-color', 'sky-mode', 'clouds',
      'fog', 'fog-color', 'fog-density', 'fog-near', 'fog-far',
      'exposure', 'tonemapping', 'tone-mapping',
      'bloom', 'bloom-strength', 'bloom-threshold', 'bloom-radius',
      'dof', 'dof-blur', 'dof-aperture', 'dof-maxblur', 'dof-focus',
      'fxaa', 'vignette', 'env', 'environment', 'ibl', 'env-preset', 'env-intensity', 'ibl-intensity',
      'ambient', 'ambient-color', 'ambient-intensity',
      'wet-floor', 'wet-reflection', 'water', 'water-amount', 'water-tint', 'water-color', 'water-distortion', 'shadow-darkness', 'shadow-edge-boost', 'shadow-edge-sat', 'shadows', 'shadow-map',
      'texture-resolution', 'image-resolution', 'resolution', 'max-texture-size', 'synthesize-normals', 'texture-filter', 'mipmaps',
      'optimize', 'merge-meshes', 'auto-instance', 'segment-scale', 'geometry-lod', 'simplify', 'vertex-weld',
      'cull-distance', 'max-distance', 'shadow-cull', 'small-object-cull', 'freeze-matrices', 'pom-cull-distance', 'shader-tier',
      'bake-screen', 'bake-title', 'bake-subtitle', 'bake-hold', 'time-of-day', 'sun-elevation', 'sun-azimuth', 'sun-color', 'cloud-density', 'cloud-coverage', 'cloud-speed', 'cloud-scale', 'cloud-puffiness', 'cloud-silver', 'cloud-shadow', 'cloud-light-color', 'cloud-shadow-color', 'cloud-puffs', 'cloud-puff-count', 'cloud-mode', 'wind-x', 'wind-z', 'sky-stars', 'time-of-day', 'sun-elevation', 'sun-azimuth', 'sun-color', 'cloud-density', 'cloud-coverage', 'cloud-speed', 'cloud-scale', 'cloud-puffiness', 'cloud-silver', 'cloud-shadow', 'cloud-light-color', 'cloud-shadow-color', 'cloud-puffs', 'cloud-puff-count', 'cloud-mode', 'wind-x', 'wind-z', 'sky-stars', 'clouds', 'env-horizon', 'env-zenith', 'env-ground', 'fps-yaw', 'fps-pitch', 'eye-height',
      'gravity', 'fps-spawn', 'fps-speed', 'fps-sprint', 'fps-jump', 'fps-eye-height', 'fps-radius',
      'pos', 'rot', 'scale', 'style', 'oninit', 'onupdate', 'ontick'
    ]);

    const sa = this.smlRoot.attributes || {};
    for (const attrKey of Object.keys(sa)) {
      if (!KNOWN_SCENE_ATTRS.has(attrKey) && !attrKey.startsWith('data-')) {
        const warnMsg = `Unknown <scene> attribute "${attrKey}"="${sa[attrKey]}" (line ${this.smlRoot.sourceLine || 1}). Supported: bloom, dof, exposure, sky, fog-color, fog-density, env, wet-floor, fps-spawn.`;
        this.warnings.push(warnMsg);
        console.warn('[Triad3D SML Warning]', warnMsg);
        logConsole(`SML Warning: ${warnMsg}`, 'warn');
      }
    }

    // Configure <scene> Post-Processing (bloom, bloom-strength, bloom-threshold, dof, dof-blur)
    if (sa.bloom !== undefined) {
      const bStr = String(sa.bloom).trim().toLowerCase();
      if (bStr === 'false' || bStr === '0' || bStr === 'none' || bStr === 'off') {
        this.postConfig.bloom = 0.0;
      } else if (bStr === 'true' || bStr === 'on') {
        this.postConfig.bloom = parseFloat(sa['bloom-strength'] || 0.65);
      } else {
        const numB = parseFloat(bStr);
        this.postConfig.bloom = isNaN(numB) ? 0.65 : numB;
      }
    }
    if (sa['bloom-strength'] !== undefined) {
      this.postConfig.bloom = parseFloat(sa['bloom-strength']) || 0.0;
    }
    if (sa['bloom-threshold'] !== undefined) {
      this.postConfig.bloomThreshold = parseFloat(sa['bloom-threshold']);
    }
    if (sa['bloom-radius'] !== undefined) {
      this.postConfig.bloomRadius = parseFloat(sa['bloom-radius']);
    }

    if (sa.dof !== undefined) {
      const dStr = String(sa.dof).trim().toLowerCase();
      if (dStr === 'false' || dStr === '0' || dStr === 'none' || dStr === 'off') {
        this.postConfig.dof = false;
      } else if (dStr === 'true' || dStr === 'on') {
        this.postConfig.dof = true;
      } else {
        const numD = parseFloat(dStr);
        if (!isNaN(numD) && numD > 0) {
          this.postConfig.dof = true;
          this.postConfig.dofBlur = numD;
        } else {
          this.postConfig.dof = false;
        }
      }
    }
    const dofBlurAttr = sa['dof-blur'] || sa['dof-maxblur'] || sa['dof-aperture'];
    if (dofBlurAttr !== undefined) {
      this.postConfig.dofBlur = parseFloat(dofBlurAttr) || 0.0014;
    }

    // Configure <scene> Environment / IBL / Exposure / Shadows / Wet-Floor
    // ToneMapping
    const tmAttr = (sa.tonemapping || sa['tone-mapping'] || '').toLowerCase();
    const tmMap = {
      none: THREE.NoToneMapping, linear: THREE.LinearToneMapping, reinhard: THREE.ReinhardToneMapping,
      cineon: THREE.CineonToneMapping, aces: THREE.ACESFilmicToneMapping, acesfilmic: THREE.ACESFilmicToneMapping,
      agx: THREE.AgXToneMapping, neutral: THREE.NeutralToneMapping
    };
    if (tmAttr && tmMap[tmAttr] !== undefined) {
      this.renderer.toneMapping = tmMap[tmAttr];
    }

    // FXAA & Vignette post-processing config
    this.postConfig.fxaa = sa.fxaa === 'true' || sa.fxaa === 'on';
    if (sa.vignette !== undefined) {
      const vs = String(sa.vignette).trim().toLowerCase();
      this.postConfig.vignette = (vs === 'false' || vs === '0' || vs === 'off') ? 0.0 : (vs === 'true' || vs === 'on' ? 0.45 : (parseFloat(vs) || 0.0));
    }

    // Declarative Ambient Light (`ambient`, `ambient-color`, `ambient-intensity`)
    if (sa.ambient !== undefined || sa['ambient-color'] || sa['ambient-intensity'] !== undefined) {
      const ambCol = sa['ambient-color'] || (sa.ambient && sa.ambient.startsWith('#') ? sa.ambient : '#ffffff');
      const ambInt = parseFloat(sa['ambient-intensity'] !== undefined ? sa['ambient-intensity'] : (sa.ambient && !sa.ambient.startsWith('#') ? sa.ambient : 0.45));
      if (!isNaN(ambInt) && ambInt > 0) {
        const ambLight = new THREE.AmbientLight(ambCol, ambInt);
        this.rootContainer.add(ambLight);
      }
    }

    // Environment Preset, Custom Env Colors, or Real HDRI / Equirectangular Texture (`env="url(...)"`)
    const envPresetAttr = sa.env || sa.environment || sa.ibl || sa['env-preset'];
    this.renderer.envColors = null;
    if (sa['env-horizon'] || sa['env-zenith'] || sa['env-ground']) {
      this.renderer.envColors = {
        horizon: sa['env-horizon'] ? new THREE.Color(sa['env-horizon']) : null,
        zenith: sa['env-zenith'] ? new THREE.Color(sa['env-zenith']) : null,
        ground: sa['env-ground'] ? new THREE.Color(sa['env-ground']) : null
      };
    }
    if (envPresetAttr !== undefined) {
      const rawEnv = String(envPresetAttr).trim();
      const envUrl = extractUrlString(rawEnv);
      if (rawEnv.toLowerCase() === 'none' || rawEnv.toLowerCase() === 'false') {
        this.threeScene.environment = null;
      } else if (envUrl && (rawEnv.includes('url(') || /\.(hdr|png|jpg|jpeg|webp)$/i.test(envUrl) || envUrl.startsWith('data:'))) {
        if (/\.hdr$/i.test(envUrl)) {
          new THREE.RGBELoader().load(envUrl, (hdrTex) => {
            this.threeScene.environment = hdrTex;
            if (this.viewer) this.viewer.renderFrame();
          });
        } else {
          new THREE.TextureLoader().load(envUrl, (eqTex) => {
            eqTex.isPMREM = true;
            this.threeScene.environment = eqTex;
            if (this.viewer) this.viewer.renderFrame();
          });
        }
      } else {
        const envMapNames = { sunset: 0, studio: 1, overcast: 2, night: 3 };
        const ep = envMapNames[rawEnv.toLowerCase()] !== undefined ? envMapNames[rawEnv.toLowerCase()] : (parseInt(rawEnv, 10) || 0);
        this.renderer.envPreset = ep;
        // Generate real PMREM equirectangular environment map from scene palette
        const pmrem = new THREE.PMREMGenerator(this.renderer);
        this.threeScene.environment = pmrem.fromScene(this.threeScene).texture;
      }
    }
    if (sa['env-intensity'] !== undefined || sa['ibl-intensity'] !== undefined) {
      this.threeScene.environmentIntensity = parseFloat(sa['env-intensity'] || sa['ibl-intensity']) || 1.0;
    }
    if (sa.shadows === 'false' || sa['shadow-map'] === 'false') {
      this.renderer.shadowMap.enabled = false;
    } else if (sa.shadows === 'true' || sa['shadow-map'] === 'true') {
      this.renderer.shadowMap.enabled = true;
    }

    const skyRaw = sa.sky || sa.background || '#2a528a';
    const disableSkyDome = (skyRaw === 'none' || skyRaw === 'false');
    const skyHex = disableSkyDome ? (sa.background && sa.background !== 'none' ? sa.background : '#080b12') : skyRaw;
    const fogHex = sa['fog-color'] || sa['horizon-color'] || '#ebcba8';
    this.threeScene.background = new THREE.Color(skyHex);

    const fogMode = (sa.fog || '').toLowerCase();
    if (fogMode === 'none' || fogMode === 'false' || parseFloat(sa['fog-density']) === 0) {
      this.threeScene.fog = null;
    } else if (sa['fog-near'] !== undefined || sa['fog-far'] !== undefined) {
      this.threeScene.fog = new THREE.Fog(fogHex, parseFloat(sa['fog-near'] || 10), parseFloat(sa['fog-far'] || 160));
    } else if (sa['fog-color'] || sa['fog-density'] !== undefined) {
      this.threeScene.fog = new THREE.FogExp2(fogHex, parseFloat(sa['fog-density'] !== undefined ? sa['fog-density'] : 0.008));
    } else {
      this.threeScene.fog = new THREE.FogExp2('#0f1218', 0.006);
    }

    if (sa.exposure !== undefined) {
      this.renderer.toneMappingExposure = parseFloat(sa.exposure) || 1.0;
      const expInp = typeof document !== 'undefined' ? document.getElementById('exposure-slider') : null;
      const expVal = typeof document !== 'undefined' ? document.getElementById('exposure-val') : null;
      if (expInp) expInp.value = String(this.renderer.toneMappingExposure);
      if (expVal) expVal.textContent = this.renderer.toneMappingExposure.toFixed(2);
    }

    const wetAttr = sa['wet-floor'] || sa['wet-reflection'];
    if (wetAttr && wetAttr !== 'false' && wetAttr !== 'none' && wetAttr !== '0') {
      const dims = String(wetAttr).trim().split(/[\s,]+/).map(Number);
      const rw = (!isNaN(dims[0]) && dims[0] > 0) ? dims[0] : 28;
      const rd = (!isNaN(dims[1]) && dims[1] > 0) ? dims[1] : 72;
      TriadAPI.post.addWetReflector(rw, rd, { reflectivity: 0.92, textureWidth: 512, textureHeight: 512 });
    }
    const waterAttr = sa['water'];
    if (waterAttr && waterAttr !== 'false' && waterAttr !== 'none' && waterAttr !== '0') {
      const dims = String(waterAttr).trim().split(/[\s,]+/).map(Number);
      const rw = (!isNaN(dims[0]) && dims[0] > 0) ? dims[0] : 400;
      const rd = (!isNaN(dims[1]) && dims[1] > 0) ? dims[1] : 400;
      TriadAPI.post.addWetReflector(rw, rd, {
        mode: 'water',
        reflectivity: parseFloat(sa['water-amount'] || 0.88),
        tint: sa['water-tint'] || '#bfe6ff',
        baseColor: sa['water-color'] || '#0c2f47',
        distortion: parseFloat(sa['water-distortion'] || 0.024),
        fogColor: fogHex,
        fogNear: parseFloat(sa['fog-near'] || 75),
        fogFar: parseFloat(sa['fog-far'] || 260),
        textureWidth: 512, textureHeight: 512
      });
    }

    // Build 1400m Camera-Centered Non-Raymarched Volumetric Sky & Cloud Engine (unless sky="none")
    this.skyUniforms = null;
    this.cloudImpostorGroup = null;
    const parseNum = (v, def) => (v !== undefined && !isNaN(parseFloat(v))) ? parseFloat(v) : def;

    const initSunDir = new THREE.Vector3(0.45, 0.58, 0.52).normalize();
    if (sa['sun-elevation'] !== undefined || sa['sun-azimuth'] !== undefined) {
      const el = THREE.MathUtils.degToRad(parseNum(sa['sun-elevation'], 28));
      const az = THREE.MathUtils.degToRad(parseNum(sa['sun-azimuth'], 42));
      initSunDir.set(Math.cos(el) * Math.sin(az), Math.sin(el), Math.cos(el) * Math.cos(az)).normalize();
    }

    const cloudDensInit = (sa.clouds === 'false' || sa.clouds === '0')
      ? 0.0
      : parseNum(sa['cloud-density'] !== undefined ? sa['cloud-density'] : sa.clouds, 0.88);

    if (!disableSkyDome) {
      const skyGeo = new THREE.SphereGeometry(1400, 64, 32);
      const skyUniforms = {
        uTime:           { value: 0.0 },
        uZenithColor:    { value: new THREE.Color(skyHex) },
        uHorizonColor:   { value: new THREE.Color(fogHex) },
        uSunColor:       { value: new THREE.Color(sa['sun-color'] || '#ffe4b5') },
        uSunDir:         { value: initSunDir.clone() },
        uOceanHorizon:   { value: (sa.horizon === 'ocean' || sa['sky-mode'] === 'ocean') ? 1.0 : 0.0 },
        uCloudDensity:   { value: cloudDensInit },
        uCloudCoverage:  { value: parseNum(sa['cloud-coverage'], 0.50) },
        uCloudSpeed:     { value: parseNum(sa['cloud-speed'], 0.025) },
        uCloudScale:     { value: parseNum(sa['cloud-scale'], 1.20) },
        uCloudPuffiness: { value: parseNum(sa['cloud-puffiness'], 0.85) },
        uCloudSilver:    { value: parseNum(sa['cloud-silver'], 0.85) },
        uCloudShadow:    { value: parseNum(sa['cloud-shadow'], 0.72) },
        uCloudDetail:    { value: parseNum(sa['cloud-detail'], 0.85) },
        uCloudErosion:   { value: parseNum(sa['cloud-erosion'], 0.55) },
        uCloudCrispness: { value: parseNum(sa['cloud-crispness'], 0.84) },
        uCloudLightCol:  { value: new THREE.Color(sa['cloud-light-color'] || '#f7f5f0') },
        uCloudShadowCol: { value: new THREE.Color(sa['cloud-shadow-color'] || '#536885') },
        uWindDir:        { value: new THREE.Vector2(parseNum(sa['wind-x'], 1.0), parseNum(sa['wind-z'], 0.42)).normalize() },
        uStarIntensity:  { value: parseNum(sa['sky-stars'], 0.65) }
      };
      this.skyUniforms = skyUniforms;

      const skyMat = new THREE.ShaderMaterial({
        uniforms: skyUniforms,
        vertexShader: `
          varying vec3 vWorldDir;
          void main() {
            vec4 wp = modelMatrix * vec4(position, 1.0);
            vWorldDir = position;
            vec4 clip = projectionMatrix * viewMatrix * wp;
            gl_Position = vec4(clip.xy, clip.w * 0.99999, clip.w);
          }
        `,
        fragmentShader: `
          precision highp float;
          uniform float uTime;
          uniform vec3 uZenithColor;
          uniform vec3 uHorizonColor;
          uniform vec3 uSunColor;
          uniform vec3 uSunDir;
          uniform float uOceanHorizon;
          uniform float uCloudDensity;
          uniform float uCloudCoverage;
          uniform float uCloudSpeed;
          uniform float uCloudScale;
          uniform float uCloudPuffiness;
          uniform float uCloudSilver;
          uniform float uCloudShadow;
          uniform float uCloudDetail;
          uniform float uCloudErosion;
          uniform float uCloudCrispness;
          uniform vec3 uCloudLightCol;
          uniform vec3 uCloudShadowCol;
          uniform vec2 uWindDir;
          uniform float uStarIntensity;
          varying vec3 vWorldDir;

          const mat2 mRot = mat2(0.80, 0.60, -0.60, 0.80);

          vec2 hash22(vec2 p) {
            p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)));
            return -1.0 + 2.0 * fract(sin(p) * 43758.5453123);
          }

          float hash21(vec2 p) {
            p = fract(p * vec2(127.1, 311.7));
            p += dot(p, p + 34.53);
            return fract(p.x * p.y);
          }

          float snoise(vec2 p) {
            const float K1 = 0.366025404;
            const float K2 = 0.211324865;
            vec2 i = floor(p + (p.x + p.y) * K1);
            vec2 a = p - i + (i.x + i.y) * K2;
            vec2 o = (a.x > a.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
            vec2 b = a - o + K2;
            vec2 c = a - 1.0 + 2.0 * K2;
            vec3 h = max(0.5 - vec3(dot(a, a), dot(b, b), dot(c, c)), 0.0);
            vec3 n = h * h * h * h * vec3(dot(a, hash22(i)), dot(b, hash22(i + o)), dot(c, hash22(i + 1.0)));
            return dot(n, vec3(70.0));
          }

          float fbm4(vec2 p) {
            float v = 0.0, a = 0.50;
            for (int i = 0; i < 4; i++) {
              v += a * (snoise(p) * 0.5 + 0.5);
              p = mRot * p * 2.06 + vec2(11.3, 7.1);
              a *= 0.50;
            }
            return v;
          }

          float fbm3(vec2 p) {
            float v = 0.0, a = 0.52;
            for (int i = 0; i < 3; i++) {
              v += a * (snoise(p) * 0.5 + 0.5);
              p = mRot * p * 2.08 + vec2(11.3, 7.1);
              a *= 0.48;
            }
            return v;
          }

          // Smooth rounded cauliflower Worley domes (zero sharp ridges!)
          float worleyDome(vec2 p) {
            vec2 i = floor(p), f = fract(p);
            float md = 1.0;
            for (int y = -1; y <= 1; y++) {
              for (int x = -1; x <= 1; x++) {
                vec2 nb = vec2(float(x), float(y));
                vec2 rnd = vec2(hash21(i + nb), hash21(i + nb + vec2(37.2, 91.7)));
                vec2 diff = nb + 0.16 + 0.68 * rnd - f;
                md = min(md, dot(diff, diff));
              }
            }
            return clamp(1.0 - sqrt(md) * 1.12, 0.0, 1.0);
          }

          // 360-degree Seamless Cauliflower Cumulus Band (dual-window blend: ZERO atan seam, ZERO diagonal stretch!)
          vec3 evalCumulusBandAtU(float u, float el, float t, float baseEl, float seed, float maxH) {
            float baseWave = (fbm3(vec2(u * 0.95 + seed * 1.9, seed * 3.3)) - 0.5) * 0.085;
            float localBase = baseEl + baseWave;
            float bank = fbm3(vec2(u * 0.36 + seed * 3.1, (el - localBase) * 1.4 + seed * 2.7));
            float bankGate = smoothstep(0.46 - uCloudCoverage * 0.34, 0.70 - uCloudCoverage * 0.28, bank);

            float vNorm = clamp((el - localBase) / maxH, 0.0, 1.2);
            float botEnv = smoothstep(localBase - 0.032, localBase + 0.062, el);
            float topEnv = 1.0 - smoothstep(0.25, 1.05, vNorm);

            vec2 domeUv = vec2(u * 1.65, (el - localBase) * (6.8 / maxH * 0.32) + seed * 1.7);
            float w1 = worleyDome(domeUv);
            float w2 = worleyDome(domeUv * 2.15 + vec2(3.1, 1.7));
            float f1 = fbm3(domeUv * 1.65 + vec2(t * 0.16, 0.0));
            float fEdge = fbm3(domeUv * 3.9 - vec2(t * 0.22, 0.0));

            float puffs = w1 * 0.46 + w2 * 0.30 + f1 * 0.24;
            float taper = 1.0 - smoothstep(0.15, 0.95, vNorm) * 0.42;
            float edgeFade = 1.0 - smoothstep(0.28, 0.65, puffs);
            float density = botEnv * topEnv * bankGate * taper * (0.42 + 0.88 * puffs) - (1.0 - fEdge) * 0.14 * edgeFade;
            float edgeSoft = mix(0.24, 0.11, uCloudCrispness);
            float mask = smoothstep(0.20, 0.20 + edgeSoft, density) * (0.55 + 0.35 * smoothstep(0.20, 0.68, density));
            return vec3(mask, max(density, 0.0), clamp(vNorm, 0.0, 1.0));
          }

          vec3 evalCumulusBand(float az, float el, float t, float baseEl, float azFreq, float seed, float maxH) {
            float sc = azFreq * uCloudScale;
            float drift = t * (0.5 + seed * 0.1);
            // Window A has its seam at +-PI (weight = 0 at +-PI, 1 at 0)
            float uA = az * sc + drift;
            // Window B is shifted by PI via periodic sin/cos wrap: continuous at +-PI, seam only at 0 where blend=0!
            float azB = atan(sin(az + 3.14159265), cos(az + 3.14159265));
            float uB = azB * sc + drift + 17.3;
            float blend = 0.5 - 0.5 * cos(az);
            vec3 a = evalCumulusBandAtU(uA, el, t, baseEl, seed, maxH);
            vec3 b = evalCumulusBandAtU(uB, el, t, baseEl, seed + 2.3, maxH);
            return mix(a, b, blend);
          }

          float hgPhase(float cosTheta, float g) {
            float g2 = g * g;
            return (1.0 - g2) / (4.0 * 3.14159 * pow(max(0.08, 1.0 + g2 - 2.0 * g * cosTheta), 1.5));
          }

          vec4 shadeCumulusBand(vec3 d, float az, float el, float t, vec3 sunD, float sunDot, float sunVis, float baseEl, float azFreq, float seed, float maxH) {
            vec3 c0 = evalCumulusBand(az, el, t, baseEl, azFreq, seed, maxH);
            float mask = c0.x;
            if (mask < 0.005) return vec4(0.0);
            float den = c0.y;
            float vNorm = c0.z;

            float dAz = evalCumulusBandAtU(az * azFreq * uCloudScale + t * (0.5 + seed * 0.1) + 0.045, el, t, baseEl, seed, maxH).y;
            float dEl = evalCumulusBandAtU(az * azFreq * uCloudScale + t * (0.5 + seed * 0.1), el + 0.012, t, baseEl, seed, maxH).y;
            vec3 cRight = normalize(vec3(-d.z, 0.0, d.x) + vec3(1e-4));
            vec3 cUp = vec3(0.0, 1.0, 0.0);
            vec3 cNorm = normalize(mix(-d, cUp, 0.48) + cRight * ((den - dAz) * 1.85) + cUp * ((den - dEl) * 1.85));

            float ndl = clamp(dot(cNorm, sunD) * 0.58 + 0.42, 0.0, 1.0);
            float heightLit = smoothstep(0.04, 0.65, vNorm);
            float sunAlt = 0.68 + 0.32 * smoothstep(-0.05, 0.35, sunD.y);
            float lit = clamp((ndl * 0.55 + heightLit * 0.45) * sunAlt, 0.0, 0.94);

            float rimFactor = 1.0 - smoothstep(0.24, 0.55, den);
            float silver = hgPhase(sunDot, 0.72) * uCloudSilver * (0.35 + 0.65 * rimFactor) * sunVis;
            vec3 ambBase = mix(uCloudShadowCol * 0.82, uHorizonColor * 0.62, 0.18);
            vec3 litTop  = uCloudLightCol * 0.90 + uSunColor * min(silver * 0.50, 0.60);
            vec3 cumCol  = mix(ambBase, litTop, smoothstep(0.14, 0.82, lit));

            float horizFade = smoothstep(0.02, 0.13, d.y);
            cumCol = mix(uHorizonColor * 0.94, cumCol, 0.35 + 0.65 * horizFade);
            return vec4(cumCol, clamp(mask * horizFade * uCloudDensity * 0.86, 0.0, 0.90));
          }



          void main() {
            vec3 d = normalize(vWorldDir);
            vec3 sunD = normalize(uSunDir);
            float sunDot = max(dot(d, sunD), 0.0);
            float nightFactor = smoothstep(0.12, -0.15, sunD.y);

            if (d.y >= 0.0) {
              // 1. Clean Atmospheric Rayleigh Sky Gradient
              float h = pow(clamp(d.y, 0.0, 1.0), 0.48);
              vec3 midSky = mix(uHorizonColor, uZenithColor, 0.56);
              vec3 sky = mix(uHorizonColor, mix(midSky, uZenithColor, h), clamp(d.y * 1.65, 0.0, 1.0));

              float sunVis = smoothstep(-0.08, 0.05, sunD.y);
              vec3 sunGlow = uSunColor * pow(sunDot, 7.0) * 0.12 * sunVis
                           + uSunColor * pow(sunDot, 56.0) * 0.22 * sunVis;
              vec3 sunDisc = uSunColor * 1.12 * smoothstep(0.9985, 0.9996, sunDot) * sunVis;

              // Night stars
              if (nightFactor > 0.02 && uStarIntensity > 0.01 && d.y > 0.05) {
                vec2 starUv = d.xz / (d.y + 0.35) * 155.0;
                vec2 sId = floor(starUv);
                vec2 sFr = fract(starUv) - 0.5;
                float sRnd = hash21(sId);
                if (sRnd > 0.968) {
                  float twinkle = 0.65 + 0.35 * sin(uTime * 3.2 + sRnd * 90.0);
                  float starMask = smoothstep(0.32, 0.0, length(sFr)) * nightFactor * uStarIntensity * twinkle;
                  sky += vec3(0.85, 0.92, 1.0) * starMask * 1.4;
                }
              }

              if (d.y > 0.01 && uCloudDensity > 0.005) {
                float t = uTime * uCloudSpeed;

                // Subtle high-altitude wispy cirrus in upper sky
                if (d.y > 0.14) {
                  vec2 cirUv = (d.xz / (d.y + 0.45)) * (uCloudScale * 1.4) + uWindDir * (t * 0.5);
                  float cir = fbm4(cirUv * vec2(0.8, 2.4));
                  float cirMask = smoothstep(0.58, 0.80, cir) * 0.22 * smoothstep(0.14, 0.35, d.y);
                  sky = mix(sky, mix(uCloudShadowCol * 1.15, uCloudLightCol, 0.85), cirMask * uCloudDensity);
                }

                // Two independently shaded & composited Cumulus Bands (zero white seam lines!)
                float az = atan(d.x, -d.z);
                vec4 farC  = shadeCumulusBand(d, az, d.y, t * 0.75, sunD, sunDot, sunVis, 0.14, 1.95, 1.2, 0.28);
                vec4 nearC = shadeCumulusBand(d, az, d.y, t * 1.05, sunD, sunDot, sunVis, 0.21, 1.25, 4.7, 0.40);

                float totalOcc = clamp(farC.a + nearC.a * (1.0 - farC.a), 0.0, 1.0);
                sky += (sunGlow + sunDisc) * (1.0 - totalOcc * 0.90);
                sky = mix(sky, farC.rgb, farC.a);
                sky = mix(sky, nearC.rgb, nearC.a);
              } else {
                sky += sunGlow + sunDisc;
              }

              gl_FragColor = vec4(sky, 1.0);
            } else {
              float gd = clamp(-d.y * 5.5, 0.0, 1.0);
              vec3 nearGround = uOceanHorizon > 0.5 ? vec3(0.03, 0.14, 0.24) : vec3(0.16, 0.14, 0.14);
              vec3 farGround  = uOceanHorizon > 0.5 ? uHorizonColor * 0.92 : uHorizonColor * 0.82;
              gl_FragColor = vec4(mix(farGround, nearGround, pow(gd, 0.55)), 1.0);
            }
          }
        `,
        side: THREE.BackSide,
        depthWrite: false,
        depthTest: true
      });
      const skyDome = new THREE.Mesh(skyGeo, skyMat);
      skyDome.renderOrder = 500;
      skyDome.frustumCulled = false;
      skyDome.userData._isHelper = true;
      this.skyDomeMesh = skyDome;
      this.rootContainer.add(skyDome);
    } else {
      this.skyDomeMesh = null;
    }

    const spawnCloudDeck = (opts = {}) => {
      if (this.cloudImpostorGroup && this.cloudImpostorGroup.parent) {
        this.cloudImpostorGroup.parent.remove(this.cloudImpostorGroup);
      }
      return null;
    };

    // Modifiable `Triad.sky` API (zero hardcoded locks!)
    const skyAPI = {
      get uniforms() { return this.skyUniforms; },
      setSun: (elevationDeg, azimuthDeg) => {
        const el = THREE.MathUtils.degToRad(elevationDeg);
        const az = THREE.MathUtils.degToRad(azimuthDeg);
        const dir = new THREE.Vector3(Math.cos(el) * Math.sin(az), Math.sin(el), Math.cos(el) * Math.cos(az)).normalize();
        if (this.skyUniforms) this.skyUniforms.uSunDir.value.copy(dir);
        let dl = null;
        this.threeScene.traverse(o => { if (o.isDirectionalLight && !dl) dl = o; });
        if (dl) dl.position.copy(dir).multiplyScalar(45);
        return dir;
      },
      setTimeOfDay: (hour = 17.5) => {
        const h = ((hour % 24) + 24) % 24;
        const elev = Math.sin(((h - 6) / 12) * Math.PI) * 68;
        const azim = (h - 6) * 15;
        skyAPI.setSun(elev, azim);
        if (!this.skyUniforms) return;
        if (h >= 5.5 && h < 8.5) {
          this.skyUniforms.uZenithColor.value.set('#22457a');
          this.skyUniforms.uHorizonColor.value.set('#f4a27e');
          this.skyUniforms.uSunColor.value.set('#ffd29d');
          this.skyUniforms.uCloudLightCol.value.set('#ffdfc2');
          this.skyUniforms.uCloudShadowCol.value.set('#5a6382');
        } else if (h >= 8.5 && h < 16.5) {
          this.skyUniforms.uZenithColor.value.set('#1e5aa8');
          this.skyUniforms.uHorizonColor.value.set('#8dc2eb');
          this.skyUniforms.uSunColor.value.set('#fff9ed');
          this.skyUniforms.uCloudLightCol.value.set('#f7f5f0');
          this.skyUniforms.uCloudShadowCol.value.set('#536885');
        } else if (h >= 16.5 && h < 19.8) {
          this.skyUniforms.uZenithColor.value.set('#1a2e5a');
          this.skyUniforms.uHorizonColor.value.set('#f28c52');
          this.skyUniforms.uSunColor.value.set('#ffb86c');
          this.skyUniforms.uCloudLightCol.value.set('#ffd8b0');
          this.skyUniforms.uCloudShadowCol.value.set('#4c4766');
        } else {
          this.skyUniforms.uZenithColor.value.set('#050914');
          this.skyUniforms.uHorizonColor.value.set('#111d33');
          this.skyUniforms.uSunColor.value.set('#93c5fd');
          this.skyUniforms.uCloudLightCol.value.set('#475e80');
          this.skyUniforms.uCloudShadowCol.value.set('#131b2b');
        }
        if (this.threeScene.fog) this.threeScene.fog.color.copy(this.skyUniforms.uHorizonColor.value);
        if (this.wetReflectors) this.wetReflectors.forEach(r => { if (r.uniforms && r.uniforms.uFogColor) r.uniforms.uFogColor.value.copy(this.skyUniforms.uHorizonColor.value); });
        this.threeScene.background.copy(this.skyUniforms.uZenithColor.value);
      },
      setClouds: (opts = {}) => {
        if (!this.skyUniforms) return;
        if (opts.density !== undefined) this.skyUniforms.uCloudDensity.value = opts.density;
        if (opts.coverage !== undefined) this.skyUniforms.uCloudCoverage.value = opts.coverage;
        if (opts.speed !== undefined) this.skyUniforms.uCloudSpeed.value = opts.speed;
        if (opts.scale !== undefined) this.skyUniforms.uCloudScale.value = opts.scale;
        if (opts.puffiness !== undefined) this.skyUniforms.uCloudPuffiness.value = opts.puffiness;
        if (opts.silverLining !== undefined) this.skyUniforms.uCloudSilver.value = opts.silverLining;
        if (opts.shadow !== undefined) this.skyUniforms.uCloudShadow.value = opts.shadow;
        if (opts.detail !== undefined) this.skyUniforms.uCloudDetail.value = opts.detail;
        if (opts.erosion !== undefined) this.skyUniforms.uCloudErosion.value = opts.erosion;
        if (opts.crispness !== undefined) this.skyUniforms.uCloudCrispness.value = opts.crispness;
        if (opts.lightColor) this.skyUniforms.uCloudLightCol.value.set(opts.lightColor);
        if (opts.shadowColor) this.skyUniforms.uCloudShadowCol.value.set(opts.shadowColor);
        if (opts.wind) this.skyUniforms.uWindDir.value.set(opts.wind[0], opts.wind[1]).normalize();
      },
      setColors: (opts = {}) => {
        if (!this.skyUniforms) return;
        if (opts.zenith) { this.skyUniforms.uZenithColor.value.set(opts.zenith); this.threeScene.background.set(opts.zenith); }
        if (opts.horizon) { this.skyUniforms.uHorizonColor.value.set(opts.horizon); if (this.threeScene.fog) this.threeScene.fog.color.set(opts.horizon); }
        if (opts.sun) this.skyUniforms.uSunColor.value.set(opts.sun);
        if (opts.stars !== undefined) this.skyUniforms.uStarIntensity.value = opts.stars;
      },
      spawnCloudDeck
    };
    TriadAPI.sky = skyAPI;
    this.skyAPI = skyAPI;

    if (sa['time-of-day'] !== undefined) {
      skyAPI.setTimeOfDay(parseFloat(sa['time-of-day']));
    }
    if (sa['cloud-puffs'] === 'true' || sa['cloud-mode'] === 'impostor') {
      spawnCloudDeck({ count: parseInt(sa['cloud-puff-count'] || 180, 10) });
    }

    // Upgrade TriadAPI.registerGenerator so if called during script pass, it updates any <mesh generator="..."> nodes live!
    TriadAPI.registerGenerator = (name, fn) => {
      this.customGenerators.set(name, fn);
      for (const node of this.allNodes) {
        if (node.tagName === 'mesh' && (node.attributes.generator || 'box') === name) {
          this.rebuildNodeGeometryAndTransform(node);
        }
      }
    };
    TriadAPI.help = (topic) => (typeof printTriadHelp === 'function' ? printTriadHelp(topic) : '');

    // Configure <scene bake-screen="...">
    this.bakeConfig = {
      enabled: sa['bake-screen'] === 'true' || sa['bake-screen'] === 'on' || (this.viewer && this.viewer.options && this.viewer.options.bakeScreen === true),
      title: sa['bake-title'] || 'TRIAD3D v9.5 · SCENE & TEXTURE BAKE PIPELINE',
      subtitle: sa['bake-subtitle'] || 'Resampling Uploaded Textures, Merging Batches, Freezing Matrices & Streaming Chunks...',
      hold: sa['bake-hold'] === 'true'
    };

    // Build Three.js Object3D tree
    const batchNodes = [];
    const autoInstNodes = [];
    const freezeNodes = [];
    const buildTree = (node, parentObj3D) => {
      if (node.tagName === 'modifier') return;
      if (node.parent && node.parent.tagName === 'csg') return;
      if (node.tagName === 'bake-screen') {
        this.bakeConfig.enabled = node.attributes.enabled !== 'false';
        if (node.attributes.title) this.bakeConfig.title = node.attributes.title;
        if (node.attributes.subtitle) this.bakeConfig.subtitle = node.attributes.subtitle;
        if (node.attributes.hold === 'true') this.bakeConfig.hold = true;
        return;
      }
      if (node.tagName === 'chunk') {
        node._sceneRef = this;
        this.allNodes.push(node);
        this.uidMap.set(node.uid, node);
        if (node.id) this.idMap.set(node.id, node);
        this.chunks.registerDeclarativeChunk(node, parentObj3D, vfsFiles);
        return;
      }

      node._sceneRef = this;
      this.allNodes.push(node);
      this.uidMap.set(node.uid, node);
      if (node.id) this.idMap.set(node.id, node);

      this._instantiateNodeObject(node);
      if (node.object3D && parentObj3D) parentObj3D.add(node.object3D);

      if (node.tagName === 'lod' && node.object3D) {
        const dStr = node.attributes.distances || node.attributes['lod-distances'] || '20 50';
        node.object3D.userData._lodDistances = dStr.trim().split(/[\s,]+/).map(Number).filter(n => !isNaN(n) && n > 0);
        this.optStats.lodGroups++;
      }

      const a = node.attributes || {};
      const isOptTag = node.tagName === 'optimize' || node.tagName === 'batch' || node.tagName === 'scene' || node.tagName === 'group';
      if (node.tagName === 'batch' || a.batch === 'true' || a['merge-meshes'] === 'true' || (a.optimize && /merge|batch/.test(a.optimize))) {
        batchNodes.push(node);
      }
      if (a['auto-instance'] === 'true' || (a.optimize && /instance/.test(a.optimize))) {
        autoInstNodes.push(node);
      }
      if (a['freeze-matrices'] === 'true' || (isOptTag && a.optimize && /freeze/.test(a.optimize))) {
        freezeNodes.push(node);
      }

      if (node.tagName === 'radial-layout') {
        const count = Math.max(1, parseInt(node.attributes.count || 6, 10));
        const radius = parseFloat(node.attributes.radius || 2.0);
        const alignTangent = node.attributes['align-tangent'] !== 'false';
        const templateChildren = [...node.children];
        node.children = [];
        for (let k = 0; k < count; k++) {
          const angle = (k / count) * Math.PI * 2;
          const x = Math.cos(angle) * radius;
          const z = Math.sin(angle) * radius;
          const rotY = alignTangent ? THREE.MathUtils.radToDeg(-angle) : 0;
          for (const tmpl of templateChildren) {
            const clone = this._cloneNodeDeep(tmpl, `${k}`);
            clone.attributes.pos = `${x.toFixed(3)} ${parseVec3Attr(tmpl.attributes.pos).y} ${z.toFixed(3)}`;
            const baseR = parseVec3Attr(tmpl.attributes.rot);
            clone.attributes.rot = `${baseR.x} ${(baseR.y + rotY).toFixed(1)} ${baseR.z}`;
            node.children.push(clone);
            clone.parent = node;
            buildTree(clone, node.object3D);
          }
        }
        return;
      }

      for (const ch of node.children) buildTree(ch, node.object3D);
      this._applyLayoutContainer(node);
    };

    buildTree(this.smlRoot, this.rootContainer);
    this.refreshStyles();

    // Count raw meshes before scoped/scene optimizations
    let rawMeshCount = 0;
    this.rootContainer.traverse(o => { if (o.isMesh && !o.userData._isHelper) rawMeshCount++; });
    this.optStats.drawsBeforeOpt = rawMeshCount;

    // 1. Hardware Auto-Instancing on scoped groups or scene
    for (const iNode of autoInstNodes) {
      this._applyAutoInstancing(iNode);
    }

    // 2. Auto-merge static child meshes inside <batch> / <optimize merge-meshes="true"> containers
    for (const bNode of batchNodes) {
      this._mergeBatchContainer(bNode);
    }

    // 3. Freeze static world matrices on <optimize freeze-matrices="true"> containers
    for (const fNode of freezeNodes) {
      if (fNode.object3D) this._freezeSubtreeMatrices(fNode.object3D);
    }

    let optMeshCount = 0;
    this.rootContainer.traverse(o => { if (o.isMesh && !o.userData._isHelper) optMeshCount++; });
    this.optStats.drawsAfterOpt = optMeshCount;

    this.physics.extractDeclarativeCollidersFromSML(this.allNodes, this.smlRoot);
    if (this.agents) this.agents.navMesh.bakeFromPhysics(this.physics);

    // Execute 3JS behavior & build `Triad.gui` controls with full stack trace reporting (NO silent catch!)
    this.tickCallbacks = [];
    const customConsole = {
      log: (...args) => logConsole(args.map(formatReplVal).join(' '), 'info'),
      warn: (...args) => logConsole(args.map(formatReplVal).join(' '), 'warn'),
      error: (...args) => logConsole(args.map(formatReplVal).join(' '), 'err')
    };

    for (const node of this.allNodes) {
      const a = node.attributes || {};
      if (a.oninit) {
        try {
          const fn = new Function('node', 'scene', 'Triad', 'THREE', 'console', a.oninit);
          fn.call(node, node, this, TriadAPI, THREE, customConsole);
        } catch (err) {
          formatScriptError(err, a.oninit, `Inline oninit on <${node.getSelectorLabel()}>`);
        }
      }
      const tickCode = a.onupdate || a.ontick;
      if (tickCode) {
        try {
          const fn = new Function('dt', 'time', 'node', 'scene', 'Triad', 'THREE', 'console', tickCode);
          this.tickCallbacks.push((dt, time) => {
            fn.call(node, dt, time, node, this, TriadAPI, THREE, customConsole);
          });
        } catch (err) {
          formatScriptError(err, tickCode, `Inline onupdate on <${node.getSelectorLabel()}>`);
        }
      }
      if (a.onclick) {
        try {
          const fn = new Function('event', 'node', 'scene', 'Triad', 'THREE', 'console', a.onclick);
          node.addEventListener('click', (ev) => {
            fn.call(node, ev, node, this, TriadAPI, THREE, customConsole);
          });
        } catch (err) {
          formatScriptError(err, a.onclick, `Inline onclick on <${node.getSelectorLabel()}>`);
        }
      }
      if (a.onhover) {
        try {
          const fn = new Function('event', 'node', 'scene', 'Triad', 'THREE', 'console', a.onhover);
          node.addEventListener('hover', (ev) => {
            fn.call(node, ev, node, this, TriadAPI, THREE, customConsole);
          });
        } catch (err) {
          formatScriptError(err, a.onhover, `Inline onhover on <${node.getSelectorLabel()}>`);
        }
      }
    }

    if (combinedJs.trim()) {
      try {
        const runFn = new Function('scene', 'Triad', 'THREE', 'console', combinedJs);
        runFn(this, TriadAPI, THREE, customConsole);
      } catch (err) {
        formatScriptError(err, combinedJs, 'Script Execution Error');
      }
    }

    const guiPanel = this.guiPanelEl !== undefined ? this.guiPanelEl : (typeof document !== 'undefined' ? document.getElementById('triad-gui-panel') : null); if (guiPanel) guiPanel.style.display = activeGuiLabels.size > 0 ? 'block' : 'none';
    this.renderer.shadowMap.needsUpdate = true;
    const elapsed = (performance.now() - t0).toFixed(1);
    return { elapsed, nodeCount: this.allNodes.length, ruleCount: this.styleSheet.rules.length };
  }

  _cloneNodeDeep(node, suffix) {
    const c = new SMLNode(node.tagName, { ...node.attributes }, node.sourceLine, node.sourceFile);
    if (c.attributes.id) c.attributes.id = `${c.attributes.id}-${suffix}`;
    for (const ch of node.children) {
      const cc = this._cloneNodeDeep(ch, suffix);
      cc.parent = c;
      c.children.push(cc);
    }
    return c;
  }

  _instantiateNodeObject(node) {
    const tag = node.tagName;
    const a = node.attributes;
    let obj = null;

    if (tag === 'clouds' || tag === 'cloud-deck') {
      obj = this.skyAPI ? this.skyAPI.spawnCloudDeck({
        count: parseInt(a.count || 140, 10),
        altitude: parseFloat(a.altitude || 52),
        spread: parseFloat(a.spread || 190),
        scale: parseFloat(a.scale || 16),
        opacity: parseFloat(a.opacity || 0.82)
      }) : new THREE.Group();
    } else if (tag === 'clouds' || tag === 'cloud-deck') {
      obj = this.skyAPI ? this.skyAPI.spawnCloudDeck({
        count: parseInt(a.count || 140, 10),
        altitude: parseFloat(a.altitude || 52),
        spread: parseFloat(a.spread || 190),
        scale: parseFloat(a.scale || 16),
        opacity: parseFloat(a.opacity || 0.82)
      }) : new THREE.Group();
    } else if (tag === 'navmesh') {
      obj = new THREE.Group();
      const bMin = (a.min || '-40 -40').trim().split(/[\s,]+/).map(Number);
      const bMax = (a.max || '40 40').trim().split(/[\s,]+/).map(Number);
      this.agents.configureNavMesh([bMin[0] || -40, bMin[1] || -40], [bMax[0] || 40, bMax[1] || 40], parseFloat(a['cell-size'] || 1.5));
    } else if (tag === 'agent') {
      obj = new THREE.Group();
      if (node.children.length === 0) {
        const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.32, 1.0, 6, 12), new THREE.MeshStandardMaterial({ color: a.color || '#38bdf8', roughness: 0.45 }));
        body.position.y = 0.85; body.castShadow = true;
        obj.add(body);
      }
      const wps = a.waypoints ? a.waypoints.split(';').map(s => parseVec3Attr(s.trim())) : [];
      this.agents.addAgent(obj, {
        id: a.id || undefined,
        behavior: a.behavior || 'patrol',
        speed: parseFloat(a.speed || 2.8),
        radius: parseFloat(a.radius || 0.45),
        waypoints: wps,
        wanderRadius: parseFloat(a['wander-radius'] || 8.0)
      });
    } else if (['scene', 'group', 'optimize', 'lod', 'batch', 'stack', 'grid-layout', 'radial-layout', 'mirror', 'collider', 'collision-marker', 'collision'].includes(tag)) {
      obj = new THREE.Group();
    } else if (['particles', 'weather', 'rain', 'mist', 'snow'].includes(tag)) {
      obj = this._createDeclarativeParticleSystem(node);
    } else if (tag === 'light' || tag === 'directional-light' || tag === 'point-light' || tag === 'spot-light' || tag === 'hemisphere-light' || tag === 'ambient-light') {
      const lType = tag.endsWith('-light') ? tag.replace('-light', '') : (a.type || 'directional').toLowerCase();
      const col = a.color || '#ffffff';
      const intensity = parseFloat(a.intensity !== undefined ? a.intensity : 1.5);
      if (lType === 'hemisphere') {
        obj = new THREE.HemisphereLight(col, a['ground-color'] || '#1e293b', intensity);
      } else if (lType === 'ambient') {
        obj = new THREE.AmbientLight(col, intensity);
      } else if (lType === 'point') {
        obj = new THREE.PointLight(col, intensity, parseFloat(a.distance || a.range || 20), parseFloat(a.decay || 2));
        obj.castShadow = a["cast-shadow"] === "true";
      } else if (lType === 'spot') {
        const rawAngle = parseFloat(a.angle !== undefined ? a.angle : 40);
        const angleRad = rawAngle > Math.PI ? THREE.MathUtils.degToRad(rawAngle) : rawAngle;
        const penumbra = parseFloat(a.penumbra !== undefined ? a.penumbra : 0.3);
        const dist = parseFloat(a.distance || a.range || 35);
        obj = new THREE.SpotLight(col, intensity, dist, angleRad, penumbra, parseFloat(a.decay || 2));
        obj.castShadow = a["cast-shadow"] !== "false";
        if (a.target) {
          obj.target.position.copy(parseVec3Attr(a.target, 0, 0, 0));
        } else if (a.dir || a.direction) {
          const p = parseVec3Attr(a.pos, 0, 0, 0);
          const d = parseVec3Attr(a.dir || a.direction, 0, -1, 0);
          obj.target.position.copy(p).add(d);
        }
      } else {
        obj = new THREE.DirectionalLight(col, intensity);
        obj.castShadow = a['cast-shadow'] !== 'false';
        obj.target.position.copy(parseVec3Attr(a.target, 0, 0, 0));
        const camRange = parseFloat(a['shadow-range'] || 14);
        obj.shadow.camera = new THREE.OrthographicCamera(-camRange, camRange, camRange, -camRange, 0.5, 80);
        obj.shadow.mapSize.set(2048, 2048);
      }
    } else if (tag === 'gltf' || tag === 'glb' || tag === 'model' || tag === 'obj') {
      obj = new THREE.Group();
      const srcUrl = a.src || a.url || '';
      if (srcUrl) {
        const onLoaded = (rootObj) => {
          if (!rootObj) return;
          rootObj.traverse(o => { if (o.isMesh) { o.castShadow = a['cast-shadow'] !== 'false'; o.receiveShadow = a['receive-shadow'] !== 'false'; } });
          obj.add(rootObj);
          this.renderer.shadowMap.needsUpdate = true;
          if (this.viewer) this.viewer.renderFrame();
        };
        if (tag === 'obj' || /\.obj$/i.test(srcUrl)) {
          new THREE.OBJLoader().load(srcUrl, onLoaded);
        } else {
          new THREE.GLTFLoader().load(srcUrl, onLoaded);
        }
      }
    } else if (tag === 'camera') {
      obj = new THREE.PerspectiveCamera(parseFloat(a.fov || 45), 1.6, parseFloat(a.near || 0.1), parseFloat(a.far || 1500));
      obj.userData._smlTarget = a.target ? parseVec3Attr(a.target, 0, 0, 0) : null;
      if (!this.activeCameraNode || a.active === 'true' || a.main === 'true') {
        this.activeCameraNode = node;
      }
    } else {
      const geo = buildGeometryForSMLNode(node, this.customGenerators);
      const reflAttr = a.reflection || (node.computedStyle && node.computedStyle.reflection);
      if (geo && reflAttr && reflAttr !== 'false' && reflAttr !== 'none' && reflAttr !== '0') {
        const reflMode = (reflAttr === 'true' || reflAttr === '1') ? 'mirror' : reflAttr;
        const cs = node.computedStyle || {};
        const rAmt = parseFloat(a['reflection-amount'] !== undefined ? a['reflection-amount'] : (cs['reflection-amount'] || 0.88));
        const rTint = a['reflection-tint'] || cs['reflection-tint'] || (reflMode === 'water' ? '#bfe6ff' : '#ffffff');
        const rDist = parseFloat(a['reflection-distortion'] !== undefined ? a['reflection-distortion'] : (cs['reflection-distortion'] || (reflMode === 'water' ? 0.024 : 0.0)));
        const rSpd = parseFloat(a['reflection-speed'] !== undefined ? a['reflection-speed'] : (cs['reflection-speed'] || 1.0));
        const rBase = a.color || cs.color || (reflMode === 'water' ? '#0c2f47' : '#1e293b');
        const pPos = parseVec3Attr(a.pos, 0, 0, 0);
        const refl = new THREE.WetFloorReflector(10, 10, {
          mode: reflMode,
          planeY: pPos.y,
          reflectivity: rAmt,
          tint: rTint,
          baseColor: rBase,
          distortion: rDist,
          speed: rSpd,
          customGeometry: geo,
          fogColor: this.threeScene.fog ? '#' + this.threeScene.fog.color.getHexString() : '#8dc2eb',
          fogNear: this.threeScene.fog ? this.threeScene.fog.near : 75,
          fogFar: this.threeScene.fog ? this.threeScene.fog.far : 260,
          textureWidth: 512, textureHeight: 512
        });
        this.wetReflectors.push(refl);
        obj = refl.mesh;
        obj.userData._isTagReflector = true;
      } else if (geo) {
        const mat = new THREE.MeshPhysicalMaterial({ color: 0x94a3b8, roughness: 0.4, metalness: 0.2 });
        obj = new THREE.Mesh(geo, mat);
        obj.castShadow = a['cast-shadow'] !== 'false';
        obj.receiveShadow = a['receive-shadow'] !== 'false';
      } else {
        const knownContainers = new Set(['scene','group','g','repeat','array','component','def','template','chunk','optimize','lod','navmesh','style','script','import','link','bake-screen','use']);
        if (!knownContainers.has(tag)) {
          const msg = `[Triad3D] Unknown SML tag <${tag}> (line ${node.sourceLine || 1}). Created empty Group.`;
          console.warn(msg);
          if (!this.warnings) this.warnings = [];
          this.warnings.push(msg);
        }
        obj = new THREE.Group();
      }
    }

    const pos = parseVec3Attr(a.pos, 0, 0, 0);
    const rot = parseVec3Attr(a.rot, 0, 0, 0);
    const scl = parseVec3Attr(a.scale, 1, 1, 1);
    node._basePos.copy(pos);
    node._baseRot.copy(rot);
    node._baseScale.copy(scl);

    obj.position.copy(pos);
    obj.rotation.set(THREE.MathUtils.degToRad(rot.x), THREE.MathUtils.degToRad(rot.y), THREE.MathUtils.degToRad(rot.z));
    obj.scale.copy(scl);
    if (node.id) obj.name = node.id;
    else if (a.name) obj.name = a.name;
    obj.userData._smlNode = node;
    node.object3D = obj;
  }


  _createDeclarativeParticleSystem(node) {
    const a = node.attributes || {};
    const pType = (a.type || (node.tagName !== 'particles' && node.tagName !== 'weather' ? node.tagName : 'rain')).toLowerCase();
    const count = Math.max(10, Math.min(25000, parseInt(a.count || (pType === 'mist' ? 600 : 1800), 10)));
    const area = parseVec3Attr(a.area || (a.size && a.size.includes(' ') ? a.size : '60 28 60'), 60, 28, 60);
    const speed = parseFloat(a.speed !== undefined ? a.speed : (pType === 'rain' ? 16.0 : (pType === 'snow' ? 2.4 : 0.8)));
    const ptSize = parseFloat(a['point-size'] || (a.size && !a.size.includes(' ') ? a.size : (pType === 'mist' ? 4.5 : (pType === 'rain' ? 0.24 : 0.35))));
    const color = new THREE.Color(a.color || (pType === 'sparks' ? '#ff9838' : (pType === 'fireflies' ? '#a3e635' : '#b8d4ff')));
    const opacity = parseFloat(a.opacity !== undefined ? a.opacity : (pType === 'mist' ? 0.22 : 0.62));
    const wind = parseVec3Attr(a.wind || '0 0 0', 0, 0, 0);

    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const phases = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      positions[i * 3]     = (Math.random() - 0.5) * area.x;
      positions[i * 3 + 1] = Math.random() * area.y;
      positions[i * 3 + 2] = (Math.random() - 0.5) * area.z;
      const shade = 0.78 + Math.random() * 0.22;
      colors[i * 3]     = color.r * shade;
      colors[i * 3 + 1] = color.g * shade;
      colors[i * 3 + 2] = color.b * shade;
      phases[i] = Math.random() * Math.PI * 2;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    geo.setAttribute('aPhase', new THREE.Float32BufferAttribute(phases, 1));
    const mat = new THREE.PointsMaterial({
      color: 0xffffff,
      size: ptSize,
      sizeAttenuation: true,
      transparent: true,
      opacity,
      vertexColors: true,
      blending: pType === 'sparks' || pType === 'fireflies' ? THREE.AdditiveBlending : THREE.NormalBlending,
      depthWrite: false
    });
    const pts = new THREE.Points(geo, mat);
    pts.frustumCulled = false;
    this.particleSystems.push({ mesh: pts, geo, pType, count, area, speed, wind, phases });
    return pts;
  }


  _applyAutoInstancing(rootNode) {
    if (!rootNode || !rootNode.object3D) return;
    rootNode.object3D.updateMatrixWorld(true);
    const invRoot = new THREE.Matrix4().copy(rootNode.object3D.matrixWorld).invert();
    const groups = new Map(); // sig -> { geo, mat, meshes: [], matrices: [], colors: [] }

    const visit = (sNode) => {
      if (sNode.object3D && sNode.object3D.isMesh && !sNode.object3D.isInstancedMesh && !sNode._animSpec && !sNode.attributes.onupdate && !sNode.attributes.ontick) {
        const mesh = sNode.object3D;
        const g = mesh.geometry, m = mesh.material;
        if (g && g.attributes && g.attributes.position && m) {
          const gKey = `${sNode.tagName}|${g.attributes.position.count}|${g.index ? g.index.count : 0}`;
          const mKey = `${m.roughness}|${m.metalness}|${m.emissive.getHexString()}|${m.opacity}|${m.map ? (m.map.uuid || 'map') : 'nomap'}`;
          const sig = `${gKey}::${mKey}`;
          if (!groups.has(sig)) {
            groups.set(sig, { geo: g, mat: m, meshes: [], relMats: [], cols: [] });
          }
          const entry = groups.get(sig);
          const relM = new THREE.Matrix4().multiplyMatrices(invRoot, mesh.matrixWorld);
          entry.meshes.push(mesh);
          entry.relMats.push(relM);
          entry.cols.push(m.color.clone());
        }
      }
      for (const ch of sNode.children) visit(ch);
    };
    visit(rootNode);

    for (const [, entry] of groups) {
      if (entry.meshes.length < 2) continue;
      const count = entry.meshes.length;
      const instMat = entry.mat.clone();
      instMat.color.set(0xffffff);
      instMat.vertexColors = true;
      const instMesh = new THREE.InstancedMesh(entry.geo, instMat, count);
      for (let i = 0; i < count; i++) {
        instMesh.setMatrixAt(i, entry.relMats[i]);
        instMesh.setColorAt(i, entry.cols[i]);
        if (entry.meshes[i].parent) entry.meshes[i].parent.remove(entry.meshes[i]);
      }
      instMesh.computeBoundingSphere();
      rootNode.object3D.add(instMesh);
      this.optStats.instancedGroups++;
    }
  }

  _freezeSubtreeMatrices(rootObj3D) {
    if (!rootObj3D) return;
    rootObj3D.updateMatrixWorld(true);
    let frozen = 0;
    rootObj3D.traverse(o => {
      if (o !== this.skyDomeMesh && !o.userData._isHelper) {
        o.matrixAutoUpdate = false;
        frozen++;
      }
    });
    this.optStats.frozenMatrices += frozen;
  }

  _mergeBatchContainer(bNode) {
    if (!bNode || !bNode.object3D) return;
    bNode.object3D.updateMatrixWorld(true);
    const invRoot = new THREE.Matrix4().copy(bNode.object3D.matrixWorld).invert();
    const buckets = new Map();
    const toRemove = [];

    const visit = (sNode) => {
      if (sNode !== bNode && sNode.object3D && sNode.object3D.isMesh && !sNode.object3D.isInstancedMesh && !sNode._animSpec && !sNode.attributes.onupdate && !sNode.attributes.ontick && !sNode.attributes.onclick) {
        const mesh = sNode.object3D;
        const m = mesh.material;
        if (m && mesh.geometry && mesh.geometry.attributes && mesh.geometry.attributes.position) {
          const sig = `${m.color.getHexString()}|${m.roughness}|${m.metalness}|${m.emissive.getHexString()}|${m.emissiveIntensity}|${m.opacity}|${m.transmission||0}|${m.map ? (m.map.uuid || 'map') : 'nomap'}`;
          if (!buckets.has(sig)) buckets.set(sig, { material: m.clone(), geos: [] });
          const gClone = mesh.geometry.clone();
          const relMat = new THREE.Matrix4().multiplyMatrices(invRoot, mesh.matrixWorld);
          gClone.applyMatrix4(relMat);
          if (!gClone.attributes.color) {
            const vc = new Float32Array(gClone.attributes.position.count * 3);
            for (let i = 0; i < vc.length; i += 3) {
              vc[i] = m.color.r; vc[i + 1] = m.color.g; vc[i + 2] = m.color.b;
            }
            gClone.setAttribute('color', new THREE.Float32BufferAttribute(vc, 3));
          }
          buckets.get(sig).geos.push(gClone);
          toRemove.push(mesh);
        }
      }
      for (const ch of sNode.children) visit(ch);
    };
    visit(bNode);

    if (buckets.size === 0) return;
    for (const mesh of toRemove) {
      if (mesh.parent) mesh.parent.remove(mesh);
    }
    for (const [, bucket] of buckets) {
      if (bucket.geos.length === 0) continue;
      const merged = THREE.mergeGeometries(bucket.geos);
      if (merged) {
        const bMat = bucket.material;
        bMat.vertexColors = true;
        bMat.color.set(0xffffff);
        const mergedMesh = new THREE.Mesh(merged, bMat);
        mergedMesh.castShadow = true;
        mergedMesh.receiveShadow = true;
        bNode.object3D.add(mergedMesh);
        this.optStats.mergedGroups++;
      }
    }
  }

  _applyLayoutContainer(node) {
    if (node.tagName === 'stack') {
      const axis = (node.attributes.axis || 'y').toLowerCase();
      const gap = parseFloat(node.attributes.gap || 0.1);
      let cursor = 0;
      for (const ch of node.children) {
        if (!ch.object3D) continue;
        const box = new THREE.Box3().setFromObject(ch.object3D);
        const size = new THREE.Vector3();
        box.getSize(size);
        const dim = axis === 'x' ? size.x : (axis === 'z' ? size.z : size.y);
        ch.object3D.position[axis] = cursor + dim * 0.5;
        ch._basePos.copy(ch.object3D.position);
        cursor += dim + gap;
      }
    } else if (node.tagName === 'grid-layout') {
      const cols = Math.max(1, parseInt(node.attributes.cols || 3, 10));
      const gapParts = (node.attributes.gap || '1.5 1.5').trim().split(/[\s,]+/).map(Number);
      const gx = gapParts[0] || 1.5, gz = gapParts[1] !== undefined ? gapParts[1] : gx;
      const rows = Math.ceil(node.children.length / cols);
      node.children.forEach((ch, idx) => {
        if (!ch.object3D) return;
        const c = idx % cols, r = Math.floor(idx / cols);
        ch.object3D.position.x += (c - (cols - 1) * 0.5) * gx;
        ch.object3D.position.z += (r - (rows - 1) * 0.5) * gz;
        ch._basePos.copy(ch.object3D.position);
      });
    }
  }

  rebuildNodeGeometryAndTransform(node) {
    if (!node || !node.object3D) return;
    const a = node.attributes;
    const pos = parseVec3Attr(a.pos, 0, 0, 0);
    const rot = parseVec3Attr(a.rot, 0, 0, 0);
    const scl = parseVec3Attr(a.scale, 1, 1, 1);
    node._basePos.copy(pos);
    node._baseRot.copy(rot);
    node._baseScale.copy(scl);
    if (node.object3D.isMesh) {
      const newGeo = buildGeometryForSMLNode(node, this.customGenerators);
      if (newGeo) {
        if (node.object3D.geometry) node.object3D.geometry.dispose();
        node.object3D.geometry = newGeo;
      }
    }
    this.applyStyleToNode(node);
    this.renderer.shadowMap.needsUpdate = true;
  }

  refreshStyles() {
    this.animatedNodes = [];
    for (const node of this.allNodes) this.applyStyleToNode(node);
  }

  applyStyleToNode(node) {
    if (!node || !node.object3D) return;
    if (node.object3D.material && node.object3D.material.isShaderMaterial) return;
    const cascade = this.styleSheet.computeCascadeForNode(node);
    node._matchedCascade = cascade;
    const cs = cascade.computed;
    node._computedStyle = cs;

    // Support 3SS 2.0 `anchor: bottom | top | center` (or SML attribute `anchor="bottom"`)
    const anchorMode = (node.attributes.anchor || cs.anchor || '').toLowerCase();
    let anchorOffsetY = 0;
    if (anchorMode === 'bottom' && node.object3D.isMesh && node.object3D.geometry) {
      const g = node.object3D.geometry;
      if (g._minY === undefined) {
        const posAttr = g.attributes.position;
        let minY = Infinity;
        if (posAttr) {
          const arr = posAttr.array;
          for (let i = 1; i < arr.length; i += 3) {
            if (arr[i] < minY) minY = arr[i];
          }
        }
        g._minY = minY;
      }
      if (g._minY !== Infinity) anchorOffsetY = -g._minY * node._baseScale.y;
    }
    node._anchorYOffset = anchorOffsetY;

    const pos = node._basePos.clone();
    pos.y += anchorOffsetY;
    const rot = node._baseRot.clone();
    const scl = node._baseScale.clone();
    if (cs.transform) this._applyTransformString(cs.transform, pos, rot, scl);

    node.object3D.position.copy(pos);
    node.object3D.rotation.set(THREE.MathUtils.degToRad(rot.x), THREE.MathUtils.degToRad(rot.y), THREE.MathUtils.degToRad(rot.z));
    node.object3D.scale.copy(scl);

    if (cs.display === 'none' || cs.visibility === 'hidden') node.object3D.visible = false;

    if (cs.animation) {
      const parts = cs.animation.trim().split(/\s+/);
      const animName = parts[0];
      const durStr = parts[1] || '4s';
      const duration = durStr.endsWith('ms') ? parseFloat(durStr) / 1000 : parseFloat(durStr) || 4.0;
      if (this.styleSheet.keyframes.has(animName)) {
        node._animSpec = { name: animName, duration, keyframes: this.styleSheet.keyframes.get(animName) };
        if (!this.animatedNodes.includes(node)) this.animatedNodes.push(node);
      }
    } else {
      node._animSpec = null;
    }

    // Rebuild geometry automatically if 3SS border-radius, inner-radius, wave-amp/freq, theta, or uv-mode changed!
    if (node.object3D.isMesh && ['surface', 'plane', 'radial-plane', 'disc', 'circle', 'ring', 'box'].includes(node.tagName)) {
      const geoStyleSig = `${cs['border-radius']||''}|${cs['inner-radius']||''}|${cs['corner-segments']||''}|${cs['theta-start']||''}|${cs['theta-length']||''}|${cs['uv-mode']||''}|${cs.orient||''}|${cs['wave-amp']||''}|${cs['wave-freq']||''}|${cs.width||''}|${cs.depth||''}|${node.attributes['border-radius']||''}|${node.attributes['inner-radius']||''}`;
      if (node._lastGeoStyleSig !== undefined && node._lastGeoStyleSig !== geoStyleSig) {
        const newGeo = buildGeometryForSMLNode(node, this.customGenerators, cs);
        if (newGeo) {
          if (node.object3D.geometry) node.object3D.geometry.dispose();
          node.object3D.geometry = newGeo;
        }
      } else if (node._lastGeoStyleSig === undefined && geoStyleSig.replace(/\|/g, '') !== '') {
        const newGeo = buildGeometryForSMLNode(node, this.customGenerators, cs);
        if (newGeo) {
          if (node.object3D.geometry) node.object3D.geometry.dispose();
          node.object3D.geometry = newGeo;
        }
      }
      node._lastGeoStyleSig = geoStyleSig;
    }

    if (node.object3D.isMesh && node.object3D.material && !node.object3D.userData._isHelper) {
      const m = node.object3D.material;
      const hasVCol = !!(node.object3D.geometry && node.object3D.geometry.attributes && node.object3D.geometry.attributes.color);
      m.vertexColors = hasVCol;
      const inlineCol = node.attributes.color || cs.color;
      if (inlineCol) m.color.set(inlineCol);
      else if (hasVCol) m.color.set(0xffffff);
      const na = node.attributes || {};
      const getVal = (k) => (na[k] !== undefined ? na[k] : cs[k]);
      if (getVal('roughness') !== undefined) m.roughness = parseFloat(getVal('roughness'));
      if (getVal('metalness') !== undefined) m.metalness = parseFloat(getVal('metalness'));
      if (getVal('clearcoat') !== undefined) m.clearcoat = parseFloat(getVal('clearcoat'));
      if (getVal('transmission') !== undefined) {
        m.transmission = parseFloat(getVal('transmission'));
        if (m.transmission > 0.01) m.transparent = true;
      }
      if (getVal('ior') !== undefined) m.ior = parseFloat(getVal('ior'));
      if (getVal('thickness') !== undefined) m.thickness = parseFloat(getVal('thickness'));
      if (getVal('attenuation-color')) m.attenuationColor.set(getVal('attenuation-color'));
      if (getVal('emissive')) m.emissive.set(getVal('emissive'));
      else m.emissive.set(0x000000);
      if (getVal('emissive-intensity') !== undefined) m.emissiveIntensity = parseFloat(getVal('emissive-intensity'));
      if (getVal('opacity') !== undefined) {
        m.opacity = parseFloat(getVal('opacity'));
        m.transparent = m.opacity < 0.999 || getVal('transparent') === 'true';
      } else if (getVal('transparent') === 'true') {
        m.transparent = true;
      }
      m.wireframe = getVal('wireframe') === 'true';
      const sideStr = (getVal('side') || 'front').toLowerCase();
      m.side = sideStr === 'double' ? THREE.DoubleSide : (sideStr === 'back' ? THREE.BackSide : THREE.FrontSide);
      m.alphaTest = getVal('alpha-test') !== undefined ? parseFloat(getVal('alpha-test')) : 0.0;

      // Face / Surface Target control (`texture-target: all | surface | top | bottom | front | back | left | right | caps | sides`)
      const targetStr = (cs['texture-target'] || cs['surface-target'] || node.attributes['texture-target'] || 'all').toLowerCase();
      const faceMap = { all: 0, mesh: 0, 'whole-mesh': 0, front: 1, back: 2, top: 3, surface: 3, bottom: 4, right: 5, left: 6, caps: 7, sides: 8 };
      m.texTargetFace = faceMap[targetStr] !== undefined ? faceMap[targetStr] : 0;

      // Texture Blend Mode (`texture-blend: decal | multiply | cutout`)
      const blendStr = (cs['texture-blend'] || node.attributes['texture-blend'] || 'decal').toLowerCase();
      m.texBlendMode = blendStr === 'multiply' || blendStr === 'tint' ? 1 : (blendStr === 'cutout' ? 2 : 0);

      // Check for External Internet PNG or Padded Surface Texture first
      const optCfg = typeof node.getEffectiveOptimizationConfig === 'function' ? node.getEffectiveOptimizationConfig() : {};
      node.object3D.userData._maxDrawDistance = optCfg.cullDistance || 0;
      node.object3D.userData._shadowCullDistance = optCfg.shadowCullDistance || 0;
      node.object3D.userData._smallShadowCullRadius = optCfg.smallObjectCull || 0;
      node.object3D.userData._pomCullDistance = optCfg.pomCullDistance || 0;
      node.object3D.userData._shaderTier = optCfg.shaderTier || 'high';
      const extTex = getExternalOrPaddedTexture(cs, node.attributes, () => {
        this.renderer.shadowMap.needsUpdate = true;
      }, optCfg);
      m.parallaxScale = parseFloat(cs['parallax-scale'] || cs.parallax || node.attributes['parallax-scale'] || node.attributes.parallax || 0.0) || 0.0;
      m.interiorDepth = parseFloat(cs['interior-depth'] || node.attributes['interior-depth'] || 0.0) || 0.0;
      if (extTex) {
        m.map = extTex;
        m.isExternalTex = true;
        m.normalMap = extTex._synthNormalMap || null;
        m.roughnessMap = extTex._synthRoughMap || null;
        const ns = parseFloat(cs['normal-strength'] || cs['normal-scale'] || 1.0);
        m.normalScale.set(ns, ns);
        if (m.texBlendMode === 2) {
          m.transparent = (cs.transparent === 'true' || (cs.opacity !== undefined && parseFloat(cs.opacity) < 0.99));
          m.alphaTest = parseFloat(cs['alpha-test'] || 0.32);
        } else if (cs.transparent === 'true') {
          m.transparent = true;
          m.alphaTest = parseFloat(cs['alpha-test'] || 0.08);
        }
      } else {
        m.isExternalTex = false;
        const pat = cs['surface-pattern'] || cs.pattern || node.attributes.pattern || 'none';
        const scaleParts = (cs['pattern-scale'] || '4 4').trim().split(/[\s,]+/).map(Number);
        const sx = scaleParts[0] || 4, sy = scaleParts[1] || sx || 4;
        // Support World-Space Metric UVs via `pattern-size: 2.0m;` or `uv-space: world;`
        if (cs['pattern-size']) {
          m.metricUVScale = Math.max(0.05, parseFloat(cs['pattern-size']) || 2.0);
        } else if ((cs['uv-space'] || node.attributes['uv-space'] || '').toLowerCase() === 'world') {
          m.metricUVScale = Math.max(0.05, 8.0 / Math.max(0.25, sx));
        } else {
          m.metricUVScale = 0.0;
        }
        const patRes = optCfg.textureResolution ? resolveTargetTextureSize(optCfg.textureResolution, 512, 512, optCfg.maxTextureSize || 2048)[0] : 512;
        const texBundle = getProceduralPatternTextures(pat, sx, sy, patRes);
        if (texBundle) {
          m.map = texBundle.map;
          m.normalMap = texBundle.normalMap;
          m.roughnessMap = texBundle.roughnessMap;
          const ns = parseFloat(cs['normal-strength'] || cs['normal-scale'] || 0.85);
          m.normalScale.set(ns, ns);
        } else {
          m.map = null; m.normalMap = null; m.roughnessMap = null;
        }
        // Support custom `normal-map: url(...)` and `roughness-map: url(...)` in 3SS
        if (cs['normal-map']) {
          const nmUrl = cs['normal-map'].replace(/^url\(['"]?|['"]?\)$/g, '').trim();
          if (nmUrl) m.normalMap = new THREE.TextureLoader().load(nmUrl);
          const ns = parseFloat(cs['normal-strength'] || cs['normal-scale'] || 1.0);
          m.normalScale.set(ns, ns);
        }
        if (cs['roughness-map']) {
          const rmUrl = cs['roughness-map'].replace(/^url\(['"]?|['"]?\)$/g, '').trim();
          if (rmUrl) m.roughnessMap = new THREE.TextureLoader().load(rmUrl);
        }
      }
    }
  }

  _applyTransformString(tfStr, pos, rot, scl) {
    const fnRegex = /([a-zA-Z0-9]+)\(([^)]*)\)/g;
    let m;
    while ((m = fnRegex.exec(tfStr)) !== null) {
      const fn = m[1].toLowerCase();
      const args = m[2].split(/[\s,]+/).filter(Boolean);
      const num = (v) => parseFloat(v) || 0;
      if (fn === 'translate3d' || fn === 'translate') {
        pos.x += num(args[0]); pos.y += num(args[1]); pos.z += num(args[2]);
      } else if (fn === 'translatex') pos.x += num(args[0]);
      else if (fn === 'translatey') pos.y += num(args[0]);
      else if (fn === 'translatez') pos.z += num(args[0]);
      else if (fn === 'rotate3d' || fn === 'rotate') {
        rot.x += num(args[0]); rot.y += num(args[1]); rot.z += num(args[2]);
      } else if (fn === 'rotatex') rot.x += num(args[0]);
      else if (fn === 'rotatey') rot.y += num(args[0]);
      else if (fn === 'rotatez') rot.z += num(args[0]);
      else if (fn === 'scale3d' || fn === 'scale') {
        const sx = num(args[0]) || 1;
        const sy = args[1] !== undefined ? num(args[1]) : sx;
        const sz = args[2] !== undefined ? num(args[2]) : sx;
        scl.x *= sx; scl.y *= sy; scl.z *= sz;
      }
    }
  }

  setRenderMode(mode = 'explore', opts = {}) {
    const target = String(mode || 'edit').toLowerCase();
    if (target === this.renderMode && !opts.force) return this._exploreStats;
    this.renderMode = target;

    if (target === 'explore' || target === 'baked' || target === 'play') {
      const cfg = {
        mergeStatic: opts.mergeStatic !== false,
        bakeAnimations: opts.bakeAnimations !== false,
        freezeShadows: opts.freezeShadows !== false,
        freezeMatrices: opts.freezeMatrices !== false,
        smartReflector: opts.smartReflector !== false,
        reflectorInterval: opts.reflectorInterval || 2,
        lutSteps: Math.max(16, Math.min(256, opts.lutSteps || 64))
      };
      this.renderer._exploreMode = true;
      this.renderer._exploreOpts = cfg;
      const t0 = performance.now();
      let mergedSourceCount = 0, mergedBucketCount = 0, bakedAnimCount = 0, frozenCount = 0;

      // A) Pre-Bake all loopable 3SS @keyframes into 64-frame Float32Array LUTs
      if (cfg.bakeAnimations) {
        const steps = cfg.lutSteps;
        for (const node of this.animatedNodes) {
          const spec = node._animSpec;
          if (!spec || !spec.keyframes.length || !node.object3D) continue;
          const lut = new Float32Array(steps * 10);
          for (let sIdx = 0; sIdx < steps; sIdx++) {
            const cycleT = sIdx / steps;
            let f0 = spec.keyframes[0], f1 = spec.keyframes[spec.keyframes.length - 1];
            for (let i = 0; i < spec.keyframes.length - 1; i++) {
              if (cycleT >= spec.keyframes[i].t && cycleT <= spec.keyframes[i + 1].t) {
                f0 = spec.keyframes[i]; f1 = spec.keyframes[i + 1]; break;
              }
            }
            const span = Math.max(0.0001, f1.t - f0.t);
            const alpha = Math.max(0, Math.min(1, (cycleT - f0.t) / span));
            const p0 = node._basePos.clone(), r0 = node._baseRot.clone(), s0 = node._baseScale.clone();
            const p1 = node._basePos.clone(), r1 = node._baseRot.clone(), s1 = node._baseScale.clone();
            p0.y += node._anchorYOffset || 0;
            p1.y += node._anchorYOffset || 0;
            if (f0.props.transform) this._applyTransformString(f0.props.transform, p0, r0, s0);
            if (f1.props.transform) this._applyTransformString(f1.props.transform, p1, r1, s1);
            const off = sIdx * 10;
            lut[off]     = p0.x + (p1.x - p0.x) * alpha;
            lut[off + 1] = p0.y + (p1.y - p0.y) * alpha;
            lut[off + 2] = p0.z + (p1.z - p0.z) * alpha;
            lut[off + 3] = THREE.MathUtils.degToRad(r0.x + (r1.x - r0.x) * alpha);
            lut[off + 4] = THREE.MathUtils.degToRad(r0.y + (r1.y - r0.y) * alpha);
            lut[off + 5] = THREE.MathUtils.degToRad(r0.z + (r1.z - r0.z) * alpha);
            lut[off + 6] = s0.x + (s1.x - s0.x) * alpha;
            lut[off + 7] = s0.y + (s1.y - s0.y) * alpha;
            lut[off + 8] = s0.z + (s1.z - s0.z) * alpha;
            lut[off + 9] = (f0.props['emissive-intensity'] !== undefined && f1.props['emissive-intensity'] !== undefined)
              ? THREE.MathUtils.lerp(parseFloat(f0.props['emissive-intensity']), parseFloat(f1.props['emissive-intensity']), alpha)
              : -1;
          }
          node._bakedAnimLUT = lut;
          node._bakedAnimSteps = steps;
          bakedAnimCount++;
        }
      }

      // B) Automatic Static Material-Bucket Geometry Merging (reversible!)
      if (cfg.mergeStatic && typeof THREE.mergeGeometries === 'function') {
        this._restoreBakedStaticGroup();
        const animSet = new Set(this.animatedNodes.map(n => n.object3D));
        const buckets = new Map();
        const hiddenOriginals = [];
        this.rootContainer.updateMatrixWorld(true);

        const visit = (obj) => {
          if (!obj || !obj.visible || obj.userData._isHelper || obj.userData._isWetReflector || obj.userData._isTagReflector || obj.userData._isBakedStatic || obj.userData._dynamic) return;
          if (animSet.has(obj)) return;
          if (obj.isMesh && !obj.isInstancedMesh && !obj.isSkinnedMesh && obj.geometry && obj.material && !obj.material.isShaderMaterial) {
            const m = obj.material;
            if ((m.transmission || 0) <= 0.01 && !m.transparent && (!obj.geometry._surfaceWave)) {
              const sig = `${m.color ? m.color.getHexString() : 'fff'}|${m.roughness}|${m.metalness}|${m.emissive ? m.emissive.getHexString() : '000'}|${m.emissiveIntensity}|${m.side}|${m.vertexColors ? 1 : 0}|${m.map ? (m.map.uuid || 'm') : ''}|${m.normalMap ? (m.normalMap.uuid || 'n') : ''}|${m.roughnessMap ? (m.roughnessMap.uuid || 'r') : ''}`;
              if (!buckets.has(sig)) buckets.set(sig, { mat: m, castShadow: obj.castShadow, receiveShadow: obj.receiveShadow, geos: [], objs: [] });
              const b = buckets.get(sig);
              const g = obj.geometry.clone();
              g.applyMatrix4(obj.matrixWorld);
              b.geos.push(g);
              b.objs.push(obj);
              return;
            }
          }
          if (obj.children) {
            for (let i = 0; i < obj.children.length; i++) visit(obj.children[i]);
          }
        };
        visit(this.rootContainer);

        const bakedGroup = new THREE.Group();
        bakedGroup.name = '__triad_baked_static_group__';
        bakedGroup.userData._isBakedStatic = true;
        for (const [, b] of buckets) {
          if (b.objs.length < 2) continue;
          const merged = THREE.mergeGeometries(b.geos);
          if (merged) {
            const mesh = new THREE.Mesh(merged, b.mat);
            mesh.castShadow = b.castShadow;
            mesh.receiveShadow = b.receiveShadow;
            mesh.matrixAutoUpdate = false;
            mesh.updateMatrix();
            mesh.userData._isBakedStatic = true;
            bakedGroup.add(mesh);
            mergedBucketCount++;
            for (const srcObj of b.objs) {
              srcObj.userData._preBakeVis = srcObj.visible;
              srcObj.visible = false;
              hiddenOriginals.push(srcObj);
              mergedSourceCount++;
            }
          }
        }
        if (mergedBucketCount > 0) {
          this.rootContainer.add(bakedGroup);
          this._bakedStaticGroup = bakedGroup;
          this._bakedHiddenOriginals = hiddenOriginals;
        }
      }

      // C) Freeze Static World Matrices
      if (cfg.freezeMatrices) {
        const animSet = new Set(this.animatedNodes.map(n => n.object3D));
        this.rootContainer.traverse(o => {
          if (o && !animSet.has(o) && !o.userData._dynamic && o.matrixAutoUpdate !== false) {
            o.updateMatrix();
            o.matrixAutoUpdate = false;
            o.userData._frozenByExplore = true;
            frozenCount++;
          }
        });
      }

      // D) Pre-Bake & Freeze Static Shadow Maps
      if (cfg.freezeShadows) {
        this._prevShadowAutoUpdate = this.renderer.shadowMap.autoUpdate;
        this.renderer.shadowMap.needsUpdate = true;
        this.renderer.shadowMap.autoUpdate = false;
      }

      this._exploreStats = {
        mode: 'explore',
        bakeMs: Number((performance.now() - t0).toFixed(2)),
        mergedSourceMeshes: mergedSourceCount,
        mergedBuckets: mergedBucketCount,
        drawCallsSaved: Math.max(0, mergedSourceCount - mergedBucketCount),
        bakedAnimationLUTs: bakedAnimCount,
        frozenMatrices: frozenCount,
        shadowsFrozen: cfg.freezeShadows
      };
      return this._exploreStats;
    } else {
      // Restore Live Edit Mode cleanly!
      this.renderer._exploreMode = false;
      this.renderer._exploreOpts = null;
      this._restoreBakedStaticGroup();
      for (const node of this.animatedNodes) {
        node._bakedAnimLUT = null;
      }
      this.rootContainer.traverse(o => {
        if (o && o.userData && o.userData._frozenByExplore) {
          o.matrixAutoUpdate = true;
          o.userData._frozenByExplore = false;
        }
      });
      if (this._prevShadowAutoUpdate !== undefined) {
        this.renderer.shadowMap.autoUpdate = this._prevShadowAutoUpdate;
      } else {
        this.renderer.shadowMap.autoUpdate = true;
      }
      this.renderer.shadowMap.needsUpdate = true;
      this._exploreStats = { mode: 'edit' };
      return this._exploreStats;
    }
  }

  _restoreBakedStaticGroup() {
    if (this._bakedStaticGroup && this._bakedStaticGroup.parent) {
      this._bakedStaticGroup.parent.remove(this._bakedStaticGroup);
    }
    this._bakedStaticGroup = null;
    if (this._bakedHiddenOriginals) {
      for (const o of this._bakedHiddenOriginals) {
        o.visible = o.userData._preBakeVis !== undefined ? o.userData._preBakeVis : true;
      }
      this._bakedHiddenOriginals = null;
    }
  }

  stepAnimations(dt, elapsed) {
    if (this.agents) this.agents.step(dt, elapsed);
    if (this.skyUniforms) {
      this.skyUniforms.uTime.value = elapsed;
    }
    if (this.cloudImpostorGroup && this.skyUniforms) {
      const spd = this.skyUniforms.uCloudSpeed.value * 40.0;
      this.cloudImpostorGroup.position.x = Math.sin(elapsed * 0.05) * spd;
    }
    if (this.skyUniforms) {
      this.skyUniforms.uTime.value = elapsed;
    }
    if (this.cloudImpostorGroup && this.skyUniforms) {
      const spd = this.skyUniforms.uCloudSpeed.value * 40.0;
      this.cloudImpostorGroup.position.x = Math.sin(elapsed * 0.05) * spd;
    }
    if (this.chunks && this.chunks.chunks.size > 0) {
      const cam = (this.viewer && this.viewer.camera) ? this.viewer.camera : null;
      if (cam) this.chunks.updateForCamera(cam.position);
    }
    for (const node of this.animatedNodes) {
      const spec = node._animSpec;
      if (!spec || !spec.keyframes.length || !node.object3D) continue;
      const cycleT = (elapsed % spec.duration) / spec.duration;
      // Fast O(1) Pre-Baked Float32Array LUT path (Explore Mode: zero clones, zero regex!)
      if (node._bakedAnimLUT) {
        const lut = node._bakedAnimLUT;
        const steps = node._bakedAnimSteps || 64;
        const fIdx = cycleT * steps;
        const i0 = Math.floor(fIdx) % steps;
        const i1 = (i0 + 1) % steps;
        const a = fIdx - Math.floor(fIdx);
        const o0 = i0 * 10, o1 = i1 * 10;
        const obj = node.object3D;
        obj.position.set(
          lut[o0] + (lut[o1] - lut[o0]) * a,
          lut[o0 + 1] + (lut[o1 + 1] - lut[o0 + 1]) * a,
          lut[o0 + 2] + (lut[o1 + 2] - lut[o0 + 2]) * a
        );
        obj.rotation.set(
          lut[o0 + 3] + (lut[o1 + 3] - lut[o0 + 3]) * a,
          lut[o0 + 4] + (lut[o1 + 4] - lut[o0 + 4]) * a,
          lut[o0 + 5] + (lut[o1 + 5] - lut[o0 + 5]) * a
        );
        obj.scale.set(
          lut[o0 + 6] + (lut[o1 + 6] - lut[o0 + 6]) * a,
          lut[o0 + 7] + (lut[o1 + 7] - lut[o0 + 7]) * a,
          lut[o0 + 8] + (lut[o1 + 8] - lut[o0 + 8]) * a
        );
        if (lut[o0 + 9] >= 0 && obj.material) {
          obj.material.emissiveIntensity = lut[o0 + 9] + (lut[o1 + 9] - lut[o0 + 9]) * a;
        }
        continue;
      }
      let f0 = spec.keyframes[0], f1 = spec.keyframes[spec.keyframes.length - 1];
      for (let i = 0; i < spec.keyframes.length - 1; i++) {
        if (cycleT >= spec.keyframes[i].t && cycleT <= spec.keyframes[i + 1].t) {
          f0 = spec.keyframes[i]; f1 = spec.keyframes[i + 1]; break;
        }
      }
      const span = Math.max(0.0001, f1.t - f0.t);
      const alpha = Math.max(0, Math.min(1, (cycleT - f0.t) / span));
      const p0 = node._basePos.clone(), r0 = node._baseRot.clone(), s0 = node._baseScale.clone();
      const p1 = node._basePos.clone(), r1 = node._baseRot.clone(), s1 = node._baseScale.clone();
      p0.y += node._anchorYOffset || 0;
      p1.y += node._anchorYOffset || 0;
      if (f0.props.transform) this._applyTransformString(f0.props.transform, p0, r0, s0);
      if (f1.props.transform) this._applyTransformString(f1.props.transform, p1, r1, s1);
      node.object3D.position.lerpVectors(p0, p1, alpha);
      node.object3D.rotation.set(
        THREE.MathUtils.degToRad(THREE.MathUtils.lerp(r0.x, r1.x, alpha)),
        THREE.MathUtils.degToRad(THREE.MathUtils.lerp(r0.y, r1.y, alpha)),
        THREE.MathUtils.degToRad(THREE.MathUtils.lerp(r0.z, r1.z, alpha))
      );
      node.object3D.scale.lerpVectors(s0, s1, alpha);
      if (f0.props['emissive-intensity'] !== undefined && f1.props['emissive-intensity'] !== undefined && node.object3D.material) {
        node.object3D.material.emissiveIntensity = THREE.MathUtils.lerp(parseFloat(f0.props['emissive-intensity']), parseFloat(f1.props['emissive-intensity']), alpha);
      }
    }
    // Animate any <surface> or <plane> with _surfaceWave (e.g. .water-ripple)
    for (const node of this.allNodes) {
      if (node.object3D && node.object3D.isMesh && node.object3D.geometry && node.object3D.geometry._surfaceWave) {
        const sw = node.object3D.geometry._surfaceWave;
        const cs = node._computedStyle || {};
        const speed = parseFloat(node.attributes.speed || cs['wave-speed'] || 2.2);
        if (speed > 0 && sw.amp > 1e-4) {
          const pos = node.object3D.geometry.attributes.position;
          const baseXZ = sw.baseXZ;
          const phase = elapsed * speed;
          for (let i = 0; i < pos.count; i++) {
            const x = baseXZ[i * 2], z = baseXZ[i * 2 + 1];
            const r = Math.hypot(x, z);
            const disp = Math.sin(r * sw.freq * 2.0 - phase) * Math.cos(x * sw.freq * 0.65 + phase * 0.35) * sw.amp / (1.0 + r * 0.35);
            if (sw.orient === 'xy') pos.setZ(i, disp);
            else pos.setY(i, disp);
          }
          pos.needsUpdate = true;
        }
      }
    }

    // Step declarative <particles> / <rain> / <mist> / <snow> systems
    for (const ps of this.particleSystems) {
      const posAttr = ps.geo.attributes.position;
      if (!posAttr) continue;
      const arr = posAttr.array;
      const hx = ps.area.x * 0.5, hy = ps.area.y, hz = ps.area.z * 0.5;
      for (let i = 0; i < ps.count; i++) {
        const o = i * 3;
        if (ps.pType === 'rain' || ps.pType === 'snow') {
          arr[o + 1] -= ps.speed * dt;
          arr[o]     += (ps.wind.x + (ps.pType === 'snow' ? Math.sin(elapsed * 1.5 + ps.phases[i]) * 0.6 : 0)) * dt;
          arr[o + 2] += ps.wind.z * dt;
          if (arr[o + 1] < 0) {
            arr[o + 1] += hy;
            arr[o] = (Math.random() - 0.5) * ps.area.x;
            arr[o + 2] = (Math.random() - 0.5) * ps.area.z;
          }
        } else {
          arr[o]     += Math.sin(elapsed * 0.7 + ps.phases[i]) * ps.speed * 0.3 * dt;
          arr[o + 1] += Math.cos(elapsed * 0.9 + ps.phases[i]) * ps.speed * 0.2 * dt;
          arr[o + 2] += Math.sin(elapsed * 0.5 + ps.phases[i] * 1.7) * ps.speed * 0.3 * dt;
          if (arr[o] > hx) arr[o] = -hx; else if (arr[o] < -hx) arr[o] = hx;
          if (arr[o + 2] > hz) arr[o] = -hz; else if (arr[o + 2] < -hz) arr[o] = hz;
        }
      }
      posAttr.needsUpdate = true;
    }

    for (const cb of this.tickCallbacks) {
      try { cb(dt, elapsed, this); }
      catch (err) {
        this.lastError = err;
        const st = (err && err.stack) ? err.stack : String(err);
        console.error('[Triad3D Tick Error]', st);
        logConsole(`3JS Tick Error: ${err.message}
${st}`, 'err');
      }
    }
  }
}


// ============================================================================
// 6B. TRIAD3D v7.6 FIRST-PERSON (FPS) CONTROLLER & 3D COLLISION MARKER ENGINE
//     Supports:
//       • SML `<collider shape="box|cylinder|sphere" type="solid|ground|trigger" ... />`
//       • SML `collision="box|cylinder|sphere|ground|trigger"` on any mesh node
//       • 3SS `collision: box | cylinder | ground | trigger;` stylesheet rules
//       • 3JS `Triad.physics.addBoxCollider(...)`, `.addCylinderCollider(...)`,
//         `.addTriggerZone(...)`, `.setSpawn(...)`, `.onCollide(...)`, `.onTrigger(...)`
//       • 3D Visual Collision Marker Overlay (Wireframe Cages + Translucent Volumes
//         + Ground Footprint Rings + Live Contact Flash + Player Capsule Avatar)
//       • Capsule FPS Controller (WASD/Arrows + Shift Sprint + Space Jump + Gravity
//         + Step-Up + OBB/Cylinder Sliding Collision Resolution + Crosshair HUD)
// ============================================================================

function buildWireframeBoxGeometry(w, h, d) {
  const hw = w * 0.5, hh = h * 0.5, hd = d * 0.5;
  const c = [
    [-hw, -hh, -hd], [ hw, -hh, -hd], [ hw, -hh,  hd], [-hw, -hh,  hd],
    [-hw,  hh, -hd], [ hw,  hh, -hd], [ hw,  hh,  hd], [-hw,  hh,  hd]
  ];
  const edges = [
    [0,1],[1,2],[2,3],[3,0], // bottom
    [4,5],[5,6],[6,7],[7,4], // top
    [0,4],[1,5],[2,6],[3,7], // vertical pillars
    [0,5],[1,4],[2,7],[3,6], // X-diagonals on front/back faces for unmistakable collider look
    [1,6],[2,5],[0,7],[3,4]  // X-diagonals on side faces
  ];
  const pos = new Float32Array(edges.length * 6);
  let p = 0;
  for (const [i0, i1] of edges) {
    pos[p++] = c[i0][0]; pos[p++] = c[i0][1]; pos[p++] = c[i0][2];
    pos[p++] = c[i1][0]; pos[p++] = c[i1][1]; pos[p++] = c[i1][2];
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  return geo;
}

function buildWireframeCylinderGeometry(radius, height, segs = 24) {
  const hh = height * 0.5;
  const pts = [];
  for (let i = 0; i < segs; i++) {
    const a0 = (i / segs) * Math.PI * 2;
    const a1 = ((i + 1) / segs) * Math.PI * 2;
    const x0 = Math.cos(a0) * radius, z0 = Math.sin(a0) * radius;
    const x1 = Math.cos(a1) * radius, z1 = Math.sin(a1) * radius;
    // Bottom ring, top ring, and mid waist ring
    pts.push(x0, -hh, z0, x1, -hh, z1);
    pts.push(x0,  hh, z0, x1,  hh, z1);
    pts.push(x0,   0, z0, x1,   0, z1);
    // Outer ground beacon ring at base
    const rOut = radius * 1.08;
    pts.push(Math.cos(a0) * rOut, -hh + 0.015, Math.sin(a0) * rOut, Math.cos(a1) * rOut, -hh + 0.015, Math.sin(a1) * rOut);
    if (i % 3 === 0) {
      pts.push(x0, -hh, z0, x0, hh, z0);
    }
  }
  // Crosshair at base & top
  pts.push(-radius, -hh, 0, radius, -hh, 0, 0, -hh, -radius, 0, -hh, radius);
  pts.push(-radius,  hh, 0, radius,  hh, 0, 0,  hh, -radius, 0,  hh, radius);
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(new Float32Array(pts), 3));
  return geo;
}

class TriadPhysicsWorld {
  constructor(runtime) {
    this.runtime = runtime;
    this.colliders = [];
    this.collideListeners = [];
    this.triggerListeners = [];
    this.spawnPos = new THREE.Vector3(0, 0.15, 9.2);
    this.spawnYaw = 0;
    this.spawnPitch = -4;
    this.playerParams = {
      radius: 0.38,
      height: 1.72,
      eyeHeight: 1.62,
      walkSpeed: 5.4,
      sprintSpeed: 9.2,
      jumpVelocity: 6.2,
      gravity: 16.5,
      stepHeight: 0.44
    };
    this.markersGroup = new THREE.Group();
    this.markersGroup.userData._isHelper = true;
    this.markersGroup.visible = false;
    this.playerAvatarGroup = null;
  }

  clear() {
    while (this.markersGroup.children.length > 0) {
      this.markersGroup.remove(this.markersGroup.children[0]);
    }
    this.colliders = [];
    this.collideListeners = [];
    this.triggerListeners = [];
    this.playerAvatarGroup = null;
  }

  setSpawn(posArr, yawDeg = 0, pitchDeg = -4) {
    if (Array.isArray(posArr)) this.spawnPos.set(posArr[0] || 0, posArr[1] || 0, posArr[2] || 0);
    else if (posArr && posArr.isVector3) this.spawnPos.copy(posArr);
    this.spawnYaw = yawDeg || 0;
    this.spawnPitch = pitchDeg || -4;
  }

  setPlayerParams(params = {}) {
    Object.assign(this.playerParams, params);
  }

  onCollide(fn) {
    if (typeof fn === 'function') this.collideListeners.push(fn);
  }

  onTrigger(fn) {
    if (typeof fn === 'function') this.triggerListeners.push(fn);
  }

  addCollider(spec = {}) {
    const shape = String(spec.shape || (spec.radius !== undefined ? 'cylinder' : 'box')).toLowerCase();
    const type = String(spec.type || 'solid').toLowerCase(); // 'solid' | 'ground' | 'trigger'
    const pos = Array.isArray(spec.pos)
      ? new THREE.Vector3(spec.pos[0] || 0, spec.pos[1] || 0, spec.pos[2] || 0)
      : (spec.pos && spec.pos.isVector3 ? spec.pos.clone() : new THREE.Vector3(0, 0.5, 0));
    const size = Array.isArray(spec.size)
      ? new THREE.Vector3(spec.size[0] || 1, spec.size[1] || 1, spec.size[2] || 1)
      : (spec.size && spec.size.isVector3 ? spec.size.clone() : new THREE.Vector3(1, 1, 1));
    const radius = spec.radius !== undefined ? parseFloat(spec.radius) : Math.max(size.x, size.z) * 0.5;
    const height = spec.height !== undefined ? parseFloat(spec.height) : size.y;
    const rotYDeg = spec.rotY !== undefined ? parseFloat(spec.rotY) : 0;
    const rotY = THREE.MathUtils.degToRad(rotYDeg);

    const col = {
      id: spec.id || `col_${this.colliders.length + 1}`,
      label: spec.label || spec.id || `${type.toUpperCase()} ${shape.toUpperCase()}`,
      shape,
      type,
      pos,
      size,
      radius: Math.max(0.05, radius),
      height: Math.max(0.05, height),
      rotY,
      rotYDeg,
      node: spec.node || null,
      onCollide: spec.onCollide || null,
      onEnter: spec.onEnter || null,
      onExit: spec.onExit || null,
      _isColliding: false,
      _isTriggered: false,
      _markerWire: null,
      _markerShell: null
    };
    this.colliders.push(col);
    this._buildColliderVisualMarker(col);
    return col;
  }

  addBoxCollider(spec = {}) { return this.addCollider({ ...spec, shape: 'box' }); }
  addCylinderCollider(spec = {}) { return this.addCollider({ ...spec, shape: 'cylinder' }); }
  addSphereCollider(spec = {}) { return this.addCollider({ ...spec, shape: 'sphere' }); }
  addTriggerZone(spec = {}) { return this.addCollider({ ...spec, type: 'trigger', shape: spec.shape || (spec.radius ? 'cylinder' : 'box') }); }

  _buildColliderVisualMarker(col) {
    const grp = new THREE.Group();
    grp.position.copy(col.pos);
    grp.rotation.y = col.rotY;
    grp.userData._isHelper = true;

    const baseHex = col.type === 'trigger' ? 0xf59e0b : (col.type === 'ground' ? 0x38bdf8 : 0x00e5a3);
    const wireMat = new THREE.LineBasicMaterial({ color: baseHex, depthTest: true, depthWrite: false });
    const shellMat = new THREE.MeshBasicMaterial({
      color: baseHex,
      transparent: true,
      opacity: col.type === 'trigger' ? 0.18 : (col.type === 'ground' ? 0.12 : 0.15),
      depthWrite: false,
      depthTest: true
    });

    let wireGeo, shellGeo;
    if (col.shape === 'cylinder' || col.shape === 'sphere') {
      wireGeo = buildWireframeCylinderGeometry(col.radius, col.height, 24);
      shellGeo = new THREE.CylinderGeometry(col.radius, col.radius, col.height, 24, 1);
    } else {
      wireGeo = buildWireframeBoxGeometry(col.size.x, col.size.y, col.size.z);
      shellGeo = new THREE.BoxGeometry(col.size.x, col.size.y, col.size.z);
    }

    const wire = new THREE.LineSegments(wireGeo, wireMat);
    const shell = new THREE.Mesh(shellGeo, shellMat);
    wire.castShadow = false; wire.receiveShadow = false;
    shell.castShadow = false; shell.receiveShadow = false;
    wire.userData._isHelper = true;
    shell.userData._isHelper = true;
    wire.renderOrder = 25;
    shell.renderOrder = 24;

    grp.add(shell, wire);
    col._markerGroup = grp;
    col._markerWire = wire;
    col._markerShell = shell;
    col._baseColorHex = baseHex;
    this.markersGroup.add(grp);
  }

  buildPlayerAvatarMarker(pos, yaw) {
    if (!this.playerAvatarGroup) {
      const g = new THREE.Group();
      g.userData._isHelper = true;
      const r = this.playerParams.radius, h = this.playerParams.height;
      const wire = new THREE.LineSegments(
        buildWireframeCylinderGeometry(r, h, 20),
        new THREE.LineBasicMaterial({ color: 0x38bdf8 })
      );
      wire.position.y = h * 0.5;
      wire.castShadow = false; wire.receiveShadow = false; wire.userData._isHelper = true;
      const shell = new THREE.Mesh(
        new THREE.CylinderGeometry(r, r, h, 20),
        new THREE.MeshBasicMaterial({ color: 0x0ea5e9, transparent: true, opacity: 0.22, depthWrite: false })
      );
      shell.position.y = h * 0.5;
      shell.castShadow = false; shell.receiveShadow = false; shell.userData._isHelper = true;
      // Forward view direction arrow at eye height
      const arrowPts = new Float32Array([
        0, this.playerParams.eyeHeight, 0,  0, this.playerParams.eyeHeight, -1.35,
        0, this.playerParams.eyeHeight, -1.35, -0.22, this.playerParams.eyeHeight, -0.95,
        0, this.playerParams.eyeHeight, -1.35,  0.22, this.playerParams.eyeHeight, -0.95
      ]);
      const arrowGeo = new THREE.BufferGeometry();
      arrowGeo.setAttribute('position', new THREE.Float32BufferAttribute(arrowPts, 3));
      const arrow = new THREE.LineSegments(arrowGeo, new THREE.LineBasicMaterial({ color: 0xfacc15 }));
      arrow.castShadow = false; arrow.userData._isHelper = true;
      g.add(shell, wire, arrow);
      this.playerAvatarGroup = g;
      this.markersGroup.add(g);
    }
    this.playerAvatarGroup.position.copy(pos);
    this.playerAvatarGroup.rotation.y = yaw;
  }

  updateMarkerColors() {
    for (const col of this.colliders) {
      if (!col._markerWire || !col._markerShell) continue;
      let hex = col._baseColorHex;
      let op = col.type === 'trigger' ? 0.18 : (col.type === 'ground' ? 0.12 : 0.15);
      if (col._isColliding) {
        hex = 0xff3b30; // Bright Crimson-Orange on active FPS contact!
        op = 0.34;
      } else if (col._isTriggered) {
        hex = 0x22c55e; // Bright Emerald-Lime when inside Trigger Zone!
        op = 0.28;
      }
      col._markerWire.material.color.setHex(hex);
      col._markerShell.material.color.setHex(hex);
      col._markerShell.material.opacity = op;
    }
  }

  extractDeclarativeCollidersFromSML(allNodes, smlRoot) {
    if (smlRoot && smlRoot.attributes) {
      const sa = smlRoot.attributes;
      if (sa['fps-spawn']) {
        const parts = String(sa['fps-spawn']).trim().split(/[\s,]+/).map(Number);
        const sx = !isNaN(parts[0]) ? parts[0] : 0;
        const sy = !isNaN(parts[1]) ? parts[1] : 0.15;
        const sz = !isNaN(parts[2]) ? parts[2] : 9.2;
        const syaw = !isNaN(parts[3]) ? parts[3] : parseFloat(sa['fps-yaw'] || 0);
        const spitch = !isNaN(parts[4]) ? parts[4] : parseFloat(sa['fps-pitch'] || -4);
        this.setSpawn([sx, sy, sz], syaw, spitch);
      }
      if (sa['fps-speed']) this.playerParams.walkSpeed = parseFloat(sa['fps-speed']) || 5.4;
      if (sa['fps-sprint']) this.playerParams.sprintSpeed = parseFloat(sa['fps-sprint']) || 10.5;
      if (sa['fps-jump']) this.playerParams.jumpSpeed = parseFloat(sa['fps-jump']) || 6.8;
      if (sa['fps-radius']) this.playerParams.radius = parseFloat(sa['fps-radius']) || 0.36;
      if (sa['gravity']) this.playerParams.gravity = parseFloat(sa['gravity']) || -18.0;
      if (sa['fps-eye-height'] || sa['eye-height']) this.playerParams.eyeHeight = parseFloat(sa['fps-eye-height'] || sa['eye-height']) || 1.62;
    }

    for (const node of allNodes) {
      const tag = node.tagName;
      const a = node.attributes || {};
      const cs = node._computedStyle || {};

      // Case 1: Dedicated `<collider>` or `<collision-marker>` or `<collision>` tag in SML
      if (tag === 'collider' || tag === 'collision-marker' || tag === 'collision') {
        const wp = new THREE.Vector3();
        if (node.object3D) {
          node.object3D.updateMatrixWorld(true);
          const me = node.object3D.matrixWorld.elements;
          wp.set(me[12], me[13], me[14]);
        } else {
          wp.copy(parseVec3Attr(a.pos, 0, 0.5, 0));
        }
        const sz = parseVec3Attr(a.size || cs.size, 1.5, 1.5, 1.5);
        const rot = parseVec3Attr(a.rot, 0, 0, 0);
        const shape = (a.shape || cs['collision-shape'] || (a.radius ? 'cylinder' : 'box')).toLowerCase();
        const cType = (a.type || cs['collision-type'] || 'solid').toLowerCase();
        this.addCollider({
          id: node.id || undefined,
          label: a.label || node.id || `${cType} ${shape}`,
          shape,
          type: cType,
          pos: wp,
          size: sz,
          radius: a.radius !== undefined ? parseFloat(a.radius) : undefined,
          height: a.height !== undefined ? parseFloat(a.height) : sz.y,
          rotY: rot.y,
          node
        });
        continue;
      }

      // Case 2: `collision="..."` attribute or 3SS `collision: ...` property on any mesh node
      const colMode = (a.collision || cs.collision || '').trim().toLowerCase();
      if (!colMode || colMode === 'none' || colMode === 'false') continue;
      if (!node.object3D) continue;

      node.object3D.updateMatrixWorld(true);
      const pad = parseFloat(a['collision-padding'] || cs['collision-padding'] || 0) || 0;
      const offset = parseVec3Attr(a['collision-offset'] || cs['collision-offset'], 0, 0, 0);

      let cType = 'solid';
      let shape = 'box';
      if (colMode === 'ground' || colMode === 'walkable' || colMode === 'floor') {
        cType = 'ground';
        shape = a['collision-shape'] || (a.radius || a['collision-radius'] ? 'cylinder' : 'box');
      } else if (colMode === 'trigger' || colMode === 'zone' || colMode === 'sensor') {
        cType = 'trigger';
        shape = a['collision-shape'] || (a.radius || a['collision-radius'] ? 'cylinder' : 'box');
      } else if (colMode === 'cylinder' || colMode === 'capsule') {
        shape = 'cylinder';
      } else if (colMode === 'sphere') {
        shape = 'sphere';
      } else {
        shape = a['collision-shape'] || (tag === 'cylinder' || tag === 'cone' ? 'cylinder' : (tag === 'sphere' ? 'sphere' : 'box'));
      }

      const box = new THREE.Box3().setFromObject(node.object3D);
      const bSize = new THREE.Vector3(), bCenter = new THREE.Vector3();
      box.getSize(bSize);
      box.getCenter(bCenter);
      bCenter.add(offset);

      if (a['collision-size']) {
        bSize.copy(parseVec3Attr(a['collision-size'], bSize.x, bSize.y, bSize.z));
      }
      bSize.x = Math.max(0.1, bSize.x + pad * 2);
      bSize.y = Math.max(0.1, bSize.y + pad * 2);
      bSize.z = Math.max(0.1, bSize.z + pad * 2);

      const cRad = a['collision-radius'] !== undefined
        ? parseFloat(a['collision-radius'])
        : (Math.max(bSize.x, bSize.z) * 0.5);
      const cHeight = a['collision-height'] !== undefined
        ? parseFloat(a['collision-height'])
        : bSize.y;

      const rot = parseVec3Attr(a.rot, 0, 0, 0);
      this.addCollider({
        id: node.id ? `col-${node.id}` : undefined,
        label: a['collision-label'] || a.label || node.id || `<${node.tagName}>`,
        shape,
        type: cType,
        pos: bCenter,
        size: bSize,
        radius: cRad + pad,
        height: cHeight,
        rotY: rot.y,
        node
      });
    }
  }

  raycast(origin, dir, maxDist = 100) {
    let bestHit = null;
    let bestDist = maxDist;
    for (const col of this.colliders) {
      if (col.type === 'trigger') continue;
      const dx = col.pos.x - origin.x, dy = col.pos.y - origin.y, dz = col.pos.z - origin.z;
      const r = col.shape === 'box' ? Math.hypot(col.size.x, col.size.z) * 0.5 : col.radius;
      const t = dx * dir.x + dy * dir.y + dz * dir.z;
      if (t > 0 && t < bestDist) {
        const px = origin.x + dir.x * t - col.pos.x;
        const pz = origin.z + dir.z * t - col.pos.z;
        if (Math.hypot(px, pz) <= r) {
          bestDist = t;
          bestHit = { collider: col, distance: t, point: new THREE.Vector3(origin.x + dir.x * t, origin.y + dir.y * t, origin.z + dir.z * t) };
        }
      }
    }
    return bestHit;
  }
}

class TriadFPSController {
  constructor(physicsWorld, perspCamera, canvas, onStatusChange = null) {
    this.physics = physicsWorld;
    this.camera = perspCamera;
    this.canvas = canvas;
    this.onStatusChange = onStatusChange;
    this.enabled = false;

    this.pos = new THREE.Vector3(0, 0.15, 9.2);
    this.vel = new THREE.Vector3(0, 0, 0);
    this.yaw = 0;
    this.pitch = -0.06;
    this.onGround = true;
    this.bobPhase = 0;

    this.keys = { w: false, a: false, s: false, d: false, up: false, down: false, left: false, right: false, shift: false, space: false };
    this.joyMove = { x: 0, y: 0 };
    this.activeHit = null;
    this.activeZone = null;
    this._insideTriggerIds = new Set();

    this._bindEvents();
  }

  resetToSpawn() {
    this.pos.copy(this.physics.spawnPos);
    this.vel.set(0, 0, 0);
    this.yaw = THREE.MathUtils.degToRad(this.physics.spawnYaw || 0);
    this.pitch = THREE.MathUtils.degToRad(this.physics.spawnPitch || -4);
    this.onGround = true;
    this.step(0.016);
  }

  setPose(x, footY, z, yawDeg = 0, pitchDeg = -4) {
    if (Array.isArray(x)) {
      pitchDeg = z !== undefined ? z : -4;
      yawDeg = footY !== undefined ? footY : 0;
      this.pos.set(x[0] || 0, x[1] || 0, x[2] || 0);
    } else {
      this.pos.set(x, footY, z);
    }
    this.vel.set(0, 0, 0);
    this.yaw = THREE.MathUtils.degToRad(yawDeg);
    this.pitch = THREE.MathUtils.degToRad(pitchDeg);
    this.step(0.016);
  }

  _bindEvents() {
    if (typeof window === 'undefined') return;
    window.addEventListener('keydown', (e) => {
      if (!this.enabled) return;
      if (document.activeElement && ['TEXTAREA', 'INPUT', 'SELECT'].includes(document.activeElement.tagName)) return;
      const k = e.key.toLowerCase();
      if (k === 'w') this.keys.w = true;
      else if (k === 's') this.keys.s = true;
      else if (k === 'a') this.keys.a = true;
      else if (k === 'd') this.keys.d = true;
      else if (e.key === 'ArrowUp') { this.keys.up = true; e.preventDefault(); }
      else if (e.key === 'ArrowDown') { this.keys.down = true; e.preventDefault(); }
      else if (e.key === 'ArrowLeft') { this.keys.left = true; e.preventDefault(); }
      else if (e.key === 'ArrowRight') { this.keys.right = true; e.preventDefault(); }
      else if (e.key === 'Shift') this.keys.shift = true;
      else if (e.key === ' ') {
        this.keys.space = true;
        if (this.onGround) {
          this.vel.y = this.physics.playerParams.jumpVelocity;
          this.onGround = false;
        }
        e.preventDefault();
      }
    });

    window.addEventListener('keyup', (e) => {
      const k = e.key.toLowerCase();
      if (k === 'w') this.keys.w = false;
      else if (k === 's') this.keys.s = false;
      else if (k === 'a') this.keys.a = false;
      else if (k === 'd') this.keys.d = false;
      else if (e.key === 'ArrowUp') this.keys.up = false;
      else if (e.key === 'ArrowDown') this.keys.down = false;
      else if (e.key === 'ArrowLeft') this.keys.left = false;
      else if (e.key === 'ArrowRight') this.keys.right = false;
      else if (e.key === 'Shift') this.keys.shift = false;
      else if (e.key === ' ') this.keys.space = false;
    });

    let lookDrag = false, lastX = 0, lastY = 0;
    if (this.canvas) {
      this.canvas.addEventListener('mousedown', (e) => {
        if (!this.enabled) return;
        lookDrag = true;
        lastX = e.clientX;
        lastY = e.clientY;
        if (this.canvas.requestPointerLock) {
          try { this.canvas.requestPointerLock(); } catch (_) {}
        }
      });
      window.addEventListener('mousemove', (e) => {
        if (!this.enabled) return;
        if (document.pointerLockElement === this.canvas) {
          this.yaw -= (e.movementX || 0) * 0.0024;
          this.pitch = Math.max(-1.35, Math.min(1.35, this.pitch - (e.movementY || 0) * 0.0022));
        } else if (lookDrag) {
          const dx = e.clientX - lastX, dy = e.clientY - lastY;
          lastX = e.clientX; lastY = e.clientY;
          this.yaw -= dx * 0.0045;
          this.pitch = Math.max(-1.35, Math.min(1.35, this.pitch - dy * 0.0042));
        }
      });
      window.addEventListener('mouseup', () => { lookDrag = false; });
    }
  }

  // Programmatic walk step helper (for automated tests & scripted walkthroughs)
  moveStep(forwardDist, strafeDist = 0, dt = 0.05) {
    const steps = Math.max(1, Math.ceil(Math.hypot(forwardDist, strafeDist) / 0.12));
    const stepF = forwardDist / steps, stepS = strafeDist / steps;
    const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
    const rx =  Math.cos(this.yaw), rz = -Math.sin(this.yaw);
    for (let i = 0; i < steps; i++) {
      this.pos.x += fx * stepF + rx * stepS;
      this.pos.z += fz * stepF + rz * stepS;
      this._resolveCollisions();
    }
    this._syncCamera(0);
    this.physics.buildPlayerAvatarMarker(this.pos, this.yaw);
    if (this.physics && this.physics.playerAvatarGroup) {
      this.physics.playerAvatarGroup.visible = !this.enabled && (this.physics.markersGroup ? this.physics.markersGroup.visible : false);
    }
    if (this.onStatusChange) this.onStatusChange(this);
    return { pos: [Number(this.pos.x.toFixed(2)), Number(this.pos.y.toFixed(2)), Number(this.pos.z.toFixed(2))], hit: this.activeHit ? this.activeHit.label : null, zone: this.activeZone ? this.activeZone.label : null };
  }

  step(dt) {
    dt = Math.min(0.05, Math.max(0.001, dt));
    const pp = this.physics.playerParams;

    let moveF = (this.keys.w || this.keys.up ? 1 : 0) - (this.keys.s || this.keys.down ? 1 : 0) + this.joyMove.y;
    let moveS = (this.keys.d || this.keys.right ? 1 : 0) - (this.keys.a || this.keys.left ? 1 : 0) + this.joyMove.x;
    const moveLen = Math.hypot(moveF, moveS);
    if (moveLen > 1.0) { moveF /= moveLen; moveS /= moveLen; }

    const speed = this.keys.shift ? pp.sprintSpeed : pp.walkSpeed;
    const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
    const rx =  Math.cos(this.yaw), rz = -Math.sin(this.yaw);

    const targetVx = (fx * moveF + rx * moveS) * speed;
    const targetVz = (fz * moveF + rz * moveS) * speed;
    const accel = this.onGround ? 14.0 : 5.0;
    this.vel.x += (targetVx - this.vel.x) * Math.min(1.0, accel * dt);
    this.vel.z += (targetVz - this.vel.z) * Math.min(1.0, accel * dt);

    // Sub-step horizontal movement & collision resolution
    const subSteps = 2;
    const subDt = dt / subSteps;
    for (let s = 0; s < subSteps; s++) {
      this.pos.x += this.vel.x * subDt;
      this.pos.z += this.vel.z * subDt;
      this._resolveCollisions();
    }

    // Gravity & ground elevation support
    this.vel.y -= pp.gravity * dt;
    this.pos.y += this.vel.y * dt;

    const supportY = this._computeSupportGroundY();
    if (this.pos.y <= supportY) {
      this.pos.y = supportY;
      this.vel.y = 0;
      this.onGround = true;
    } else {
      this.onGround = false;
    }

    const horizSpeed = Math.hypot(this.vel.x, this.vel.z);
    if (this.onGround && horizSpeed > 0.25) {
      this.bobPhase += horizSpeed * dt * 2.4;
    }
    const bobOffset = (this.onGround && horizSpeed > 0.25) ? Math.sin(this.bobPhase) * 0.038 * Math.min(1.0, horizSpeed / pp.walkSpeed) : 0.0;

    this._syncCamera(bobOffset);
    this.physics.buildPlayerAvatarMarker(this.pos, this.yaw);
    if (this.physics && this.physics.playerAvatarGroup) this.physics.playerAvatarGroup.visible = !this.enabled && (this.physics.markersGroup ? this.physics.markersGroup.visible : false);
    if (this.onStatusChange) this.onStatusChange(this);
  }

  _computeSupportGroundY() {
    let groundY = 0.0;
    const pp = this.physics.playerParams;
    for (const col of this.physics.colliders) {
      if (col.type !== 'ground' && col.type !== 'solid') continue;
      const topY = col.pos.y + col.height * 0.5;
      // Only step onto surfaces within stepHeight of current footY
      if (topY > this.pos.y + pp.stepHeight + 0.05) continue;
      if (col.shape === 'cylinder' || col.shape === 'sphere') {
        const d = Math.hypot(this.pos.x - col.pos.x, this.pos.z - col.pos.z);
        if (d <= col.radius) {
          // Smoothly ramp height on curved knolls
          const t = col.type === 'ground' ? Math.max(0, 1.0 - Math.pow(d / col.radius, 2.0)) : 1.0;
          const h = col.type === 'ground' ? (col.pos.y - col.height * 0.5 + col.height * t) : topY;
          if (h > groundY) groundY = h;
        }
      } else {
        const dx = this.pos.x - col.pos.x, dz = this.pos.z - col.pos.z;
        const c = Math.cos(-col.rotY), s = Math.sin(-col.rotY);
        const lx = dx * c - dz * s, lz = dx * s + dz * c;
        if (Math.abs(lx) <= col.size.x * 0.5 && Math.abs(lz) <= col.size.z * 0.5) {
          if (topY > groundY) groundY = topY;
        }
      }
    }
    return groundY;
  }

  _resolveCollisions() {
    const pp = this.physics.playerParams;
    const pRad = pp.radius;
    const pMinY = this.pos.y + pp.stepHeight * 0.65;
    const pMaxY = this.pos.y + pp.height;

    this.activeHit = null;
    this.activeZone = null;

    for (const col of this.physics.colliders) {
      col._isColliding = false;
      col._isTriggered = false;

      const cMinY = col.pos.y - col.height * 0.5;
      const cMaxY = col.pos.y + col.height * 0.5;

      if (col.type === 'ground') continue;

      // Vertical overlap check
      if (pMaxY < cMinY || pMinY > cMaxY) {
        if (col.type === 'trigger' && this._insideTriggerIds.has(col.id)) {
          this._insideTriggerIds.delete(col.id);
          if (col.onExit) col.onExit(this);
        }
        continue;
      }

      if (col.shape === 'cylinder' || col.shape === 'sphere') {
        const dx = this.pos.x - col.pos.x;
        const dz = this.pos.z - col.pos.z;
        const dist = Math.hypot(dx, dz);
        const minDist = col.radius + pRad;
        if (dist < minDist) {
          if (col.type === 'trigger') {
            col._isTriggered = true;
            this.activeZone = col;
            if (!this._insideTriggerIds.has(col.id)) {
              this._insideTriggerIds.add(col.id);
              if (col.onEnter) col.onEnter(this);
              for (const fn of this.physics.triggerListeners) fn({ type: 'enter', collider: col, player: this });
            }
          } else {
            col._isColliding = true;
            this.activeHit = col;
            const nx = dist > 1e-5 ? dx / dist : 0;
            const nz = dist > 1e-5 ? dz / dist : 1;
            const pen = minDist - dist;
            this.pos.x += nx * pen;
            this.pos.z += nz * pen;
            const vn = this.vel.x * nx + this.vel.z * nz;
            if (vn < 0) {
              this.vel.x -= nx * vn;
              this.vel.z -= nz * vn;
            }
            if (col.onCollide) col.onCollide(this);
            for (const fn of this.physics.collideListeners) fn({ collider: col, normal: [nx, 0, nz], penetration: pen });
          }
        } else if (col.type === 'trigger' && this._insideTriggerIds.has(col.id)) {
          this._insideTriggerIds.delete(col.id);
          if (col.onExit) col.onExit(this);
          for (const fn of this.physics.triggerListeners) fn({ type: 'exit', collider: col, player: this });
        }
      } else {
        // OBB / AABB Box vs Capsule Circle in XZ plane
        const dx = this.pos.x - col.pos.x;
        const dz = this.pos.z - col.pos.z;
        const cosR = Math.cos(-col.rotY), sinR = Math.sin(-col.rotY);
        const lx = dx * cosR - dz * sinR;
        const lz = dx * sinR + dz * cosR;
        const hw = col.size.x * 0.5, hd = col.size.z * 0.5;

        const clx = Math.max(-hw, Math.min(hw, lx));
        const clz = Math.max(-hd, Math.min(hd, lz));
        const dlx = lx - clx, dlz = lz - clz;
        const distSq = dlx * dlx + dlz * dlz;

        if (distSq < pRad * pRad) {
          if (col.type === 'trigger') {
            col._isTriggered = true;
            this.activeZone = col;
            if (!this._insideTriggerIds.has(col.id)) {
              this._insideTriggerIds.add(col.id);
              if (col.onEnter) col.onEnter(this);
              for (const fn of this.physics.triggerListeners) fn({ type: 'enter', collider: col, player: this });
            }
          } else {
            col._isColliding = true;
            this.activeHit = col;
            let lnx = 0, lnz = 0, pen = 0;
            const dist = Math.sqrt(distSq);
            if (dist > 1e-5) {
              lnx = dlx / dist;
              lnz = dlz / dist;
              pen = pRad - dist;
            } else {
              const px = hw - Math.abs(lx), pz = hd - Math.abs(lz);
              if (px < pz) { lnx = lx >= 0 ? 1 : -1; pen = px + pRad; }
              else { lnz = lz >= 0 ? 1 : -1; pen = pz + pRad; }
            }
            const cPos = Math.cos(col.rotY), sPos = Math.sin(col.rotY);
            const wx = lnx * cPos - lnz * sPos;
            const wz = lnx * sPos + lnz * cPos;
            this.pos.x += wx * pen;
            this.pos.z += wz * pen;
            const vn = this.vel.x * wx + this.vel.z * wz;
            if (vn < 0) {
              this.vel.x -= wx * vn;
              this.vel.z -= wz * vn;
            }
            if (col.onCollide) col.onCollide(this);
            for (const fn of this.physics.collideListeners) fn({ collider: col, normal: [wx, 0, wz], penetration: pen });
          }
        } else if (col.type === 'trigger' && this._insideTriggerIds.has(col.id)) {
          this._insideTriggerIds.delete(col.id);
          if (col.onExit) col.onExit(this);
          for (const fn of this.physics.triggerListeners) fn({ type: 'exit', collider: col, player: this });
        }
      }
    }

    this.physics.updateMarkerColors();
  }

  _syncCamera(bobOffset = 0) {
    const eyeY = this.pos.y + this.physics.playerParams.eyeHeight + bobOffset;
    this.camera.position.set(this.pos.x, eyeY, this.pos.z);
    const cosP = Math.cos(this.pitch), sinP = Math.sin(this.pitch);
    const tx = this.pos.x - Math.sin(this.yaw) * cosP * 10.0;
    const ty = eyeY + sinP * 10.0;
    const tz = this.pos.z - Math.cos(this.yaw) * cosP * 10.0;
    this.camera.lookAt(new THREE.Vector3(tx, ty, tz));
    this.camera.updateMatrixWorld();
  }
}

  // ==========================================================================
  // STANDALONE VIEWER & `<triad-scene>` WEB COMPONENT API (v7.6 FPS + Colliders)
  // ==========================================================================
  function createEnvDataTexture(preset = 0) {
    const w = 64, h = 32;
    const data = new Uint8Array(w * h * 4);
    const presets = [
      { zen: [66, 122, 204], hor: [242, 198, 152], gnd: [122, 84, 56] },
      { zen: [208, 218, 236], hor: [248, 250, 255], gnd: [115, 120, 130] },
      { zen: [190, 205, 226], hor: [238, 244, 250], gnd: [118, 114, 108] },
      { zen: [20, 30, 64], hor: [230, 140, 68], gnd: [56, 38, 28] }
    ];
    const p = presets[preset] || presets[0];
    for (let y = 0; y < h; y++) {
      const v = y / (h - 1);
      for (let x = 0; x < w; x++) {
        const idx = (y * w + x) * 4;
        const c = v >= 0.5
          ? p.hor.map((hc, k) => Math.round(hc + (p.zen[k] - hc) * ((v - 0.5) * 2)))
          : p.gnd.map((gc, k) => Math.round(gc + (p.hor[k] - gc) * (v * 2)));
        data[idx] = c[0]; data[idx + 1] = c[1]; data[idx + 2] = c[2]; data[idx + 3] = 255;
      }
    }
    const envTex = new THREE.DataTexture(data, w, h);
    envTex.needsUpdate = true;
    return envTex;
  }

  const ENV_NAME_MAP = { sunset: 0, studio: 1, overcast: 2, night: 3 };

  class TriadViewer {
    constructor(target, options = {}) {
      this.container = typeof target === 'string' ? document.querySelector(target) : target;
      if (!this.container) throw new Error('Triad3D.mount: target container not found');
      this.options = Object.assign({
        envPreset: 0,
        exposure: 1.0,
        gui: true,
        hud: false,
        fps: false,
        colliders: false,
        bakeScreen: false,
        images: null,
        autoPlay: true,
        pixelRatio: Math.min(typeof window !== 'undefined' ? (window.devicePixelRatio || 1) : 1, 2)
      }, options);

      const cs = window.getComputedStyle(this.container);
      if (cs.position === 'static') this.container.style.position = 'relative';
      this.container.style.overflow = 'hidden';

      this.canvas = document.createElement('canvas');
      this.canvas.style.cssText = 'width:100%;height:100%;display:block;touch-action:none;outline:none;';
      this.container.appendChild(this.canvas);

      // Optional floating Triad.gui parameter panel
      this.guiPanelEl = null;
      this.guiRowsEl = null;
      if (this.options.gui !== false) {
        this.guiPanelEl = document.createElement('div');
        this.guiPanelEl.style.cssText = 'position:absolute;top:12px;right:12px;width:220px;background:rgba(255,255,255,0.92);backdrop-filter:blur(10px);border:1px solid rgba(148,163,184,0.45);border-radius:8px;padding:8px 10px;font-family:system-ui,-apple-system,sans-serif;font-size:11px;color:#0f172a;box-shadow:0 8px 24px rgba(15,23,42,0.12);display:none;z-index:10;';
        this.guiPanelEl.innerHTML = '<div style="font-weight:700;font-size:10px;letter-spacing:0.05em;color:#475569;margin-bottom:6px;display:flex;justify-content:space-between;"><span>SCENE PARAMETERS</span><span style="color:#2563eb;">LIVE</span></div><div class="triad-lib-gui-rows" style="display:flex;flex-direction:column;gap:5px;"></div>';
        this.guiRowsEl = this.guiPanelEl.querySelector('.triad-lib-gui-rows');
        this.container.appendChild(this.guiPanelEl);
      }

      // Optional compact telemetry pill
      this.hudEl = null;
      if (this.options.hud) {
        this.hudEl = document.createElement('div');
        this.hudEl.style.cssText = 'position:absolute;bottom:10px;left:10px;background:rgba(255,255,255,0.90);backdrop-filter:blur(8px);border:1px solid rgba(148,163,184,0.4);border-radius:999px;padding:4px 11px;font-family:ui-monospace,monospace;font-size:11px;color:#0f172a;box-shadow:0 4px 12px rgba(15,23,42,0.10);z-index:10;pointer-events:none;';
        this.hudEl.textContent = 'Triad3D v7.6 · Ready';
        this.container.appendChild(this.hudEl);
      }

      // Built-in FPS Crosshair & Collision Marker Status HUD Overlay
      this.fpsOverlayEl = document.createElement('div');
      this.fpsOverlayEl.style.cssText = 'position:absolute;inset:0;pointer-events:none;z-index:18;display:none;font-family:system-ui,-apple-system,sans-serif;';
      this.fpsOverlayEl.innerHTML = `
        <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:18px;height:18px;border:2px solid rgba(255,255,255,0.88);border-radius:50%;box-shadow:0 0 8px rgba(0,0,0,0.45);">
          <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:4px;height:4px;background:#10b981;border-radius:50%;"></div>
        </div>
        <div style="position:absolute;bottom:14px;left:50%;transform:translateX(-50%);background:rgba(15,23,42,0.88);color:#f8fafc;border:1px solid rgba(56,189,248,0.48);border-radius:999px;padding:6px 16px;font-size:11.5px;font-weight:600;display:flex;align-items:center;gap:12px;box-shadow:0 6px 20px rgba(0,0,0,0.35);backdrop-filter:blur(8px);white-space:nowrap;">
          <span style="color:#38bdf8;font-weight:700;">🏃 FPS WALK</span>
          <span><b>WASD / Arrows</b> Move · <b>Shift</b> Sprint · <b>Space</b> Jump · <b>Drag / Click</b> Look</span>
          <span class="triad-fps-pos" style="font-family:ui-monospace,monospace;color:#cbd5e1;">POS (0.0, 0.0, 0.0)</span>
          <span class="triad-fps-hit" style="padding:2px 8px;border-radius:4px;background:rgba(16,185,129,0.22);color:#34d399;font-family:ui-monospace,monospace;font-size:10.5px;">CLEAR</span>
        </div>
      `;
      this.container.appendChild(this.fpsOverlayEl);
      this.fpsPosEl = this.fpsOverlayEl.querySelector('.triad-fps-pos');
      this.fpsHitEl = this.fpsOverlayEl.querySelector('.triad-fps-hit');

      if (this.options.images && typeof this.options.images === 'object') {
        for (const [imgName, imgSrc] of Object.entries(this.options.images)) {
          registerUploadedImage(imgName, imgSrc, this.options.textureResolution || null);
        }
      }

      // Built-in Multi-Stage Bake-Time Loading Screen Overlay
      this.bakeOverlayEl = document.createElement('div');
      this.bakeOverlayEl.className = 'triad-bake-screen';
      this.bakeOverlayEl.style.cssText = 'position:absolute;inset:0;z-index:45;background:radial-gradient(circle at 50% 28%, rgba(15,23,42,0.96), rgba(4,7,15,0.99));backdrop-filter:blur(16px);display:none;flex-direction:column;align-items:center;justify-content:center;font-family:system-ui,-apple-system,sans-serif;color:#f8fafc;padding:24px;box-sizing:border-box;transition:opacity 0.35s ease;';
      this.bakeOverlayEl.innerHTML = `
        <div style="width:min(880px, 95%);background:rgba(15,23,42,0.88);border:1px solid rgba(56,189,248,0.42);border-radius:16px;padding:24px 28px;box-shadow:0 24px 60px rgba(0,0,0,0.65);">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
            <span class="bake-title" style="font-size:16px;font-weight:800;letter-spacing:0.04em;color:#38bdf8;">TRIAD3D v9.5 · SCENE & TEXTURE BAKE PIPELINE</span>
            <span class="bake-badge" style="padding:3px 10px;border-radius:999px;font-family:ui-monospace,monospace;font-size:11px;font-weight:700;background:rgba(56,189,248,0.18);color:#38bdf8;border:1px solid rgba(56,189,248,0.4);">BAKING...</span>
          </div>
          <div class="bake-subtitle" style="font-size:12.5px;color:#94a3b8;margin-bottom:16px;">Resampling uploaded textures, welding & batching geometry, baking shadows, and streaming spatial chunks...</div>
          <div style="width:100%;height:10px;background:rgba(30,41,59,0.9);border-radius:999px;overflow:hidden;border:1px solid rgba(71,85,105,0.5);margin-bottom:18px;">
            <div class="bake-bar" style="width:0%;height:100%;background:linear-gradient(90deg,#0ea5e9,#38bdf8,#34d399);transition:width 0.18s ease;"></div>
          </div>
          <div class="bake-stages" style="display:flex;flex-direction:column;gap:7px;font-family:ui-monospace,monospace;font-size:11.5px;margin-bottom:18px;background:rgba(2,6,23,0.65);border-radius:10px;padding:12px 14px;border:1px solid rgba(51,65,85,0.45);"></div>
          <div class="bake-metrics" style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px;"></div>
          <div style="display:flex;justify-content:space-between;align-items:center;font-size:11px;color:#64748b;">
            <span class="bake-footer-note">Tag-level image downscaling & chunk async streaming active</span>
            <button class="bake-dismiss-btn" style="background:linear-gradient(135deg,#0284c7,#2563eb);color:#fff;border:none;border-radius:8px;padding:6px 16px;font-size:11.5px;font-weight:700;cursor:pointer;">Enter 3D Scene →</button>
          </div>
        </div>
      `;
      this.container.appendChild(this.bakeOverlayEl);
      this.bakeOverlayEl.querySelector('.bake-dismiss-btn').addEventListener('click', () => {
        this.hideBakeScreen();
      });

      this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true, preserveDrawingBuffer: true });
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      this.renderer.setPixelRatio(this.options.pixelRatio);
      this.renderer.toneMappingExposure = parseFloat(this.options.exposure) || 1.0;

      this.scene = new THREE.Scene();
      const initEnv = typeof this.options.envPreset === 'string'
        ? (ENV_NAME_MAP[this.options.envPreset.toLowerCase()] || 0)
        : (parseInt(this.options.envPreset, 10) || 0);
      this.setEnvPreset(initEnv);

      this.perspCamera = new THREE.PerspectiveCamera(45, 1.6, 0.1, 2500);
      this.orthoCamera = new THREE.OrthographicCamera(-16, 16, 10, -10, -800, 2500);
      this.camera = this.perspCamera;
      this.isOrtho = false;

      this.runtime = new TriadSceneRuntime(this.scene, this.renderer);
      this.runtime.viewer = this;
      this.runtime.guiRowsEl = this.guiRowsEl;
      this.runtime.guiPanelEl = this.guiPanelEl;

      this.orbit = {
        target: new THREE.Vector3(0, 2.2, 0),
        spherical: { radius: 13.5, phi: 1.24, theta: 0.44 },
        updateCamera: () => {
          if (this.fpsController && this.fpsController.enabled) return;
          const s = this.orbit.spherical, t = this.orbit.target;
          const sinPhi = Math.sin(s.phi);
          const px = t.x + s.radius * sinPhi * Math.sin(s.theta);
          const py = t.y + s.radius * Math.cos(s.phi);
          const pz = t.z + s.radius * sinPhi * Math.cos(s.theta);
          this.perspCamera.position.set(px, py, pz);
          this.perspCamera.lookAt(t);
          this.perspCamera.updateMatrixWorld();
          this.orthoCamera.position.set(px, py, pz);
          this.orthoCamera.lookAt(t);
          const halfH = Math.max(1.0, s.radius * 0.42);
          const halfW = halfH * (this.perspCamera.aspect || 1.6);
          this.orthoCamera.left = -halfW; this.orthoCamera.right = halfW;
          this.orthoCamera.top = halfH; this.orthoCamera.bottom = -halfH;
          this.orthoCamera.updateProjectionMatrix();
          this.orthoCamera.updateMatrixWorld();
        }
      };

      if (this.options.camera) {
        const c = this.options.camera;
        if (c.target) this.orbit.target.set(c.target[0] || 0, c.target[1] || 0, c.target[2] || 0);
        if (c.radius !== undefined) this.orbit.spherical.radius = c.radius;
        if (c.theta !== undefined) this.orbit.spherical.theta = THREE.MathUtils.degToRad(c.theta);
        if (c.phi !== undefined) this.orbit.spherical.phi = THREE.MathUtils.degToRad(c.phi);
        if (c.fov !== undefined) { this.perspCamera.fov = c.fov; this.perspCamera.updateProjectionMatrix(); }
        if (c.ortho) this.setOrtho(true);
      }

      this.fpsController = new TriadFPSController(this.runtime.physics, this.perspCamera, this.canvas, (fps) => {
        this._updateFPSHud(fps);
        if (typeof this.options.onFPSState === 'function') this.options.onFPSState(fps);
      });

      this._bindControls();
      this.resize();
      this._resizeHandler = () => this.resize();
      window.addEventListener('resize', this._resizeHandler);

      this.clock = new THREE.Clock();
      this.isPaused = !this.options.autoPlay;
      this._disposed = false;
      this._readyToRender = false;
      this.lastCompileStats = null;

      if (this.options.files) {
        this.loadFiles(this.options.files);
      } else if (this.options.sml) {
        this.loadSML(this.options.sml);
      } else if (this.options.src) {
        this.loadURL(this.options.src);
      }

      if (this.options.colliders) this.setShowColliders(true);
      if (this.options.fps) this.setFPSMode(true);
      this._readyToRender = true;
      this.renderFrame();

      this._animate = () => {
        if (this._disposed || this.isPaused) return;
        requestAnimationFrame(this._animate);
        const dt = this.clock.getDelta();
        if (this.fpsController && this.fpsController.enabled) {
          this.fpsController.step(dt);
        }
        this.runtime.stepAnimations(dt, this.clock.elapsedTime);
        this.renderFrame();
      };
      if (!this.isPaused) requestAnimationFrame(this._animate);
    }

    _updateFPSHud(fps) {
      if (!this.fpsOverlayEl) return;
      const isFps = !!(this.fpsController && this.fpsController.enabled);
      this.fpsOverlayEl.style.display = isFps ? 'block' : 'none';
      if (this.hudEl) {
        this.hudEl.style.display = isFps ? 'none' : 'block';
      }
      if (this.fpsPosEl && fps && fps.pos) {
        this.fpsPosEl.textContent = `POS (${fps.pos.x.toFixed(1)}, ${fps.pos.y.toFixed(2)}, ${fps.pos.z.toFixed(1)})`;
      }
      if (this.fpsHitEl && fps) {
        if (fps.activeHit) {
          this.fpsHitEl.textContent = `🛑 COLLISION: ${fps.activeHit.label || fps.activeHit.id}`;
          this.fpsHitEl.style.background = 'rgba(239,68,68,0.28)';
          this.fpsHitEl.style.color = '#fca5a5';
        } else if (fps.activeZone) {
          this.fpsHitEl.textContent = `✨ TRIGGER ZONE: ${fps.activeZone.label || fps.activeZone.id}`;
          this.fpsHitEl.style.background = 'rgba(245,158,11,0.28)';
          this.fpsHitEl.style.color = '#fcd34d';
        } else {
          this.fpsHitEl.textContent = `CLEAR · ${this.runtime.physics.colliders.length} COLLIDERS`;
          this.fpsHitEl.style.background = 'rgba(16,185,129,0.22)';
          this.fpsHitEl.style.color = '#34d399';
        }
      }
    }

    setFPSMode(enabled) {
      this.fpsController.enabled = !!enabled;
      if (this.fpsController.enabled) {
        if (typeof document !== 'undefined' && document.activeElement && document.activeElement.blur) document.activeElement.blur();
        if (this.isOrtho) this.setOrtho(false);
        this.camera = this.perspCamera;
        this.runtime.physics.markersGroup.visible = !!this.options.colliders;
        if (this.guiPanelEl) this.guiPanelEl.style.display = 'none';
        this.fpsController.resetToSpawn();
      } else {
        if (this.guiPanelEl && this.guiRowsEl && this.guiRowsEl.children.length > 0 && this.options.gui !== false) {
          this.guiPanelEl.style.display = 'block';
        }
        if (typeof document !== 'undefined' && document.pointerLockElement === this.canvas && document.exitPointerLock) {
          try { document.exitPointerLock(); } catch (_) {}
        }
        this.orbit.updateCamera();
      }
      if (this.runtime.physics.playerAvatarGroup) {
        this.runtime.physics.playerAvatarGroup.visible = (!this.fpsController.enabled) && this.runtime.physics.markersGroup.visible;
      }
      this._updateFPSHud(this.fpsController);
      this.renderFrame();
      return this.fpsController.enabled;
    }

    setShowColliders(visible) {
      this.runtime.physics.markersGroup.visible = !!visible;
      this.runtime.physics.buildPlayerAvatarMarker(this.fpsController.pos, this.fpsController.yaw);
      if (this.runtime.physics.playerAvatarGroup) {
        this.runtime.physics.playerAvatarGroup.visible = (!!visible) && (!this.fpsController.enabled);
      }
      this.renderFrame();
      return this.runtime.physics.markersGroup.visible;
    }

    moveStep(forward = 0, strafe = 0, dt = 0.05) {
      const res = this.fpsController.moveStep(forward, strafe, dt);
      this._updateFPSHud(this.fpsController);
      this.renderFrame();
      return res;
    }

    getColliders() {
      return this.runtime.physics ? this.runtime.physics.colliders : [];
    }

    _bindControls() {
      let dragging = false, panning = false, lastX = 0, lastY = 0, downX = 0, downY = 0;
      const raycaster = new THREE.Raycaster();
      const ndc = new THREE.Vector2();

      this.canvas.addEventListener('contextmenu', e => e.preventDefault());
      this.canvas.addEventListener('mousedown', e => {
        if (this.fpsController && this.fpsController.enabled) return;
        const picked = pickNodeAtEvent(e);
        if (picked && picked.node) {
          _lastActiveNode = picked.node;
          picked.node._isActive = true;
          this.runtime.applyStyleToNode(picked.node);
        }
        dragging = true;
        panning = (e.button === 2 || e.shiftKey);
        lastX = downX = e.clientX;
        lastY = downY = e.clientY;
      });
      let _lastHoverNode = null;
      let _lastActiveNode = null;
      let _lastSelectedNode = null;
      const pickNodeAtEvent = (ev) => {
        const rect = this.canvas.getBoundingClientRect();
        if (!rect.width || !rect.height) return null;
        ndc.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
        ndc.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;
        raycaster.setFromCamera(ndc, this.camera);
        const hits = raycaster.intersectObjects(this.runtime.rootContainer.children, true);
        return (hits.length > 0 && hits[0].object.userData._smlNode) ? { node: hits[0].object.userData._smlNode, hit: hits[0] } : null;
      };
      this.setHoveredNode = (node) => {
        if (_lastHoverNode === node) return;
        if (_lastHoverNode) {
          _lastHoverNode._isHovered = false;
          if (_lastHoverNode.object3D) _lastHoverNode.object3D.userData._isHovered = false;
          this.runtime.applyStyleToNode(_lastHoverNode);
        }
        _lastHoverNode = node;
        if (node) {
          node._isHovered = true;
          if (node.object3D) node.object3D.userData._isHovered = true;
          this.runtime.applyStyleToNode(node);
          node.dispatchEvent('hover', { node });
        }
      };
      this.setSelectedNode = (node) => {
        if (_lastSelectedNode && _lastSelectedNode !== node) {
          _lastSelectedNode._isSelected = false;
          if (_lastSelectedNode.object3D) _lastSelectedNode.object3D.userData._isSelected = false;
          this.runtime.applyStyleToNode(_lastSelectedNode);
        }
        _lastSelectedNode = node;
        if (node) {
          node._isSelected = true;
          if (node.object3D) node.object3D.userData._isSelected = true;
          this.runtime.applyStyleToNode(node);
        }
      };

      window.addEventListener('mousemove', e => {
        if (this.fpsController && this.fpsController.enabled) return;
        if (!dragging) {
          if (e.target === this.canvas) {
            const picked = pickNodeAtEvent(e);
            this.setHoveredNode(picked ? picked.node : null);
          }
          return;
        }
        const dx = e.clientX - lastX, dy = e.clientY - lastY;
        lastX = e.clientX; lastY = e.clientY;
        if (panning) {
          const panScale = this.orbit.spherical.radius * 0.0015;
          const right = new THREE.Vector3(Math.cos(this.orbit.spherical.theta), 0, -Math.sin(this.orbit.spherical.theta));
          this.orbit.target.addScaledVector(right, -dx * panScale);
          this.orbit.target.y += dy * panScale;
        } else {
          this.orbit.spherical.theta -= dx * 0.006;
          this.orbit.spherical.phi = Math.max(0.06, Math.min(Math.PI * 0.49, this.orbit.spherical.phi - dy * 0.006));
        }
        this.orbit.updateCamera();
        if (this.isPaused) this.renderFrame();
      });
      window.addEventListener('mouseup', e => {
        if (this.fpsController && this.fpsController.enabled) return;
        if (_lastActiveNode) {
          _lastActiveNode._isActive = false;
          this.runtime.applyStyleToNode(_lastActiveNode);
          _lastActiveNode = null;
        }
        if (!dragging) return;
        dragging = false;
        if (Math.hypot(e.clientX - downX, e.clientY - downY) < 5) {
          const picked = pickNodeAtEvent(e);
          if (picked) {
            this.setSelectedNode(picked.node);
            let curr = picked.node;
            while (curr) {
              curr.dispatchEvent('click', picked.hit);
              curr = curr.parent;
            }
          } else {
            this.setSelectedNode(null);
          }
        }
      });
      this.canvas.addEventListener('wheel', e => {
        if (this.fpsController && this.fpsController.enabled) return;
        e.preventDefault();
        this.orbit.spherical.radius = Math.max(1.2, Math.min(900, this.orbit.spherical.radius * (1 + e.deltaY * 0.001)));
        this.orbit.updateCamera();
        if (this.isPaused) this.renderFrame();
      }, { passive: false });

      // Multi-touch 1-finger orbit + 2-finger pinch-zoom & pan
      let ts = { mode: 'none', lastX: 0, lastY: 0, lastDist: 0 };
      this.canvas.addEventListener('touchstart', e => {
        if (this.fpsController && this.fpsController.enabled) return;
        if (e.touches.length === 1) {
          ts = { mode: 'orbit', lastX: e.touches[0].clientX, lastY: e.touches[0].clientY, lastDist: 0 };
        } else if (e.touches.length === 2) {
          e.preventDefault();
          const t0 = e.touches[0], t1 = e.touches[1];
          ts = {
            mode: 'pinch',
            lastX: (t0.clientX + t1.clientX) * 0.5,
            lastY: (t0.clientY + t1.clientY) * 0.5,
            lastDist: Math.hypot(t1.clientX - t0.clientX, t1.clientY - t0.clientY)
          };
        }
      }, { passive: false });
      this.canvas.addEventListener('touchmove', e => {
        if (this.fpsController && this.fpsController.enabled) return;
        if (e.touches.length === 1 && ts.mode === 'orbit') {
          e.preventDefault();
          const t = e.touches[0];
          const dx = t.clientX - ts.lastX, dy = t.clientY - ts.lastY;
          ts.lastX = t.clientX; ts.lastY = t.clientY;
          this.orbit.spherical.theta -= dx * 0.0065;
          this.orbit.spherical.phi = Math.max(0.06, Math.min(Math.PI * 0.49, this.orbit.spherical.phi - dy * 0.0065));
          this.orbit.updateCamera();
          if (this.isPaused) this.renderFrame();
        } else if (e.touches.length === 2) {
          e.preventDefault();
          const t0 = e.touches[0], t1 = e.touches[1];
          const dist = Math.hypot(t1.clientX - t0.clientX, t1.clientY - t0.clientY);
          const mx = (t0.clientX + t1.clientX) * 0.5, my = (t0.clientY + t1.clientY) * 0.5;
          if (ts.lastDist > 5) {
            this.orbit.spherical.radius = Math.max(1.2, Math.min(900, this.orbit.spherical.radius * (ts.lastDist / Math.max(5, dist))));
          }
          const dx = mx - ts.lastX, dy = my - ts.lastY;
          const panScale = this.orbit.spherical.radius * 0.0016;
          const right = new THREE.Vector3(Math.cos(this.orbit.spherical.theta), 0, -Math.sin(this.orbit.spherical.theta));
          this.orbit.target.addScaledVector(right, -dx * panScale);
          this.orbit.target.y += dy * panScale;
          ts.lastDist = dist; ts.lastX = mx; ts.lastY = my;
          this.orbit.updateCamera();
          if (this.isPaused) this.renderFrame();
        }
      }, { passive: false });
      this.canvas.addEventListener('touchend', () => { ts.mode = 'none'; });
    }

    resize() {
      const w = Math.max(64, this.container.clientWidth || 640);
      const h = Math.max(64, this.container.clientHeight || 400);
      this.perspCamera.aspect = w / h;
      this.perspCamera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
      this.orbit.updateCamera();
      this.renderFrame();
    }

    renderFrame() {
      if (!this._readyToRender) return;
      if (this.runtime && this.runtime.skyDomeMesh) {
        this.runtime.skyDomeMesh.position.copy(this.camera.position);
        let dl = null;
        this.scene.traverse(o => { if (o.isDirectionalLight && !dl) dl = o; });
        if (dl && !this.runtime.skyUniforms && this.runtime.skyDomeMesh.material?.uniforms?.uSunDir) {
          this.runtime.skyDomeMesh.material.uniforms.uSunDir.value
            .subVectors(dl.position, dl.target.position)
            .normalize();
        }
      }
      if (this.camera && this.scene) {
        if (this.runtime && this.runtime.wetReflectors && this.runtime.wetReflectors.length) {
          for (const refl of this.runtime.wetReflectors) {
            refl.uniforms.uTime.value = this.clock ? this.clock.elapsedTime : 0;
            refl.renderReflection(this.renderer, this.scene, this.camera);
          }
        }
        const pc = this.runtime && this.runtime.postConfig ? this.runtime.postConfig : { bloom: 0, dof: false };
        if (pc.bloom > 0.01 || pc.dof || pc.fxaa || (pc.vignette && pc.vignette > 0.001)) {
          const w = this.renderer.domElement.width || 1280;
          const h = this.renderer.domElement.height || 720;
          if (!this._composer) {
            this._composer = new THREE.EffectComposer(this.renderer);
            this._renderPass = new THREE.RenderPass(this.scene, this.camera);
            this._bloomPass = new THREE.UnrealBloomPass({ x: w, y: h }, pc.bloom || 0.5, 0.4, pc.bloomThreshold || 0.72);
            this._bokehPass = new THREE.BokehPass(this.scene, this.camera, { maxblur: pc.dofBlur || 0.0014 });
            this._fxaaVignettePass = new THREE.ShaderPass({
              uniforms: {
                tDiffuse: { value: null },
                uResolution: { value: new THREE.Vector2(w, h) },
                uFxaa: { value: 0.0 },
                uVignette: { value: 0.0 }
              },
              vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`,
              fragmentShader: `
                precision highp float;
                uniform sampler2D tDiffuse;
                uniform vec2 uResolution;
                uniform float uFxaa;
                uniform float uVignette;
                varying vec2 vUv;
                void main() {
                  vec3 c = texture2D(tDiffuse, vUv).rgb;
                  if (uFxaa > 0.5) {
                    vec2 texel = 1.0 / max(uResolution, vec2(1.0));
                    vec3 cN = texture2D(tDiffuse, vUv + vec2(0.0, texel.y)).rgb;
                    vec3 cS = texture2D(tDiffuse, vUv - vec2(0.0, texel.y)).rgb;
                    vec3 cE = texture2D(tDiffuse, vUv + vec2(texel.x, 0.0)).rgb;
                    vec3 cW = texture2D(tDiffuse, vUv - vec2(texel.x, 0.0)).rgb;
                    float lumC = dot(c, vec3(0.299, 0.587, 0.114));
                    float lumAvg = dot((cN + cS + cE + cW) * 0.25, vec3(0.299, 0.587, 0.114));
                    float edge = clamp(abs(lumC - lumAvg) * 6.0, 0.0, 0.65);
                    c = mix(c, (cN + cS + cE + cW) * 0.25, edge);
                  }
                  if (uVignette > 0.001) {
                    float d = length(vUv - 0.5) * 1.414;
                    c *= mix(1.0, 1.0 - smoothstep(0.35, 1.05, d), clamp(uVignette, 0.0, 1.0));
                  }
                  gl_FragColor = vec4(c, 1.0);
                }
              `
            });
            this._composer.addPass(this._renderPass);
            this._composer.addPass(this._bloomPass);
            this._composer.addPass(this._bokehPass);
            this._composer.addPass(this._fxaaVignettePass);
          }
          this._renderPass.scene = this.scene;
          this._renderPass.camera = this.camera;
          this._bloomPass.enabled = pc.bloom > 0.01;
          this._bloomPass.strength = pc.bloom;
          this._bloomPass.threshold = pc.bloomThreshold;
          this._bokehPass.enabled = !!pc.dof;
          this._bokehPass.maxblur = pc.dofBlur || 0.0014;
          if (this._fxaaVignettePass) {
            this._fxaaVignettePass.enabled = !!(pc.fxaa || (pc.vignette && pc.vignette > 0.001));
            this._fxaaVignettePass.uniforms.uResolution.value.set(w, h);
            this._fxaaVignettePass.uniforms.uFxaa.value = pc.fxaa ? 1.0 : 0.0;
            this._fxaaVignettePass.uniforms.uVignette.value = pc.vignette || 0.0;
          }
          this._composer.setSize(w, h);
          this._composer.render();
        } else {
          this.renderer.render(this.scene, this.camera);
        }
      }
    }


    get chunks() { return this.runtime ? this.runtime.chunks : null; }

    setUploadedImage(name, dataUrlOrImg, defaultResolution = null) {
      registerUploadedImage(name, dataUrlOrImg, defaultResolution);
      return this;
    }

    getOptimizationReport() {
      const os = this.runtime ? this.runtime.optStats : {};
      const ch = (this.runtime && this.runtime.chunks) ? this.runtime.chunks.getStats() : { total: 0, loaded: 0 };
      const origKB = Math.round(TextureTelemetry.originalBytesTotal / 1024);
      const optKB = Math.round(TextureTelemetry.optimizedBytesTotal / 1024);
      const savedPct = origKB > 0 ? Math.max(0, Math.round((1 - optKB / origKB) * 100)) : 0;
      return {
        texturesProcessed: TextureTelemetry.texturesProcessed,
        downscaledTextures: TextureTelemetry.downscaledCount,
        normalsSkipped: TextureTelemetry.normalsSkippedCount,
        originalVramKB: origKB,
        optimizedVramKB: optKB,
        vramSavedPercent: savedPct,
        textureDetails: Array.from(TextureTelemetry.entries.values()),
        drawsBeforeOpt: os.drawsBeforeOpt || 0,
        drawsAfterOpt: os.drawsAfterOpt || 0,
        mergedGroups: os.mergedGroups || 0,
        instancedGroups: os.instancedGroups || 0,
        frozenMatrices: os.frozenMatrices || 0,
        lodGroups: os.lodGroups || 0,
        chunks: ch
      };
    }

    showBakeScreen(hold = true) {
      if (!this.bakeOverlayEl) return;
      this.bakeOverlayEl.style.display = 'flex';
      this.bakeOverlayEl.style.opacity = '1';
      this._populateBakeScreenSummary(100, 'BAKE COMPLETE · READY');
      if (!hold) {
        setTimeout(() => this.hideBakeScreen(), 900);
      }
    }

    hideBakeScreen() {
      if (!this.bakeOverlayEl) return;
      this.bakeOverlayEl.style.opacity = '0';
      setTimeout(() => {
        if (this.bakeOverlayEl) this.bakeOverlayEl.style.display = 'none';
      }, 280);
    }

    _populateBakeScreenSummary(pct = 100, badgeText = 'OPTIMIZED & READY') {
      if (!this.bakeOverlayEl) return;
      const cfg = (this.runtime && this.runtime.bakeConfig) ? this.runtime.bakeConfig : {};
      const rep = this.getOptimizationReport();
      const stats = this.lastCompileStats || { compileMs: 0, nodes: 0, triangles: 0, draws: 0 };

      const titleEl = this.bakeOverlayEl.querySelector('.bake-title');
      const subEl = this.bakeOverlayEl.querySelector('.bake-subtitle');
      const badgeEl = this.bakeOverlayEl.querySelector('.bake-badge');
      const barEl = this.bakeOverlayEl.querySelector('.bake-bar');
      const stagesEl = this.bakeOverlayEl.querySelector('.bake-stages');
      const metricsEl = this.bakeOverlayEl.querySelector('.bake-metrics');

      if (titleEl && cfg.title) titleEl.textContent = cfg.title;
      if (subEl && cfg.subtitle) subEl.textContent = cfg.subtitle;
      if (badgeEl) {
        badgeEl.textContent = badgeText;
        badgeEl.style.color = pct >= 100 ? '#34d399' : '#38bdf8';
        badgeEl.style.background = pct >= 100 ? 'rgba(16,185,129,0.2)' : 'rgba(56,189,248,0.18)';
      }
      if (barEl) barEl.style.width = `${Math.min(100, Math.max(0, pct))}%`;

      if (stagesEl) {
        const stages = [
          { pct: 20, name: '1. SML AST & Macro Expansion', detail: `${stats.nodes} nodes · ${stats.rules || 0} 3SS rules (${stats.compileMs} ms)` },
          { pct: 45, name: '2. Tag-Level Texture Resampling & Normals', detail: `${rep.texturesProcessed} textures (${rep.downscaledTextures} downscaled · ${rep.originalVramKB} KB → ${rep.optimizedVramKB} KB, -${rep.vramSavedPercent}% VRAM)` },
          { pct: 70, name: '3. Scoped Mesh Merging, Instancing & Freezing', detail: `${rep.drawsBeforeOpt} → ${rep.drawsAfterOpt} mesh draws · ${rep.mergedGroups} batches · ${rep.instancedGroups} instanced · ${rep.frozenMatrices} frozen` },
          { pct: 90, name: '4. 2048×2048 PCF Shadow Map & PMREM IBL Bake', detail: `${stats.triangles.toLocaleString()} active tris · ${this.renderer.info.render.culledShadows || 0} micro-shadows culled` },
          { pct: 100, name: '5. Spatial Chunk Async Streamer Ready', detail: `${rep.chunks.total} chunks registered (${rep.chunks.loaded} active in range · ${rep.chunks.unloaded} deferred)` }
        ];
        stagesEl.innerHTML = stages.map(s => {
          const done = pct >= s.pct;
          const icon = done ? '<span style="color:#34d399;">✔</span>' : '<span style="color:#38bdf8;">⏳</span>';
          return `<div style="display:flex;justify-content:space-between;gap:12px;color:${done ? '#e2e8f0' : '#64748b'};">
            <span>${icon} ${escapeHtml(s.name)}</span>
            <span style="color:#38bdf8;">${escapeHtml(s.detail)}</span>
          </div>`;
        }).join('');
      }

      if (metricsEl) {
        const cards = [
          { label: 'TEXTURE VRAM SAVED', val: `-${rep.vramSavedPercent}%`, sub: `${rep.originalVramKB} KB → ${rep.optimizedVramKB} KB` },
          { label: 'MESH DRAW CALLS', val: `${rep.drawsBeforeOpt} → ${rep.drawsAfterOpt}`, sub: `${rep.mergedGroups} Batches · ${rep.instancedGroups} Instanced` },
          { label: 'FROZEN & CULLED', val: `${rep.frozenMatrices}`, sub: `Static Matrices · ${this.renderer.info.render.culledShadows || 0} Shadows Culled` },
          { label: 'ASYNC CHUNKS', val: `${rep.chunks.loaded} / ${rep.chunks.total}`, sub: `${rep.chunks.activeTriangles.toLocaleString()} Streamed Tris` }
        ];
        metricsEl.innerHTML = cards.map(c => `
          <div style="background:rgba(15,23,42,0.9);border:1px solid rgba(56,189,248,0.28);border-radius:10px;padding:10px 12px;">
            <div style="font-size:9.5px;font-weight:700;color:#64748b;letter-spacing:0.04em;">${escapeHtml(c.label)}</div>
            <div style="font-size:17px;font-weight:800;color:#f8fafc;margin:3px 0;font-family:ui-monospace,monospace;">${escapeHtml(c.val)}</div>
            <div style="font-size:10.5px;color:#38bdf8;">${escapeHtml(c.sub)}</div>
          </div>
        `).join('');
      }
    }

    async runBakePipeline(options = {}) {
      const hold = options.hold !== undefined ? options.hold : (this.runtime && this.runtime.bakeConfig && this.runtime.bakeConfig.hold);
      if (this.bakeOverlayEl) {
        this.bakeOverlayEl.style.display = 'flex';
        this.bakeOverlayEl.style.opacity = '1';
      }
      this._populateBakeScreenSummary(25, 'STAGE 1/5 · AST & TEXTURES');
      await new Promise(r => setTimeout(r, 15));

      // Wait for any pending external/uploaded images in ExternalImageCache
      const pending = [];
      for (const [, entry] of ExternalImageCache) {
        if (entry.status === 'loading') {
          pending.push(new Promise(res => entry.listeners.push(() => res())));
        }
      }
      if (pending.length > 0) await Promise.all(pending);
      this._populateBakeScreenSummary(55, 'STAGE 2/5 · RESAMPLING & NORMALS');
      await new Promise(r => setTimeout(r, 15));

      // Stream initial in-range chunks
      if (this.runtime && this.runtime.chunks && this.runtime.chunks.chunks.size > 0) {
        this._populateBakeScreenSummary(80, 'STAGE 3/5 · STREAMING CHUNKS');
        this.runtime.chunks.updateForCamera(this.camera.position);
        await new Promise(r => setTimeout(r, 25));
      }

      this.renderer.shadowMap.needsUpdate = true;
      this.renderFrame();
      this._populateBakeScreenSummary(100, 'BAKE COMPLETE · READY');

      if (!hold) {
        setTimeout(() => this.hideBakeScreen(), options.autoHideMs || 450);
      }
      return this.getOptimizationReport();
    }

    loadFiles(vfsFiles) {
      const stats = this.runtime.compileVFSProject(vfsFiles);
      if (this.runtime.activeCameraNode && this.runtime.activeCameraNode.object3D && (!this.fpsController || !this.fpsController.enabled)) {
        const cn = this.runtime.activeCameraNode;
        const cObj = cn.object3D;
        this.perspCamera.fov = cObj.fov || 45;
        this.perspCamera.near = cObj.near || 0.1;
        this.perspCamera.far = cObj.far || 1500;
        this.perspCamera.updateProjectionMatrix();
        if (cObj.userData._smlTarget && this.orbit && this.orbit.spherical) {
          const t = cObj.userData._smlTarget;
          const off = new THREE.Vector3().subVectors(cObj.position, t);
          const rawLen = off.length();
          const rad = Math.max(0.5, isFinite(rawLen) ? rawLen : 5.0);
          const yNorm = Math.max(-0.999, Math.min(0.999, off.y / rad));
          const phi = Math.max(0.05, Math.min(Math.PI - 0.05, Math.acos(yNorm)));
          const theta = Math.atan2(off.x, off.z);
          this.orbit.target.copy(t);
          this.orbit.spherical.radius = rad;
          this.orbit.spherical.phi = phi;
          this.orbit.spherical.theta = theta;
          this.orbit.updateCamera();
        } else {
          this.perspCamera.position.copy(cObj.position);
          this.perspCamera.rotation.copy(cObj.rotation);
          this.perspCamera.updateMatrixWorld(true);
        }
      }
      if (this.fpsController) {
        this.fpsController.pos.copy(this.runtime.physics.spawnPos);
        this.fpsController.yaw = THREE.MathUtils.degToRad(this.runtime.physics.spawnYaw || 0);
        this.runtime.physics.buildPlayerAvatarMarker(this.fpsController.pos, this.fpsController.yaw);
        if (this.runtime.physics.playerAvatarGroup) {
          this.runtime.physics.playerAvatarGroup.visible = (!this.fpsController.enabled) && this.runtime.physics.markersGroup.visible;
        }
        this._updateFPSHud(this.fpsController);
      }
      this.renderer.shadowMap.needsUpdate = true;
      this.renderFrame();
      let tris = Math.round(this.renderer.info.render.triangles);
      let verts = 0;
      for (const n of this.runtime.allNodes) {
        if (n.object3D?.isMesh && n.object3D.geometry?.attributes?.position) {
          verts += n.object3D.geometry.attributes.position.count;
        }
      }
      this.lastCompileStats = {
        compileMs: parseFloat(stats.elapsed),
        nodes: stats.nodeCount,
        rules: stats.ruleCount,
        colliders: this.runtime.physics ? this.runtime.physics.colliders.length : 0,
        draws: this.renderer.info.render.calls,
        triangles: tris,
        vertices: verts
      };
      if (this.hudEl) {
        this.hudEl.textContent = `Compiled in ${this.lastCompileStats.compileMs} ms · ${this.lastCompileStats.nodes} nodes · ${this.lastCompileStats.colliders} colliders · ${tris.toLocaleString()} tris`;
      }
      if (this.runtime && this.runtime.bakeConfig && this.runtime.bakeConfig.enabled) {
        this.showBakeScreen(this.runtime.bakeConfig.hold);
      }
      return this.lastCompileStats;
    }

    loadSML(smlString) {
      return this.loadFiles({ 'main.sml': String(smlString || '') });
    }

    async loadURL(url) {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`Failed to fetch SML from ${url}: ${res.status}`);
      const text = await res.text();
      return this.loadSML(text);
    }

    setOrbitPose(tx, ty, tz, radius, thetaDeg, phiDeg) {
      this.orbit.target.set(tx, ty, tz);
      this.orbit.spherical.radius = radius;
      this.orbit.spherical.theta = THREE.MathUtils.degToRad(thetaDeg);
      this.orbit.spherical.phi = THREE.MathUtils.degToRad(phiDeg);
      this.orbit.updateCamera();
      this.renderFrame();
    }

    setOrtho(enabled) {
      this.isOrtho = !!enabled;
      this.camera = this.isOrtho ? this.orthoCamera : this.perspCamera;
      this.orbit.updateCamera();
      this.renderFrame();
    }

    setEnvPreset(preset) {
      const p = typeof preset === 'string' ? (ENV_NAME_MAP[preset.toLowerCase()] || 0) : (parseInt(preset, 10) || 0);
      this.renderer.envPreset = p;
      this.scene.environment = createEnvDataTexture(p);
      this.renderFrame();
    }

    setExposure(val) {
      this.renderer.toneMappingExposure = parseFloat(val) || 1.0;
      this.renderFrame();
    }

    setDebugPass(passIdx) {
      this.renderer.debugMode = parseInt(passIdx, 10) || 0;
      this.renderFrame();
    }

    snapshot(width = 2560, height = 1440) {
      const prevW = this.renderer.width, prevH = this.renderer.height, prevPR = this.renderer.getPixelRatio();
      this.renderer.setPixelRatio(1);
      this.renderer.setSize(width, height);
      this.perspCamera.aspect = width / height;
      this.perspCamera.updateProjectionMatrix();
      this.orbit.updateCamera();
      this.renderFrame();
      const dataUrl = this.canvas.toDataURL('image/png');
      this.renderer.setPixelRatio(prevPR);
      this.renderer.setSize(prevW, prevH);
      this.perspCamera.aspect = prevW / Math.max(1, prevH);
      this.perspCamera.updateProjectionMatrix();
      this.orbit.updateCamera();
      this.renderFrame();
      return dataUrl;
    }

    getElementById(id) { return this.runtime.getElementById(id); }
    querySelector(sel) { return this.runtime.querySelector(sel); }
    querySelectorAll(sel) { return this.runtime.querySelectorAll(sel); }
    pause() { this.isPaused = true; }
    play() { if (this.isPaused) { this.isPaused = false; this.clock.getDelta(); requestAnimationFrame(this._animate); } }
    dispose() {
      this._disposed = true;
      window.removeEventListener('resize', this._resizeHandler);
      this.runtime.clear();
    }
  }

  // Register `<triad-scene>` Declarative Custom Element if running in a browser
  if (typeof window !== 'undefined' && typeof customElements !== 'undefined' && !customElements.get('triad-scene')) {
    class TriadSceneElement extends HTMLElement {
      connectedCallback() {
        if (this._viewer) return;
        if (!this.style.display) this.style.display = 'block';
        if (!this.style.height && this.clientHeight < 20) this.style.height = '480px';
        const inlineScript = this.querySelector('script[type="text/sml"]');
        const inlineSml = inlineScript ? inlineScript.textContent : null;
        const src = this.getAttribute('src');
        const env = this.getAttribute('env') || 'sunset';
        const exp = parseFloat(this.getAttribute('exposure') || '1.0');
        const gui = this.getAttribute('gui') !== 'false';
        const hud = this.getAttribute('hud') === 'true';
        const fps = this.getAttribute('fps') === 'true' || this.hasAttribute('fps');
        const colliders = this.getAttribute('colliders') === 'true' || this.hasAttribute('colliders');
        let camOpt = null;
        const camAttr = this.getAttribute('camera');
        if (camAttr) {
          const parts = camAttr.split('|').map(s => s.trim().split(/[\s,]+/).map(Number));
          camOpt = {
            target: parts[0] || [0, 2, 0],
            radius: parts[1]?.[0] ?? 14,
            theta: parts[1]?.[1] ?? 25,
            phi: parts[1]?.[2] ?? 72
          };
        }
        this._viewer = new TriadViewer(this, {
          sml: inlineSml,
          src: !inlineSml ? src : null,
          envPreset: env,
          exposure: exp,
          gui,
          hud,
          fps,
          colliders,
          camera: camOpt
        });
      }
      disconnectedCallback() {
        if (this._viewer) {
          this._viewer.dispose();
          this._viewer = null;
        }
      }
    }
    customElements.define('triad-scene', TriadSceneElement);
  }


  const TRIAD3D_DOCS = {
    version: '11.5.0',
    overview: 'Triad3D v11.5 — Declarative (.sml + .3ss) & Procedural (.3js / THREE) WebGL2 Engine with 360-deg Dynamic Clouds, True Metals, Nested Transmission, Indoor Reflections, Shadow-Edge Contrast & Baked Explore Mode.',
    sceneAttributes: {
      sky: 'Hex color (e.g. "#080d18") or "none" to disable built-in sky dome.',
      'time-of-day': 'Hour 0..24 driving sun elevation/azimuth and sky/cloud palette.',
      'cloud-density / cloud-coverage / cloud-speed / cloud-scale / cloud-silver / cloud-shadow': 'Live-modifiable 360-deg non-raymarched cloud parameters.',
      'fog-color / fog-density / fog-near / fog-far / fog': 'Exponential or linear fog controls.',
      'bloom / bloom-threshold / dof / fxaa / vignette / exposure': 'Post-processing & ACES tone mapping.',
      'env / env-intensity / env-horizon / env-zenith / env-ground': 'Preset, HDRI url(...), or custom IBL colors.',
      'wet-floor / water / water-tint / water-color / water-distortion / water-amount': 'Planar wet-floor or FBM rippled water reflectors (with indoor oblique clipping).',
      'shadows / shadow-darkness / shadow-edge-boost / shadow-edge-sat': 'Shadow map & penumbra contrast controls.',
      'gravity / fps-spawn / fps-speed / fps-sprint / fps-jump / fps-radius / fps-eye-height': 'FPS capsule controller parameters.'
    },
    smlTags: {
      primitives: ['box (with border-radius)', 'sphere', 'cylinder', 'cone', 'torus', 'capsule', 'plane (with reflection="water|mirror|true")', 'ring', 'circle', 'disc', 'lathe', 'extrude', 'tube', 'surface', 'csg', 'mesh'],
      modelsAndAI: ['gltf', 'glb', 'model', 'obj', 'navmesh', 'agent'],
      procedural: ['component', 'particles', 'terrain', 'repeat', 'for', 'if', 'batch', 'optimize', 'chunk', 'canvas-texture'],
      lights: ['light', 'directional-light', 'point-light', 'spot-light', 'hemisphere-light', 'ambient-light']
    },
    scriptAPI: [
      'Triad.sky: setTimeOfDay(), setSun(), setClouds(), setColors()',
      'Triad.lighting: setShadowEdgeContrast({ boost, saturation, darkness })',
      'Triad.mode: set("explore" | "edit", opts), rebakeShadows(), getStats()',
      'Triad.agents, Triad.chunks, Triad.physics, Triad.optimize, Triad.post, Triad.camera, Triad.onTick'
    ],
    styles3SS: [
      'color, roughness, metalness (0% diffuse at 1.0), clearcoat, opacity, transparent, alpha-test, wireframe, side',
      'emissive, emissive-intensity (supported both inline and in 3SS)',
      'transmission (nested back-to-front), ior, thickness, attenuation-color',
      'reflection: water|mirror|wet-floor, reflection-amount, reflection-tint, reflection-distortion, reflection-speed',
      'surface-texture, parallax-scale, interior-depth, synthesize-normals, surface-pattern (13 built-in + 3 Paris)'
    ],
    threeSupport: [
      'Math: Vector2/3/4, Matrix3/4, Euler, Quaternion, Color, Box2/3, Sphere, Plane, Ray, Frustum, MathUtils',
      'Loaders: GLTFLoader, OBJLoader, RGBELoader, DRACOLoader, KTX2Loader, TextureLoader',
      'Lights & Shadows: 16 PointLights (1 shadow), 8 SpotLights (1 shadow), DirectionalLight (2048px PCF), HemisphereLight'
    ]
  };

  function printTriadHelp(topic) {
    const t = (topic || '').toLowerCase();
    let out = '';
    if (t === 'scene') out = JSON.stringify(TRIAD3D_DOCS.sceneAttributes, null, 2);
    else if (t === 'sml' || t === 'tags') out = JSON.stringify(TRIAD3D_DOCS.smlTags, null, 2);
    else if (t === '3ss' || t === 'css' || t === 'style') out = JSON.stringify(TRIAD3D_DOCS.styles3SS, null, 2);
    else if (t === 'three') out = JSON.stringify(TRIAD3D_DOCS.threeSupport, null, 2);
    else out = JSON.stringify(TRIAD3D_DOCS, null, 2);
    console.info('[Triad3D v11.5 Documentation]\n' + out);
    return TRIAD3D_DOCS;
  }

  return {
    version: '11.5.0',
    registerUploadedImage,
    TextureTelemetry,
    DOCS: TRIAD3D_DOCS,
    help: printTriadHelp,
    THREE,
    MeshBuilder: TriadMeshBuilder,
    noise: TriadNoise,
    PhysicsWorld: TriadPhysicsWorld,
    FPSController: TriadFPSController,
    TriadViewer,
    mount: (target, options) => new TriadViewer(target, options),
    registerGenerator: (name, fn) => BuiltinGenerators.set(name, fn),
    registerPattern: registerCustomPattern
  };
});