import { DEMO_SCENES } from '../scenes/demo-scenes.js';
import { MODELING_PLAN } from '../data/modeling-plan.js';
import { PORTRAIT_SAMPLES } from '../lib/visage-bridge.js';

function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'className') node.className = v;
    else if (k === 'textContent') node.textContent = v;
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v !== null && v !== undefined) node.setAttribute(k, String(v));
  }
  for (const child of children) {
    if (typeof child === 'string') node.appendChild(document.createTextNode(child));
    else if (child) node.appendChild(child);
  }
  return node;
}

const STUDIO_SNIPPETS = [
  {
    label: '+ Weeping Willow',
    sml: `  <tree pos="3.4 0.28 2.4" species="willow" seed="882" height="6.8" />`
  },
  {
    label: '+ Pine Tree',
    sml: `  <tree pos="-3.8 0.28 2.2" species="pine" seed="314" height="7.6" />`
  },
  {
    label: '+ Portrait Bust',
    sml: `  <portrait-head pos="0 0.88 1.6" cm-scale="0.026" subject="elena" hair-style="auto" wind="0.95" />`
  },
  {
    label: '+ Portrait Figure',
    sml: `  <figure pos="0 0.28 2.4" height="1.76" posture="contrapposto" portrait-subject="elena">\n    <hair style="auto" color="#181515" wind="0.85" />\n    <garment type="jeans" color="#243042" />\n    <garment type="tshirt" color="#1e293b" sleeve-length="0.54" />\n  </figure>`
  },
  {
    label: '+ Dynamic Cloth',
    sml: `  <cloth pos="0 1.6 1.8" width="1.1" height="1.4" pin="corners" wind="0.85" color="#47688a" />`
  }
];

export function createWorkbenchUI(root, callbacks) {
  root.innerHTML = '';

  const viewportHost = el('div', {
    id: 'triad-viewport',
    className: 'absolute inset-0 w-full h-full bg-slate-950'
  });

  const fallbackOverlay = el('div', {
    id: 'webgl-fallback',
    className: 'hidden absolute inset-0 z-30 flex items-center justify-center bg-slate-950/95 text-slate-200 p-6'
  }, [
    el('div', { className: 'max-w-md border border-slate-700 bg-slate-900 rounded-lg p-5 text-center' }, [
      el('h2', { className: 'font-display text-lg font-semibold text-white mb-2', textContent: 'WebGL Viewport Unavailable' }),
      el('p', { className: 'text-sm text-slate-400', textContent: 'The WebGL2 rendering context was lost or is unavailable in this browser.' })
    ])
  ]);

  const sceneButtons = new Map();
  const sceneSwitcher = el('div', {
    className: 'flex items-center gap-1 bg-slate-950/90 border border-slate-800 rounded-md p-1',
    role: 'group',
    'aria-label': 'Test scenes'
  });

  for (const scene of DEMO_SCENES) {
    const btn = el('button', {
      type: 'button',
      'data-scene-id': scene.id,
      className: 'px-2.5 py-1.5 rounded text-xs font-medium whitespace-nowrap transition-colors cursor-pointer',
      textContent: scene.name,
      onClick: () => callbacks.onSelectScene(scene.id)
    });
    sceneButtons.set(scene.id, btn);
    sceneSwitcher.appendChild(btn);
  }

  const btnHigh = el('button', {
    type: 'button',
    id: 'mode-high-btn',
    className: 'px-2.5 py-1.5 rounded text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer',
    textContent: 'v12 Crisp Default',
    onClick: () => callbacks.onSetQualityMode('high')
  });
  const btnLegacy = el('button', {
    type: 'button',
    id: 'mode-legacy-btn',
    className: 'px-2.5 py-1.5 rounded text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer',
    textContent: 'v11.5 Legacy',
    onClick: () => callbacks.onSetQualityMode('legacy')
  });
  const modeSwitcher = el('div', {
    className: 'flex items-center gap-1 bg-slate-950/90 border border-slate-800 rounded-md p-1',
    role: 'group',
    'aria-label': 'Engine quality comparison'
  }, [btnHigh, btnLegacy]);

  const studioToggleBtn = el('button', {
    type: 'button',
    id: 'toggle-plan-btn',
    className: 'px-3 py-1.5 rounded-md text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white whitespace-nowrap transition-colors cursor-pointer',
    textContent: 'Live SML Studio',
    onClick: () => togglePlanDrawer()
  });

  const downloadBtn = el('a', {
    id: 'download-engine-btn',
    href: '/triad3d.js',
    download: 'triad3d-v12.2.js',
    className: 'px-3 py-1.5 rounded-md text-xs font-medium bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-100 whitespace-nowrap transition-colors',
    textContent: 'Download triad3d.js'
  });

  const topBar = el('header', {
    className: 'absolute top-2.5 left-3 right-3 z-30 flex flex-wrap items-center justify-between gap-1.5 pointer-events-none'
  }, [
    el('div', {
      className: 'pointer-events-auto flex items-center gap-2.5 bg-slate-900/95 border border-slate-700/90 rounded-lg px-2.5 py-1.5 shadow-lg'
    }, [
      el('div', { className: 'flex items-baseline gap-1.5' }, [
        el('h1', { className: 'font-display text-sm font-bold tracking-tight text-white whitespace-nowrap', textContent: 'Triad3D Workbench' }),
        el('span', { className: 'font-mono-code text-[11px] font-medium text-sky-400 whitespace-nowrap', textContent: 'v12.3.0' })
      ]),
      el('div', { className: 'h-4 w-px bg-slate-700/80 hidden sm:block' }),
      sceneSwitcher
    ]),
    el('div', {
      className: 'pointer-events-auto flex items-center gap-1.5 bg-slate-900/95 border border-slate-700/90 rounded-lg px-2 py-1.5 shadow-lg'
    }, [
      modeSwitcher,
      studioToggleBtn,
      downloadBtn
    ])
  ]);

  // Bottom-left compact Quality Inspector & Controls panel
  const inspectorBody = el('div', { id: 'inspector-body', className: 'space-y-3 pt-2.5' });

  const statShadowMap = el('dd', { className: 'font-mono-code text-xs text-slate-100', textContent: '--' });
  const statTexel = el('dd', { className: 'font-mono-code text-xs text-sky-300', textContent: '--' });
  const statAA = el('dd', { className: 'font-mono-code text-xs text-emerald-300', textContent: '--' });

  const statsGrid = el('dl', {
    className: 'grid grid-cols-3 gap-2 bg-slate-950/90 border border-slate-800 rounded-md p-2.5'
  }, [
    el('div', {}, [
      el('dt', { className: 'text-[10px] uppercase tracking-wider text-slate-400', textContent: 'Shadow Map' }),
      statShadowMap
    ]),
    el('div', {}, [
      el('dt', { className: 'text-[10px] uppercase tracking-wider text-slate-400', textContent: 'Texel Size' }),
      statTexel
    ]),
    el('div', {}, [
      el('dt', { className: 'text-[10px] uppercase tracking-wider text-slate-400', textContent: 'Anti-Aliasing' }),
      statAA
    ])
  ]);

  const softnessValEl = el('span', { className: 'font-mono-code text-[11px] text-slate-300', textContent: '0.55 px' });
  const softnessInput = el('input', {
    id: 'shadow-softness-slider',
    type: 'range',
    min: '0.20',
    max: '2.00',
    step: '0.05',
    value: '0.55',
    className: 'triad-slider w-full',
    onInput: (e) => {
      const val = parseFloat(e.target.value);
      softnessValEl.textContent = `${val.toFixed(2)} px`;
      callbacks.onChangeShadowSoftness(val);
    }
  });

  const sunAzValEl = el('span', { className: 'font-mono-code text-[11px] text-slate-300', textContent: '38°' });
  const sunAzInput = el('input', {
    id: 'sun-azimuth-slider',
    type: 'range',
    min: '-140',
    max: '140',
    step: '1',
    value: '38',
    className: 'triad-slider w-full',
    onInput: (e) => {
      const deg = parseFloat(e.target.value);
      sunAzValEl.textContent = `${Math.round(deg)}°`;
      callbacks.onChangeSunAzimuth(deg);
    }
  });

  const windValEl = el('span', { className: 'font-mono-code text-[11px] text-sky-300', textContent: '1.00×' });
  const windInput = el('input', {
    id: 'wind-breeze-slider',
    type: 'range',
    min: '0.00',
    max: '2.00',
    step: '0.05',
    value: '1.00',
    className: 'triad-slider w-full',
    onInput: (e) => {
      const val = parseFloat(e.target.value);
      windValEl.textContent = `${val.toFixed(2)}×`;
      if (callbacks.onChangeWindStrength) callbacks.onChangeWindStrength(val);
    }
  });

  // Contextual Portrait 3DMM Controls (visible on Portrait 3DMM scene)
  const sampleButtons = new Map();
  const sampleRow = el('div', { className: PORTRAIT_SAMPLES.length <= 1 ? 'grid grid-cols-1 gap-1' : 'grid grid-cols-4 gap-1' });
  for (const sample of PORTRAIT_SAMPLES) {
    const sBtn = el('button', {
      type: 'button',
      'data-portrait-sample': sample.id,
      className: 'px-1.5 py-1 rounded text-[11px] font-medium bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 cursor-pointer transition-colors',
      textContent: sample.label,
      onClick: () => {
        if (callbacks.onSelectPortraitSample) callbacks.onSelectPortraitSample(sample.id);
      }
    });
    sampleButtons.set(sample.id, sBtn);
    sampleRow.appendChild(sBtn);
  }

  const photoFileInput = el('input', {
    id: 'portrait-upload-input',
    type: 'file',
    accept: 'image/*',
    className: 'hidden',
    onChange: (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        if (callbacks.onUploadPortrait) callbacks.onUploadPortrait(reader.result, file.name);
      };
      reader.readAsDataURL(file);
      e.target.value = '';
    }
  });

  const blinkBtn = el('button', {
    type: 'button',
    id: 'portrait-blink-btn',
    className: 'px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-[11px] font-medium text-slate-100 whitespace-nowrap cursor-pointer transition-colors',
    textContent: 'Blink',
    onClick: () => {
      if (callbacks.onTriggerBlink) callbacks.onTriggerBlink();
    }
  });

  const uploadBtn = el('button', {
    type: 'button',
    id: 'portrait-upload-btn',
    className: 'px-2.5 py-1 rounded bg-sky-600 hover:bg-sky-500 text-[11px] font-semibold text-white whitespace-nowrap cursor-pointer transition-colors',
    textContent: 'Upload',
    onClick: () => photoFileInput.click()
  });

  const hairStyleSelect = el('select', {
    id: 'portrait-hair-style-select',
    'aria-label': 'Hair style',
    className: 'flex-1 min-w-0 bg-slate-950 border border-slate-700 rounded px-2 py-1 text-[11px] text-slate-100 focus:border-sky-500 focus:outline-none',
    onChange: (e) => {
      if (callbacks.onChangeHairStyle) callbacks.onChangeHairStyle(e.target.value);
    }
  }, [
    el('option', { value: 'auto', textContent: 'Hair: Auto (Photo)' }),
    el('option', { value: 'long_wavy', textContent: 'Hair: Long Wavy' }),
    el('option', { value: 'flowing_straight', textContent: 'Hair: Straight' }),
    el('option', { value: 'bob', textContent: 'Hair: Bob' }),
    el('option', { value: 'short_crop', textContent: 'Hair: Short Crop' }),
    el('option', { value: 'curly_halo', textContent: 'Hair: Curly Halo' }),
    el('option', { value: 'updo_bun', textContent: 'Hair: Updo Bun' })
  ]);

  const portraitThumbImg = el('img', {
    id: 'portrait-source-thumb',
    src: PORTRAIT_SAMPLES[0].url,
    alt: 'Active source portrait photo',
    referrerPolicy: 'no-referrer',
    className: 'w-10 h-10 rounded object-cover border border-slate-600 shrink-0 bg-slate-950'
  });

  const portraitStatusEl = el('div', {
    id: 'portrait-status-line',
    className: 'font-mono-code text-[10px] text-sky-300 truncate',
    textContent: 'Visage 3DMM ready'
  });

  const portraitControlsSection = el('div', {
    id: 'portrait-studio-controls',
    className: 'hidden space-y-2 pt-2 border-t border-slate-800'
  }, [
    el('div', { className: 'flex items-center gap-2' }, [
      portraitThumbImg,
      el('div', { className: 'min-w-0 flex-1 space-y-1' }, [
        el('div', { className: 'flex items-center justify-between gap-2' }, [
          el('span', { className: 'text-[11px] font-medium text-slate-300', textContent: 'Source Photo -> 3DMM' }),
          portraitStatusEl
        ]),
        sampleRow
      ])
    ]),
    el('div', { className: 'flex items-center gap-1.5' }, [
      hairStyleSelect,
      blinkBtn,
      uploadBtn,
      photoFileInput
    ])
  ]);

  const cameraButtonsContainer = el('div', {
    className: 'flex items-center gap-1.5',
    role: 'group',
    'aria-label': 'Camera presets'
  });

  const controlsSection = el('div', { className: 'space-y-2.5' }, [
    el('div', {}, [
      el('div', { className: 'flex items-center justify-between mb-1' }, [
        el('label', { for: 'shadow-softness-slider', className: 'text-[11px] font-medium text-slate-300', textContent: 'PCF Penumbra Radius' }),
        softnessValEl
      ]),
      softnessInput
    ]),
    el('div', {}, [
      el('div', { className: 'flex items-center justify-between mb-1' }, [
        el('label', { for: 'sun-azimuth-slider', className: 'text-[11px] font-medium text-slate-300', textContent: 'Sun Azimuth Angle' }),
        sunAzValEl
      ]),
      sunAzInput
    ]),
    el('div', {}, [
      el('div', { className: 'flex items-center justify-between mb-1' }, [
        el('label', { for: 'wind-breeze-slider', className: 'text-[11px] font-medium text-slate-300', textContent: 'Cloth & Hair Wind Breeze' }),
        windValEl
      ]),
      windInput
    ]),
    portraitControlsSection,
    el('div', {}, [
      el('div', { className: 'text-[11px] font-medium text-slate-400 mb-1.5', textContent: 'Camera Views' }),
      cameraButtonsContainer
    ])
  ]);

  inspectorBody.appendChild(statsGrid);
  inspectorBody.appendChild(controlsSection);

  let inspectorCollapsed = false;
  const collapseBtn = el('button', {
    type: 'button',
    className: 'text-[11px] font-medium text-slate-400 hover:text-white px-1.5 py-0.5 rounded cursor-pointer',
    textContent: 'Hide',
    onClick: () => {
      inspectorCollapsed = !inspectorCollapsed;
      inspectorBody.classList.toggle('hidden', inspectorCollapsed);
      collapseBtn.textContent = inspectorCollapsed ? 'Expand' : 'Hide';
    }
  });

  const sceneCaptionEl = el('p', {
    className: 'text-[11px] text-slate-400 leading-snug mt-0.5',
    textContent: DEMO_SCENES[0].subtitle
  });

  const inspectorPanel = el('aside', {
    className: 'absolute bottom-3 left-3 z-20 w-[330px] max-w-[calc(100vw-24px)] max-h-[calc(100vh-7.25rem)] overflow-y-auto triad-scroll bg-slate-900/95 border border-slate-700/90 rounded-lg p-3 shadow-xl'
  }, [
    el('div', { className: 'flex items-start justify-between gap-2' }, [
      el('div', {}, [
        el('div', { className: 'font-display text-xs font-semibold text-white', textContent: 'Shadow & AA Quality Inspector' }),
        sceneCaptionEl
      ]),
      collapseBtn
    ]),
    inspectorBody
  ]);

  const orbitHint = el('div', {
    className: 'absolute bottom-3 right-3 z-10 hidden md:block bg-slate-900/90 border border-slate-800 rounded-md px-2.5 py-1.5 text-[11px] text-slate-300 pointer-events-none'
  }, [
    'Drag to orbit · Scroll to zoom · Right-drag to pan · Double-click surface to focus'
  ]);

  // Slide-over Drawer: Interactive Live SML Studio & v12.0 Modeling Docs
  let planOpen = false;
  let activePlanTab = 'studio';
  let currentSmlText = DEMO_SCENES[0].sml;
  let studioStatusMsg = '';

  const planTabs = [
    { id: 'studio', label: 'Live SML Studio' },
    { id: 'architecture', label: 'v12.0 Tag Guide' },
    { id: 'tree', label: 'Tree SML' },
    { id: 'human', label: 'Human SML' }
  ];

  const planTabButtons = new Map();
  const planContentHost = el('div', { className: 'flex-1 overflow-y-auto triad-scroll p-5 space-y-4' });

  let smlTextarea = null;
  let studioStatusEl = null;

  function renderPlanContent() {
    planContentHost.innerHTML = '';
    for (const [id, btn] of planTabButtons.entries()) {
      const isAct = id === activePlanTab;
      btn.className = isAct
        ? 'px-2.5 py-1.5 rounded text-xs font-semibold bg-sky-600 text-white whitespace-nowrap cursor-pointer'
        : 'px-2.5 py-1.5 rounded text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 whitespace-nowrap cursor-pointer';
    }

    if (activePlanTab === 'studio') {
      const snippetBar = el('div', { className: 'flex flex-wrap items-center gap-1.5' });
      for (const snip of STUDIO_SNIPPETS) {
        snippetBar.appendChild(
          el('button', {
            type: 'button',
            className: 'px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-[11px] font-medium text-sky-300 cursor-pointer transition-colors',
            textContent: snip.label,
            onClick: () => {
              if (!smlTextarea) return;
              const cur = smlTextarea.value;
              const closeIdx = cur.lastIndexOf('</scene>');
              if (closeIdx >= 0) {
                smlTextarea.value = cur.slice(0, closeIdx) + '\n' + snip.sml + '\n' + cur.slice(closeIdx);
              } else {
                smlTextarea.value = cur + '\n' + snip.sml;
              }
              currentSmlText = smlTextarea.value;
              const res = callbacks.onApplyCustomSML(currentSmlText);
              studioStatusMsg = res && res.ok ? `Inserted ${snip.label.slice(2)} & rebuilt scene` : (res && res.error ? res.error : '');
              if (studioStatusEl) studioStatusEl.textContent = studioStatusMsg;
            }
          })
        );
      }

      smlTextarea = el('textarea', {
        id: 'live-sml-editor',
        'aria-label': 'Live SML scene editor',
        spellcheck: 'false',
        className: 'w-full h-[360px] font-mono-code text-[11px] leading-relaxed bg-slate-950 border border-slate-700 focus:border-sky-500 focus:outline-none rounded-lg p-3.5 text-emerald-300 resize-y'
      });
      smlTextarea.value = currentSmlText;
      smlTextarea.addEventListener('input', () => {
        currentSmlText = smlTextarea.value;
      });

      studioStatusEl = el('span', {
        id: 'sml-studio-status',
        className: 'text-[11px] text-emerald-300 font-medium',
        textContent: studioStatusMsg || 'Edit any <tree>, <figure>, <sdf>, <sweep>, <loft>, or <csg> tag and apply live.'
      });

      const applyBtn = el('button', {
        type: 'button',
        id: 'apply-sml-btn',
        className: 'px-3.5 py-1.5 rounded-md bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-semibold cursor-pointer transition-colors',
        textContent: 'Apply Live SML',
        onClick: () => {
          currentSmlText = smlTextarea.value;
          const res = callbacks.onApplyCustomSML(currentSmlText);
          studioStatusMsg = res && res.ok ? 'Scene rebuilt cleanly' : `Error: ${res && res.error ? res.error : 'Invalid SML'}`;
          studioStatusEl.textContent = studioStatusMsg;
          studioStatusEl.className = res && res.ok
            ? 'text-[11px] text-emerald-300 font-medium'
            : 'text-[11px] text-rose-400 font-medium';
        }
      });

      const resetBtn = el('button', {
        type: 'button',
        className: 'px-3 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium cursor-pointer transition-colors',
        textContent: 'Reset Scene',
        onClick: () => {
          callbacks.onResetCurrentScene();
          studioStatusMsg = 'Reset to default scene SML';
          if (studioStatusEl) studioStatusEl.textContent = studioStatusMsg;
        }
      });

      planContentHost.appendChild(
        el('div', { className: 'space-y-3' }, [
          el('div', { className: 'space-y-1.5' }, [
            el('div', { className: 'text-[11px] font-medium text-slate-400', textContent: 'Quick Insert v12.0 Organic Elements' }),
            snippetBar
          ]),
          smlTextarea,
          el('div', { className: 'flex items-center justify-between gap-2' }, [
            el('div', { className: 'flex items-center gap-2' }, [applyBtn, resetBtn]),
            studioStatusEl
          ])
        ])
      );
    } else if (activePlanTab === 'architecture') {
      planContentHost.appendChild(
        el('p', {
          className: 'text-xs leading-relaxed text-slate-300',
          textContent: 'Triad3D v12.0 ships all 6 declarative organic modeling layers directly inside triad3d.js—so authors and LLMs write expressive SML tags instead of raw vertex buffers.'
        })
      );

      for (const pillar of MODELING_PLAN.pillars) {
        planContentHost.appendChild(
          el('article', { className: 'bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-1.5' }, [
            el('div', { className: 'flex items-center justify-between gap-2' }, [
              el('h3', { className: 'font-display text-sm font-semibold text-white', textContent: pillar.title }),
              el('span', { className: 'font-mono-code text-[11px] text-emerald-400 shrink-0', textContent: 'LIVE IN v12.0' })
            ]),
            el('p', { className: 'text-xs font-medium text-sky-200/90', textContent: pillar.tagline }),
            el('p', { className: 'text-xs text-slate-300 leading-relaxed pt-1', textContent: pillar.howItWorks }),
            el('p', { className: 'text-[11px] text-slate-400 pt-1' }, [
              el('strong', { className: 'text-slate-200 font-semibold', textContent: 'Best for: ' }),
              pillar.bestFor
            ])
          ])
        );
      }
    } else if (activePlanTab === 'tree') {
      planContentHost.appendChild(
        el('div', { className: 'space-y-3' }, [
          el('h3', { className: 'font-display text-sm font-semibold text-white', textContent: 'Declarative Botanical Modeling (<tree> + <sweep> + <foliage-layer>)' }),
          el('p', {
            className: 'text-xs text-slate-300 leading-relaxed',
            textContent:
              'Supported species: oak, pine, cypress, willow, birch. Deterministic seeded growth with Murray\'s Law tapering, flared buttress roots, hemispherical canopy normals, and crisp scalloped leaf shadows.'
          }),
          el('pre', {
            className: 'font-mono-code text-[11px] leading-relaxed bg-slate-950 border border-slate-800 rounded-lg p-4 text-emerald-300 overflow-x-auto select-text'
          }, [MODELING_PLAN.treeExampleSML])
        ])
      );
    } else if (activePlanTab === 'human') {
      planContentHost.appendChild(
        el('div', { className: 'space-y-3' }, [
          el('h3', { className: 'font-display text-sm font-semibold text-white', textContent: 'Skeleton-Driven Figure Modeling (<figure> + <skeleton> + <skin> + <garment>)' }),
          el('p', {
            className: 'text-xs text-slate-300 leading-relaxed',
            textContent:
              'Supports postures (neutral, contrapposto, heroic, stride), bilateral mirror="x", tapered anatomical bone chains, bone-attached <sdf-op> sculpt details, and procedurally pleated <garment> meshes.'
          }),
          el('pre', {
            className: 'font-mono-code text-[11px] leading-relaxed bg-slate-950 border border-slate-800 rounded-lg p-4 text-sky-300 overflow-x-auto select-text'
          }, [MODELING_PLAN.humanExampleSML])
        ])
      );
    }
  }

  const planTabBar = el('div', {
    className: 'flex items-center gap-1 px-5 py-2.5 border-b border-slate-800 overflow-x-auto bg-slate-950/60'
  });
  for (const t of planTabs) {
    const tb = el('button', {
      type: 'button',
      'data-plan-tab': t.id,
      textContent: t.label,
      onClick: () => {
        activePlanTab = t.id;
        renderPlanContent();
      }
    });
    planTabButtons.set(t.id, tb);
    planTabBar.appendChild(tb);
  }

  const planDrawer = el('section', {
    id: 'modeling-plan-drawer',
    'aria-label': 'Triad3D v12.0 Live SML Studio and Modeling Guide',
    className: 'hidden absolute top-16 bottom-3 right-3 z-30 w-[580px] max-w-[calc(100vw-24px)] bg-slate-900 border border-slate-700 rounded-xl shadow-2xl flex flex-col overflow-hidden'
  }, [
    el('div', { className: 'flex items-center justify-between gap-3 px-5 py-3.5 border-b border-slate-800 bg-slate-900' }, [
      el('div', {}, [
        el('h2', { className: 'font-display text-sm font-bold text-white', textContent: 'Triad3D v12.0 Organic Modeling Studio' }),
        el('p', { className: 'text-[11px] text-slate-400', textContent: 'Live SML authoring for <tree>, <figure>, <sdf>, <sweep>, <loft>, <mod> & <csg>' })
      ]),
      el('button', {
        type: 'button',
        id: 'close-plan-btn',
        className: 'px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 cursor-pointer',
        textContent: 'Close',
        onClick: () => togglePlanDrawer(false)
      })
    ]),
    planTabBar,
    planContentHost
  ]);

  function togglePlanDrawer(forceState) {
    planOpen = forceState !== undefined ? !!forceState : !planOpen;
    planDrawer.classList.toggle('hidden', !planOpen);
    studioToggleBtn.className = planOpen
      ? 'px-3 py-1.5 rounded-md text-xs font-semibold bg-slate-700 text-white whitespace-nowrap transition-colors cursor-pointer'
      : 'px-3 py-1.5 rounded-md text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white whitespace-nowrap transition-colors cursor-pointer';
    if (planOpen) renderPlanContent();
  }

  root.appendChild(viewportHost);
  root.appendChild(fallbackOverlay);
  root.appendChild(topBar);
  root.appendChild(inspectorPanel);
  root.appendChild(orbitHint);
  root.appendChild(planDrawer);

  function setActiveSceneUI(sceneObj) {
    currentSmlText = sceneObj.sml;
    studioStatusMsg = '';
    if (smlTextarea) smlTextarea.value = currentSmlText;
    if (studioStatusEl) studioStatusEl.textContent = 'Edit any <tree>, <figure>, <sdf>, <sweep>, <loft>, or <csg> tag and apply live.';

    for (const [id, btn] of sceneButtons.entries()) {
      const act = id === sceneObj.id;
      btn.className = act
        ? 'px-2.5 py-1.5 rounded text-xs font-semibold bg-slate-100 text-slate-950 whitespace-nowrap transition-colors cursor-pointer'
        : 'px-2.5 py-1.5 rounded text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 whitespace-nowrap transition-colors cursor-pointer';
    }
    sceneCaptionEl.textContent = sceneObj.subtitle;
    sunAzInput.value = String(sceneObj.defaultSunAzimuth);
    sunAzValEl.textContent = `${sceneObj.defaultSunAzimuth}°`;

    const hasPortrait = sceneObj.id === 'portrait' || sceneObj.id === 'figure';
    portraitControlsSection.classList.toggle('hidden', !hasPortrait);
    if (hasPortrait) {
      setActivePortraitSample('elena');
      setPortraitSourceThumb(PORTRAIT_SAMPLES[0].url, PORTRAIT_SAMPLES[0].label);
      hairStyleSelect.value = 'auto';
    }

    cameraButtonsContainer.innerHTML = '';
    for (const cam of sceneObj.cameras) {
      cameraButtonsContainer.appendChild(
        el('button', {
          type: 'button',
          'data-cam-id': cam.id,
          className: 'flex-1 px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-[11px] font-medium text-slate-200 whitespace-nowrap transition-colors cursor-pointer',
          textContent: cam.label,
          onClick: () => callbacks.onSelectCamera(cam.pose)
        })
      );
    }
  }

  function setActivePortraitSample(sampleId) {
    for (const [id, btn] of sampleButtons.entries()) {
      const act = id === sampleId;
      btn.className = act
        ? 'px-1.5 py-1 rounded text-[11px] font-semibold bg-sky-500 text-slate-950 border border-sky-400 cursor-pointer transition-colors'
        : 'px-1.5 py-1 rounded text-[11px] font-medium bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 cursor-pointer transition-colors';
    }
  }

  function setPortraitSourceThumb(srcUrl, label = 'Portrait') {
    if (srcUrl) {
      portraitThumbImg.src = srcUrl;
      portraitThumbImg.alt = `${label} reference photo`;
    }
  }

  function setPortraitStatus(msg) {
    portraitStatusEl.textContent = msg;
  }

  function updateQualityUI(stats) {
    const isLegacy = stats.mode === 'legacy-v11.5';
    btnHigh.className = !isLegacy
      ? 'px-2.5 py-1.5 rounded text-xs font-semibold bg-emerald-500 text-slate-950 whitespace-nowrap transition-colors cursor-pointer'
      : 'px-2.5 py-1.5 rounded text-xs font-medium text-slate-300 hover:text-white whitespace-nowrap transition-colors cursor-pointer';
    btnLegacy.className = isLegacy
      ? 'px-2.5 py-1.5 rounded text-xs font-semibold bg-amber-500 text-slate-950 whitespace-nowrap transition-colors cursor-pointer'
      : 'px-2.5 py-1.5 rounded text-xs font-medium text-slate-300 hover:text-white whitespace-nowrap transition-colors cursor-pointer';

    statShadowMap.textContent = `${stats.shadowMapSize}px`;
    statTexel.textContent = stats.shadowTexelCm ? `${stats.shadowTexelCm} cm` : '--';
    if (isLegacy) {
      statAA.textContent = '0× / Off';
      statAA.className = 'font-mono-code text-xs text-amber-400';
      softnessInput.value = '1.55';
      softnessValEl.textContent = '1.55 px';
      softnessInput.disabled = true;
    } else {
      const aaParts = [];
      if (stats.msaaSamples > 1) aaParts.push(`${stats.msaaSamples}× MSAA`);
      if (stats.fxaa311) aaParts.push('FXAA');
      statAA.textContent = aaParts.length ? aaParts.join('+') : 'Native';
      statAA.className = 'font-mono-code text-xs text-emerald-300';
      softnessInput.disabled = false;
      if (typeof stats.shadowSoftness === 'number') {
        softnessInput.value = String(stats.shadowSoftness.toFixed(2));
        softnessValEl.textContent = `${stats.shadowSoftness.toFixed(2)} px`;
      }
    }
  }

  renderPlanContent();

  return {
    viewportHost,
    fallbackOverlay,
    setActiveSceneUI,
    setActivePortraitSample,
    setPortraitSourceThumb,
    setPortraitStatus,
    setHairStyleUI: (val) => { hairStyleSelect.value = val; },
    updateQualityUI,
    togglePlanDrawer,
    setPlanTab: (tabId) => {
      activePlanTab = tabId;
      renderPlanContent();
    }
  };
}
