/**
 * VISAGE // FORGE — First-Principles Multi-View Hair Vision & Structure-Tensor Analyzer
 * 100% Pure Vanilla JS · Zero External ML Models
 *
 * Inspects portrait RGB image(s) + 25 anatomical landmarks to extract:
 *  1. Illumination-Invariant Foreground Hair Probability (row-matched backdrop + normalized-chromaticity skin shadow rejection)
 *  2. 5-Zone Silhouette Volume Profile (crown height, temple sweep, cheek/ear flank, jaw-neck drape,
 *     plus 3/4-view retro-auricular chignon/bun detection)
 *  3. Scalp Parting Detector (center part vs side part vs unparted buzz crop)
 *  4. 2D Structure-Tensor Strand Coherence & Wave Oscillation
 *  5. Pure Multi-Tone Hair Melanin & Specular Palette (rootRGB, midRGB, tipRGB, sheenRGB)
 */

import { clamp } from './math3d.js';

function smoothstep(e0, e1, x) {
  const t = clamp((x - e0) / (e1 - e0 || 1e-6), 0.0, 1.0);
  return t * t * (3.0 - 2.0 * t);
}

function sampleBoxRGB(data, W, H, nx, ny, rad = 3) {
  const cx = clamp(Math.round(nx * (W - 1)), 0, W - 1);
  const cy = clamp(Math.round(ny * (H - 1)), 0, H - 1);
  let r = 0, g = 0, b = 0, cnt = 0;
  for (let dy = -rad; dy <= rad; dy++) {
    const py = clamp(cy + dy, 0, H - 1);
    for (let dx = -rad; dx <= rad; dx++) {
      const px = clamp(cx + dx, 0, W - 1);
      const o = (py * W + px) * 4;
      r += data[o];
      g += data[o + 1];
      b += data[o + 2];
      cnt++;
    }
  }
  return [r / cnt, g / cnt, b / cnt];
}

function colorDist(a, b) {
  return Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
}

function rgbLum(c) {
  return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2];
}

function normChroma(c) {
  const s = c[0] + c[1] + c[2] + 1e-4;
  return [c[0] / s, c[1] / s];
}

/**
 * Build row-aware studio backdrop profile (immune to vertical studio lighting vignettes!)
 * plus illumination-invariant normalized-chromaticity skin model.
 */
function buildSceneAppearanceModels(data, W, H, lms) {
  const rowStops = [0.04, 0.16, 0.28, 0.42, 0.56, 0.68];
  const leftRows = rowStops.map((ry) => sampleBoxRGB(data, W, H, 0.025, ry, 4));
  const rightRows = rowStops.map((ry) => sampleBoxRGB(data, W, H, 0.975, ry, 4));
  const topCenter = sampleBoxRGB(data, W, H, 0.50, 0.022, 4);

  const skinPatches = [
    sampleBoxRGB(data, W, H, 0.5 * (lms.hairline[0] + lms.nasion[0]), 0.55 * lms.hairline[1] + 0.45 * lms.nasion[1], 4),
    sampleBoxRGB(data, W, H, 0.52 * lms.cheekLeft[0] + 0.48 * lms.noseTip[0], 0.5 * (lms.eyeLeft[1] + lms.alarLeft[1]), 4),
    sampleBoxRGB(data, W, H, 0.52 * lms.cheekRight[0] + 0.48 * lms.noseTip[0], 0.5 * (lms.eyeRight[1] + lms.alarRight[1]), 4),
    sampleBoxRGB(data, W, H, lms.chin[0], 0.60 * lms.lowerLipBottom[1] + 0.40 * lms.chin[1], 4),
  ];

  const skinMean = [0, 0, 0];
  for (const p of skinPatches) {
    skinMean[0] += p[0]; skinMean[1] += p[1]; skinMean[2] += p[2];
  }
  skinMean[0] /= skinPatches.length;
  skinMean[1] /= skinPatches.length;
  skinMean[2] /= skinPatches.length;

  const skinLum = Math.max(35.0, rgbLum(skinMean));
  const skinRG = normChroma(skinMean);

  const faceH = Math.abs(lms.chin[1] - lms.hairline[1]);
  const shirt = sampleBoxRGB(data, W, H, lms.chin[0], clamp(lms.chin[1] + 0.55 * faceH, 0.05, 0.97), 6);

  return { rowStops, leftRows, rightRows, topCenter, skinMean, skinLum, skinRG, shirt };
}

function getRowBackdropRGB(models, nx, ny) {
  if (ny < 0.08) return models.topCenter;
  const rows = nx < 0.5 ? models.leftRows : models.rightRows;
  const stops = models.rowStops;
  const yc = clamp(ny, stops[0], stops[stops.length - 1]);
  for (let i = 0; i < stops.length - 1; i++) {
    if (yc <= stops[i + 1]) {
      const f = (yc - stops[i]) / (stops[i + 1] - stops[i]);
      return [
        rows[i][0] * (1 - f) + rows[i + 1][0] * f,
        rows[i][1] * (1 - f) + rows[i + 1][1] * f,
        rows[i][2] * (1 - f) + rows[i + 1][2] * f,
      ];
    }
  }
  return rows[rows.length - 1];
}

/**
 * Evaluate illumination-invariant hair probability P_hair in [0, 1] at normalized (nx, ny).
 * Rejects both studio backdrop vignettes AND shadowed neck/temple/ear skin!
 */
function evalHairProb(data, W, H, nx, ny, models, checkShirt = false) {
  if (nx < 0.012 || nx > 0.988 || ny < 0.008 || ny > 0.96) return 0.0;
  const px = clamp(Math.round(nx * (W - 1)), 1, W - 2);
  const py = clamp(Math.round(ny * (H - 1)), 1, H - 2);
  const o = (py * W + px) * 4;
  const c = [data[o], data[o + 1], data[o + 2]];

  const bgLocal = getRowBackdropRGB(models, nx, ny);
  const dBg = colorDist(c, bgLocal);

  // Local 3x3 luminance gradient (detects fine hair strand texture)
  const oL = (py * W + (px - 1)) * 4;
  const oR = (py * W + (px + 1)) * 4;
  const oU = ((py - 1) * W + px) * 4;
  const oD = ((py + 1) * W + px) * 4;
  const gx = (data[oR] - data[oL]) * 0.3 + (data[oR + 1] - data[oL + 1]) * 0.59 + (data[oR + 2] - data[oL + 2]) * 0.11;
  const gy = (data[oD] - data[oU]) * 0.3 + (data[oD + 1] - data[oU + 1]) * 0.59 + (data[oD + 2] - data[oU + 2]) * 0.11;
  const gradMag = Math.hypot(gx, gy);

  // 1) Must clearly differ from same-row studio backdrop (or have strong strand texture + luminance offset)
  const fgProb = smoothstep(20.0, 42.0, dBg + gradMag * 0.35);
  if (fgProb < 0.02) return 0.0;

  // 2) Illumination-invariant skin-shadow rejection:
  // Shadowed skin on temples, ears, and neck preserves normalized (r, g) chromaticity!
  // Only count as hair if it is VERY dark relative to skin (lumRatio < 0.36) OR chromatically distinct from skin!
  const lum = rgbLum(c);
  const lumRatio = lum / models.skinLum;
  const rg = normChroma(c);
  const chromaDelta = Math.hypot(rg[0] - models.skinRG[0], rg[1] - models.skinRG[1]);

  const veryDarkHair = 1.0 - smoothstep(0.28, 0.44, lumRatio);
  const veryBrightBlondeHair = smoothstep(1.25, 1.55, lumRatio);
  const nonSkinChroma = smoothstep(0.042, 0.082, chromaDelta);
  const notSkinProb = Math.max(veryDarkHair, veryBrightBlondeHair, nonSkinChroma);

  let shirtAllow = 1.0;
  if (checkShirt) {
    const dShirt = colorDist(c, models.shirt);
    if (dShirt < 22.0 && gradMag < 10.0) {
      shirtAllow = smoothstep(10.0, 26.0, dShirt + gradMag * 0.8);
    }
  }

  return clamp(fgProb * notSkinProb * shirtAllow, 0.0, 1.0);
}

/**
 * Compute 2D Structure Tensor strand coherence & vertical wave oscillation.
 */
function analyzeStrandStructureTensor(data, W, H, nx0, ny0, nx1, ny1, models) {
  const x0 = clamp(Math.round(Math.min(nx0, nx1) * (W - 1)), 2, W - 3);
  const x1 = clamp(Math.round(Math.max(nx0, nx1) * (W - 1)), 2, W - 3);
  const y0 = clamp(Math.round(Math.min(ny0, ny1) * (H - 1)), 2, H - 3);
  const y1 = clamp(Math.round(Math.max(ny0, ny1) * (H - 1)), 2, H - 3);

  let jxx = 0, jxy = 0, jyy = 0, weightSum = 0;
  const rowAngles = [];

  const stepY = Math.max(1, Math.floor((y1 - y0) / 34));
  const stepX = Math.max(1, Math.floor((x1 - x0) / 34));

  for (let py = y0; py <= y1; py += stepY) {
    let rJxx = 0, rJxy = 0, rJyy = 0, rW = 0;
    for (let px = x0; px <= x1; px += stepX) {
      const pHair = evalHairProb(data, W, H, px / (W - 1), py / (H - 1), models, false);
      if (pHair < 0.45) continue;

      const lumAt = (x, y) => {
        const o = (y * W + x) * 4;
        return 0.299 * data[o] + 0.587 * data[o + 1] + 0.114 * data[o + 2];
      };
      const gx = 0.5 * (lumAt(px + 1, py) - lumAt(px - 1, py));
      const gy = 0.5 * (lumAt(px, py + 1) - lumAt(px, py - 1));

      jxx += pHair * gx * gx;
      jxy += pHair * gx * gy;
      jyy += pHair * gy * gy;
      weightSum += pHair;

      rJxx += pHair * gx * gx;
      rJxy += pHair * gx * gy;
      rJyy += pHair * gy * gy;
      rW += pHair;
    }
    if (rW > 2.0) {
      rowAngles.push(0.5 * Math.atan2(2.0 * rJxy, rJxx - rJyy));
    }
  }

  if (weightSum < 3.0) {
    return { coherence: 0.22, angleOscillation: 0.14 };
  }

  const coherence = clamp(Math.hypot(jxx - jyy, 2.0 * jxy) / (jxx + jyy + 1e-5), 0.0, 1.0);
  let osc = 0;
  for (let i = 1; i < rowAngles.length; i++) {
    let d = Math.abs(rowAngles[i] - rowAngles[i - 1]);
    if (d > Math.PI * 0.5) d = Math.PI - d;
    osc += d;
  }
  const angleOscillation = rowAngles.length > 2 ? osc / (rowAngles.length - 1) : 0.14;
  return { coherence, angleOscillation };
}

/**
 * Detect frontal scalp parting seam (center part vs left/right side part vs uniform buzz crop).
 */
function detectScalpParting(data, W, H, lms, models) {
  const cx = lms.hairline[0];
  const cy = lms.hairline[1];
  const faceW = Math.hypot(lms.cheekRight[0] - lms.cheekLeft[0], lms.cheekRight[1] - lms.cheekLeft[1]);
  const faceH = Math.abs(lms.chin[1] - lms.hairline[1]);

  const numBins = 41;
  const scores = new Float32Array(numBins);
  const offsets = new Float32Array(numBins);

  for (let bi = 0; bi < numBins; bi++) {
    const rel = -0.32 + (0.64 * bi) / (numBins - 1);
    offsets[bi] = rel;
    const xProbe = cx + rel * faceW;

    let seamLum = 0, leftLum = 0, rightLum = 0;
    let leftHair = 0, rightHair = 0;
    let cnt = 0;

    for (const dyFrac of [-0.115, -0.082, -0.052]) {
      const yProbe = cy + dyFrac * faceH;
      const cMid = sampleBoxRGB(data, W, H, xProbe, yProbe, 1);
      const cL   = sampleBoxRGB(data, W, H, xProbe - 0.052 * faceW, yProbe, 2);
      const cR   = sampleBoxRGB(data, W, H, xProbe + 0.052 * faceW, yProbe, 2);

      seamLum += rgbLum(cMid);
      leftLum += rgbLum(cL);
      rightLum += rgbLum(cR);
      leftHair += evalHairProb(data, W, H, xProbe - 0.062 * faceW, yProbe, models, false);
      rightHair += evalHairProb(data, W, H, xProbe + 0.062 * faceW, yProbe, models, false);
      cnt++;
    }

    seamLum /= cnt; leftLum /= cnt; rightLum /= cnt;
    leftHair /= cnt; rightHair /= cnt;

    const flankHair = Math.min(leftHair, rightHair);
    const localPeak = seamLum - Math.max(leftLum, rightLum);
    scores[bi] = Math.max(0.0, localPeak) * flankHair * (1.0 - 0.25 * (rel / 0.32) ** 2);
  }

  let bestIdx = Math.floor(numBins / 2);
  let bestScore = 0, meanScore = 0;
  for (let bi = 0; bi < numBins; bi++) {
    meanScore += scores[bi];
    if (scores[bi] > bestScore) {
      bestScore = scores[bi];
      bestIdx = bi;
    }
  }
  meanScore /= numBins;

  const partStrength = clamp((bestScore - meanScore) / 16.0, 0.0, 1.0);
  const partOffset = partStrength > 0.32 ? clamp(offsets[bestIdx] / 0.26, -0.45, 0.45) : 0.0;
  return { partOffset, partStrength };
}

/**
 * Analyze all input portrait views to produce a unified, photo-matched 3D Hair Groom Profile!
 */
export function analyzeReferenceHairGroom(views, poses = null) {
  if (!views || views.length === 0) return getDefaultHairProfile();

  let frontIdx = 0;
  let minAbsYaw = Infinity;
  for (let i = 0; i < views.length; i++) {
    const yaw = poses && poses[i] ? Math.abs(poses[i].ry) : Math.abs(views[i].initialPose?.yawRad || 0);
    if (yaw < minAbsYaw) {
      minAbsYaw = yaw;
      frontIdx = i;
    }
  }

  const fView = views[frontIdx];
  const { width: W, height: H, imageData, landmarks2D: lms } = fView;
  const data = imageData.data;
  const models = buildSceneAppearanceModels(data, W, H, lms);

  const cx = 0.5 * (lms.cheekLeft[0] + lms.cheekRight[0]);
  const faceW = Math.max(0.12, Math.abs(lms.cheekRight[0] - lms.cheekLeft[0]));
  const faceH = Math.max(0.14, Math.abs(lms.chin[1] - lms.hairline[1]));

  // 1) Crown Height Ratio above hairline
  let crownTopY = lms.hairline[1];
  for (let step = 1; step <= 42; step++) {
    const ny = lms.hairline[1] - (step / 42) * faceH * 0.50;
    if (ny < 0.008) break;
    let pRow = 0;
    for (const dx of [-0.14, -0.07, 0.0, 0.07, 0.14]) {
      pRow += evalHairProb(data, W, H, lms.hairline[0] + dx * faceW, ny, models, false);
    }
    if (pRow / 5 > 0.42) crownTopY = ny;
    else if (step > 4) break;
  }
  const crownHeightRatio = clamp((lms.hairline[1] - crownTopY) / faceH, 0.05, 0.44);

  // 2) Lateral Hairline Arch Drop (distinguishes sleek arched/swept hair in 1-photo mode like Elena
  // from a flat horizontal barbershop lineup like Marcus!)
  let latHairY = 0;
  for (const sgn of [-1, 1]) {
    const nx = cx + sgn * 0.36 * faceW;
    let lowestHairY = lms.hairline[1] - 0.02 * faceH;
    for (let s = -2; s <= 16; s++) {
      const ny = lms.hairline[1] + (s / 16) * 0.25 * faceH;
      if (evalHairProb(data, W, H, nx, ny, models, false) > 0.52) {
        lowestHairY = ny;
      } else if (s > 3) {
        break;
      }
    }
    latHairY += lowestHairY;
  }
  latHairY *= 0.5;
  const templeSweepScore = clamp((latHairY - lms.hairline[1]) / (0.18 * faceH), 0.0, 1.0);

  // 3) Cheek / Ear Flanking Hair Width (outside cheekLeft/Right -> jawLeft/Right)
  let earFlankSum = 0, earFlankCnt = 0;
  for (const sgn of [-1, 1]) {
    const cEdge = sgn < 0 ? lms.cheekLeft[0] : lms.cheekRight[0];
    const jEdge = sgn < 0 ? lms.jawLeft[0] : lms.jawRight[0];
    for (const outFrac of [0.11, 0.19, 0.28]) {
      for (const tY of [0.15, 0.50, 0.85]) {
        const bx = cEdge * (1 - tY) + jEdge * tY;
        const ny = lms.cheekLeft[1] * (1 - tY) + lms.jawLeft[1] * tY;
        earFlankSum += evalHairProb(data, W, H, bx + sgn * outFrac * faceW, ny, models, false);
        earFlankCnt++;
      }
    }
  }
  const earFlankCoverage = earFlankSum / Math.max(1, earFlankCnt);

  // 4) Jaw-to-Upper-Neck Drape Zone with Strand-Continuity Gate:
  // Flowing locks MUST pass down outside the cheeks/ears (earFlankCoverage > 0.22) to reach the neck;
  // gating by earFlankCoverage prevents dark crew-neck t-shirts/jackets on cropped-hair subjects from triggering drape!
  let drapeSum = 0, drapeCnt = 0, deepDrapeSum = 0, deepCnt = 0;
  for (const tY of [0.0, 0.35, 0.72]) {
    const ny = lms.jawLeft[1] + tY * (lms.chin[1] - lms.jawLeft[1]);
    for (const sgn of [-1, 1]) {
      for (const xFrac of [0.44, 0.56, 0.68]) {
        const p = evalHairProb(data, W, H, cx + sgn * xFrac * faceW, ny, models, true);
        drapeSum += p;
        drapeCnt++;
      }
    }
  }
  const rawNeckDrape = drapeSum / Math.max(1, drapeCnt);
  const neckDrapeCoverage = rawNeckDrape * smoothstep(0.14, 0.34, earFlankCoverage);

  // If jaw-neck drape is confirmed (> 0.35), trace further down toward shoulders to measure exact lock length!
  if (neckDrapeCoverage > 0.35) {
    for (const extraFrac of [0.10, 0.20, 0.30]) {
      const ny = lms.chin[1] + extraFrac * faceH;
      for (const sgn of [-1, 1]) {
        for (const xFrac of [0.46, 0.60, 0.74]) {
          deepDrapeSum += evalHairProb(data, W, H, cx + sgn * xFrac * faceW, ny, models, true);
          deepCnt++;
        }
      }
    }
  }
  const shoulderDrapeScore = deepCnt > 0 ? deepDrapeSum / deepCnt : 0.0;

  // 5) Multi-View 3/4 Retro-Auricular Chignon / Low Bun Detector
  let retroBunScore = 0.0, angledCount = 0;
  for (let vi = 0; vi < views.length; vi++) {
    const yawRad = poses && poses[vi] ? poses[vi].ry : (views[vi].initialPose?.yawRad || 0);
    if (Math.abs(yawRad) < 0.16) continue;
    const av = views[vi];
    const aModels = buildSceneAppearanceModels(av.imageData.data, av.width, av.height, av.landmarks2D);
    const aLms = av.landmarks2D;
    const aFW = Math.max(0.10, Math.abs(aLms.cheekRight[0] - aLms.cheekLeft[0]));
    const backDir = yawRad < 0 ? 1.0 : -1.0;
    const earAnchorX = backDir > 0 ? aLms.cheekRight[0] : aLms.cheekLeft[0];
    const earAnchorY = 0.42 * (backDir > 0 ? aLms.cheekRight[1] : aLms.cheekLeft[1]) +
                       0.58 * (backDir > 0 ? aLms.jawRight[1] : aLms.jawLeft[1]);

    let hits = 0, nS = 0;
    for (const offX of [0.12, 0.19, 0.26]) {
      for (const offY of [-0.06, 0.02, 0.10]) {
        hits += evalHairProb(av.imageData.data, av.width, av.height, earAnchorX + backDir * offX * aFW, earAnchorY + offY * aFW, aModels, false);
        nS++;
      }
    }
    retroBunScore += hits / Math.max(1, nS);
    angledCount++;
  }
  if (angledCount > 0) retroBunScore /= angledCount;

  // 6) Parting & Structure Tensor
  const parting = detectScalpParting(data, W, H, lms, models);
  const crownTensor = analyzeStrandStructureTensor(
    data, W, H,
    lms.hairline[0] - 0.22 * faceW,
    Math.max(0.01, crownTopY),
    lms.hairline[0] + 0.22 * faceW,
    lms.hairline[1] + 0.02 * faceH,
    models
  );

  let sideTensor = crownTensor;
  let silhouetteCurlScore = 0.0;
  if (neckDrapeCoverage > 0.35) {
    sideTensor = analyzeStrandStructureTensor(
      data, W, H,
      lms.cheekRight[0] + 0.04 * faceW,
      lms.cheekRight[1],
      lms.cheekRight[0] + 0.42 * faceW,
      Math.min(0.96, lms.chin[1] + 0.34 * faceH),
      models
    );

    // Measure outer silhouette wave/curl undulation along left & right hanging locks!
    let waveEnergy = 0, wavePairs = 0;
    for (const sgn of [-1, 1]) {
      const outerXs = [];
      for (let iy = 0; iy < 14; iy++) {
        const ny = lms.cheekLeft[1] + (iy / 13) * Math.min(0.95 - lms.cheekLeft[1], (lms.chin[1] - lms.cheekLeft[1]) + 0.30 * faceH);
        let maxOut = 0.38;
        for (let step = 0; step <= 26; step++) {
          const xf = 0.38 + (step / 26) * 0.56;
          if (evalHairProb(data, W, H, cx + sgn * xf * faceW, ny, models, true) > 0.48) {
            maxOut = xf;
          }
        }
        outerXs.push(maxOut);
      }
      for (let i = 1; i < outerXs.length - 1; i++) {
        const secondDiff = Math.abs(outerXs[i] - 0.5 * (outerXs[i - 1] + outerXs[i + 1]));
        waveEnergy += secondDiff;
        wavePairs++;
      }
    }
    silhouetteCurlScore = clamp((waveEnergy / Math.max(1, wavePairs)) * 18.0, 0.0, 1.0);
  }

  // 7) Pure Hair Pigment Extraction (strictly from high-confidence hair regions, zero skin bleed!)
  const hairPixels = [];
  const sampleZones = [
    // Upper crown band right above trichion
    [lms.hairline[0] - 0.26 * faceW, Math.max(0.012, crownTopY + 0.015), lms.hairline[0] + 0.26 * faceW, lms.hairline[1] - 0.018 * faceH],
  ];
  if (neckDrapeCoverage > 0.38) {
    sampleZones.push(
      [cx - 0.72 * faceW, lms.cheekLeft[1], cx - 0.48 * faceW, lms.chin[1]],
      [cx + 0.48 * faceW, lms.cheekRight[1], cx + 0.72 * faceW, lms.chin[1]]
    );
  }

  for (const [x0, y0, x1, y1] of sampleZones) {
    if (y1 <= y0 || x1 <= x0) continue;
    for (let iy = 0; iy < 12; iy++) {
      const ny = y0 + ((y1 - y0) * iy) / 11;
      for (let ix = 0; ix < 14; ix++) {
        const nx = clamp(x0 + ((x1 - x0) * ix) / 13, 0.02, 0.98);
        const p = evalHairProb(data, W, H, nx, ny, models, false);
        if (p > 0.72) {
          const c = sampleBoxRGB(data, W, H, nx, ny, 1);
          hairPixels.push({ lum: rgbLum(c), c });
        }
      }
    }
  }

  let rootRGB = [18, 17, 19];
  let midRGB  = [28, 26, 28];
  let tipRGB  = [48, 43, 44];
  let sheenRGB = [96, 94, 102];

  if (hairPixels.length >= 6) {
    hairPixels.sort((a, b) => a.lum - b.lum);
    const pick = (q) => hairPixels[clamp(Math.floor(q * (hairPixels.length - 1)), 0, hairPixels.length - 1)].c;
    const p18 = pick(0.18);
    const p52 = pick(0.52);
    const p78 = pick(0.78);
    const p92 = pick(0.92);

    rootRGB  = [clamp(Math.round(p18[0] * 0.86), 10, 220), clamp(Math.round(p18[1] * 0.86), 10, 220), clamp(Math.round(p18[2] * 0.86), 10, 220)];
    midRGB   = [clamp(Math.round(p52[0]), 16, 235), clamp(Math.round(p52[1]), 15, 235), clamp(Math.round(p52[2]), 15, 235)];
    tipRGB   = [clamp(Math.round(p78[0] * 1.12 + 8), 26, 245), clamp(Math.round(p78[1] * 1.10 + 7), 24, 245), clamp(Math.round(p78[2] * 1.08 + 7), 24, 245)];
    sheenRGB = [clamp(Math.round(p92[0] * 1.30 + 34), 62, 255), clamp(Math.round(p92[1] * 1.26 + 32), 58, 255), clamp(Math.round(p92[2] * 1.26 + 34), 60, 255)];
  }

  // 8) Hairstyle Archetype Classification
  let styleArchetype = 'tied_bun';
  let styleLabel = 'Center-Part Sleek + Low Bun';
  let drapeLengthCm = 5.2;
  let waviness = 0.14;
  let stiffness = 0.54;
  let bunRadiusCm = 0.0;

  if (neckDrapeCoverage > 0.34 || (earFlankCoverage > 0.42 && neckDrapeCoverage > 0.22)) {
    waviness = clamp(0.34 + sideTensor.angleOscillation * 1.05 + silhouetteCurlScore * 0.42, 0.22, 0.88);
    styleArchetype = waviness > 0.30 ? 'flowing_wavy' : 'flowing_straight';
    styleLabel = waviness > 0.52 ? 'Shoulder Curly Locks' : (waviness > 0.30 ? 'Shoulder Wavy Locks' : 'Flowing Layered Locks');
    // True metric arc length from crown/part (`y ~ +9.5 cm`) around temple down across front clavicles (`y ~ -18 cm`): 27.5..34 cm!
    drapeLengthCm = clamp(27.5 + shoulderDrapeScore * 7.0, 27.0, 34.5);
    stiffness = 0.20;
  } else if (
    retroBunScore > 0.28 ||
    crownTensor.coherence > 0.18
  ) {
    styleArchetype = 'tied_bun';
    const partDesc = Math.abs(parting.partOffset) < 0.13 ? 'Center-Part' : 'Side-Part';
    styleLabel = `${partDesc} Sleek + Low Bun`;
    drapeLengthCm = 5.4;
    waviness = 0.12;
    stiffness = 0.52;
    bunRadiusCm = clamp(2.25 + retroBunScore * 0.55, 2.15, 2.75);
  } else {
    styleArchetype = 'cropped_fade';
    styleLabel = 'Tapered Buzz Crop';
    drapeLengthCm = clamp(0.45 + crownHeightRatio * 1.5, 0.48, 0.88);
    waviness = 0.65;
    stiffness = 0.88;
    bunRadiusCm = 0.0;
  }

  return {
    styleArchetype,
    styleLabel,
    partOffset: styleArchetype === 'cropped_fade' ? 0.0 : parting.partOffset,
    partStrength: styleArchetype === 'cropped_fade' ? 0.0 : parting.partStrength,
    crownHeightRatio,
    templeSweepScore,
    earFlankCoverage,
    neckDrapeCoverage,
    shoulderDrapeScore,
    retroBunScore,
    drapeLengthCm,
    bunRadiusCm,
    waviness,
    stiffness,
    coherence: crownTensor.coherence,
    rootRGB,
    midRGB,
    tipRGB,
    sheenRGB,
  };
}

export function getDefaultHairProfile() {
  return {
    styleArchetype: 'tied_bun',
    styleLabel: 'Center-Part Sleek + Low Bun',
    partOffset: 0.0,
    partStrength: 0.65,
    crownHeightRatio: 0.22,
    templeSweepScore: 0.46,
    earFlankCoverage: 0.08,
    neckDrapeCoverage: 0.0,
    shoulderDrapeScore: 0.0,
    retroBunScore: 0.55,
    drapeLengthCm: 5.4,
    bunRadiusCm: 2.4,
    waviness: 0.12,
    stiffness: 0.52,
    coherence: 0.45,
    rootRGB: [18, 18, 20],
    midRGB: [26, 26, 30],
    tipRGB: [46, 46, 52],
    sheenRGB: [98, 102, 112],
  };
}
