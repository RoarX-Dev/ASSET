/**
 * VISAGE // FORGE — Pure Vanilla JS Parametric 3D Morphable Head & 360° Bust Engine (v10 Dense)
 * Master-Sculpted Human Asaro/Loomis Craniofacial Topology:
 *  - Planar-Anterior Frontal & Orbital Shelf (eliminates cylindrical wrap-back / fox-eye slant at all camera pitches!)
 *  - True Gonial Mandibular Border + Broad U-Oval Chin + Slender Submental Neck Tuck (zero ice-cream-cone V-jaw!)
 *  - Anatomically Seated Low-Profile Pinna Ears (strictly eye-to-subnasale height behind |theta| > 1.46 rad)
 *  - 79 Dense 3D Anatomical Landmarks + Real 3D Upper/Lower Eyelid Blink Morph Buffers
 */

import { applyDedicatedNoseAndSoftLipCarvers } from './anatomicalCarvers3D.js';

function clamp(v, lo, hi) {
  return v < lo ? lo : v > hi ? hi : v;
}

function mix(a, b, t) {
  return a + (b - a) * t;
}

function smoothstep(e0, e1, x) {
  const t = clamp((x - e0) / (e1 - e0 || 1e-8), 0, 1);
  return t * t * (3 - 2 * t);
}

function gauss(x, mu, sigma) {
  const d = (x - mu) / sigma;
  return Math.exp(-0.5 * d * d);
}

function gauss2D(x, y, mx, my, sx, sy) {
  const dx = (x - mx) / sx;
  const dy = (y - my) / sy;
  return Math.exp(-0.5 * (dx * dx + dy * dy));
}

/**
 * Clinical Ophthalmic Human Palpebral Fissure Contour (`dxEye` in [-1 = medial canthus .. +1 = lateral canthus]):
 *  - Asymmetric upper lid arch peaking just nasal to pupil center (`u ~ 0.43`, `dxEye ~ -0.14`)
 *  - Medial lacrimal caruncle / tear-duct beak (`u in [0, 0.14]`)
 *  - Asymmetric lower lid S-curve dipping just temporal to pupil center (`u ~ 0.58`, `dxEye ~ +0.16`)
 *  - Natural +1.5 mm anatomical lateral canthal elevation modulated by `canthalSlope`
 */
function evalPalpebralContour(dxEye, eyeY, eyeOpenH, canthalSlope) {
  const u = clamp(0.5 * (dxEye + 1.0), 0.0, 1.0);
  // Subtle +1.1 mm neutral anatomical lateral elevation (prevents exaggerated fox-eye slant in 3/4 & 90-deg side views!)
  const canthalLineY = eyeY + (0.042 + canthalSlope) * clamp(dxEye, -1.05, 1.05);
  const medialBeak = 1.0 - 0.22 * Math.exp(-(((u - 0.03) / 0.085) ** 2));
  const medialLowerFlat = 1.0 - 0.34 * Math.exp(-(((u - 0.05) / 0.105) ** 2));
  const upperShape = Math.pow(u, 0.76) * Math.pow(1.0 - u, 0.94) * 3.56 * medialBeak;
  const lowerShape = Math.pow(u, 1.08) * Math.pow(1.0 - u, 0.74) * 3.54 * medialLowerFlat;
  return {
    canthalLineY,
    upperEdge: canthalLineY + eyeOpenH * 1.06 * upperShape,
    lowerEdge: canthalLineY - eyeOpenH * 0.86 * lowerShape,
    u,
  };
}

function evalCatmullSpline(knots, vals, uQuery) {
  const n = knots.length;
  const u = clamp(uQuery, knots[0], knots[n - 1]);
  if (u >= knots[n - 1] - 1e-9) return vals[n - 1];
  let i = 0;
  while (i < n - 2 && u > knots[i + 1]) i++;

  // Chordal-weighted C1 Catmull-Rom with gentle corner-overshoot guard ONLY on >3.2x same-sign slope jumps (e.g. cervicomental corner):
  // Preserves 100% unclamped C2-like smoothness at local extrema (brow, subnasale, chin) while preventing upward submental overshoot!
  const secant = (k) => (vals[k + 1] - vals[k]) / Math.max(1e-9, knots[k + 1] - knots[k]);
  const tangentAt = (k) => {
    if (k <= 0) return secant(0);
    if (k >= n - 1) return secant(n - 2);
    const sPrev = secant(k - 1);
    const sNext = secant(k);
    const hPrev = Math.max(1e-9, knots[k] - knots[k - 1]);
    const hNext = Math.max(1e-9, knots[k + 1] - knots[k]);
    let m = (hPrev * sNext + hNext * sPrev) / (hPrev + hNext);
    if (sPrev * sNext > 0.0) {
      const minAbs = Math.min(Math.abs(sPrev), Math.abs(sNext));
      const maxAbs = Math.max(Math.abs(sPrev), Math.abs(sNext));
      if (maxAbs > 3.2 * minAbs) {
        m = Math.sign(m) * Math.min(Math.abs(m), 2.5 * minAbs);
      }
    }
    return m;
  };

  const t0 = knots[i];
  const t1 = knots[i + 1];
  const h = Math.max(1e-9, t1 - t0);
  const lt = (u - t0) / h;
  const lt2 = lt * lt;
  const lt3 = lt2 * lt;

  const p0 = vals[i];
  const p1 = vals[i + 1];
  const m0 = tangentAt(i) * h;
  const m1 = tangentAt(i + 1) * h;

  const h00 = 2.0 * lt3 - 3.0 * lt2 + 1.0;
  const h10 = lt3 - 2.0 * lt2 + lt;
  const h01 = -2.0 * lt3 + 3.0 * lt2;
  const h11 = lt3 - lt2;
  return h00 * p0 + h10 * m0 + h01 * p1 + h11 * m1;
}

export const DEFAULT_3DMM_WEIGHTS = {
  faceWidth: 0.0,         // [-1.6..+1.6] bizygomatic & cranial breadth
  faceHeight: 0.0,        // [-1.6..+1.6] mid/lower vertical facial index
  foreheadHeight: 0.0,    // [-1.6..+1.6] hairline height above brow
  jawWidth: 0.0,          // [-1.6..+1.6] mandibular gonion breadth
  cheekHollow: 0.0,       // [-1.5..+1.5] + = leaner buccal taper, - = fuller cheeks
  chinProjection: 0.0,    // [-1.6..+1.6] chin prominence
  chinWidth: 0.0,         // [-1.5..+1.5] chin arch breadth
  eyeSpacing: 0.0,        // [-1.6..+1.6] interpupillary distance
  eyeWidth: 0.0,          // [-1.5..+1.5] horizontal palpebral fissure length (endocanthion-to-exocanthion)
  eyeSize: 0.0,           // [-1.2..+1.2] palpebral fissure vertical opening
  eyeTilt: 0.0,           // [-1.2..+1.2] canthal tilt (0 = natural gentle upward lateral tilt)
  noseProjection: 0.0,    // [-1.6..+1.6] nasal tip & dorsum forward projection
  noseBridgeWidth: 0.0,   // [-1.5..+1.5] nasal bone / dorsum bridge width
  noseBridgeArch: 0.0,    // [-1.5..+1.5] dorsal hump (+) vs gentle slope (-)
  noseWidth: 0.0,         // [-1.6..+1.6] alar wing / nostril flare
  noseTipBall: 0.0,       // [-1.5..+1.5] pronasale tip ball fullness
  noseLength: 0.0,        // [-1.5..+1.5] vertical nasal length (+ = longer downward)
  mouthWidth: 0.0,        // [-1.6..+1.6] oral commissure width
  mouthHeight: 0.0,       // [-1.5..+1.5] vertical oral placement (+ = lower)
  upperLipFullness: 0.0,  // [-1.6..+1.6] upper vermilion height & Cupid's bow volume
  lowerLipFullness: 0.0,  // [-1.6..+1.6] lower vermilion pillow volume
  mouthCornerLift: 0.0,   // [-1.2..+1.2] oral commissure corner lift
  mouthOpen: 0.0,         // [0.0..+1.5] open laughing / smiling oral aperture & mandible drop
  browProminence: 0.0,    // [-1.5..+1.5] supraorbital ridge relief
  browHeight: 0.0,        // [-1.5..+1.5] vertical eyebrow height above eye
  browArch: 0.0,          // [-1.5..+1.5] eyebrow arch peak curvature
  browTilt: 0.0,          // [-1.5..+1.5] outer brow tail lift (+) vs drop (-)
  cheekbones: 0.0,        // [-1.5..+1.5] high zygomatic malar definition
  noseTipRoundness: 1.0,  // [0.20..1.80] dedicated 3D spherical tip blunting & rounding carver
  noseSideCarve: 1.0,     // [0.00..1.80] dedicated nasal sidewall, 3D nostril wings & supra-alar groove carver
  nasalCavityDepth: 1.0,  // [0.00..1.80] dedicated upward-recessed 3D nostril cavity & columella carver
  lipSoftness: 1.0,       // [0.25..1.80] dedicated 3D toroidal soft cushion lip roll & Taubin fairing
  mouthLineDepth: 0.0,    // [0.00..1.80] vision-matched 3D nasolabial mouth-line sculpting (0.0 on smooth young faces!)
  dimpleDepth: 0.0,       // [0.00..1.50] vision-matched cheek/commissure dimple hollow
  neckWidth: 0.0,         // [-1.2..+1.4] Neck Vision cylindrical cervical breadth
  craniumScale: 1.0,      // [0.86..1.16]
  earProminence: 1.0,     // [0.55..1.45]
  neckBustScale: 1.0,     // [0.85..1.18]
};

export function buildParameterGrid(density = 'standard') {
  const M = density === 'hd' ? 312 : (density === 'medium' ? 148 : 248);
  const R = density === 'hd' ? 288 : (density === 'medium' ? 136 : 228);

  // Dual-Axis 1024-Sample CDF Inversion:
  // 1) Horizontal columns (`thetas`): concentrates high sub-millimeter column density across BOTH
  //    the central nose (`|s| < 0.105`) AND bilateral palpebral fissures/canthi (`|s| ~ 0.145`)!
  const NS = 1024;
  const cdfU = new Float64Array(NS + 1);
  for (let i = 1; i <= NS; i++) {
    const s = ((i - 0.5) / NS) * 2.0 - 1.0; // [-1 .. +1] -> [-PI .. +PI]
    const absS = Math.abs(s);
    const rhoU =
      1.0 +
      2.5 * Math.exp(-((s / 0.100) ** 2)) +               // Nose tip dome, sidewalls, columella & Cupid's bow
      3.0 * Math.exp(-(((absS - 0.148) / 0.068) ** 2)) +   // Bilateral eyes, eyelids, medial caruncle & lateral canthi!
      1.4 * Math.exp(-((s / 0.340) ** 2)) +                // Full brows & oral commissures
      1.65 * Math.exp(-(((absS - 0.492) / 0.072) ** 2));   // High-poly 3D pinna ears, tragus, helix, ramus & gonial corner!
    cdfU[i] = cdfU[i - 1] + rhoU;
  }
  const totalRhoU = cdfU[NS] || 1.0;
  for (let i = 0; i <= NS; i++) cdfU[i] /= totalRhoU;

  const thetas = new Float64Array(M + 1);
  const uCoords = new Float64Array(M + 1);
  thetas[0] = -Math.PI;
  thetas[M] = Math.PI;
  uCoords[0] = 0.0;
  uCoords[M] = 1.0;
  let ju = 0;
  for (let m = 1; m < M; m++) {
    const u = m / M;
    while (ju < NS - 1 && cdfU[ju + 1] < u) ju++;
    const span = cdfU[ju + 1] - cdfU[ju];
    const frac = span > 1e-9 ? (u - cdfU[ju]) / span : 0.0;
    const normTheta = clamp((ju + frac) / NS, 0.0, 1.0);
    thetas[m] = (normTheta * 2.0 - 1.0) * Math.PI;
    uCoords[m] = u;
  }

  // 2) Vertical rows (`tVals`): ~0.35 mm sub-millimeter row spacing across eyelids (`t ~ 0.344`),
  //    rounded nasal tip & 3D nostril cavities (`t ~ 0.436`), and soft lips (`t ~ 0.508`)!
  const cdf = new Float64Array(NS + 1);
  for (let i = 1; i <= NS; i++) {
    const tMid = (i - 0.5) / NS;
    const rho =
      1.0 +
      4.4 * Math.exp(-(((tMid - 0.344) / 0.028) ** 2)) + // Ultra-smooth upper/lower eyelids, tarsal rims & cornea!
      3.6 * Math.exp(-(((tMid - 0.436) / 0.030) ** 2)) + // Blunt nasal tip ball, infratip, 3D nostril cavities & columella
      4.2 * Math.exp(-(((tMid - 0.508) / 0.034) ** 2)) + // Philtrum, soft upper lip cushion, kiss-line & soft lower lip pillow
      2.35 * Math.exp(-(((tMid - 0.556) / 0.035) ** 2)); // High-res diagonal mandibular border, gonion corner & cervicomental shelf
    cdf[i] = cdf[i - 1] + rho;
  }
  const totalRho = cdf[NS] || 1.0;
  for (let i = 0; i <= NS; i++) cdf[i] /= totalRho;

  const tVals = new Float64Array(R + 1);
  tVals[0] = 0.0;
  tVals[R] = 1.0;
  let j = 0;
  for (let r = 1; r < R; r++) {
    const u = r / R;
    while (j < NS - 1 && cdf[j + 1] < u) j++;
    const span = cdf[j + 1] - cdf[j];
    const frac = span > 1e-9 ? (u - cdf[j]) / span : 0.0;
    tVals[r] = clamp((j + frac) / NS, 0.0, 1.0);
  }

  return { M, R, thetas, uCoords, tVals };
}

const PROFILE_KNOTS = [
  0.00, // 0: Crown vertex pole
  0.08, // 1: Upper frontal / parietal dome
  0.17, // 2: Forehead trichion / parietal boss
  0.27, // 3: Supraorbital brow / temporal / upper occiput
  0.35, // 4: Eye / zygomatic arch peak / occipital prominence
  0.44, // 5: Mid-cheek buccal / mid-ear / lower occiput
  0.52, // 6: Oral / gonion jaw corner / mastoid-inion tuck
  0.59, // 7: Menton chin tip (front) / lower mandibular ramus (side)
  0.65, // 8: Submental throat tuck / slender upper neck
  0.75, // 9: Mid-lower anatomical neck / SCM column
  0.86, // 10: Classical portrait bust shoulders & clavicular cut
  0.94, // 11: Sculpted museum plinth outer rim
  1.00, // 12: Flat pedestal bottom center cap
];

/**
 * Evaluate 3D position (x, y, z) in metric cm on our Human Asaro/Loomis Cranio-Cervical-Bust manifold.
 */
export function evaluateHeadBustPoint(theta, t, w = DEFAULT_3DMM_WEIGHTS) {
  const sinT = Math.sin(theta);
  const cosT = Math.cos(theta);
  const absTheta = Math.abs(theta);
  const sgnX = theta >= 0 ? 1.0 : -1.0;

  const faceW   = 1.0 + 0.080 * (w.faceWidth || 0);
  const faceH   = 1.0 + 0.072 * (w.faceHeight || 0);
  const fhShift = 0.58 * (w.foreheadHeight || 0);
  const jawW    = 1.0 + 0.110 * (w.jawWidth || 0);
  const chinP   = 0.48 * (w.chinProjection || 0);
  const chinWid = 1.0 + 0.24 * (w.chinWidth || 0);
  const hollow  = w.cheekHollow || 0.0;
  const cranS   = clamp((w.craniumScale ?? 1.0), 0.86, 1.15);
  const bustS   = w.neckBustScale ?? 1.0;
  const neckW   = clamp((1.0 + 0.13 * (w.neckWidth || 0)) * mix(1.0, bustS, 0.65), 0.82, 1.22);
  const earS    = w.earProminence ?? 1.0;
  const malarG  = 1.0 + 0.26 * (w.cheekbones || 0);
  const browG   = 1.0 + 0.26 * (w.browProminence || 0);

  const legacyLip = w.lipFullness || 0.0;
  const upLipW = w.upperLipFullness !== undefined ? w.upperLipFullness : legacyLip;
  const loLipW = w.lowerLipFullness !== undefined ? w.lowerLipFullness : legacyLip;
  const mOpen  = clamp(w.mouthOpen || 0.0, 0.0, 1.55);
  const jawOpenDrop = 0.92 * mOpen;

  // 1. Reference-Faithful Human Cranio-Cervical & V-Tapered Trapezius/Shoulder Bust Curves:
  //    Natural ~4.4 cm human menton-to-suprasternal throat length (`Y = -7.64 -> -12.1 cm` front) paired with a
  //    continuous V-tapered trapezius web starting just below chin level (`Y_SIDE = -7.88 -> -9.90 -> -12.25 cm` at ~23.5 deg slope —
  //    ZERO giraffe pipe & ZERO upside-down `T` shelf, matching `elena-front.jpg`, `aria-front.jpg` & `marcus-front.jpg`!)
  const Y_FRONT = [
    10.42 * cranS + fhShift * 0.30, // 0: Compact human crown vertex pole
     9.78 * cranS + fhShift * 0.38, // 1: Rounded upper frontal dome
     8.32 + fhShift * 0.54,         // 2: Natural forehead trichion (~6.75 cm above eyeY)
     4.00 * faceH,                  // 3: Supraorbital brow level
     1.54 * faceH,                  // 4: Orbit / eye center plane
    -1.74 * faceH,                  // 5: Maxilla / subnasale plane
    -4.56 * faceH - jawOpenDrop * 0.45, // 6: Oral / labiomental plane (drops smoothly when laughing!)
    -7.30 * faceH - jawOpenDrop,    // 7: Menton chin bottom (true lowest point of mandibular symphysis!)
    -7.78 * mix(1.0, faceH, 0.55) - jawOpenDrop * 0.30, // 8: Smooth ~112-deg cervicomental hyoid curve (matches `image-16` & `elena-right.jpg` — ZERO double-chin & ZERO sharp L-corner!)
   -11.65,                          // 9: Mid-lower anterior throat descending cleanly from hyoid into suprasternal pit
   -14.75,                          // 10: Suprasternal notch / clavicular manubrium chest
   -17.35,                          // 11: Sculpted portrait bust lower pectoral rim
   -17.85,                          // 12: Flat pedestal bottom center cap
  ];

  const Z_FRONT = [
    -1.65,                          // 0: Crown pole
     1.72 * cranS,                  // 1: Smooth rounded upper frontal dome
     5.28 * cranS,                  // 2: Natural ~7-deg sloping human forehead
     5.80,                          // 3: Smooth supraorbital brow & glabella plane (zero harsh overhang!)
     5.42,                          // 4: Nasion/radix plane
     5.54,                          // 5: Ortho-gnathic maxillary support (recessed slightly so nasal pyramid stands proudly!)
     5.46,                          // 6: Balanced alveolar support (prevents prognathic/pointy lip protrusion!)
     5.34 + chinP - jawOpenDrop * 0.16, // 7: Classical human pogonion/menton chin projection
     3.58 + 0.28 * chinP,           // 8: Natural ~1.76 cm human submental setback to hyoid (~10.3 cm neck A-P depth, matching `image-16`!)
     3.06 * bustS,                  // 9: Monotonic forward-oblique anterior cervical column (ZERO backward throat dip!)
     3.58 * bustS,                  // 10: Clavicular / manubrium bust chest
     3.36 * bustS,                  // 11: Sculpted portrait bust front rim
    -2.85,                          // 12: Bottom center cap
  ];

  const Y_BACK = [
    10.46 * cranS + fhShift * 0.40,
     9.68 * cranS + fhShift * 0.34,
     7.82 * cranS,
     4.75 * cranS,
     1.45 * cranS,
    -2.20 * cranS,
    -4.95,                          // 6: Inion / occipital base
    -7.35,                          // 7: Upper nuchal neck
    -9.80,                          // 8: Mid nuchal cervical waist
   -12.15,                          // 9: C7 / dorsal trapezius bridge
   -14.65,                          // 10: Upper dorsal scapular / trapezius slope
   -17.20,                          // 11: Posterior bust rim
   -17.85,                          // 12: Bottom center cap
  ];

  const Z_BACK = [
    -1.65,
    -5.25 * cranS,
    -8.95 * cranS,
   -10.65 * cranS,
   -10.95 * cranS,
    -9.85 * cranS,
    -7.85,
    -6.75 * bustS,
    -6.68 * bustS,
    -7.10 * bustS,
    -8.85 * bustS,
    -8.60 * bustS,
    -2.85,
  ];

  // Reference-Matched Coronal Breadths (`0°` Smooth U-Oval Mandible -> Slender Sculpted Neck -> V-Tapered Trapezius):
  // `gonionRX = 5.18` + `lowerJawBodyRX = 4.20` (with `Y_SIDE[7] = -6.28` sitting 1.04 cm ABOVE `Y_FRONT[7] = -7.32`!)
  // produces a strictly convex U-oval jaw arch from `0°` — ZERO pointy V-cone AND ZERO square boxy jowls!
  const gonionRX = 5.18 * faceW * jawW;
  const lowerJawBodyRX = 4.20 * faceW * mix(1.0, jawW, 0.68) * mix(1.0, chinWid, 0.34);
  const upperNeckRX = Math.min(gonionRX * 0.768, 3.96 * neckW);
  const midNeckRX = Math.min(gonionRX * 0.795, 4.10 * neckW);
  const trapWebRX = Math.max(midNeckRX + 2.45, 6.85 * mix(neckW, bustS, 0.58));
  const RX_SIDE = [
     0.00,                          // 0: Crown pole
     3.84 * cranS * faceW,          // 1: Rounded upper cranial dome
     5.46 * cranS * faceW,          // 2: Bifrontal hairline breadth (Farkas 0.87x bizygomatic — zero boxy upper head!)
     5.82 * cranS * faceW,          // 3: Frontotemporal temple breadth (Farkas 0.92x bizygomatic — natural oval taper!)
     6.28 * faceW,                  // 4: Bizygomatic cheekbone breadth (~12.56 cm)
     5.78 * faceW,                  // 5: Smooth mid-cheek / maxillary oval continuity
     gonionRX,                      // 6: Full human bigonial jaw breadth (~82.5% of bizygomatic, matching `elena-front.jpg`!)
     lowerJawBodyRX,                // 7: Smooth U-oval parasymphysis breadth (neither pointy V-cone nor square jowl box!)
     upperNeckRX,                   // 8: Slender sub-mandibular upper neck (~77% of bigonial jaw breadth!)
     midNeckRX,                     // 9: Sculpted mid-lower cervical waist before trapezius flare
    11.85 * bustS,                  // 10: Natural ~26-deg sloped clavicular/acromion shoulders (~23.7 cm span at Y=-14.55)
    12.85 * bustS,                  // 11: Smooth convex lateral deltoid cap & portrait bust base (ZERO horizontal saucer lip!)
     0.00,                          // 12: Bottom center cap
  ];

  // Smooth Diagonal Human Mandible -> Taut Submental Neck -> V-Tapered Trapezius -> Acromion Shoulder:
  // Every `Y_SIDE[6..8]` sits ABOVE `Y_FRONT[6..8]` so the jaw curves smoothly upward from Menton -> Parasymphysis -> Gonion!
  const Y_SIDE = [
    10.40 * cranS + fhShift * 0.38,
     9.62 * cranS + fhShift * 0.40,
     7.72 + fhShift * 0.50,         // 2: Aligned with Y_FRONT[2]
     4.00 * faceH,                  // 3: Exact horizontal brow ring
     1.54 * faceH,                  // 4: Exact horizontal eye ring
    -1.74 * faceH,                  // 5: Exact horizontal maxilla ring
    -5.08 * faceH - jawOpenDrop * 0.34, // 6: Anatomical gonial jaw angle ~1.9 cm below earlobe
    -6.28 * faceH - jawOpenDrop * 0.62, // 7: Parasymphysis border 1.04 cm ABOVE Menton -> graceful U-oval chin curve!
    -7.56 * mix(1.0, faceH, 0.45) - jawOpenDrop * 0.24, // 8: Sub-gonial neck 0.40 cm ABOVE Hyoid -> zero drooping side corners!
   -11.35,                          // 9: Lower cervical / superior trapezius transition
   -14.55,                          // 10: Acromion / clavicle lateral shoulder slope (~26 deg natural human slope!)
   -17.15,                          // 11: Smooth convex deltoid shoulder cap & side bust rim
   -17.85,                          // 12: Bottom cap
  ];

  // Anatomical Human Coronal Side Plane (`Z_SIDE` at `theta = ±PI/2`):
  // Places the coronal temple/ear/gonion plane dead-on 4 finger-widths (`~5.5 cm` 3D chord, `ΔZ ≈ 4.95 cm`) behind the outer eye corner,
  // eliminating giant flat side-cheek deserts AND restoring full rounded posterior cranium depth behind the ear!
  const Z_SIDE = [
    -1.65,                          // 0: Crown pole (exact match to Z_FRONT[0] & Z_BACK[0])
    -1.52 * cranS,                  // 1: Upper parietal coronal axis
    -1.48 * cranS,                  // 2: Temporal hairline axis
    -1.48,                          // 3: Supra-auricular temple axis
    -1.52,                          // 4: External acoustic meatus / ear coronal center (exact 4.0 fingers behind exocanthion!)
    -1.48,                          // 5: Earlobe / TMJ / posterior ramus axis
    -1.42,                          // 6: Bony gonion / mastoid coronal plane
    -1.56,                          // 7: Sub-auricular upper lateral neck
    -1.80,                          // 8: Mid-cervical neck waist lateral midline
    -2.15,                          // 9: Superior trapezius crest
    -2.64,                          // 10: Acromion / shoulder mid-axis
    -2.78,                          // 11: Lateral deltoid cap
    -2.85,                          // 12: Bottom center cap (exact match to Z_FRONT[12] & Z_BACK[12])
  ];

  const yF = evalCatmullSpline(PROFILE_KNOTS, Y_FRONT, t);
  const zF = evalCatmullSpline(PROFILE_KNOTS, Z_FRONT, t);
  const yB = evalCatmullSpline(PROFILE_KNOTS, Y_BACK, t);
  const zB = evalCatmullSpline(PROFILE_KNOTS, Z_BACK, t);
  // Prevent Catmull-Rom tangent overshoot past `RX_SIDE[11]` on the deltoid cap (`t > 0.86`) so shoulders round cleanly downward without a saucer brim!
  const rawRx = evalCatmullSpline(PROFILE_KNOTS, RX_SIDE, t);
  const maxDeltoidRx = 12.92 * bustS;
  const rx = Math.max(0.0, t > 0.85 ? Math.min(rawRx, maxDeltoidRx) : rawRx);
  const yS = evalCatmullSpline(PROFILE_KNOTS, Y_SIDE, t);
  const zS = evalCatmullSpline(PROFILE_KNOTS, Z_SIDE, t);

  const c2 = cosT * cosT;
  const s2 = sinT * sinT;
  const s4 = s2 * s2;

  // Smooth C^inf Oblique Mandibular-to-Cervical & Coronal Side-Plane Blend:
  // `s4 = sin^4(theta)` preserves 100% of front-face (`|theta| < 0.55`) orbital/nasal/oral curvature while anchoring
  // `theta = ±PI/2` cleanly at `zS` (~4 fingers behind outer eye) with strictly monotonic C^inf smoothness!
  let y = s2 * yS + c2 * (cosT >= 0 ? yF : yB);
  const zMid = 0.5 * (zF + zB);
  const zAmp = 0.5 * (zF - zB);
  let z = zMid + zAmp * cosT + s4 * (zS - zMid);

  // CORONAL FRONTO-ORBITAL SHELF & LATERAL ORBITAL PILLAR (`C^inf` smooth, ZERO horizontal step!):
  // Real human orbits face FORWARD (`+Z`) — Whitnall's lateral orbital rim sits ~4.5 mm posterior to the medial canthus
  // (eliminating cylindrical side-view eye slant!), then glides with wide `sigma_t = 0.062` C^inf smoothness into the malar cheek!
  if (cosT > 0.0 && t < 0.62) {
    const foreheadPlaneEnv =
      smoothstep(0.09, 0.20, t) *
      (1.0 - smoothstep(0.25, 0.39, t));
    const squircleZ = 0.58 * Math.pow(cosT, 1.22) * s2 * foreheadPlaneEnv;
    const latOrbitalPillar = 0.68 * gauss(absTheta, 0.72, 0.24) * gauss(t, 0.334, 0.062);
    z += squircleZ + latOrbitalPillar;
  }

  // Smooth Convex U-Oval Chin & Clean Post-Auricular Mastoid Taper (`ZERO` pointy V-pinch & `ZERO` post-ear bulge in 3/4 view!):
  const chinUEnv = gauss(t, 0.582, 0.044) * Math.pow(Math.max(0, cosT), 1.40);
  const chinOvalTaper = 0.018 * chinUEnv * smoothstep(0.10, 0.38, absTheta) * (1.0 - smoothstep(0.62, 1.05, absTheta));
  // Smooth retro-auricular mastoid-to-neck taper strictly BEHIND the ear (`absTheta > 1.54`, `t in [0.43, 0.61]`):
  const posteriorJawTaper =
    (-0.115 * gauss(t, 0.495, 0.056) - 0.145 * gauss(t, 0.568, 0.046)) *
    smoothstep(1.54, 1.88, absTheta) *
    (1.0 - smoothstep(2.42, 2.88, absTheta));
  const chinArchBoost = 0.085 * (w.chinWidth || 0) * chinUEnv * smoothstep(0.05, 0.36, absTheta) * (1.0 - smoothstep(0.55, 1.05, absTheta));
  let x = rx * (1.0 + chinOvalTaper + posteriorJawTaper + chinArchBoost) * sinT;

  // Natural Organic Human Neck (`Broad Cylindrical SCM Bellies`, `Gentle Laryngeal Column`, `Soft Suprasternal Fossa`, `S-Clavicles`):
  if (t > 0.57 && t < 0.94) {
    // 1) Broad, Organic Sternocleidomastoid (SCM) Muscle Columns (`mastoid -> medial clavicle`, stopping cleanly AT the collarbone!):
    const scmProg = clamp((t - 0.575) / 0.215, 0.0, 1.0);
    const scmTheta = mix(1.54, 0.20, scmProg);
    const scmSigma = mix(0.24, 0.168, scmProg);
    const midlineGate = smoothstep(0.06, 0.18, absTheta) * (1.0 - smoothstep(1.62, 2.02, absTheta));
    const scmVertEnv = smoothstep(0.585, 0.648, t) * (1.0 - smoothstep(0.742, 0.796, t));
    const scmSternal = midlineGate * gauss(absTheta, scmTheta, scmSigma) * scmVertEnv;
    const scmClavTheta = mix(1.50, 0.46, scmProg);
    const scmClavicular = smoothstep(0.24, 0.42, absTheta) * gauss(absTheta, scmClavTheta, 0.165) *
                          smoothstep(0.640, 0.700, t) * (1.0 - smoothstep(0.745, 0.796, t));

    x += sgnX * (0.110 * scmSternal + 0.060 * scmClavicular) * bustS * Math.sin(Math.min(Math.PI, absTheta));
    z += (0.195 * scmSternal + 0.095 * scmClavicular) * bustS * Math.max(0.0, Math.cos(absTheta * 0.52));

    // Gentle midline thyroid/tracheal column + soft carotid sulci (subtle & natural — ZERO sharp vertical cords in 90-deg profile!)
    if (absTheta < 0.68 && t > 0.63 && t < 0.78) {
      const larynxEnv = gauss(t, 0.702, 0.048);
      const tracheaCol = 0.075 * gauss(theta, 0.0, 0.175) * larynxEnv;
      const carotidTheta = mix(0.38, 0.20, clamp((t - 0.63) / 0.14, 0.0, 1.0));
      const carotidGroove = -0.062 * gauss(absTheta, carotidTheta, 0.125) * larynxEnv;
      z += (tracheaCol + carotidGroove) * bustS;
    }

    // Concave-diagonal superior trapezius web (`t = 0.72..0.84`) flaring gracefully from neck waist into shoulders!
    const trapWeb = gauss(absTheta, 1.54, 0.38) * gauss(t, 0.775, 0.056);
    y += 0.24 * bustS * trapWeb;
    x += sgnX * 0.68 * bustS * trapWeb;

    if (absTheta < 1.38) {
      // 2) Soft Rounded Suprasternal (Jugular) Fossa (`t ~ 0.788`) + Manubrium Sterni Support (`t ~ 0.834`)
      const jugularHollow = gauss(theta, 0.0, 0.165) * gauss(t, 0.788, 0.028);
      const manubriumSupport = gauss(theta, 0.0, 0.28) * gauss(t, 0.834, 0.038);

      // 3) Smooth S-Curved Clavicles (`t = 0.800 -> 0.834`, `Y ~ -13.1 -> -13.9 cm`)
      const uClav = clamp((absTheta - 0.15) / 0.98, 0.0, 1.0);
      const clavicleCurveT = 0.800 + 0.034 * Math.pow(uClav, 1.15) - 0.006 * Math.sin(uClav * Math.PI);
      const clavSpanEnv = smoothstep(0.12, 0.24, absTheta) * (1.0 - smoothstep(0.98, 1.28, absTheta));
      const clavicleShaft = clavSpanEnv * gauss(t, clavicleCurveT, 0.022);
      const sternoClavKnob = gauss(absTheta, 0.20, 0.095) * gauss(t, 0.798, 0.022);
      const supraClavHollow = smoothstep(0.30, 0.46, absTheta) * (1.0 - smoothstep(0.92, 1.20, absTheta)) *
                              gauss(t, clavicleCurveT - 0.026, 0.024);
      const infraClavDip = smoothstep(0.26, 0.42, absTheta) * (1.0 - smoothstep(0.95, 1.22, absTheta)) *
                           gauss(t, clavicleCurveT + 0.026, 0.024);

      z += (-0.185 * jugularHollow + 0.135 * manubriumSupport - 0.155 * supraClavHollow - 0.075 * infraClavDip + 0.255 * clavicleShaft + 0.145 * sternoClavKnob) * bustS;
      y += (0.105 * clavicleShaft + 0.048 * sternoClavKnob - 0.038 * supraClavHollow) * bustS;
    }
  }

  // --- STAGE A2: Rich Sculpted 3D Cheek Ogee (Rolling Malar Mass, Zygomatic Arch, Buccal Plane & Soft Nasolabial Roll) ---
  if (cosT > -0.52 && t > 0.22 && t < 0.72) {
    const belowOrbitGate = smoothstep(0.325, 0.415, t);
    // 1) Rolling Anterior Malar Cheek Cushion ("apple of the cheek" — real sculptural 3D volume catching side & 3/4 light!)
    const cheekApple = belowOrbitGate * gauss(absTheta, 0.57, 0.23) * gauss(t, 0.416, 0.050);
    z += 0.62 * malarG * cheekApple;
    x += sgnX * 0.30 * malarG * cheekApple;

    // 2) High Zygomatic Arch & Lateral Malar Eminence (rolling smoothly from cheek apple toward temporal arch!)
    const zygoArch = smoothstep(0.310, 0.388, t) * gauss(absTheta, 0.88, 0.26) * gauss(t, 0.388, 0.048);
    z += 0.44 * malarG * zygoArch;
    x += sgnX * 0.34 * malarG * zygoArch;

    // Subtle anatomical temporal fossa concavity just above the zygomatic arch so brow & cheekbone read as distinct planes
    const temporalHollow = gauss(absTheta, 1.04, 0.22) * gauss(t, 0.285, 0.048);
    x -= sgnX * 0.14 * temporalHollow;
    z -= 0.12 * temporalHollow;

    // 3) Anterior Submalar / Mid-Cheek Cushion + Sculpted Buccal-Masseteric Plane Roll underneath the cheekbone
    const subMalarMask = gauss(absTheta, 0.62, 0.22) * gauss(t, 0.468, 0.048);
    const cheekyPlump = clamp(0.30 - 0.22 * Math.max(0.0, hollow - 0.10) - 0.12 * Math.min(0.0, hollow), -0.14, 0.40);
    z += cheekyPlump * subMalarMask;
    x += sgnX * 0.28 * cheekyPlump * subMalarMask;

    const buccalPlane = gauss(absTheta, 0.98, 0.23) * gauss(t, 0.476, 0.048);
    x -= sgnX * (0.145 + 0.085 * Math.max(0.0, hollow)) * buccalPlane;
    z -= (0.125 + 0.075 * Math.max(0.0, hollow)) * buccalPlane;

    // Soft youthful nasolabial cheek-pad roll meeting the maxillary lip barrel (rolling mass, NOT harsh wrinkle!)
    const nlFold = gauss(absTheta, 0.36, 0.11) * gauss(t, 0.468, 0.044);
    const nlCheekPad = gauss(absTheta, 0.52, 0.15) * gauss(t, 0.456, 0.044);
    z += -0.095 * nlFold + 0.145 * malarG * nlCheekPad;

    // 4) Clean, Taut Human Mandible + Upward-Tucked Mylohyoid Submental Plane (`ZERO` pointy `0°` jaw & `ZERO` side double-chin!):
    //    Instead of carving an artificial groove ABOVE a hanging throat pouch, the lower border of the mandible (`t = 0.590 -> 0.535`)
    //    is the TRUE bottom edge of the jaw, and behind it (`t = 0.602..0.646`) the submental floor tucks tautly UPWARD (`+Y`) & BACKWARD (`-Z`)!
    const jWid = w.jawWidth || 0.0;
    const ascendingRamus =
      gauss(absTheta, 1.40, 0.17) *
      smoothstep(0.395, 0.445, t) *
      (1.0 - smoothstep(0.515, 0.560, t));
    const retroMandibularHollow =
      gauss(absTheta, 1.62, 0.16) *
      gauss(t, 0.548, 0.046);

    x += sgnX * ((0.048 + 0.045 * jWid) * ascendingRamus - 0.155 * retroMandibularHollow);
    z += 0.038 * ascendingRamus;

    // Gentle inferior mandibular definition + Catmull-Rom vertical-tangent-overshoot canceler (`submentalTuck` at `t = 0.614`):
    // Produces a 100% taut, linear-concave ~112-deg submental slope from Menton to Hyoid (`ZERO` double-chin & `ZERO` 90-deg flat shelf!)
    const uJawArc = clamp(absTheta / 1.42, 0.0, 1.0);
    const jawRimT = 0.588 - 0.054 * Math.pow(uJawArc, 1.15);
    const jawRimGate = smoothstep(0.24, 0.52, absTheta) * (1.0 - smoothstep(1.28, 1.52, absTheta));
    const jawRim = gauss(t, jawRimT, 0.020) * jawRimGate;
    const submentalTuck =
      gauss(t, 0.614, 0.023) *
      (1.0 - smoothstep(1.05, 1.44, absTheta)) *
      Math.pow(Math.max(0.0, cosT + 0.15) / 1.15, 1.15);

    x += sgnX * (0.028 + 0.036 * jWid) * jawRim;
    y += -0.028 * jawRim + 0.118 * submentalTuck;
    z += 0.032 * jawRim * Math.max(0.15, cosT) - 0.052 * submentalTuck;
  }

  // --- STAGE B: Clinical Fusiform Almond Eyes + Dynamic Brows + Proud Goode-Ratio Nose + Untouched Pillowy Lips ---
  if (cosT > 0.05 && t > 0.19 && t < 0.63) {
    const ax = Math.abs(x);
    const eyeX = (2.82 + 0.22 * (w.eyeSpacing || 0)) * faceW;
    const eyeY = 1.56 * faceH;
    // Clinical adult palpebral fissure: ~28 mm wide x ~8.2 mm tall (~3.4:1 fusiform almond, NEVER round puffy goggles!)
    const eyeHalfW = 1.38 * (1.0 + 0.11 * (w.eyeWidth || 0)) * faceW;
    const eyeOpenH = 0.42 * (1.0 + 0.28 * (w.eyeSize || 0));
    const canthalSlope = 0.125 * (w.eyeTilt || 0);

    // 1. Youthful Silky C^inf Human Orbit + Rested Under-Eye Cheek Support (ZERO deep-set hollow elderly shadow!)
    const browU = clamp((ax - (eyeX - 1.72)) / 3.76, 0.0, 1.0);
    const bHeightShift = 0.36 * (w.browHeight || 0);
    const bArchAmp = 0.30 + 0.18 * (w.browArch || 0);
    const bTiltSlope = 0.22 * (w.browTilt || 0) + canthalSlope * 0.20;
    const browCurveY =
      eyeY +
      1.18 +
      bHeightShift +
      bArchAmp * Math.sin(Math.pow(browU, 0.88) * Math.PI) -
      0.15 * browU * browU +
      bTiltSlope * (browU - 0.5);

    const socketRecess =
      -0.17 * gauss2D(ax, y, eyeX - 0.86, eyeY + 0.32 + 0.28 * bHeightShift, 0.80, 0.68) -
       0.11 * gauss2D(ax, y, eyeX + 0.06, eyeY + 0.36 + 0.28 * bHeightShift, 1.48, 0.62);
    const infraOrbitalSupport = 0.30 * malarG * gauss2D(ax, y, eyeX + 0.24, eyeY - 0.90, 1.66, 0.62);

    const browRidge = (0.32 + 0.12 * smoothstep(1.4, 4.1, ax)) * browG * gauss2D(ax, y, eyeX + 0.20, browCurveY + 0.10, 2.18, 0.78);
    const glabella  = 0.16 * browG * gauss2D(x, y, 0.0, eyeY + 1.18 + bHeightShift * 0.45, 0.96, 0.72);

    let eyeDetailZ = 0.0;
    const dxEye = (ax - eyeX) / eyeHalfW;
    if (Math.abs(dxEye) < 1.85 && Math.abs(y - eyeY) < 1.75) {
      const eyeWin =
        (1.0 - smoothstep(1.22, 1.78, Math.abs(dxEye))) *
        (1.0 - smoothstep(1.12, 1.68, Math.abs(y - eyeY)));

      const { upperEdge, lowerEdge, canthalLineY, u: uEye } = evalPalpebralContour(dxEye, eyeY, eyeOpenH, canthalSlope);
      const lidSpan = Math.max(0.0, 1.0 - dxEye * dxEye);

      // 0) Frontal Orbital Plane Leveling: real human eyes face straight forward (+Z) inside frontal sockets
      //    rather than slanting steeply backward along the cylindrical cheek slope! Smoothly brings the lateral
      //    half of the palpebral fissure forward while keeping a silky C^inf blend into the temple & cheek.
      const frontPlaneHoriz =
        smoothstep(-1.18, -0.35, dxEye) *
        (1.0 - smoothstep(0.90, 1.66, dxEye));
      const frontPlaneVert =
        smoothstep(-1.25, -0.42, y - eyeY) *
        (1.0 - smoothstep(0.58, 1.38, y - eyeY));
      const orbitalFrontal =
        (0.52 * clamp((dxEye + 0.32) / 1.32, 0.0, 1.0) - 0.14 * Math.max(0.0, -dxEye)) *
        frontPlaneHoriz * frontPlaneVert;

      // A) Nyquist-Smooth C^inf 3D Spherical Eyeball (`R = 1.24 cm`) + Outward Convex Corneal Dome & Tarsal Wrap:
      //    All transitions exceed 2.5x sub-millimeter quad spacing (`>= 0.075 cm`) so ZERO polygon sawtooth facets appear!
      const openVert = smoothstep(lowerEdge - 0.072, lowerEdge + 0.072, y) *
                       (1.0 - smoothstep(upperEdge - 0.072, upperEdge + 0.072, y));
      const openHoriz = 1.0 - smoothstep(0.82, 1.04, Math.abs(dxEye));
      const palpebralOpen = openVert * openHoriz;

      const rBall = 1.24;
      const gx = (ax - (eyeX - 0.02)) * 0.84;
      const gy = (y - (eyeY + 0.01)) * 0.94;
      const rNorm2 = (gx * gx + gy * gy) / (rBall * rBall);
      const rawSphere = Math.sqrt(Math.max(0.0, 1.0 - Math.min(1.0, rNorm2)));
      const tarsalVertEnv =
        smoothstep(lowerEdge - 0.36, lowerEdge + 0.04, y) *
        (1.0 - smoothstep(upperEdge + 0.08, upperEdge + 0.60, y));
      const tarsalHorizEnv =
        smoothstep(-1.24, -0.64, dxEye) *
        (1.0 - smoothstep(0.64, 1.24, dxEye));
      const tarsalEnv = tarsalVertEnv * tarsalHorizEnv;

      // Proud, unmistakable outward-convex 3D eyeball & corneal meniscus dome
      const rCornea2 = ((ax - eyeX) / 0.72) ** 2 + ((y - eyeY) / 0.56) ** 2;
      const cornealBulge = rCornea2 < 1.0 ? 0.24 * Math.pow(1.0 - rCornea2, 1.32) * palpebralOpen : 0.0;
      const globeDome = 0.74 * rawSphere * tarsalEnv + cornealBulge;

      // B) Silky High-Poly Tarsal Eyelid Folds Wrapping Around the Convex Eyeball (ZERO jagged sub-triangle ridges!):
      const lidSpanEnv = Math.pow(lidSpan, 0.62);
      const lidMarginUpper  = 0.084 * gauss(y, upperEdge + 0.062, 0.075) * lidSpanEnv;
      const upperTarsalFold = 0.074 * gauss(y, upperEdge + 0.150, 0.108) * Math.pow(lidSpan, 0.56);
      const creaseHeight    = 0.26 + 0.04 * Math.sin(uEye * Math.PI);
      const supraCrease     = -0.044 * gauss(y, upperEdge + creaseHeight, 0.095) * gauss(dxEye, -0.02, 0.80);
      const lidMarginLower  = 0.046 * gauss(y, lowerEdge - 0.050, 0.070) * Math.pow(lidSpan, 0.70);
      const tearTrough      = -0.005 * gauss(y, lowerEdge - 0.22 - 0.05 * uEye, 0.16) * gauss(dxEye, -0.32, 0.48);

      // Smooth wide canthal dimples (never sharp 1-triangle pinches!)
      const canthusIndent =
        -0.028 * gauss2D(ax, y, eyeX - eyeHalfW * 0.98, canthalLineY - (0.042 + canthalSlope) * 0.95, 0.26, 0.22) -
         0.026 * gauss2D(ax, y, eyeX + eyeHalfW * 0.99, canthalLineY + (0.042 + canthalSlope) * 0.95, 0.30, 0.24);

      eyeDetailZ =
        (orbitalFrontal +
          globeDome +
          upperTarsalFold +
          lidMarginUpper * (1.0 - 0.56 * palpebralOpen) +
          supraCrease +
          lidMarginLower * (1.0 - 0.54 * palpebralOpen) +
          tearTrough +
          canthusIndent) *
        eyeWin;
    }

    // 2. Proud, Dimensional Goode-Ratio Human Nose (`Goode ~0.56`, `peakH = 1.66 * noseProj` + Nasomaxillary Paranasal Relief!):
    //    Stands proudly out from the cheek plane in 0-deg front & 3/4 views while keeping slender `alarW` (zero side-fattening) & smooth rounded tip!
    const nasionY    = eyeY + 0.42;
    const noseTipY   = (-1.80 - 0.50 * (w.noseLength || 0)) * faceH;
    const subnasaleY = noseTipY - 0.56 * faceH;

    const noseProj   = clamp(1.0 + 0.17 * (w.noseProjection || 0), 0.86, 1.28);
    const bridgeWid  = clamp(1.0 + 0.28 * (w.noseBridgeWidth || 0), 0.76, 1.50);
    const tipBall    = clamp(1.0 + 0.22 * (w.noseTipBall || 0), 0.92, 1.48);
    const bridgeArch = 0.15 * (w.noseBridgeArch || 0);
    const alarW      = clamp((1.38 + 0.32 * (w.noseWidth || 0)) * faceW, 1.14, 2.20);

    const nasionSaddle = -0.08 * gauss2D(x, y, 0.0, nasionY + 0.16, 0.86, 0.44);

    let noseZ = 0.0;
    let noseX = 0.0;
    if (y < nasionY + 1.25 && y > subnasaleY - 0.85 && ax < 3.6) {
      // Exact C^1/C^2 Singularity-Free Rounded Nasal Tip & Infratip Curve:
      //  - Above `yc`: generous spherical curve (`Rball = 0.78 * tipBall`) tangent to the dorsal bridge at `yt1`
      //  - Below `yc`: smooth C^1/C^2 rounded infratip arc `peakH * (1 - uInf^1.95)^1.32` (`exponent 1.32 > 1` -> ZERO landing slope at subnasale!)
      const yc = noseTipY + 0.28 * faceH;
      const Rball = clamp(0.78 * tipBall, 0.72, 0.94);
      const peakH = 1.44 * noseProj;
      const zc = peakH - Rball;

      const y0 = nasionY + 0.08;
      const z0 = 0.0;
      const vx = y0 - yc, vz = z0 - zc;
      const D2 = Math.max(Rball * Rball + 0.06, vx * vx + vz * vz);
      const root1 = Math.sqrt(Math.max(0.0, D2 - Rball * Rball));
      const ny1 = (Rball * vx - vz * root1) / D2;
      const nz1 = (Rball * vz + vx * root1) / D2;
      const yt1 = yc + Rball * ny1;
      const zt1 = zc + Rball * nz1;
      const slope1 = (zt1 - z0) / Math.min(-0.25, yt1 - y0);

      let profileEnv = 0.0;
      if (y >= yt1) {
        const dyTop = y0 - y;
        const radixSmooth = 0.5 * (dyTop + Math.sqrt(dyTop * dyTop + 0.045));
        const uBridge = clamp(dyTop / Math.max(0.5, y0 - yt1), 0.0, 1.0);
        const rhinionArtic = 0.024 * gauss(uBridge, 0.44, 0.18);
        profileEnv = (-slope1) * radixSmooth + rhinionArtic + bridgeArch * Math.sin(uBridge * Math.PI);
      } else if (y >= yc) {
        const dyC = clamp(y - yc, 0.0, Rball);
        profileEnv = zc + Math.sqrt(Math.max(0.0, Rball * Rball - dyC * dyC));
      } else {
        const yBot = subnasaleY - 0.26 * faceH;
        const uInf = clamp((yc - y) / Math.max(0.50, yc - yBot), 0.0, 1.0);
        profileEnv = peakH * Math.pow(Math.max(0.0, 1.0 - Math.pow(uInf, 1.95)), 1.32);
      }
      profileEnv = Math.max(0.0, profileEnv);

      // Smooth, monotonic bridge-to-tip width expansion over ~2.6 cm with NO lower `tipZone` pinch cutoff
      // (`profileEnv` itself lands C^1-smoothly at 0 — eliminating horizontal paranasal/subnasale normal shelves in Clay & PBR!)
      const tipZone = smoothstep(nasionY - 0.35, noseTipY + 0.28 * faceH, y);
      const baseSigmaX = mix(Math.max(0.68, 0.78 * bridgeWid), clamp(0.95 * tipBall, 0.88, 1.16), tipZone);
      const crestWeight = 0.22 * (1.0 - 0.98 * tipZone);
      const domeCrossX =
        (1.0 - crestWeight) * Math.exp(-Math.pow(Math.abs(x) / baseSigmaX, mix(2.20, 2.12, tipZone))) +
        crestWeight * gauss(x, 0.0, Math.max(0.38, 0.46 * bridgeWid));

      // Lateral-only tip lobule fullness + gentle apex softening dilutes absolute tip sharpness
      const tipLobuleCushion = 0.12 * tipBall * smoothstep(0.10, 0.38, ax) * gauss2D(ax, y, 0.44, noseTipY + 0.10 * faceH, 0.42, 0.36);
      const tipApexDilute = -0.042 * gauss2D(x, y, 0.0, yc - 0.04 * faceH, 0.46, 0.36);
      const dorsumAndTip = profileEnv * domeCrossX + tipLobuleCushion + tipApexDilute;
      // Real sculptural paranasal & pyriform fossa depth beside the nasal sidewalls & alar wings:
      // Steps gently inward beside the nose BEFORE rolling outward into the anterior malar cheek mass!
      const paranasalVert = smoothstep(nasionY + 0.15, nasionY - 0.45, y) * (1.0 - smoothstep(subnasaleY + 0.15, subnasaleY - 0.45, y));
      const paranasalHollow = -0.22 * gauss(ax, 1.38, 0.48) * paranasalVert;
      const pyriformFossa = -0.18 * gauss2D(ax, y, alarW * 1.12, noseTipY - 0.30 * faceH, 0.54, 0.52);

      // Sculpted central columella pillar & soft nasolabial angle
      const columella = noseProj * (
        0.22 * gauss2D(x, y, 0.0, 0.5 * (noseTipY + subnasaleY), 0.23, 0.22) +
        0.13 * gauss2D(x, y, 0.0, subnasaleY - 0.04, 0.40, 0.22)
      );

      // Natural 3D Lateral Nostril Rim (`alae nasi`) + Rounded Lateral Tip Lobule Breadth:
      const alarY = noseTipY - 0.20 * faceH;
      const alarCut = 1.0 - smoothstep(subnasaleY - 0.04, subnasaleY - 0.48, y);
      const alarLobe = 0.37 * gauss2D(ax, y, alarW * 0.65, alarY, 0.24 * (0.94 + 0.10 * tipBall), 0.22) * alarCut;
      const alarGroove = -0.095 * gauss2D(ax, y, alarW * 0.98, alarY + 0.02, 0.20, 0.26) * alarCut;
      const nostrilRecess = -0.17 * gauss2D(ax, y, alarW * 0.45, subnasaleY + 0.15, 0.20, 0.13);
      const tipLateralBulbX = 0.115 * tipBall * gauss2D(ax, y, 0.52, noseTipY + 0.08 * faceH, 0.38, 0.40);

      const noseBounds =
        (1.0 - smoothstep(nasionY + 0.55, nasionY + 1.20, y)) *
        smoothstep(subnasaleY - 0.80, subnasaleY - 0.30, y) *
        (1.0 - smoothstep(2.65, 3.55, ax));

      noseZ = (dorsumAndTip + paranasalHollow + pyriformFossa + columella + alarLobe + alarGroove + nostrilRecess) * noseBounds;
      noseX = sgnX * (0.05 * Math.max(0.4, 0.80 + 0.28 * (w.noseWidth || 0)) * alarLobe + tipLateralBulbX) * noseBounds;
    }

    // 3. Soft, Blunt, Pillowy Human Lips (`ZERO` pointy `<` ridge & `ZERO` razor-gash stomion!):
    //    Uses broad, flat-round super-circular cushion arcs `(1 - s^2)^0.78` across 32+ sub-millimeter rows,
    //    then rolled in 3D `(dy, dz)` and Taubin-faired by `applyDedicatedNoseAndSoftLipCarvers`!
    const mouthY     = (-4.04 - 0.36 * (w.mouthHeight || 0)) * faceH - jawOpenDrop * 0.36;
    const mouthHalfW = (2.18 + 0.34 * (w.mouthWidth || 0) + 0.22 * mOpen) * faceW;
    const upVol      = clamp(1.0 + 0.28 * upLipW, 0.88, 1.56);
    const loVol      = clamp(1.0 + 0.28 * loLipW, 0.90, 1.60);
    const upProjZ    = clamp(1.0 + 0.18 * upLipW, 0.90, 1.28);
    const loProjZ    = clamp(1.0 + 0.18 * loLipW, 0.92, 1.30);
    const cornerLift = 0.26 * (w.mouthCornerLift || 0) + 0.16 * mOpen;

    let mouthZ = 0.0;
    if (ax < mouthHalfW * 2.18 && y < nasionY - 0.10 && y > mouthY - 3.10 - jawOpenDrop * 0.6) {
      const mx = clamp(ax / mouthHalfW, 0.0, 1.35);
      // C^1 smooth outer exponent (`1.26 > 1.0` -> zero slope at `mx = 1.0`, eliminating rectangular oral border in Clay/Normals!)
      const upHorizEnv = mx < 1.0 ? Math.pow(1.0 - Math.pow(mx, 2.10), 1.26) : 0.0;
      const loHorizEnv = mx < 1.0 ? Math.pow(1.0 - Math.pow(mx, 2.00), 1.28) : 0.0;
      const openSpanEnv = mx < 0.96 ? Math.pow(Math.max(0.0, 1.0 - Math.pow(mx / 0.96, 2.0)), 1.15) : 0.0;
      const halfOpenCm = 0.56 * mOpen * openSpanEnv;

      // A) Smooth Curved Maxillary-Mandibular Dental Arch tapering gently over ~3.6 cm up the paranasal maxilla (ZERO mid-nose step!)
      const barrelHoriz = gauss(ax, 0.0, mouthHalfW * 0.84);
      const barrelVert =
        smoothstep(nasionY - 0.25, subnasaleY - 0.68, y) *
        (1.0 - smoothstep(mouthY - halfOpenCm - 0.68, mouthY - halfOpenCm - 2.15, y));
      let localMouthZ = 0.34 * barrelHoriz * barrelVert;

      // B) Gentle Concave Philtrum flowing seamlessly into the soft upper vermilion cushion
      const pTopY = subnasaleY - 0.02;
      const pBotY = mouthY + halfOpenCm + 0.52;
      const uPhil = clamp((pTopY - y) / Math.max(0.42, pTopY - pBotY), 0.0, 1.15);
      const philConcaveDip = -0.045 * Math.sin(clamp(uPhil, 0.0, 1.0) * Math.PI) * barrelHoriz;
      const pMidY = 0.5 * (subnasaleY + pBotY);
      const pHalfH = Math.max(0.30, 0.5 * (subnasaleY - pBotY));
      const pVert = gauss(y, pMidY, pHalfH * 0.65);
      localMouthZ += philConcaveDip +
                     (0.028 * gauss(ax, 0.42, 0.20) - 0.018 * gauss(x, 0.0, 0.22)) * pVert;

      const cupidsArch = (0.090 * gauss(ax, 0.44, 0.26) - 0.034 * gauss(x, 0.0, 0.18)) * upHorizEnv;
      const partCenterY = mouthY + cornerLift * (mx * mx) - 0.016 * gauss(x, 0.0, 0.34);
      const upInnerY = partCenterY + halfOpenCm * 0.76;
      const loInnerY = partCenterY - halfOpenCm * 1.24;

      // C) Blunt, Flat-Round Super-Elliptical Upper Lip Cushion (`(1 - |s|^2.85)^1.28`: flat-topped blunt profile AND C^1 zero landing slope!)
      const upHeight = (0.64 + 0.15 * (upVol - 1.0)) * faceH + cupidsArch * 0.80;
      const uUp = (y - upInnerY) / Math.max(0.36, upHeight);
      let softPillowUp = 0.0;
      if (uUp > -0.28 && uUp < 1.56) {
        const sUp = (uUp - 0.48) / (uUp < 0.48 ? 0.76 : 1.06);
        if (Math.abs(sUp) < 1.0) {
          softPillowUp = Math.pow(1.0 - Math.pow(Math.abs(sUp), 2.85), 1.28);
        }
      }
      const tubercle = 0.014 * gauss(x, 0.0, 0.58) * gauss(uUp, 0.42, 0.40);
      const upperCushion = (0.205 * (1.0 - 0.30 * clamp(mOpen, 0, 1)) * upProjZ * softPillowUp + tubercle) * upHorizEnv;

      // D) Broad, Blunt, Flat-Round Lower Lip Cushion (`(1 - |s|^2.85)^1.28`: blunt profile AND C^1 zero landing slope!)
      const loHeight = (0.74 + 0.16 * (loVol - 1.0)) * faceH;
      const uLo = (loInnerY - y) / Math.max(0.38, loHeight);
      let softPillowLo = 0.0;
      if (uLo > -0.28 && uLo < 1.58) {
        const sLo = (uLo - 0.47) / (uLo < 0.47 ? 0.75 : 1.08);
        if (Math.abs(sLo) < 1.0) {
          softPillowLo = Math.pow(1.0 - Math.pow(Math.abs(sLo), 2.85), 1.28);
        }
      }
      const bilobe = 0.018 * gauss(ax, 0.48, 0.42) * gauss(uLo, 0.46, 0.40);
      const lowerCushion = (0.250 * (1.0 - 0.38 * clamp(mOpen, 0, 1)) * loProjZ * softPillowLo + bilobe) * loHorizEnv;

      // E) Gentle, Soft Stomion Kiss-Line (ZERO deep `<` V-beak notch in side profile!)
      let apertureZ = 0.0;
      if (halfOpenCm > 0.03) {
        const inOpenY =
          smoothstep(loInnerY - 0.35, loInnerY + 0.30, y) *
          (1.0 - smoothstep(upInnerY - 0.30, upInnerY + 0.35, y));
        apertureZ = -0.14 * inOpenY * openSpanEnv;
      } else {
        apertureZ = -0.056 * gauss(y, partCenterY, 0.165) * Math.pow(upHorizEnv, 1.15);
      }
      const cornerTuck = -0.09 * gauss2D(ax, y, mouthHalfW * 0.98, partCenterY, 0.42, 0.36);

      const windowX = 1.0 - smoothstep(mouthHalfW * 1.45, mouthHalfW * 2.15, ax);
      const windowY =
        (1.0 - smoothstep(subnasaleY + 0.35, nasionY - 0.15, y)) *
        smoothstep(loInnerY - 2.65, loInnerY - 1.10, y);

      mouthZ = (localMouthZ + upperCushion + lowerCushion + apertureZ + cornerTuck) * windowX * windowY;
    }

    // Gentle Natural Holdaway Mentolabial Curve & Broad Rounded 3D Oval Chin Pad (`pogonion` — wide rounded oval, NEVER pointy V!):
    const mentoSulcus = -0.115 * gauss2D(x, y, 0.0, mouthY - 0.70 * mOpen - 1.18 * faceH, 1.54, 0.54);
    const chinCushion =  0.265 * gauss2D(x, y, 0.0, -6.92 * faceH - jawOpenDrop, 1.82 * chinWid, 0.88);

    z += socketRecess + infraOrbitalSupport + browRidge + glabella + eyeDetailZ + nasionSaddle + noseZ + mouthZ + mentoSulcus + chinCushion;
    x += noseX;
  }

  // --- STAGE C: High-Definition Anatomically Detailed 3D Human Pinna Ear (~4 Fingers Behind Outer Eye!) ---
  const earTopY = 2.18 * faceH;
  const earBotY = -3.18 * faceH;
  if (absTheta > 1.37 && absTheta < 1.94 && y > earBotY - 0.35 && y < earTopY + 0.35) {
    const earMidY = 0.5 * (earTopY + earBotY);
    const earHalfH = 0.5 * (earTopY - earBotY); // ~2.68 cm (~5.36 cm full human ear height!)
    const earMidZ = -1.72;

    const dyE = y - earMidY;
    const dzE = z - earMidZ;
    // Rotate by 10.5 deg backward tilt of human pinna axis (parallels nasal dorsum!)
    const rotY = (dyE * 0.983 - dzE * 0.182) / earHalfH;
    const rotZ = (dyE * 0.182 + dzE * 0.983) / 1.44; // ~2.95 cm AP pinna breadth

    // Natural human kidney/C-oval pinna silhouette (wider rounded helix dome superiorly, tapered fleshy lobule inferiorly)
    const widthTaper = 0.84 + 0.18 * clamp(rotY + 0.15, -0.95, 1.0);
    const rEar = Math.hypot(rotY * 0.95, rotZ / widthTaper);

    if (rEar < 1.26) {
      const thEnv = smoothstep(1.37, 1.48, absTheta) * smoothstep(1.94, 1.78, absTheta);
      const rEnv  = smoothstep(1.16, 0.82, rEar);
      // Outer boundary C^1 guard strictly outside `rEar = 1.04` so helix (`0.87`) & lobule stay 100% crisp!
      const rimZeroGuard = smoothstep(1.25, 1.04, rEar);
      const env   = thEnv * rEnv;

      // 1) Crisp pre-tragal valley right in front of the tragus
      const preTragalValley = -0.12 * gauss(rotZ, 0.72, 0.15) * gauss(rotY, -0.10, 0.40) * thEnv;
      // 2) Natural ~23-deg human auriculocephalic pinna angle (upper helix flares gently outward like `elena-front.jpg`!)
      const postTilt = clamp((-rotZ + 0.58) / 1.34, 0.0, 1.22);
      const upperEarFlare = 0.88 + 0.24 * clamp(rotY, -0.5, 0.9);
      const basePinna = 0.68 * env * (0.20 + 0.80 * postTilt) * upperEarFlare;
      // 3) Smooth, continuous rolled outer C-Helix rim (`sigma = 0.135` prevents 0-deg grid scallops!) + Crus of Helix!
      const helixArcGate = smoothstep(0.64, -0.16, rotZ - rotY * 0.28) * smoothstep(-0.76, -0.34, rotY);
      const cHelix = 0.30 * gauss(rEar, 0.87, 0.135) * helixArcGate * thEnv;
      const helixCrus = 0.16 * Math.exp(-(((rotY - 0.12) / 0.13) ** 2 + ((rotZ - 0.22) / 0.28) ** 2)) * thEnv;
      // 4) Defined Scaphoid fossa groove + Y-shaped Antihelix, Superior/Inferior Crura & Triangular Fossa!
      const scapha = -0.13 * gauss(rEar, 0.70, 0.088) * smoothstep(-0.36, 0.25, rotY) * helixArcGate * thEnv;
      const antihelix = 0.23 * gauss(rEar, 0.53, 0.105) * smoothstep(-0.54, 0.42, rotY) * smoothstep(0.45, -0.05, rotZ) * thEnv;
      const supCrus = 0.14 * Math.exp(-(((rotY - 0.48) / 0.19) ** 2 + ((rotZ - 0.14) / 0.15) ** 2)) * thEnv;
      const infCrus = 0.12 * Math.exp(-(((rotY - 0.34) / 0.12) ** 2 + ((rotZ - 0.26) / 0.18) ** 2)) * thEnv;
      const triFossa = -0.11 * Math.exp(-(((rotY - 0.54) / 0.14) ** 2 + ((rotZ - 0.24) / 0.13) ** 2)) * thEnv;
      // 5) Deep Concha Cavum & Cymba Bowl + Sharp Tragus, Intertragic Notch, Antitragus & Smooth Fleshy Lobule!
      const conchaBowl = -0.44 * Math.exp(-(((rotY + 0.04) / 0.33) ** 2 + ((rotZ - 0.04) / 0.26) ** 2)) * thEnv;
      const tragus = 0.24 * Math.exp(-(((rotY + 0.15) / 0.16) ** 2 + ((rotZ - 0.52) / 0.14) ** 2)) * thEnv;
      const intertragicNotch = -0.16 * Math.exp(-(((rotY + 0.42) / 0.12) ** 2 + ((rotZ - 0.34) / 0.13) ** 2)) * thEnv;
      const antitragus = 0.14 * Math.exp(-(((rotY + 0.42) / 0.15) ** 2 + ((rotZ + 0.04) / 0.16) ** 2)) * thEnv;
      const lobule = 0.22 * Math.exp(-(((rotY + 0.72) / 0.24) ** 2 + ((rotZ - 0.02) / 0.28) ** 2)) * thEnv;

      const totalDx = earS * rimZeroGuard * (
        preTragalValley + basePinna + cHelix + helixCrus + scapha +
        antihelix + supCrus + infCrus + triFossa + conchaBowl + tragus + intertragicNotch + antitragus + lobule
      );
      x += sgnX * totalDx;
      z -= 0.19 * earS * rimZeroGuard * (env * postTilt + 0.48 * cHelix);
    }
  }

  return [x, y, z];
}

/**
 * Precompute Real Diffeomorphic 3D Spherical-Globe Eyelid Blink Morph Deltas, Recomputed Closed-Lid Normals, & Eyelid Shader Mask!
 *  - Interpolates exact post-warp 8-point upper/lower eyelid landmarks (`Inner, UpperInner, Upper, UpperOuter, Outer, LowerInner, Lower, LowerOuter`)
 *  - Strictly monotonic vertical mapping (`ZERO` crushed vertex pileups, `ZERO` double-ridge steps!)
 *  - Wraps upper tarsal skin smoothly over the convex `R = 1.18 cm` eyeball sphere and recomputes exact 3D closed normals (`blinkNormalDeltas`)!
 */
export function computeEyelidBlinkBuffers(
  positions,
  regionT,
  w = DEFAULT_3DMM_WEIGHTS,
  keyLandmarks3D = null,
  indices = null,
  cols = 0,
  rows = 0,
  openNormals = null
) {
  const numVerts = positions.length / 3;
  const blinkDeltas       = new Float32Array(numVerts * 3);
  const blinkNormalDeltas = new Float32Array(numVerts * 3);
  const blinkMask         = new Float32Array(numVerts * 2); // [skinCoverWeight, lashLineWeight]

  const lms = keyLandmarks3D || getKeyAnatomicalLandmarks3D(w);

  const buildEyeCurveSpec = (isRight) => {
    const pIn  = isRight ? lms.eyeRightInner      : lms.eyeLeftInner;
    const pUpI = isRight ? lms.eyeRightUpperInner : lms.eyeLeftUpperInner;
    const pUpM = isRight ? lms.eyeRightUpper      : lms.eyeLeftUpper;
    const pUpO = isRight ? lms.eyeRightUpperOuter : lms.eyeLeftUpperOuter;
    const pOut = isRight ? lms.eyeRightOuter      : lms.eyeLeftOuter;
    const pLoI = isRight ? lms.eyeRightLowerInner : lms.eyeLeftLowerInner;
    const pLoM = isRight ? lms.eyeRightLower      : lms.eyeLeftLower;
    const pLoO = isRight ? lms.eyeRightLowerOuter : lms.eyeLeftLowerOuter;
    const pCtr = isRight ? lms.eyeRight           : lms.eyeLeft;

    const axIn  = Math.abs(pIn[0]);
    const axOut = Math.abs(pOut[0]);
    const spanX = Math.max(1.80, axOut - axIn);
    const knotsU = [0.0, 0.27, 0.50, 0.73, 1.0];
    const upYs   = [pIn[1], pUpI[1], pUpM[1], pUpO[1], pOut[1]];
    const loYs   = [pIn[1], pLoI[1], pLoM[1], pLoO[1], pOut[1]];

    return {
      axIn,
      axOut,
      spanX,
      knotsU,
      upYs,
      loYs,
      ballAx: Math.abs(pCtr[0]),
      ballY:  pCtr[1],
      ballZ:  pCtr[2] - 1.10,
      ballR:  1.16,
    };
  };

  const specs = { left: buildEyeCurveSpec(false), right: buildEyeCurveSpec(true) };

  // Pre-sample per-column open-mesh Z anchors `(zBotCol, zTopCol)` when grid `(cols, rows)` is available
  // so closed eyelids form a 100% silky, wrinkle-free convex tarsal dome in BOTH Sculpt Clay & PBR!
  const colZTop = cols > 0 ? new Float32Array(cols) : null;
  const colZBot = cols > 0 ? new Float32Array(cols) : null;
  const colHasEye = cols > 0 ? new Uint8Array(cols) : null;

  if (cols > 0 && rows > 0) {
    // Sub-row linearly interpolated Z sampler along meridian column `m` (ZERO staircase row quantization!)
    const sampleColZLinear = (m, yQuery) => {
      let prevY = positions[m * 3 + 1];
      let prevZ = positions[m * 3 + 2];
      let bestD = Math.abs(prevY - yQuery);
      let bestZ = prevZ;
      for (let r = 1; r < rows; r++) {
        const idx3 = (r * cols + m) * 3;
        const curY = positions[idx3 + 1];
        const curZ = positions[idx3 + 2];
        if (curZ > 2.0 && prevZ > 2.0) {
          if ((prevY >= yQuery && curY <= yQuery) || (prevY <= yQuery && curY >= yQuery)) {
            const denom = prevY - curY;
            const frac = Math.abs(denom) > 1e-6 ? clamp((prevY - yQuery) / denom, 0.0, 1.0) : 0.5;
            return mix(prevZ, curZ, frac);
          }
        }
        const d = Math.abs(curY - yQuery);
        if (curZ > 2.0 && d < bestD) {
          bestD = d;
          bestZ = curZ;
        }
        prevY = curY;
        prevZ = curZ;
      }
      return bestZ;
    };

    for (let m = 0; m < cols; m++) {
      const midR = Math.min(rows - 1, Math.round(rows * 0.34));
      const pxSample = positions[(midR * cols + m) * 3];
      const pzSample = positions[(midR * cols + m) * 3 + 2];
      if (pzSample < 2.2) continue;
      const spec = pxSample < 0 ? specs.left : specs.right;
      const uRaw = (Math.abs(pxSample) - spec.axIn) / spec.spanX;
      if (uRaw <= -0.22 || uRaw >= 1.22) continue;
      const uC = clamp(uRaw, 0.0, 1.0);
      const upY = evalCatmullSpline(spec.knotsU, spec.upYs, uC) + 0.135;
      const loY = evalCatmullSpline(spec.knotsU, spec.loYs, uC) - 0.070;
      colZTop[m] = sampleColZLinear(m, upY + 0.48);
      colZBot[m] = sampleColZLinear(m, loY - 0.26);
      colHasEye[m] = 1;
    }

    // 4 passes of [0.25, 0.50, 0.25] horizontal column smoothing across `colZTop` & `colZBot`!
    const tmpT = new Float32Array(cols);
    const tmpB = new Float32Array(cols);
    for (let pass = 0; pass < 4; pass++) {
      tmpT.set(colZTop);
      tmpB.set(colZBot);
      for (let m = 1; m < cols - 1; m++) {
        if (colHasEye[m] && colHasEye[m - 1] && colHasEye[m + 1]) {
          colZTop[m] = 0.25 * tmpT[m - 1] + 0.50 * tmpT[m] + 0.25 * tmpT[m + 1];
          colZBot[m] = 0.25 * tmpB[m - 1] + 0.50 * tmpB[m] + 0.25 * tmpB[m + 1];
        }
      }
    }
  }

  for (let i = 0; i < numVerts; i++) {
    const t = regionT[i];
    if (t < 0.25 || t > 0.43) continue;
    const pz = positions[3 * i + 2];
    if (pz < 2.2) continue;

    const px = positions[3 * i];
    const py = positions[3 * i + 1];
    const ax = Math.abs(px);
    const spec = px < 0 ? specs.left : specs.right;

    const uRaw = (ax - spec.axIn) / spec.spanX;
    if (uRaw <= -0.16 || uRaw >= 1.16) continue;

    const uClamped = clamp(uRaw, 0.0, 1.0);
    const sinU = Math.max(0.0, Math.sin(uClamped * Math.PI));
    const horizEnv =
      smoothstep(-0.16, 0.04, uRaw) *
      (1.0 - smoothstep(0.96, 1.16, uRaw)) *
      Math.pow(sinU, 0.50);
    if (horizEnv <= 1e-4) continue;

    // `upperRimY` includes open upper eyelashes (`+0.135 cm`) & `lowerRimY` includes lower waterline (`-0.070 cm`),
    // so ONLY clean lash-free upper/lower eyelid skin stretches across the closed eye (ZERO double dark lash line!)
    const upperRimY = evalCatmullSpline(spec.knotsU, spec.upYs, uClamped) + 0.135;
    const lowerRimY = evalCatmullSpline(spec.knotsU, spec.loYs, uClamped) - 0.070;
    const apH = Math.max(0.18, upperRimY - lowerRimY);

    // Natural downward-curved closed eyelash arc
    const closedY = lowerRimY + 0.22 * apH - 0.036 * sinU;
    const topY = upperRimY + 0.48;
    const botY = lowerRimY - 0.26;

    if (py <= topY && py >= botY) {
      let targetY = py;
      const seamHalf = 0.022;
      if (py >= upperRimY) {
        const sUp = clamp((py - upperRimY) / Math.max(0.16, topY - upperRimY), 0.0, 1.0);
        targetY = mix(closedY + seamHalf, topY, Math.pow(sUp, 0.90));
      } else if (py >= lowerRimY) {
        const sAp = clamp((py - lowerRimY) / apH, 0.0, 1.0);
        targetY = mix(closedY - seamHalf, closedY + seamHalf, sAp);
      } else {
        const sLo = clamp((py - botY) / Math.max(0.10, lowerRimY - botY), 0.0, 1.0);
        targetY = mix(botY, closedY - seamHalf, Math.pow(sLo, 0.96));
      }

      const dy = (targetY - py) * horizEnv;
      const newY = py + dy;

      let dz = 0.0;
      const mCol = cols > 0 ? (i % cols) : -1;
      if (mCol >= 0 && colHasEye[mCol]) {
        const sClosed = clamp((newY - botY) / Math.max(0.25, topY - botY), 0.0, 1.0);
        const zChord = mix(colZBot[mCol], colZTop[mCol], sClosed);
        const zEyeballConvex = 0.135 * Math.pow(Math.sin(sClosed * Math.PI), 0.90) * Math.pow(sinU, 0.68);
        const fissureCleft   = -0.032 * gauss(newY, closedY, 0.038) * Math.pow(sinU, 0.78);
        const upperLidLip    =  0.015 * gauss(newY, closedY + 0.055, 0.048) * Math.pow(sinU, 0.78);
        const closedSupraFold = -0.022 * gauss(newY, closedY + 0.32, 0.072) * Math.pow(sinU, 0.72);
        const zClosedTarget = zChord + zEyeballConvex + fissureCleft + upperLidLip + closedSupraFold;
        const vertFade = smoothstep(botY, botY + 0.09, py) * (1.0 - smoothstep(topY - 0.10, topY, py));
        dz = (zClosedTarget - pz) * vertFade * horizEnv;
      } else {
        dz = 0.05 * Math.sin(clamp((newY - botY) / (topY - botY), 0, 1) * Math.PI) * horizEnv;
      }

      blinkDeltas[3 * i + 1] = dy;
      blinkDeltas[3 * i + 2] = dz;

      const lashDist = Math.abs(newY - closedY);
      const lashCrease = Math.exp(-(((lashDist) / 0.040) ** 2)) * Math.pow(sinU, 0.82);

      // Smoothly cover 100% of open-eye interior (`[lowerRimY - 0.10, upperRimY + 0.06]`) AND feather seamlessly
      // up into the shaded orbital fold (`upperRimY + 0.44`) so ZERO patch edge is ever visible on closed lids!
      const coreEyeVert =
        smoothstep(lowerRimY - 0.10, lowerRimY + 0.01, py) *
        (1.0 - smoothstep(upperRimY + 0.04, upperRimY + 0.18, py));
      const unfurlCreaseVert =
        0.86 *
        smoothstep(upperRimY - 0.04, upperRimY + 0.05, py) *
        (1.0 - smoothstep(upperRimY + 0.12, upperRimY + 0.44, py));
      const inEyeVert = Math.max(coreEyeVert, unfurlCreaseVert);
      const inEyeHoriz =
        Math.pow(sinU, 0.42) *
        smoothstep(-0.08, 0.04, uRaw) *
        (1.0 - smoothstep(0.96, 1.08, uRaw));

      blinkMask[2 * i]     = clamp(Math.max(inEyeVert * inEyeHoriz * 1.28, lashCrease * 0.92), 0.0, 1.0);
      blinkMask[2 * i + 1] = clamp(lashCrease, 0.0, 1.0);
    }
  }

  // Horizontal-guided smoothing pass on `blinkDeltas.z` across adjacent columns so closed-lid clay is 100% glass-smooth!
  if (cols > 0 && rows > 0) {
    const tmpZ = new Float32Array(numVerts);
    for (let pass = 0; pass < 2; pass++) {
      for (let v = 0; v < numVerts; v++) tmpZ[v] = positions[3 * v + 2] + blinkDeltas[3 * v + 2];
      for (let r = 1; r < rows - 1; r++) {
        for (let m = 1; m < cols - 1; m++) {
          const v = r * cols + m;
          if (Math.abs(blinkDeltas[3 * v + 1]) < 1e-5 && Math.abs(blinkDeltas[3 * v + 2]) < 1e-5) continue;
          const zSm = 0.25 * tmpZ[v - 1] + 0.50 * tmpZ[v] + 0.25 * tmpZ[v + 1];
          blinkDeltas[3 * v + 2] = zSm - positions[3 * v + 2];
        }
      }
    }
  }

  if (indices && cols > 0 && rows > 0) {
    const baseN = openNormals || computeSeamlessGridNormals(positions, indices, cols, rows);
    const closedPos = new Float32Array(positions.length);
    for (let k = 0; k < positions.length; k++) {
      closedPos[k] = positions[k] + blinkDeltas[k];
    }
    const closedN = computeSeamlessGridNormals(closedPos, indices, cols, rows);
    for (let k = 0; k < blinkNormalDeltas.length; k++) {
      blinkNormalDeltas[k] = closedN[k] - baseN[k];
    }
  }

  return { blinkDeltas, blinkNormalDeltas, blinkMask };
}

export function generate3DMMBustGeometry(weights = DEFAULT_3DMM_WEIGHTS, density = 'standard') {
  const { M, R, thetas, uCoords, tVals } = buildParameterGrid(density);
  const cols = M + 1;
  const rows = R + 1;
  const numVerts = cols * rows;

  const positions = new Float32Array(numVerts * 3);
  const uvs = new Float32Array(numVerts * 2);
  const regionT = new Float32Array(numVerts);

  for (let r = 0; r <= R; r++) {
    const t = tVals[r];
    // Direct linear UV row mapping (`1 - r / R`): dedicates 2.5x more vertical UV texture pixels to eyes, nose & lips!
    const vUv = 1.0 - r / R;
    for (let m = 0; m <= M; m++) {
      const idx = r * cols + m;
      const theta = m === M ? thetas[0] : thetas[m];
      const [px, py, pz] =
        r === 0
          ? evaluateHeadBustPoint(0.0, 0.0, weights)
          : r === R
          ? evaluateHeadBustPoint(0.0, 1.0, weights)
          : evaluateHeadBustPoint(theta, t, weights);

      positions[3 * idx]     = px;
      positions[3 * idx + 1] = py;
      positions[3 * idx + 2] = pz;

      uvs[2 * idx]     = uCoords[m];
      uvs[2 * idx + 1] = vUv;
      regionT[idx]     = t;
    }
  }

  const indices = new Uint32Array(R * M * 6);
  let ptr = 0;
  for (let r = 0; r < R; r++) {
    for (let m = 0; m < M; m++) {
      const i00 = r * cols + m;
      const i10 = r * cols + (m + 1);
      const i01 = (r + 1) * cols + m;
      const i11 = (r + 1) * cols + (m + 1);

      indices[ptr++] = i00;
      indices[ptr++] = i01;
      indices[ptr++] = i11;

      indices[ptr++] = i00;
      indices[ptr++] = i11;
      indices[ptr++] = i10;
    }
  }

  // Apply Dedicated 3D Nose Tip, Nasal Sidewall, Upward-Recessed 3D Nasal Cavity & Soft Pillow Lip Carvers
  // + 8-step Volume-Preserving Taubin Soft-Tissue Fairing (`ZERO` pointy tip & `ZERO` pointy/low-poly lips!)
  const { cavityAO } = applyDedicatedNoseAndSoftLipCarvers(positions, regionT, cols, rows, weights);

  const normals = computeSeamlessGridNormals(positions, indices, cols, rows);
  const keyLandmarks3D = getKeyAnatomicalLandmarks3D(weights);
  const { blinkDeltas, blinkNormalDeltas, blinkMask } = computeEyelidBlinkBuffers(
    positions,
    regionT,
    weights,
    keyLandmarks3D,
    indices,
    cols,
    rows,
    normals
  );

  return {
    positions,
    normals,
    uvs,
    regionT,
    cavityAO,
    indices,
    cols,
    rows,
    keyLandmarks3D,
    blinkDeltas,
    blinkNormalDeltas,
    blinkMask,
  };
}

export function computeSeamlessGridNormals(positions, indices, cols, rows) {
  const normals = new Float32Array(positions.length);
  for (let i = 0; i < indices.length; i += 3) {
    const a = indices[i] * 3;
    const b = indices[i + 1] * 3;
    const c = indices[i + 2] * 3;

    const ux = positions[b] - positions[a];
    const uy = positions[b + 1] - positions[a + 1];
    const uz = positions[b + 2] - positions[a + 2];

    const vx = positions[c] - positions[a];
    const vy = positions[c + 1] - positions[a + 1];
    const vz = positions[c + 2] - positions[a + 2];

    const nx = uy * vz - uz * vy;
    const ny = uz * vx - ux * vz;
    const nz = ux * vy - uy * vx;

    normals[a] += nx; normals[a + 1] += ny; normals[a + 2] += nz;
    normals[b] += nx; normals[b + 1] += ny; normals[b + 2] += nz;
    normals[c] += nx; normals[c + 1] += ny; normals[c + 2] += nz;
  }

  for (let r = 0; r < rows; r++) {
    const i0 = r * cols * 3;
    const iM = (r * cols + (cols - 1)) * 3;
    const sx = normals[i0] + normals[iM];
    const sy = normals[i0 + 1] + normals[iM + 1];
    const sz = normals[i0 + 2] + normals[iM + 2];
    normals[i0] = normals[iM] = sx;
    normals[i0 + 1] = normals[iM + 1] = sy;
    normals[i0 + 2] = normals[iM + 2] = sz;
  }

  for (const poleRow of [0, rows - 1]) {
    let sx = 0, sy = 0, sz = 0;
    for (let m = 0; m < cols; m++) {
      const idx = (poleRow * cols + m) * 3;
      sx += normals[idx]; sy += normals[idx + 1]; sz += normals[idx + 2];
    }
    for (let m = 0; m < cols; m++) {
      const idx = (poleRow * cols + m) * 3;
      normals[idx] = sx; normals[idx + 1] = sy; normals[idx + 2] = sz;
    }
  }

  for (let i = 0; i < normals.length; i += 3) {
    const len = Math.hypot(normals[i], normals[i + 1], normals[i + 2]) || 1e-12;
    normals[i] /= len;
    normals[i + 1] /= len;
    normals[i + 2] /= len;
  }
  return normals;
}

/**
 * Evaluate all 91 Dense 3D Anatomical Landmarks on the parametric 3DMM head surface!
 * Uses exact surface coordinate inversion `evalAtXY(targetX, targetY)` so every 3D landmark
 * sits to `< 0.01 mm` on its exact sculpted 3D eyeball, eyelid rim, brow arch, nostril & vermilion border!
 */
export function getKeyAnatomicalLandmarks3D(w = DEFAULT_3DMM_WEIGHTS, yawRad = 0) {
  const faceW = 1.0 + 0.080 * (w.faceWidth || 0);
  const faceH = 1.0 + 0.072 * (w.faceHeight || 0);

  const eyeX = (2.82 + 0.22 * (w.eyeSpacing || 0)) * faceW;
  const eyeY = 1.56 * faceH;
  const eyeHalfW = 1.38 * (1.0 + 0.11 * (w.eyeWidth || 0)) * faceW;
  const eyeOpenH = 0.37 * (1.0 + 0.28 * (w.eyeSize || 0));
  const canthalSlope = 0.125 * (w.eyeTilt || 0);

  const bHeightShift = 0.36 * (w.browHeight || 0);
  const bArchAmp = 0.30 + 0.18 * (w.browArch || 0);
  const bTiltSlope = 0.22 * (w.browTilt || 0) + canthalSlope * 0.20;
  const browYAtU = (u) =>
    eyeY +
    1.18 +
    bHeightShift +
    bArchAmp * Math.sin(Math.pow(u, 0.88) * Math.PI) -
    0.15 * u * u +
    bTiltSlope * (u - 0.5);

  const nasionY    = eyeY + 0.42;
  const noseTipY   = (-1.80 - 0.50 * (w.noseLength || 0)) * faceH;
  const subnasaleY = noseTipY - 0.56 * faceH;
  const alarW      = clamp((1.38 + 0.32 * (w.noseWidth || 0)) * faceW, 1.14, 2.20);

  const legacyLip = w.lipFullness || 0.0;
  const upLipW = w.upperLipFullness !== undefined ? w.upperLipFullness : legacyLip;
  const loLipW = w.lowerLipFullness !== undefined ? w.lowerLipFullness : legacyLip;
  const mOpen  = clamp(w.mouthOpen || 0.0, 0.0, 1.55);
  const jawOpenDrop = 0.92 * mOpen;
  const mouthY     = (-4.04 - 0.36 * (w.mouthHeight || 0)) * faceH - jawOpenDrop * 0.36;
  const mouthHalfW = (2.18 + 0.34 * (w.mouthWidth || 0) + 0.22 * mOpen) * faceW;
  const upVol      = clamp(1.0 + 0.30 * upLipW, 0.80, 1.58);
  const loVol      = clamp(1.0 + 0.30 * loLipW, 0.82, 1.60);
  const cornerLift = 0.26 * (w.mouthCornerLift || 0) + 0.16 * mOpen;
  const upHeight   = (0.44 + 0.14 * (upVol - 1.0)) * faceH;
  const loHeight   = (0.56 + 0.16 * (loVol - 1.0)) * faceH;
  const halfOpenCenter = 0.56 * mOpen;
  const upInnerMidY = mouthY + halfOpenCenter * 0.76;
  const loInnerMidY = mouthY - halfOpenCenter * 1.24;
  const halfOpenMid58 = halfOpenCenter * Math.pow(Math.max(0.0, 1.0 - (0.58 / 0.96) ** 2), 0.68);

  // Precompute fast 24-knot centerline `t <-> y` lookup + 4-step exact `(theta, t)` refinement (< 0.04 ms total!)
  const TK = 24;
  const tSamples = new Float64Array(TK + 1);
  const ySamples = new Float64Array(TK + 1);
  for (let i = 0; i <= TK; i++) {
    const tv = 0.10 + (0.54 * i) / TK;
    tSamples[i] = tv;
    ySamples[i] = evaluateHeadBustPoint(0.0, tv, w)[1];
  }

  const evalAtXY = (targetX, targetY) => {
    let i = 0;
    while (i < TK - 1 && ySamples[i + 1] > targetY) i++;
    const spanY = ySamples[i] - ySamples[i + 1];
    let t = spanY > 1e-5
      ? clamp(tSamples[i] + ((ySamples[i] - targetY) / spanY) * (tSamples[i + 1] - tSamples[i]), 0.10, 0.62)
      : tSamples[i];
    let th = Math.asin(clamp(targetX / (6.35 * faceW), -0.92, 0.92));

    for (let it = 0; it < 3; it++) {
      const p = evaluateHeadBustPoint(th, t, w);
      const ex = targetX - p[0];
      const ey = targetY - p[1];
      if (Math.abs(ex) < 0.005 && Math.abs(ey) < 0.005) return p;
      th = clamp(th + ex / (6.25 * faceW), -1.15, 1.15);
      t  = clamp(t - ey / 27.5, 0.10, 0.62);
    }
    return evaluateHeadBustPoint(th, t, w);
  };

  // Exact 1:1 Surface-Aligned Palpebral Lashline Landmarks (evaluated on the EXACT sculpted `evalPalpebralContour` rims!)
  const eyeLidPt = (sgn, dxFrac, isUpper) => {
    const x = sgn * (eyeX + dxFrac * eyeHalfW);
    const { upperEdge, lowerEdge } = evalPalpebralContour(dxFrac, eyeY, eyeOpenH, canthalSlope);
    const y = isUpper ? upperEdge : lowerEdge;
    return evalAtXY(x, y);
  };
  const eyeCanthusPt = (sgn, isOuter) => {
    const dxFrac = isOuter ? 0.99 : -0.98;
    const x = sgn * (eyeX + dxFrac * eyeHalfW);
    const { canthalLineY } = evalPalpebralContour(dxFrac, eyeY, eyeOpenH, canthalSlope);
    return evalAtXY(x, canthalLineY);
  };

  const browXAtU = (u) => (eyeX - 1.72) + u * 3.76;
  const browHalfThickAtU = (u) => 0.24 - 0.11 * Math.pow(u, 1.5);
  const browPt = (sgn, u, vOff = 0.0) =>
    evalAtXY(sgn * browXAtU(u), browYAtU(u) + vOff * browHalfThickAtU(u));

  const wNoEar = { ...w, earProminence: 0.0 };
  const yShift = clamp(yawRad, -0.65, 0.65);
  const hzL = (base) => clamp(-base - yShift * 0.62, -1.86, -0.28);
  const hzR = (base) => clamp( base - yShift * 0.62,  0.28,  1.86);

  return {
    // 1. Hairline Arch (5)
    hairlineLeftTemple:  evaluateHeadBustPoint(-0.68, 0.212, w),
    hairlineLeftArch:    evaluateHeadBustPoint(-0.36, 0.174, w),
    hairline:            evaluateHeadBustPoint( 0.00, 0.168, w),
    hairlineRightArch:   evaluateHeadBustPoint( 0.36, 0.174, w),
    hairlineRightTemple: evaluateHeadBustPoint( 0.68, 0.212, w),

    // 2. Full Closed 8-Point Upper+Lower Eyebrow Contour Rings + Centerline (22)
    browLeftInner:       browPt(-1, 0.00,  0.0),
    browLeftMidInner:    browPt(-1, 0.27,  0.0),
    browLeft:            browPt(-1, 0.56,  0.0),
    browLeftMidOuter:    browPt(-1, 0.80,  0.0),
    browLeftOuter:       browPt(-1, 1.00,  0.0),
    browLeftUpperInner:  browPt(-1, 0.27, +1.0),
    browLeftUpper:       browPt(-1, 0.56, +1.0),
    browLeftUpperOuter:  browPt(-1, 0.80, +1.0),
    browLeftLowerInner:  browPt(-1, 0.27, -1.0),
    browLeftLower:       browPt(-1, 0.56, -1.0),
    browLeftLowerOuter:  browPt(-1, 0.80, -1.0),

    browRightInner:      browPt(+1, 0.00,  0.0),
    browRightMidInner:   browPt(+1, 0.27,  0.0),
    browRight:           browPt(+1, 0.56,  0.0),
    browRightMidOuter:   browPt(+1, 0.80,  0.0),
    browRightOuter:      browPt(+1, 1.00,  0.0),
    browRightUpperInner: browPt(+1, 0.27, +1.0),
    browRightUpper:      browPt(+1, 0.56, +1.0),
    browRightUpperOuter: browPt(+1, 0.80, +1.0),
    browRightLowerInner: browPt(+1, 0.27, -1.0),
    browRightLower:      browPt(+1, 0.56, -1.0),
    browRightLowerOuter: browPt(+1, 0.80, -1.0),

    // 3. Exact Surface-Aligned Palpebral Eyes + Irises (18)
    eyeLeft:             evalAtXY(-eyeX, eyeY),
    eyeLeftInner:        eyeCanthusPt(-1, false),
    eyeLeftUpperInner:   eyeLidPt(-1, -0.46, true),
    eyeLeftUpper:        eyeLidPt(-1,  0.00, true),
    eyeLeftUpperOuter:   eyeLidPt(-1, +0.46, true),
    eyeLeftOuter:        eyeCanthusPt(-1, true),
    eyeLeftLowerOuter:   eyeLidPt(-1, +0.46, false),
    eyeLeftLower:        eyeLidPt(-1,  0.00, false),
    eyeLeftLowerInner:   eyeLidPt(-1, -0.46, false),

    eyeRight:            evalAtXY( eyeX, eyeY),
    eyeRightInner:       eyeCanthusPt(+1, false),
    eyeRightUpperInner:  eyeLidPt(+1, -0.46, true),
    eyeRightUpper:       eyeLidPt(+1,  0.00, true),
    eyeRightUpperOuter:  eyeLidPt(+1, +0.46, true),
    eyeRightOuter:       eyeCanthusPt(+1, true),
    eyeRightLowerOuter:  eyeLidPt(+1, +0.46, false),
    eyeRightLower:       eyeLidPt(+1,  0.00, false),
    eyeRightLowerInner:  eyeLidPt(+1, -0.46, false),

    // 4. Exact Surface-Aligned Nose (12)
    glabella:            evalAtXY(0.0, eyeY + 1.15 + bHeightShift * 0.4),
    nasion:              evalAtXY(0.0, nasionY),
    rhinion:             evalAtXY(0.0, 0.5 * (nasionY + noseTipY)),
    supratip:            evalAtXY(0.0, 0.32 * nasionY + 0.68 * noseTipY),
    noseTip:             evalAtXY(0.0, noseTipY + 0.08),
    subnasale:           evalAtXY(0.0, subnasaleY + 0.04),
    alarCrestLeft:       evalAtXY(-alarW * 0.88, noseTipY - 0.06 * faceH),
    alarLeft:            evalAtXY(-alarW * 0.98, noseTipY - 0.22 * faceH),
    nostrilLeft:         evalAtXY(-alarW * 0.50, subnasaleY + 0.14),
    nostrilRight:        evalAtXY( alarW * 0.50, subnasaleY + 0.14),
    alarRight:           evalAtXY( alarW * 0.98, noseTipY - 0.22 * faceH),
    alarCrestRight:      evalAtXY( alarW * 0.88, noseTipY - 0.06 * faceH),

    // 5. Exact Surface-Aligned Outer + Inner Vermilion Lips (15 — tracks both closed AND open laughing mouths!)
    mouthLeft:           evalAtXY(-mouthHalfW, mouthY + cornerLift),
    upperLipLeft:        evalAtXY(-mouthHalfW * 0.58, mouthY + cornerLift * 0.34 + halfOpenMid58 * 0.76 + upHeight * 0.72),
    cupidPeakLeft:       evalAtXY(-mouthHalfW * 0.24, upInnerMidY + upHeight + 0.06),
    upperLipTop:         evalAtXY( 0.0, upInnerMidY + upHeight - 0.02),
    cupidPeakRight:      evalAtXY( mouthHalfW * 0.24, upInnerMidY + upHeight + 0.06),
    upperLipRight:       evalAtXY( mouthHalfW * 0.58, mouthY + cornerLift * 0.34 + halfOpenMid58 * 0.76 + upHeight * 0.72),
    mouthRight:          evalAtXY( mouthHalfW, mouthY + cornerLift),
    lowerLipRight:       evalAtXY( mouthHalfW * 0.58, mouthY + cornerLift * 0.34 - halfOpenMid58 * 1.24 - loHeight * 0.74),
    lowerLipBottom:      evalAtXY( 0.0, loInnerMidY - loHeight),
    lowerLipLeft:        evalAtXY(-mouthHalfW * 0.58, mouthY + cornerLift * 0.34 - halfOpenMid58 * 1.24 - loHeight * 0.74),
    stomionLeft:         evalAtXY(-mouthHalfW * 0.58, mouthY + cornerLift * 0.34),
    upperLipInner:       evalAtXY( 0.0, upInnerMidY + 0.02),
    mouthCenter:         evalAtXY( 0.0, 0.5 * (upInnerMidY + loInnerMidY)),
    lowerLipInner:       evalAtXY( 0.0, loInnerMidY - 0.02),
    stomionRight:        evalAtXY( mouthHalfW * 0.58, mouthY + cornerLift * 0.34),

    // 6. Dense 17-Point Face Oval & Oblique Gonial-to-Menton Jawline (17)
    //    `jaw` = gonion (`theta ~ 1.30`), `mandible` = mid-mandibular body (`theta ~ 0.90`), `chinLeft/Right` = parasymphysis (`theta ~ 0.48`)!
    templeLeft:          evaluateHeadBustPoint(hzL(1.36), 0.305, wNoEar),
    cheekLeft:           evaluateHeadBustPoint(hzL(1.42), 0.352, wNoEar),
    upperCheekLeft:      evaluateHeadBustPoint(hzL(1.40), 0.402, wNoEar),
    midCheekLeft:        evaluateHeadBustPoint(hzL(1.38), 0.448, wNoEar),
    lowerCheekLeft:      evaluateHeadBustPoint(hzL(1.38), 0.484, wNoEar),
    jawLeft:             evaluateHeadBustPoint(hzL(1.40), 0.528, wNoEar),
    mandibleLeft:        evaluateHeadBustPoint(hzL(1.02), 0.566, wNoEar),
    chinLeft:            evaluateHeadBustPoint(hzL(0.54), 0.586, wNoEar),
    chin:                evaluateHeadBustPoint(0.00,      0.590, w),
    chinRight:           evaluateHeadBustPoint(hzR(0.54), 0.586, wNoEar),
    mandibleRight:       evaluateHeadBustPoint(hzR(1.02), 0.566, wNoEar),
    jawRight:            evaluateHeadBustPoint(hzR(1.40), 0.528, wNoEar),
    lowerCheekRight:     evaluateHeadBustPoint(hzR(1.38), 0.484, wNoEar),
    midCheekRight:       evaluateHeadBustPoint(hzR(1.38), 0.448, wNoEar),
    upperCheekRight:     evaluateHeadBustPoint(hzR(1.40), 0.402, wNoEar),
    cheekRight:          evaluateHeadBustPoint(hzR(1.42), 0.352, wNoEar),
    templeRight:         evaluateHeadBustPoint(hzR(1.36), 0.305, wNoEar),

    // 7. Outer Ear Anchors (2 — aligned to 4-finger anatomical pinna position!)
    earLeft:             evaluateHeadBustPoint(-1.60, 0.395, w),
    earRight:            evaluateHeadBustPoint( 1.60, 0.395, w),
  };
}
