/**
 * Curated Triad3D v12.0 Showcase Scenes:
 *  1. Sunlit Pergola          — Crisp Default Shadows & Diagonal AA stress test
 *  2. Botanical Grove (<tree>) — 100% Declarative <tree>, <sweep>, <sdf> (zero JS mesh code!)
 *  3. Human & Sculpt (<figure>)— 100% Declarative <figure>/<skeleton>/<skin>, <loft>, <sdf>, <csg>
 *  4. Chrome & Glass Atelier   — 4x MSAA + FXAA 3.11 + Specular AA + Refractive Glass
 */

export function registerOrganicDemoGenerators() {
  // v12.0 requires ZERO custom JS mesh generators for trees, humans, sweeps, lofts, or SDFs!
}

export const DEMO_SCENES = [
  {
    id: 'pergola',
    name: 'Sunlit Pergola',
    subtitle: 'Thin cedar louvers, limestone colonnade & brass gnomon casting crisp shadows on travertine',
    cameras: [
      { id: 'hero', label: 'Hero View', pose: [0.2, 1.9, 0.0, 13.8, 36, 68] },
      { id: 'shadow', label: 'Shadow Close-Up', pose: [0.4, 0.5, 0.6, 7.6, 26, 48] },
      { id: 'edges', label: 'Louver Edges', pose: [0.0, 3.2, -0.4, 8.2, 54, 74] }
    ],
    defaultSunAzimuth: 38,
    defaultSunElevation: 42,
    sml: `<scene sky="#6ea3d8"
       fog-color="#dce7f2"
       fog-density="0.0045"
       env="studio"
       env-intensity="1.05"
       exposure="1.06"
       cloud-density="0.42"
       cloud-coverage="0.38"
       shadow-darkness="0.44"
       shadow-edge-boost="0.14"
       shadow-edge-sat="0.16">

  <style>
    .plaza-ground { color: #cfc6b8; roughness: 0.92; metalness: 0.0; }
    .travertine   { color: #ebe3d5; roughness: 0.82; metalness: 0.0; }
    .limestone    { color: #dfd7c8; roughness: 0.78; metalness: 0.0; }
    .cedar        { color: #8c5633; roughness: 0.66; metalness: 0.0; }
    .dark-steel   { color: #262e39; roughness: 0.30; metalness: 0.86; }
    .brass        { color: #d8ac56; roughness: 0.22; metalness: 0.92; }
    .basin-stone  { color: #435060; roughness: 0.58; metalness: 0.05; }
    .water-surf   { color: #2f7d96; roughness: 0.08; metalness: 0.12; opacity: 0.84; transparent: true; }
  </style>

  <directional-light id="key-sun" pos="14 16 12" target="0 1.4 0" color="#fff3df" intensity="3.1" cast-shadow="true" />
  <hemisphere-light color="#cfe5ff" ground-color="#a8937b" intensity="1.08" />

  <plane pos="0 0 0" width="120" depth="120" receive-shadow="true" cast-shadow="false" class="plaza-ground" />

  <box pos="0 0.12 0" size="11.6 0.24 9.6" border-radius="0.03" class="limestone" />
  <box pos="0 0.30 0" size="10.4 0.16 8.4" border-radius="0.02" class="travertine" />

  <group id="colonnade">
    <box pos="-4.2 0.44 -3.2" size="0.56 0.12 0.56" class="dark-steel" />
    <box pos="-4.2 2.24 -3.2" size="0.46 3.50 0.46" border-radius="0.03" class="limestone" />
    <box pos=" 4.2 0.44 -3.2" size="0.56 0.12 0.56" class="dark-steel" />
    <box pos=" 4.2 2.24 -3.2" size="0.46 3.50 0.46" border-radius="0.03" class="limestone" />
    <box pos="-4.2 0.44  3.2" size="0.56 0.12 0.56" class="dark-steel" />
    <box pos="-4.2 2.24  3.2" size="0.46 3.50 0.46" border-radius="0.03" class="limestone" />
    <box pos=" 4.2 0.44  3.2" size="0.56 0.12 0.56" class="dark-steel" />
    <box pos=" 4.2 2.24  3.2" size="0.46 3.50 0.46" border-radius="0.03" class="limestone" />
  </group>

  <box pos="0 4.04 -3.2" size="9.2 0.24 0.24" class="dark-steel" />
  <box pos="0 4.04  3.2" size="9.2 0.24 0.24" class="dark-steel" />
  <box pos="-4.2 4.04 0" size="0.24 0.24 6.6" class="dark-steel" />
  <box pos=" 4.2 4.04 0" size="0.24 0.24 6.6" class="dark-steel" />

  <repeat count="15" pos="-3.92 4.08 0" step="0.56 0 0">
    <box size="0.09 0.24 6.2" rot="0 0 18" class="cedar" />
  </repeat>

  <repeat count="11" pos="-3.6 2.18 -3.2" step="0.72 0 0">
    <box size="0.045 3.45 0.045" class="dark-steel" />
  </repeat>
  <box pos="0 1.42 -3.2" size="7.9 0.05 0.06" class="brass" />
  <box pos="0 2.94 -3.2" size="7.9 0.05 0.06" class="brass" />

  <group pos="-0.6 0.38 0.2">
    <cylinder pos="0 0.34 0" radius-top="0.78" radius-bottom="0.88" height="0.68" segments="36" class="limestone" />
    <cylinder pos="0 0.70 0" radius="0.72" height="0.05" segments="36" class="basin-stone" />
    <torus pos="0 1.38 0" radius="0.58" tube="0.032" rot="32 22 0" class="brass" />
    <torus pos="0 1.38 0" radius="0.44" tube="0.022" rot="-52 68 0" class="dark-steel" />
    <cylinder pos="0 1.48 0" radius="0.018" height="1.55" rot="0 0 -28" segments="16" class="brass" />
    <sphere pos="0 1.38 0" radius="0.11" class="brass" />
  </group>

  <group pos="2.2 0.38 0.4">
    <box pos="0 0.24 0" size="2.4 0.48 0.72" border-radius="0.02" class="limestone" />
    <box pos="0 0.50 0" size="2.48 0.06 0.78" border-radius="0.015" class="cedar" />
  </group>
  <group pos="-2.7 0.38 1.4">
    <box pos="0 0.18 0" size="2.2 0.36 1.5" class="basin-stone" />
    <box pos="0 0.37 0" size="1.96 0.02 1.26" cast-shadow="false" class="water-surf" />
  </group>
</scene>`
  },
  {
    id: 'grove',
    name: 'Botanical Grove',
    subtitle: 'Procedural PBR bark maps, fluted buttress trunks, S-arched boughs & individual 3D sculpted leaves',
    cameras: [
      { id: 'hero', label: 'Grove Hero', pose: [0.0, 3.8, 0.0, 20.5, 34, 72] },
      { id: 'branches', label: 'Bark & Branches', pose: [0.1, 3.3, 0.1, 7.2, 28, 76] },
      { id: 'roots', label: 'Buttress & Roots', pose: [0.0, 1.2, 0.4, 6.2, 26, 66] }
    ],
    defaultSunAzimuth: 42,
    defaultSunElevation: 39,
    sml: `<scene sky="#649bd4"
       fog-color="#d7e4ef"
       fog-density="0.004"
       env="studio"
       env-intensity="1.05"
       exposure="1.08"
       cloud-density="0.46"
       cloud-coverage="0.40"
       shadow-darkness="0.42"
       shadow-edge-boost="0.14"
       shadow-edge-sat="0.18">

  <style>
    .meadow-ground { color: #8c9e6c; roughness: 0.94; metalness: 0.0; }
    .terrace-stone { color: #e2dbc9; roughness: 0.84; metalness: 0.0; }
    .soil-bed      { color: #56422f; roughness: 0.95; metalness: 0.0; }
    .moss-stone    { color: #ffffff; roughness: 0.88; metalness: 0.0; }
    .iron-rail     { color: #222a35; roughness: 0.34; metalness: 0.85; }
    .warm-stone    { color: #d5cab6; roughness: 0.86; metalness: 0.0; }
    .garden-vine   { color: #4d7834; roughness: 0.72; metalness: 0.0; }
  </style>

  <directional-light id="key-sun" pos="15 16 12" target="0 2.6 0" color="#fff1d6" intensity="3.0" cast-shadow="true" />
  <hemisphere-light color="#cfe6ff" ground-color="#8b8266" intensity="1.12" />

  <plane pos="0 0 0" width="140" depth="140" receive-shadow="true" cast-shadow="false" class="meadow-ground" />

  <!-- Circular stone terrace & raised soil planter -->
  <cylinder pos="0 0.14 0" radius-top="6.8" radius-bottom="7.05" height="0.28" segments="48" class="terrace-stone" />
  <cylinder pos="0 0.38 0" radius-top="2.25" radius-bottom="2.38" height="0.24" segments="36" class="warm-stone" />
  <cylinder pos="0 0.48 0" radius-top="2.06" height="0.06" segments="32" class="soil-bed" />

  <!-- Declarative Hero Oak Tree: Solid Murray's Law boughs/twigs + individual sculpted 3D oak leaves -->
  <tree id="ancient-oak"
        pos="0 0.46 0"
        species="oak"
        seed="4217"
        height="8.4"
        trunk-radius="0.42"
        root-flare="1.65"
        branch-levels="3"
        branch-spread="0.84"
        gnarl="0.34"
        leaf-density="0.88"
        leaf-size="0.26"
        bark-furrow="0.075">
    <sweep role="root" path="0.2,0.52,0.18; 0.88,0.18,0.62; 1.68,0.03,0.96"
           radius="0.20 -> 0.10 -> 0.03" furrow="0.05" />
    <foliage-layer palette="#68a842 #7bbd4f #89c95a #579436" />
  </tree>

  <!-- Companion Mediterranean Cypress & Silver Birch with individual 3D foliage -->
  <tree id="cypress-left" pos="-5.4 0.28 -3.6" species="cypress" seed="108" height="7.4" leaf-density="0.90" />
  <tree id="birch-right"  pos=" 5.6 0.28 -3.4" species="birch"   seed="709" height="6.8" leaf-density="0.85" />

  <!-- Organic Smooth-Blended Mossy Boulder Cluster via <sdf> with color blending & noise -->
  <sdf pos="-2.9 0.56 2.1" resolution="32" smooth="0.24" noise-amp="0.055" noise-freq="2.4" class="moss-stone">
    <ellipsoid pos="0 0.12 0"      size="1.45 0.82 1.12" color="#8c877c" />
    <ellipsoid pos="0.62 -0.04 0.35" size="0.92 0.62 0.84" color="#6d8254" />
    <sphere    pos="-0.48 0.24 -0.18" radius="0.38"        color="#5e7a48" />
  </sdf>

  <!-- Curved stone bench with sculpted <sweep> vine handrail -->
  <box pos="3.5 0.54 1.7" size="2.0 0.48 0.64" rot="0 -26 0" border-radius="0.03" class="warm-stone" />
  <sweep pos="2.2 0.28 2.4"
         path="0,0,0; 0.35,0.65,0.22; 0.95,0.92,0.05; 1.55,0.62,-0.18; 1.95,0.05,-0.32"
         radius="0.065 -> 0.045 -> 0.03"
         furrow="0.04"
         class="garden-vine" />

  <!-- Fine wrought-iron terrace fence behind the oak -->
  <group pos="0 0.28 -5.4">
    <box pos="0 0.96 0" size="7.6 0.045 0.05" class="iron-rail" />
    <box pos="0 0.16 0" size="7.6 0.04 0.045" class="iron-rail" />
    <repeat count="20" pos="-3.61 0.56 0" step="0.38 0 0">
      <box size="0.028 0.86 0.028" class="iron-rail" />
    </repeat>
    <box pos="-3.8 0.58 0" size="0.18 1.16 0.18" class="warm-stone" />
    <box pos=" 3.8 0.58 0" size="0.18 1.16 0.18" class="warm-stone" />
  </group>
</scene>`
  },
  {
    id: 'figure',
    name: 'Human & Sculpt',
    subtitle: 'Analytical human anatomy, proportion-detecting hollow tailored tee + slim jeans, 5-finger hands & 3-View Visage 3DMM head',
    cameras: [
      { id: 'hero', label: 'Gallery Hero', pose: [0.0, 1.50, 0.0, 5.4, 20, 74] },
      { id: 'human', label: 'Figure & Cloth', pose: [0.0, 1.50, 0.0, 2.55, 22, 78] },
      { id: 'portrait', label: 'Face & Hair', pose: [0.0, 2.18, 0.04, 0.72, 12, 86] }
    ],
    zoomFocusAnchor: { base: [0.0, 1.50, 0.0], close: [0.0, 2.18, 0.04], farRadius: 2.8, nearRadius: 0.78 },
    defaultSunAzimuth: 32,
    defaultSunElevation: 40,
    sml: `<scene sky="#191f2a"
       fog-color="#191f2a"
       fog-density="0.006"
       env="studio"
       env-intensity="0.80"
       exposure="1.04"
       clouds="false"
       shadow-darkness="0.38"
       shadow-edge-boost="0.10"
       shadow-edge-sat="0.10">

  <style>
    .gallery-floor { color: #262d3a; roughness: 0.78; metalness: 0.04; }
    .gallery-wall  { color: #202733; roughness: 0.88; metalness: 0.0; }
    .plinth-stone  { color: #1b222e; roughness: 0.34; metalness: 0.16; }
    .travertine    { color: #d8d1c5; roughness: 0.72; metalness: 0.0; }
    .marble-skin   { color: #dfb8a0; roughness: 0.54; metalness: 0.0; }
    .terracotta    { color: #c26a48; roughness: 0.42; metalness: 0.04; clearcoat: 0.25; }
    .patina-bronze { color: #b88a4a; roughness: 0.24; metalness: 0.90; }
    .carved-jade   { color: #4e8c74; roughness: 0.28; metalness: 0.08; clearcoat: 0.35; }
  </style>

  <directional-light id="key-sun" pos="4.6 6.8 9.2" target="0 1.45 0" color="#fff6ec" intensity="1.48" cast-shadow="true" />
  <point-light pos="-3.0 2.4 3.0" color="#d4e4ff" intensity="1.38" distance="14" decay="2" />
  <point-light pos="2.0 2.7 -2.0" color="#ffe9d2" intensity="1.22" distance="12" decay="2" />
  <hemisphere-light color="#e2ecfa" ground-color="#485062" intensity="0.90" />

  <plane pos="0 0 0" width="90" depth="90" receive-shadow="true" cast-shadow="false" class="gallery-floor" />
  <box pos="0 2.8 -3.6" size="12.0 5.6 0.24" class="gallery-wall" />

  <!-- Center Pedestal: Analytical Human Anatomy + Proportion-Detecting Hollow Clothing + 3-View Visage 3DMM Head -->
  <box pos="0 0.26 0" size="1.45 0.52 1.45" border-radius="0.03" class="plinth-stone" />
  <box pos="0 0.55 0" size="1.28 0.06 1.28" border-radius="0.02" class="travertine" />

  <figure id="studio-human" pos="0 0.58 0" height="1.74" build="feminine" portrait-subject="elena" eye-color="#3a5266">
    <skin class="marble-skin" />
    <hair style="long_wavy" color="#1c1715" wind="0.85" />
    <garment type="jeans" color="#213450" shoe-color="#262d38" />
    <garment type="tshirt" color="#313f52" sleeve-length="0.30" />
  </figure>

  <!-- Left Pedestal: Cross-Section <loft> Ceramic Amphora + Outward-Wound Bronze <sweep> Handles -->
  <box pos="-2.25 0.34 0.15" size="1.15 0.68 1.15" border-radius="0.03" class="plinth-stone" />
  <loft pos="-2.25 0.68 0.15" segments="32" radial-segments="32" class="terracotta">
    <profile pos="0 0.00 0" radius="0.22" shape="circle" />
    <profile pos="0 0.24 0" radius="0.36" shape="circle" />
    <profile pos="0 0.68 0" radius="0.42 0.38" shape="circle" />
    <profile pos="0 1.04 0" radius="0.16" shape="circle" />
    <profile pos="0 1.24 0" radius="0.25" shape="circle" />
  </loft>
  <sweep pos="-2.25 0.68 0.15"
         path="0.37,0.34,0; 0.62,0.62,0.02; 0.50,0.98,0.01; 0.22,1.18,0"
         radius="0.036 -> 0.028 -> 0.024"
         class="patina-bronze">
    <mod type="mirror" axis="x" />
  </sweep>

  <!-- Right Pedestal: General Volumetric <csg mode="subtract"> Carved Jade Monolith & Bronze <sdf> -->
  <box pos="2.25 0.34 0.15" size="1.15 0.68 1.15" border-radius="0.03" class="plinth-stone" />
  <csg pos="2.25 1.32 0.15" mode="subtract" smooth="0.035" resolution="42" class="carved-jade">
    <box pos="0 0 0" size="0.88 1.22 0.58" border-radius="0.06" />
    <sphere pos="0 0.16 0" radius="0.34" />
    <cylinder pos="0 -0.28 0" radius="0.22" height="0.90" rot="90 0 0" />
  </csg>
  <sdf pos="2.25 1.48 0.15" mirror="x" resolution="30" smooth="0.08" class="patina-bronze">
    <torus pos="0 0 0" radius="0.18" tube="0.045" rot="90 0 0" />
    <sphere pos="0.12 0 0" radius="0.08" />
  </sdf>
</scene>`
  },
  {
    id: 'studio',
    name: 'Chrome & Glass',
    subtitle: 'High-contrast metallic trusses, specular edges, refractive glass & bloom with 4x MSAA',
    cameras: [
      { id: 'hero', label: 'Studio Hero', pose: [0.0, 1.5, 0.0, 10.6, 32, 70] },
      { id: 'specular', label: 'Specular AA', pose: [0.0, 1.55, 0.0, 5.8, 18, 66] },
      { id: 'top', label: 'Contact Shadows', pose: [0.0, 0.9, 0.3, 8.4, -36, 46] }
    ],
    defaultSunAzimuth: 44,
    defaultSunElevation: 48,
    sml: `<scene sky="#1e2736"
       fog-color="#1e2736"
       fog-density="0.008"
       env="studio"
       env-intensity="1.15"
       exposure="1.04"
       clouds="false"
       bloom="0.22"
       bloom-threshold="0.90"
       shadow-darkness="0.56"
       shadow-edge-boost="0.14"
       shadow-edge-sat="0.16">

  <style>
    .studio-floor { color: #bcc5d2; roughness: 0.74; metalness: 0.0; }
    .obsidian     { color: #1d2531; roughness: 0.26; metalness: 0.18; }
    .chrome       { color: #e2e8f0; roughness: 0.10; metalness: 0.98; }
    .copper       { color: #d9824b; roughness: 0.18; metalness: 0.94; }
    .glass-shell  { color: #e0f2fe; roughness: 0.04; metalness: 0.0; transmission: 0.90; ior: 1.50; thickness: 0.42; }
    .amber-core   { color: #ffba52; emissive: #f59e0b; emissive-intensity: 1.65; roughness: 0.22; }
    .matte-panel  { color: #e6e9ef; roughness: 0.86; metalness: 0.0; }
  </style>

  <directional-light id="key-sun" pos="10 14 9" target="0 1.2 0" color="#fff7eb" intensity="2.8" cast-shadow="true" />
  <hemisphere-light color="#dde8f8" ground-color="#4e5869" intensity="0.78" />

  <plane pos="0 0 0" width="90" depth="90" receive-shadow="true" cast-shadow="false" class="studio-floor" />
  <box pos="0 2.6 -3.8" size="11.0 5.2 0.22" class="matte-panel" />

  <box pos="0 0.22 0" size="6.2 0.44 3.8" border-radius="0.04" class="obsidian" />
  <box pos="0 0.47 0" size="5.6 0.06 3.2" border-radius="0.02" class="chrome" />

  <group pos="-1.75 1.55 0">
    <cylinder pos="0 -0.92 0" radius-top="0.28" radius-bottom="0.42" height="0.26" segments="32" class="obsidian" />
    <cylinder pos="0 -0.42 0" radius="0.05" height="0.78" segments="20" class="chrome" />
    <torus pos="0 0.18 0" radius="0.72" tube="0.036" rot="18 28 0" class="chrome" />
    <torus pos="0 0.18 0" radius="0.54" tube="0.028" rot="-44 58 0" class="copper" />
    <torus pos="0 0.18 0" radius="0.36" tube="0.022" rot="62 -35 0" class="chrome" />
    <sphere pos="0 0.18 0" radius="0.16" class="copper" />
  </group>

  <group pos="0 1.48 0">
    <cylinder pos="0 -0.88 0" radius="0.52" height="0.20" segments="36" class="obsidian" />
    <sphere pos="0 0.0 0" radius="0.32" class="amber-core" />
    <sphere pos="0 0.0 0" radius="0.72" class="glass-shell" />
    <torus pos="0 -0.74 0" radius="0.54" tube="0.025" rot="90 0 0" class="copper" />
  </group>

  <group pos="1.85 1.55 0">
    <box pos="0 -0.94 0" size="1.15 0.22 1.15" border-radius="0.02" class="obsidian" />
    <box pos="-0.48 0.12 -0.48" size="0.055 2.10 0.055" class="chrome" />
    <box pos=" 0.48 0.12 -0.48" size="0.055 2.10 0.055" class="chrome" />
    <box pos="-0.48 0.12  0.48" size="0.055 2.10 0.055" class="chrome" />
    <box pos=" 0.48 0.12  0.48" size="0.055 2.10 0.055" class="chrome" />
    <repeat count="9" pos="0 -0.72 0" step="0 0.21 0">
      <box size="0.94 0.030 0.86" rot="24 0 0" class="copper" />
    </repeat>
    <box pos="0 1.18 0" size="1.08 0.06 1.08" class="obsidian" />
  </group>
</scene>`
  },
  {
    id: 'portrait',
    name: 'Portrait 3DMM',
    subtitle: '3-View Visage 3DMM photo-to-head reconstruction, 1536px PBR skin bake, 3D blink & live silk hair physics',
    cameras: [
      { id: 'hero', label: 'Portrait Hero', pose: [0.0, 1.38, 0.0, 1.85, 16, 84] },
      { id: 'profile', label: 'Side Profile', pose: [0.0, 1.38, 0.0, 1.80, 68, 84] },
      { id: 'detail', label: 'Hair & Face', pose: [0.0, 1.44, 0.04, 1.15, -12, 83] }
    ],
    zoomFocusAnchor: { base: [0.0, 1.38, 0.0], close: [0.0, 1.44, 0.04], farRadius: 1.9, nearRadius: 0.72 },
    defaultSunAzimuth: 30,
    defaultSunElevation: 38,
    sml: `<scene sky="#141922"
       fog-color="#141922"
       fog-density="0.008"
       env="studio"
       env-intensity="0.72"
       exposure="1.02"
       clouds="false"
       shadow-darkness="0.44"
       shadow-edge-boost="0.12"
       shadow-edge-sat="0.12">

  <style>
    .studio-floor  { color: #1f2633; roughness: 0.74; metalness: 0.06; }
    .backdrop-wall { color: #1c222e; roughness: 0.88; metalness: 0.0; }
    .plinth-dark   { color: #171d28; roughness: 0.30; metalness: 0.22; }
    .plinth-trim   { color: #c9a362; roughness: 0.26; metalness: 0.88; }
    .marble-cap    { color: #d8d1c5; roughness: 0.52; metalness: 0.02; }
  </style>

  <directional-light id="key-sun" pos="5.2 7.2 7.4" target="0 1.35 0" color="#fff4e4" intensity="1.95" cast-shadow="true" />
  <point-light pos="-3.4 2.6 2.8" color="#c8dcff" intensity="1.45" distance="14" decay="2" />
  <point-light pos="1.8 2.8 -2.4" color="#ffe5c4" intensity="1.25" distance="12" decay="2" />
  <hemisphere-light color="#d8e4f5" ground-color="#3c4454" intensity="0.76" />

  <plane pos="0 0 0" width="60" depth="60" receive-shadow="true" cast-shadow="false" class="studio-floor" />
  <box pos="0 2.6 -3.0" size="10.0 5.4 0.20" class="backdrop-wall" />

  <!-- Sculptural Gallery Bust Pedestal -->
  <cylinder pos="0 0.40 0" radius-top="0.46" radius-bottom="0.54" height="0.80" segments="44" class="plinth-dark" />
  <cylinder pos="0 0.82 0" radius="0.49" height="0.04" segments="44" class="plinth-trim" />
  <cylinder pos="0 0.86 0" radius-top="0.44" radius-bottom="0.46" height="0.04" segments="44" class="marble-cap" />

  <!-- Declarative <portrait-head>: 3-View Stereo 3DMM Reconstruction + 1536px Baked PBR Skin + 3D Blink + Live Hair Physics -->
  <portrait-head id="visage-bust"
                 pos="0 0.88 0"
                 cm-scale="0.028"
                 subject="elena"
                 hair-style="auto"
                 wind="0.85"
                 density="0.90"
                 tex-size="1536" />
</scene>`
  }
];
