/**
 * Structured Engineering Plan: Intuitive Complex & Organic Modeling in Triad3D
 * Designed so both LLMs and human authors can author high-quality organic trees,
 * articulated humans, creatures, and sculptural architecture declaratively in SML/3SS.
 */

export const MODELING_PLAN = {
  title: 'Intuitive Organic & Complex Modeling Architecture for Triad3D',
  summary:
    'Today, authors and LLMs must choose between blocky SML primitives (<box>, <sphere>, <cylinder>) or verbose procedural vertex arrays in <script>. To make complex organic forms (trees, humans, creatures, draped cloth, sculpted architecture) effortless to author, Triad3D should introduce a 6-layer declarative geometry pipeline built directly onto SML and TriadMeshBuilder.',
  whyModelsStruggle: [
    'Primitive assembly forces manual trig/coordinate alignment for every limb or branch, producing visible seams and rigid silhouettes.',
    'Raw BufferGeometry vertex code is error-prone for LLMs: inverted winding, broken UV seams, and non-manifold holes are common.',
    'Anatomical and botanical forms are naturally described by skeletons, cross-section profiles, smooth blending volumes, and growth rules — not raw triangles.'
  ],
  pillars: [
    {
      id: 'sdf',
      badge: 'Layer 1',
      title: 'Smooth-Union Volumetric Sculpting (<sdf>)',
      tagline: 'Declarative metaballs and signed-distance booleans meshed cleanly with Surface Nets',
      howItWorks:
        'Wrap familiar primitives (<capsule>, <sphere>, <ellipsoid>, <torus>, <cone>) inside an <sdf resolution="64" smooth="0.14"> tag. The engine evaluates polynomial smooth-min (smin) / smooth-subtract in a sparse octree or bounded voxel grid, extracts a watertight quad-dominant mesh via Dual Contouring / Surface Nets, computes analytic SDF gradients for silky-smooth normals, and blends vertex colors & roughness across joints automatically.',
      bestFor: 'Human torsos, shoulders, faces, hands, animal bodies, tree root flares, eroded boulders, stylized vehicles.'
    },
    {
      id: 'skeleton',
      badge: 'Layer 2',
      title: 'Skeleton-Driven Skinning & Auto-Tubing (<skeleton> + <skin>)',
      tagline: 'Write bone hierarchies with anatomical radii; get a rigged, watertight organic mesh + animation',
      howItWorks:
        'Define a readable semantic hierarchy of <bone name="pelvis"> -> <bone name="spine"> -> <bone name="chest"> -> <bone name="upper-arm-l"> using natural lengths, joint angles (rot), and cross-section radius profiles (profile="0.11 0.14 0.09", oval="1.3 0.9"). <skin mode="sdf|loft" smooth="0.06"> automatically skins the bone graph into a seamless mesh with bone weights, UV seams along the back/inner limb, and built-in 3SS keyframe or IK posing.',
      bestFor: 'Articulated humans, quadrupeds, hands, tentacles, mech frames, and animated characters.'
    },
    {
      id: 'botanical',
      badge: 'Layer 3',
      title: 'Parametric Botanical Growth (<tree> & <foliage>)',
      tagline: 'Space-colonization & recursive branching with flared roots, bark furrows, and instanced leaf cards',
      howItWorks:
        'Expose a dedicated <tree species="oak|pine|birch|willow|olive|palm" height="9" trunk-radius="0.45" gnarl="0.35" levels="4" crown="dome" leaf-style="broadleaf" seed="42"> tag backed by a deterministic Space-Colonization + Weber-Penn branching solver. The trunk and primary limbs build welded tapered tubes with root buttress flares and radial bark displacement; fine twigs emit thousands of GPU-instanced alpha-tested leaf cluster cards with per-instance tint variation, subsurface backlighting, and vertex-shader wind sway.',
      bestFor: 'Photorealistic or stylized oaks, pines, palms, bonsai, ivy vines, and dense forest groves.'
    },
    {
      id: 'spline',
      badge: 'Layer 4',
      title: 'Declarative Spline Sweeps & Cross-Section Lofts (<sweep>, <loft>)',
      tagline: 'Promote TriadMeshBuilder.addTaperedTube & addLoft into first-class SML tags',
      howItWorks:
        'Add <sweep path="0,0,0; 0.2,1.5,0.1; -0.3,3.2,0.4" radius="0.35 -> 0.12 -> 0.04" twist="45" ribs="8" rib-depth="0.06"> and <loft> with nested <section y="..." shape="circle|rounded-rect|star|custom" rx="..." rz="..."/> children. Automatically generates continuous Frenet/parallel-transport frames (preventing twists/kinks), closed caps, and metric UVs.',
      bestFor: 'Branches, roots, horns, robes, vases, car fenders, coiled cables, arched moldings, and boat hulls.'
    },
    {
      id: 'subdiv',
      badge: 'Layer 5',
      title: 'Catmull-Clark Subdivision & Non-Destructive Modifiers (<subdiv>, <mod>)',
      tagline: 'Author a 6-box coarse control cage, get a smooth organic surface with symmetric mirroring',
      howItWorks:
        'Wrap coarse geometry or a compact vertex/quad cage in <subdiv level="2" crease="0.3"> and stack declarative modifiers: <mod type="mirror" axis="x"/>, <mod type="taper" factor="0.6"/>, <mod type="bend" angle="25"/>, <mod type="displace" noise="fbm" scale="0.08"/>. Because half-symmetry (<mod type="mirror"/>) halves coordinate work, LLMs only author one side of a face, torso, chair, or chassis.',
      bestFor: 'Stylized characters, ergonomic furniture, automotive bodies, helmets, architectural shells.'
    },
    {
      id: 'csg',
      badge: 'Layer 6',
      title: 'True Manifold Boolean CSG & Semantic Anatomical Presets',
      tagline: 'Replace hardcoded doorway <csg> with general BSP/Manifold booleans + reusable macros',
      howItWorks:
        'Upgrade <csg op="subtract|union|intersect"> to perform real mesh booleans on any child geometry (carving arched niches, eye sockets, window reveals, mechanical housings). Pair this with an extensible standard library of semantic macros (<humanoid>, <tree>, <rock>, <staircase>, <archway>) that expose intuitive artistic parameters (age, build, posture, outfit, species, wind) while remaining 100% inspectable and styleable via 3SS.',
      bestFor: 'Detailed architecture, mechanical parts, rapid scene assembly with consistent scale and proportions.'
    }
  ],
  treeExampleSML: `<!-- Intuitive High-Quality Organic Tree in Proposed Triad3D v12 SML -->
<tree id="ancient-oak"
      species="oak"
      seed="4217"
      height="9.5"
      trunk-radius="0.48"
      root-flare="1.65"
      branch-levels="4"
      branch-spread="0.72"
      gnarl="0.34"
      canopy-shape="dome"
      canopy-clusters="26"
      leaf-density="0.88"
      bark-furrow="0.09"
      wind="0.35">
  <!-- Optional artistic override for hero roots or deadwood boughs -->
  <sweep role="root" path="0,0.4,0; 0.9,0.12,0.5; 1.9,-0.04,0.9"
         radius="0.24 -> 0.11 -> 0.03" furrow="0.05" />
  <foliage-layer height="0.55..1.0" palette="#2d5a27 #3f7332 #5c8a3b"
                 subsurface="0.42" alpha-test="0.38" />
</tree>`,
  humanExampleSML: `<!-- Intuitive Articulated Human in Proposed Triad3D v12 SML -->
<skeleton id="explorer" pose="contrapposto" height="1.76">
  <!-- Right side automatically mirrored when symmetry="x" is active -->
  <bone name="pelvis" pos="0 0.96 0" length="0.16" profile="0.16 0.15" oval="1.35 0.9">
    <bone name="spine" length="0.24" rot="4 0 0" profile="0.13 0.14" oval="1.25 0.88">
      <bone name="chest" length="0.26" rot="-3 0 0" profile="0.16 0.18 0.14" oval="1.42 0.92">
        <bone name="neck" length="0.11" profile="0.058 0.052">
          <bone name="head" length="0.22" rot="2 -8 0">
            <!-- Smooth-blended facial features inside the head bone space -->
            <sdf smooth="0.025" resolution="48">
              <ellipsoid pos="0 0.11 0" size="0.088 0.112 0.102" />
              <ellipsoid pos="0 0.04 0.055" size="0.058 0.052 0.055" />
              <capsule   pos="0 0.09 0.098" radius="0.011" length="0.038" rot="16 0 0" />
              <sphere    op="subtract" pos="-0.032 0.112 0.084" radius="0.018" smooth="0.012" />
              <sphere    op="subtract" pos=" 0.032 0.112 0.084" radius="0.018" smooth="0.012" />
            </sdf>
          </bone>
        </bone>
        <bone name="arm" symmetry="x" offset="0.19 0.21 0" rot="0 0 -14" length="0.30" profile="0.058 0.048">
          <bone name="forearm" rot="18 0 0" length="0.27" profile="0.046 0.034">
            <bone name="hand" length="0.17" profile="0.036 0.042 0.018" oval="1.4 0.45" />
          </bone>
        </bone>
      </bone>
    </bone>
    <bone name="thigh" symmetry="x" offset="0.10 -0.02 0" rot="4 0 -3" length="0.44" profile="0.092 0.068">
      <bone name="shin" rot="-6 0 0" length="0.43" profile="0.062 0.040">
        <bone name="foot" rot="88 0 0" length="0.24" profile="0.042 0.048 0.030" oval="1.2 0.65" />
      </bone>
    </bone>
  </bone>

  <!-- Watertight SDF skinning welds torso, shoulders, hips & limbs seamlessly -->
  <skin mode="sdf" resolution="72" smooth="0.045" material="class:skin-warm" />
  <garment over="chest,spine,arm" type="jacket" thickness="0.014" collar="0.06" class="canvas-coat" />
</skeleton>`,
  roadmap: [
    {
      phase: 'Phase 1 · Weeks 1–2',
      title: 'Declarative <sweep>, <loft>, and <mod type="mirror|taper|bend|noise">',
      effort: 'Low risk · Builds directly on existing TriadMeshBuilder',
      deliverables: [
        'Expose addTaperedTube and addLoft as <sweep> and <loft> SML tags with parallel-transport framing (no twisting artifacts).',
        'Add post-build modifier stack (<mod>) for X/Z symmetry mirroring, radial bark/stone FBM displacement, taper, and bend.',
        'Upgrade vertex welding + crease-angle normal computation so organic shapes shade seamlessly.'
      ]
    },
    {
      phase: 'Phase 2 · Weeks 3–4',
      title: 'Parametric <tree> & Instanced Botanical Foliage Pipeline',
      effort: 'High impact for outdoor scenes & natural environments',
      deliverables: [
        'Implement deterministic Space-Colonization + recursive spline branching with flared root buttresses and bark UV unwrapping.',
        'Generate GPU-instanced leaf cluster cards (<foliage-layer>) with alpha-to-coverage / sharpened cutout AA, vertex wind sway, and per-instance color variation.',
        'Ship 6 built-in species presets (oak, pine, birch, willow, olive, palm) tunable via intuitive semantic attributes.'
      ]
    },
    {
      phase: 'Phase 3 · Weeks 5–7',
      title: 'Sparse Octree <sdf> Sculpting & Surface Nets Mesher',
      effort: 'Unlocks intuitive organic modeling for LLMs with zero seams',
      deliverables: [
        'Implement polynomial smooth-union (smin), smooth-subtract, and smooth-intersect primitives in a fast typed-array Surface Nets mesher.',
        'Compute analytic SDF gradient normals + smooth material/vertex-color blending across primitive boundaries.',
        'Cache meshed SDF geometry by AST attribute signature so static organic assets compile once in <30ms.'
      ]
    },
    {
      phase: 'Phase 4 · Weeks 8–10',
      title: '<skeleton> + <skin> Rigged Character Pipeline & General CSG',
      effort: 'Enables articulated humans, creatures, clothing & animation',
      deliverables: [
        'Build declarative <skeleton>/<bone> graph parser with automatic symmetry="x", joint constraint limits, and SDF/loft auto-skinning.',
        'Add GPU vertex skinning (uBoneMatrices[48]) so 3SS keyframes and procedural walk/idle cycles deform characters smoothly.',
        'Replace doorway-only <csg> with a general manifold mesh boolean kernel for arbitrary architectural and mechanical cutouts.'
      ]
    }
  ]
};
