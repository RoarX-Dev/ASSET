import './index.css';
import { DEMO_SCENES, registerOrganicDemoGenerators } from './scenes/demo-scenes.js';
import { createWorkbenchUI } from './ui/workbench.js';
import { createVisagePortraitEngine, PORTRAIT_SAMPLES } from './lib/visage-bridge.js';
import { createHumanBodyEngine } from './lib/human-body.js';

function bootstrap() {
  const root = document.getElementById('app');
  const Triad3D = window.Triad3D;
  if (!root || !Triad3D) {
    throw new Error('Triad3D engine failed to load.');
  }

  registerOrganicDemoGenerators(Triad3D);
  const portraitEngine = createVisagePortraitEngine();
  if (typeof Triad3D.registerPortraitEngine === 'function') {
    Triad3D.registerPortraitEngine(portraitEngine);
  }
  const humanBodyEngine = createHumanBodyEngine();
  if (typeof Triad3D.registerHumanBodyEngine === 'function') {
    Triad3D.registerHumanBodyEngine(humanBodyEngine);
  }

  let currentScene = DEMO_SCENES[0];
  let currentMode = 'high';
  let currentSoftness = 0.55;
  let currentWindStrength = 1.0;
  let currentHairStyle = 'auto';
  let viewer = null;

  function syncPlaybackState() {
    if (!viewer) return;
    if (typeof viewer.setWindStrength === 'function') {
      viewer.setWindStrength(currentWindStrength);
    }
    if (typeof viewer.hasDynamicSimulators === 'function' && viewer.hasDynamicSimulators()) {
      viewer.play();
    } else {
      viewer.pause();
    }
  }

  function getActivePortraitTarget() {
    if (!viewer) return null;
    const node =
      viewer.getElementById('visage-bust') ||
      viewer.getElementById('studio-human') ||
      viewer.querySelector('portrait-head') ||
      viewer.querySelector('figure');
    if (!node || !node.object3D) return null;
    const skinList = Array.isArray(node.object3D.userData._bodySkinMeshes) && node.object3D.userData._bodySkinMeshes.length
      ? node.object3D.userData._bodySkinMeshes
      : (node.object3D.userData._bodySkinMesh ? [node.object3D.userData._bodySkinMesh] : []);
    return {
      figureRoot: node.object3D,
      inner: node.object3D.userData._portraitInner || node.object3D,
      bodySkinMeshes: skinList,
      readyPromise: node.object3D.userData._portraitReadyPromise || null
    };
  }

  async function reconstructPortraitFromSource(srcInput, label, sampleId = '', thumbUrl = '') {
    const target = getActivePortraitTarget();
    if (!target || !target.inner || !viewer) return null;
    const previewUrl = thumbUrl || (Array.isArray(srcInput) ? (srcInput[0] && srcInput[0].url) : srcInput);
    ui.setActivePortraitSample(sampleId);
    ui.setPortraitSourceThumb(previewUrl, label);
    ui.setPortraitStatus(`Solving ${label}...`);
    try {
      // Live proportion re-tailoring: switch body build & re-drape hollow garments when switching subjects
      if (sampleId && target.figureRoot && typeof target.figureRoot.userData._rebuildForBuild === 'function') {
        target.figureRoot.userData._rebuildForBuild(sampleId === 'marcus' ? 'athletic' : 'feminine');
      }
      const metrics = await portraitEngine.reconstructIntoGroup(
        Triad3D.THREE,
        target.inner,
        srcInput,
        label,
        { hairStyle: currentHairStyle, wind: 0.85, densityScale: 0.90, texSize: 1536 },
        viewer.runtime
      );
      if (target.bodySkinMeshes.length && metrics && metrics.neckSkinRGB && typeof portraitEngine.applyVisageBodySkinMaterial === 'function') {
        portraitEngine.applyVisageBodySkinMaterial(Triad3D.THREE, target.bodySkinMeshes, metrics.neckSkinRGB);
      }
      viewer.renderer.shadowMap.needsUpdate = true;
      viewer.renderer._lastShadowSig = '';
      syncPlaybackState();
      viewer.renderFrame();
      const viewsTag = metrics.viewCount > 1 ? ` · ${metrics.viewCount}-View` : '';
      ui.setPortraitStatus(`${label}${viewsTag} · ${metrics.strandCount} strands`);
      return metrics;
    } catch (err) {
      ui.setPortraitStatus(`Error: ${err && err.message ? err.message : 'Failed'}`);
      return null;
    }
  }

  function applyPortraitHairStyle(styleName) {
    currentHairStyle = styleName || 'auto';
    ui.setHairStyleUI(currentHairStyle);
    const target = getActivePortraitTarget();
    if (!target || !target.inner || !viewer) return null;
    const metrics = portraitEngine.updateHairStyleInGroup(
      Triad3D.THREE,
      target.inner,
      currentHairStyle,
      { wind: 0.85, windScale: currentWindStrength, densityScale: 0.90 },
      viewer.runtime
    );
    viewer.renderer.shadowMap.needsUpdate = true;
    viewer.renderer._lastShadowSig = '';
    syncPlaybackState();
    viewer.renderFrame();
    if (metrics) {
      ui.setPortraitStatus(`${currentHairStyle} · ${metrics.strandCount || 0} strands`);
    }
    return metrics;
  }

  function triggerPortraitBlink() {
    const target = getActivePortraitTarget();
    if (!target || !target.inner || !viewer) return false;
    if (typeof portraitEngine.triggerBlinkInGroup === 'function') {
      const ok = portraitEngine.triggerBlinkInGroup(target.inner);
      if (ok && viewer.isPaused) viewer.play();
      return ok;
    }
    return false;
  }

  const ui = createWorkbenchUI(root, {
    onSelectScene: (sceneId) => loadSceneById(sceneId),
    onSetQualityMode: (mode) => applyQualityMode(mode),
    onChangeShadowSoftness: (val) => {
      currentSoftness = val;
      if (viewer && currentMode === 'high') {
        const stats = viewer.setQualityMode('high', { shadowSoftness: val });
        ui.updateQualityUI(stats);
      }
    },
    onChangeSunAzimuth: (deg) => updateSunPosition(deg),
    onChangeWindStrength: (val) => {
      currentWindStrength = val;
      if (viewer && typeof viewer.setWindStrength === 'function') {
        viewer.setWindStrength(val);
      }
    },
    onSelectPortraitSample: (sampleId) => {
      const sample = PORTRAIT_SAMPLES.find((s) => s.id === sampleId);
      if (sample) reconstructPortraitFromSource(sample.views || sample.url, sample.label, sample.id, sample.url);
    },
    onUploadPortrait: (dataUrl, fileName) => {
      const cleanName = String(fileName || 'Custom Photo').replace(/\.[^.]+$/, '').slice(0, 18);
      reconstructPortraitFromSource(dataUrl, cleanName, '', dataUrl);
    },
    onChangeHairStyle: (styleName) => applyPortraitHairStyle(styleName),
    onTriggerBlink: () => triggerPortraitBlink(),
    onSelectCamera: (pose) => {
      if (viewer) {
        viewer.setOrbitPose(pose[0], pose[1], pose[2], pose[3], pose[4], pose[5]);
      }
    },
    onApplyCustomSML: (smlSource) => {
      if (!viewer) return { ok: false, error: 'Viewer not ready' };
      try {
        viewer.loadSML(smlSource);
        applyQualityMode(currentMode);
        syncPlaybackState();
        return { ok: true };
      } catch (err) {
        return { ok: false, error: err && err.message ? err.message : String(err) };
      }
    },
    onResetCurrentScene: () => loadSceneById(currentScene.id)
  });

  viewer = Triad3D.mount(ui.viewportHost, {
    gui: false,
    hud: false,
    autoPlay: false,
    exposure: 1.04
  });

  viewer.canvas.addEventListener('triad-portrait-ready', (e) => {
    const detail = e && e.detail ? e.detail : {};
    const m = detail.metrics || {};
    if (currentScene && (currentScene.id === 'portrait' || currentScene.id === 'figure')) {
      ui.setPortraitStatus(`${m.label || detail.subject || 'Portrait'} · ${m.strandCount || 0} strands`);
    }
    syncPlaybackState();
    viewer.renderFrame();
  });

  viewer.canvas.addEventListener('webglcontextlost', (event) => {
    event.preventDefault();
    ui.fallbackOverlay.classList.remove('hidden');
  });
  viewer.canvas.addEventListener('webglcontextrestored', () => {
    ui.fallbackOverlay.classList.add('hidden');
    loadSceneById(currentScene.id);
  });

  function updateSunPosition(azimuthDeg) {
    if (!viewer) return;
    const sunNode = viewer.getElementById('key-sun');
    const dirLight = sunNode && sunNode.object3D ? sunNode.object3D : null;
    if (!dirLight) return;
    const elRad = (currentScene.defaultSunElevation * Math.PI) / 180;
    const azRad = (azimuthDeg * Math.PI) / 180;
    const dist = 24;
    dirLight.position.set(
      Math.cos(elRad) * Math.sin(azRad) * dist,
      Math.sin(elRad) * dist,
      Math.cos(elRad) * Math.cos(azRad) * dist
    );
    dirLight.updateMatrixWorld(true);
    if (viewer.runtime && viewer.runtime.skyUniforms && viewer.runtime.skyUniforms.uSunDir) {
      viewer.runtime.skyUniforms.uSunDir.value
        .copy(dirLight.position)
        .sub(dirLight.target.position)
        .normalize();
    }
    viewer.renderer.shadowMap.needsUpdate = true;
    viewer.renderer._lastShadowSig = '';
    viewer.renderFrame();
    ui.updateQualityUI(viewer.getQualityStats());
  }

  function applyQualityMode(mode) {
    currentMode = mode;
    if (!viewer) return;
    const overrides = mode === 'high' ? { shadowSoftness: currentSoftness } : {};
    const stats = viewer.setQualityMode(mode, overrides);
    ui.updateQualityUI(stats);
  }

  function loadSceneById(sceneId) {
    const found = DEMO_SCENES.find((s) => s.id === sceneId) || DEMO_SCENES[0];
    currentScene = found;
    currentHairStyle = 'auto';
    ui.setActiveSceneUI(found);
    if (found.id === 'portrait' || found.id === 'figure') ui.setPortraitStatus('Solving Elena...');
    viewer.loadSML(found.sml);
    const hero = found.cameras[0].pose;
    viewer.setOrbitPose(hero[0], hero[1], hero[2], hero[3], hero[4], hero[5]);
    if (typeof viewer.setZoomFocusAnchor === 'function') {
      if (found.zoomFocusAnchor) {
        const z = found.zoomFocusAnchor;
        viewer.setZoomFocusAnchor(z.base, z.close, z.farRadius, z.nearRadius);
      } else {
        viewer.setZoomFocusAnchor(null, null);
      }
    }
    applyQualityMode(currentMode);
    syncPlaybackState();
  }

  loadSceneById(DEMO_SCENES[0].id);

  window.__TRIAD_WORKBENCH__ = {
    getVersion: () => Triad3D.version,
    getSceneId: () => currentScene.id,
    getQualityStats: () => viewer.getQualityStats(),
    setQualityMode: (mode) => applyQualityMode(mode),
    setWindStrength: (val) => {
      currentWindStrength = val;
      return viewer.setWindStrength(val);
    },
    isPlaying: () => !viewer.isPaused,
    pause: () => {
      viewer.pause();
      const target = getActivePortraitTarget();
      if (target && target.inner && typeof portraitEngine.resetEyesOpenInGroup === 'function') {
        portraitEngine.resetEyesOpenInGroup(target.inner);
      }
      viewer.renderFrame();
    },
    play: () => viewer.play(),
    triggerBlink: () => triggerPortraitBlink(),
    selectPortraitSample: async (sampleId) => {
      const sample = PORTRAIT_SAMPLES.find((s) => s.id === sampleId);
      if (!sample) return null;
      return reconstructPortraitFromSource(sample.views || sample.url, sample.label, sample.id, sample.url);
    },
    setPortraitHairStyle: (styleName) => applyPortraitHairStyle(styleName),
    waitForPortraitReady: async () => {
      const target = getActivePortraitTarget();
      if (target && target.readyPromise) return target.readyPromise;
      return null;
    },
    getOrbitState: () => ({
      target: [viewer.orbit.target.x, viewer.orbit.target.y, viewer.orbit.target.z],
      radius: viewer.orbit.spherical.radius
    }),
    getSimSummary: () => {
      const rt = viewer.runtime;
      const clothSims = (rt && rt.clothSimulators) || [];
      const hairSims = (rt && rt.hairSimulators) || [];
      return {
        playing: !viewer.isPaused,
        clothCount: clothSims.length,
        hairCount: hairSims.length,
        clothSample: clothSims.map((s) => {
          const i = Math.max(0, s.pos.length - 12);
          return [s.pos[i], s.pos[i + 1], s.pos[i + 2]];
        }),
        hairSample: hairSims.map((h) => {
          const st = h.strands[0];
          const pts = st ? st.pts : null;
          const k = pts ? pts.length - 3 : 0;
          return pts ? [pts[k], pts[k + 1], pts[k + 2]] : [0, 0, 0];
        })
      };
    },
    loadScene: (id) => loadSceneById(id),
    applyCustomSML: (sml) => {
      viewer.loadSML(sml);
      applyQualityMode(currentMode);
      syncPlaybackState();
    },
    setCameraPose: (pose) => viewer.setOrbitPose(pose[0], pose[1], pose[2], pose[3], pose[4], pose[5]),
    openModelingPlan: (tab) => {
      ui.togglePlanDrawer(true);
      if (tab) ui.setPlanTab(tab);
    },
    closeModelingPlan: () => ui.togglePlanDrawer(false)
  };
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', bootstrap);
} else {
  bootstrap();
}
