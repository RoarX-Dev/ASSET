/**
 * VISAGE // FORGE — Pure Vanilla JS Deliverable Exporter
 *  1. Binary .GLB (glTF 2.0 PBR mesh + embedded Albedo, Normal & Roughness maps)
 *  2. Wavefront .OBJ + .MTL + PBR PNGs (.zip via JSZip)
 *  3. Copy-ready Standalone Pure Vanilla JS + Three.js ES Module Source Code
 *  4. Self-Contained Single-File .HTML Interactive 3D Viewer (inline Base64 .GLB)
 */

import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';

export function triggerDownload(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

function rgbaToPngBlob(rgba, size) {
  return new Promise((resolve) => {
    const c = document.createElement('canvas');
    c.width = size;
    c.height = size;
    const ctx = c.getContext('2d');
    ctx.putImageData(new ImageData(new Uint8ClampedArray(rgba), size, size), 0, 0);
    c.toBlob((blob) => resolve(blob), 'image/png');
  });
}

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = '';
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

/**
 * Serialize reconstructed PBR 3D Bust to glTF 2.0 Binary (.GLB) ArrayBuffer.
 */
export function buildGLBBuffer(viewport, bakedTextures) {
  return new Promise((resolve, reject) => {
    const exportRoot = viewport.buildExportablePBRMesh(bakedTextures);
    if (!exportRoot) {
      reject(new Error('No reconstructed 3D bust available to export.'));
      return;
    }

    const exporter = new GLTFExporter();
    exporter.parse(
      exportRoot,
      (result) => {
        exportRoot.traverse((node) => {
          if (node.isMesh) {
            if (node.geometry) node.geometry.dispose();
            const m = node.material;
            if (m) {
              if (m.map) m.map.dispose();
              if (m.normalMap) m.normalMap.dispose();
              if (m.roughnessMap) m.roughnessMap.dispose();
              m.dispose();
            }
          }
        });

        if (result instanceof ArrayBuffer) {
          resolve(result);
        } else {
          const jsonStr = JSON.stringify(result, null, 2);
          resolve(new TextEncoder().encode(jsonStr).buffer);
        }
      },
      (err) => reject(err),
      { binary: true, maxTextureSize: 1024 }
    );
  });
}

export async function downloadBustGLB(viewport, bakedTextures, subjectSlug = 'visage') {
  const glbBuf = await buildGLBBuffer(viewport, bakedTextures);
  const filename = `${subjectSlug}_bust360.glb`;
  triggerDownload(new Blob([glbBuf], { type: 'model/gltf-binary' }), filename);
  return { filename, byteLength: glbBuf.byteLength };
}

/**
 * Bundle Wavefront .OBJ + .MTL + Albedo/Normal/Roughness/Coverage PNGs into a single .ZIP archive.
 */
export async function downloadBustOBJZip(recon, bakedTextures, subjectSlug = 'visage', hairState = null, hairProfile = null) {
  const JSZipLib = window.JSZip;
  if (!JSZipLib) throw new Error('JSZip library not loaded.');

  const zip = new JSZipLib();
  const { positions, normals, uvs, indices } = recon.geometry;
  const numV = positions.length / 3;
  const numF = indices.length / 3;

  const objLines = [
    `# VISAGE // FORGE — Custom 360° Parametric + SfS Digital-Human Bust & Hair Groom`,
    `# Pure Vanilla JS Engine (Zero External Neural Models)`,
    `# Bust Vertices: ${numV} | Triangles: ${numF}`,
    `mtllib ${subjectSlug}_bust360.mtl`,
    `o VisageBust360`,
  ];

  // Export in metric meters (0.01x cm)
  for (let i = 0; i < numV; i++) {
    const x = (positions[3 * i] * 0.01).toFixed(6);
    const y = (positions[3 * i + 1] * 0.01).toFixed(6);
    const z = (positions[3 * i + 2] * 0.01).toFixed(6);
    objLines.push(`v ${x} ${y} ${z}`);
  }
  for (let i = 0; i < numV; i++) {
    const u = uvs[2 * i].toFixed(6);
    const v = uvs[2 * i + 1].toFixed(6);
    objLines.push(`vt ${u} ${v}`);
  }
  for (let i = 0; i < numV; i++) {
    const nx = normals[3 * i].toFixed(5);
    const ny = normals[3 * i + 1].toFixed(5);
    const nz = normals[3 * i + 2].toFixed(5);
    objLines.push(`vn ${nx} ${ny} ${nz}`);
  }

  objLines.push(`usemtl VisageBustPBR`);
  objLines.push(`s 1`);
  for (let f = 0; f < numF; f++) {
    const a = indices[3 * f] + 1;
    const b = indices[3 * f + 1] + 1;
    const c = indices[3 * f + 2] + 1;
    objLines.push(`f ${a}/${a}/${a} ${b}/${b}/${b} ${c}/${c}/${c}`);
  }

  if (hairState && hairState.ribbonPositions) {
    const hPos = hairState.ribbonPositions;
    const hNrm = hairState.ribbonNormals;
    const hUv = hairState.ribbonUVs;
    const hIdx = hairState.ribbonIndices;
    const hNumV = hPos.length / 3;
    const hNumF = hIdx.length / 3;

    objLines.push(`o VisageHairGroom`);
    for (let i = 0; i < hNumV; i++) {
      objLines.push(`v ${(hPos[3 * i] * 0.01).toFixed(6)} ${(hPos[3 * i + 1] * 0.01).toFixed(6)} ${(hPos[3 * i + 2] * 0.01).toFixed(6)}`);
    }
    for (let i = 0; i < hNumV; i++) {
      objLines.push(`vt ${hUv[2 * i].toFixed(6)} ${hUv[2 * i + 1].toFixed(6)}`);
    }
    for (let i = 0; i < hNumV; i++) {
      objLines.push(`vn ${hNrm[3 * i].toFixed(5)} ${hNrm[3 * i + 1].toFixed(5)} ${hNrm[3 * i + 2].toFixed(5)}`);
    }
    objLines.push(`usemtl VisageHairPBR`);
    objLines.push(`s 1`);
    for (let f = 0; f < hNumF; f++) {
      const a = numV + hIdx[3 * f] + 1;
      const b = numV + hIdx[3 * f + 1] + 1;
      const c = numV + hIdx[3 * f + 2] + 1;
      objLines.push(`f ${a}/${a}/${a} ${b}/${b}/${b} ${c}/${c}/${c}`);
    }
  }

  const midRGB = hairProfile?.midRGB || [36, 28, 22];
  const kdR = (midRGB[0] / 255).toFixed(3);
  const kdG = (midRGB[1] / 255).toFixed(3);
  const kdB = (midRGB[2] / 255).toFixed(3);

  const mtlText = [
    `# VISAGE // FORGE PBR Material`,
    `newmtl VisageBustPBR`,
    `Ka 1.000 1.000 1.000`,
    `Kd 1.000 1.000 1.000`,
    `Ks 0.080 0.080 0.080`,
    `Ns 42.0`,
    `d 1.0`,
    `illum 2`,
    `map_Kd albedo.png`,
    `map_Bump -bm 0.18 normal.png`,
    `map_Pr roughness.png`,
    ``,
    `newmtl VisageHairPBR`,
    `Ka ${kdR} ${kdG} ${kdB}`,
    `Kd ${kdR} ${kdG} ${kdB}`,
    `Ks 0.220 0.210 0.200`,
    `Ns 64.0`,
    `d 1.0`,
    `illum 2`,
  ].join('\n');

  const sz = bakedTextures.texSize;
  const [albBlob, nrmBlob, rghBlob, covBlob] = await Promise.all([
    rgbaToPngBlob(bakedTextures.albedoData, sz),
    rgbaToPngBlob(bakedTextures.normalData, sz),
    rgbaToPngBlob(bakedTextures.roughnessData, sz),
    rgbaToPngBlob(bakedTextures.coverageData, sz),
  ]);

  zip.file(`${subjectSlug}_bust360.obj`, objLines.join('\n'));
  zip.file(`${subjectSlug}_bust360.mtl`, mtlText);
  zip.file('albedo.png', albBlob);
  zip.file('normal.png', nrmBlob);
  zip.file('roughness.png', rghBlob);
  zip.file('coverage_diagnostic.png', covBlob);

  const zipBlob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE' });
  const filename = `${subjectSlug}_bust360_obj_pbr.zip`;
  triggerDownload(zipBlob, filename);
  return { filename, byteLength: zipBlob.size };
}

/**
 * Generate clean, copy-ready Pure Vanilla JS + Three.js ES Module viewer code!
 */
export function generateVanillaThreeCode(recon, subjectSlug = 'visage') {
  const glbFilename = `${subjectSlug}_bust360.glb`;
  const wJson = JSON.stringify(
    Object.fromEntries(Object.entries(recon.weights).map(([k, v]) => [k, Number(v.toFixed(3))])),
    null,
    2
  );
  const poseSummary = recon.poses
    .map(
      (p, i) =>
        ` *   View ${i + 1}: yaw=${p.yawDeg.toFixed(1)}°, pitch=${p.pitchDeg.toFixed(1)}°, roll=${p.rollDeg.toFixed(1)}°, rmse=${p.reprojectionErrorPx.toFixed(2)}px`
    )
    .join('\n');

  return `/**
 * VISAGE // FORGE — Standalone Pure Vanilla JS + Three.js 360° Bust Scene
 * Subject: ${subjectSlug}
 * Topology: ${recon.metrics.vertexCount.toLocaleString()} vertices · ${recon.metrics.triangleCount.toLocaleString()} watertight triangles
 * Multi-View Camera Solve (${recon.metrics.viewCount} view${recon.metrics.viewCount > 1 ? 's' : ''}):
${poseSummary}
 *
 * Place "${glbFilename}" alongside an index.html containing <div id="app"></div>
 * and load this module with <script type="module" src="./scene.js"></script>.
 */

import * as THREE from 'https://unpkg.com/three@0.170.0/build/three.module.js';
import { OrbitControls } from 'https://unpkg.com/three@0.170.0/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'https://unpkg.com/three@0.170.0/examples/jsm/loaders/GLTFLoader.js';

// Solved Custom 3DMM Anthropometric Identity Parameters (for reference / procedural animation)
export const SOLVED_3DMM_WEIGHTS = ${wJson};

const container = document.getElementById('app') || document.body;
container.style.margin = '0';
container.style.width = '100vw';
container.style.height = '100vh';
container.style.background = 'radial-gradient(circle at 50% 35%, #172030 0%, #090c12 100%)';

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(19, window.innerWidth / window.innerHeight, 0.05, 25);
camera.position.set(0, -0.022, 1.12); // Telephoto 112cm portrait lens in metric meters

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.04;
container.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.target.set(0, -0.026, 0.005);

// Soft Wrap-Around Studio Portrait Lighting Rig
scene.add(new THREE.HemisphereLight(0xf6f8ff, 0xa8968c, 1.52));

const keyLight = new THREE.DirectionalLight(0xfff9f2, 0.92);
keyLight.position.set(0.32, 0.22, 0.42);
scene.add(keyLight);

const fillLight = new THREE.DirectionalLight(0xdbe8ff, 0.58);
fillLight.position.set(-0.38, 0.08, 0.30);
scene.add(fillLight);

const rimLight = new THREE.DirectionalLight(0x93c5fd, 0.52);
rimLight.position.set(-0.18, 0.22, -0.42);
scene.add(rimLight);

// Load Exported Reconstructed 360° PBR Bust (.GLB)
let bustRoot = null;
const loader = new GLTFLoader();
loader.load('./${glbFilename}', (gltf) => {
  bustRoot = gltf.scene;
  scene.add(bustRoot);
});

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

function animate() {
  requestAnimationFrame(animate);
  controls.update();
  renderer.render(scene, camera);
}
animate();
`;
}

/**
 * Export a single self-contained .HTML file with inline Base64 .GLB so it opens standalone!
 */
export async function downloadStandaloneHTMLViewer(viewport, bakedTextures, recon, subjectSlug = 'visage') {
  const glbBuf = await buildGLBBuffer(viewport, bakedTextures);
  const b64 = arrayBufferToBase64(glbBuf);
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>VISAGE // FORGE — ${subjectSlug.toUpperCase()} 360° Bust Viewer</title>
  <style>
    html, body { margin: 0; height: 100%; overflow: hidden; background: radial-gradient(circle at 50% 35%, #172030 0%, #090c12 100%); font-family: system-ui, sans-serif; color: #e2e8f0; }
    #hud { position: fixed; left: 20px; bottom: 20px; padding: 10px 14px; background: rgba(13, 18, 28, 0.82); border: 1px solid rgba(56, 189, 248, 0.28); border-radius: 10px; font-size: 12px; letter-spacing: 0.04em; backdrop-filter: blur(8px); }
    #hud strong { color: #38bdf8; }
  </style>
  <script type="importmap">
  {
    "imports": {
      "three": "https://unpkg.com/three@0.170.0/build/three.module.js",
      "three/addons/": "https://unpkg.com/three@0.170.0/examples/jsm/"
    }
  }
  </script>
</head>
<body>
  <div id="hud">
    <strong>VISAGE // FORGE</strong> · ${subjectSlug.toUpperCase()} 360° PBR BUST · ${recon.metrics.vertexCount.toLocaleString()} VERTS · DRAG TO ORBIT
  </div>
  <script type="module">
    import * as THREE from 'three';
    import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
    import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(19, innerWidth / innerHeight, 0.05, 25);
    camera.position.set(0, -0.022, 1.12);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.setSize(innerWidth, innerHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.04;
    document.body.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.target.set(0, -0.026, 0.005);

    scene.add(new THREE.HemisphereLight(0xf6f8ff, 0xa8968c, 1.52));
    const key = new THREE.DirectionalLight(0xfff9f2, 0.92); key.position.set(0.32, 0.22, 0.42); scene.add(key);
    const fill = new THREE.DirectionalLight(0xdbe8ff, 0.58); fill.position.set(-0.38, 0.08, 0.30); scene.add(fill);
    const rim = new THREE.DirectionalLight(0x93c5fd, 0.52); rim.position.set(-0.18, 0.22, -0.42); scene.add(rim);

    const b64 = "${b64}";
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);

    new GLTFLoader().parse(bytes.buffer, '', (gltf) => scene.add(gltf.scene));

    addEventListener('resize', () => {
      camera.aspect = innerWidth / innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(innerWidth, innerHeight);
    });

    (function loop() {
      requestAnimationFrame(loop);
      controls.update();
      renderer.render(scene, camera);
    })();
  </script>
</body>
</html>`;

  const filename = `${subjectSlug}_bust360_viewer.html`;
  triggerDownload(new Blob([html], { type: 'text/html;charset=utf-8' }), filename);
  return { filename };
}
