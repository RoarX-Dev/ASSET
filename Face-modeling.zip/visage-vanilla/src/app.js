/**
 * VISAGE // FORGE — Master Pure Vanilla JS Application Controller
 * Zero React, Zero TypeScript, Zero Build Step, Zero External AI/MediaPipe Models.
 */

import { detectClassicalFaceLandmarks } from './classicalFaceVision.js?v=v81_sculpt_gold';
import {
  DEFAULT_3DMM_WEIGHTS,
  generate3DMMBustGeometry,
  getKeyAnatomicalLandmarks3D,
  computeSeamlessGridNormals,
  computeEyelidBlinkBuffers,
} from './morphableHead3DMM.js?v=v81_sculpt_gold';
import { projectPoint3D } from './math3d.js?v=v81_sculpt_gold';
import { reconstruct3DHeadBust } from './reconstructionSolver.js?v=v81_sculpt_gold';
import { bakeMultiViewBustTextures } from './textureBaker.js?v=v81_sculpt_gold';
import { analyzeReferenceHairGroom } from './hairVisionEngine.js?v=v81_sculpt_gold';
import { BustViewport3D } from './viewport3d.js?v=v81_sculpt_gold';
import {
  downloadBustGLB,
  downloadBustOBJZip,
  generateVanillaThreeCode,
  downloadStandaloneHTMLViewer,
  triggerDownload,
} from './exporter.js?v=v81_sculpt_gold';

const PRESETS = {
  'elena-stereo': {
    title: 'ELENA · 3-VIEW STEREO',
    slug: 'elena_stereo',
    sources: [
      { url: './samples/elena-front.jpg', label: 'Front 0°' },
      { url: './samples/elena-left.jpg', label: 'Left 3/4' },
      { url: './samples/elena-right.jpg', label: 'Right 3/4' },
    ],
  },
  'aria-single': {
    title: 'ARIA · WAVY LOCKS',
    slug: 'aria_wavy',
    sources: [{ url: './samples/aria-front.jpg', label: 'Front 0°' }],
  },
  'sofia-laugh': {
    title: 'SOFIA · LAUGHING SMILE',
    slug: 'sofia_laugh',
    sources: [{ url: './samples/sofia-laugh.jpg', label: 'Front 0°' }],
  },
  'marcus-single': {
    title: 'MARCUS · BUZZ FADE',
    slug: 'marcus_single',
    sources: [{ url: './samples/marcus-front.jpg', label: 'Front 0°' }],
  },
  'elena-single': {
    title: 'ELENA · SINGLE PHOTO',
    slug: 'elena_single',
    sources: [{ url: './samples/elena-front.jpg', label: 'Front 0°' }],
  },
};

const SLIDER_DEFS = [
  { key: 'noseTipRoundness', label: 'Carver · Blunt Nose Tip Roundness', min: 0.20, max: 1.80, step: 0.02 },
  { key: 'noseSideCarve',    label: 'Carver · 3D Nostril Wings & Groove', min: 0.00, max: 1.80, step: 0.02 },
  { key: 'nasalCavityDepth', label: 'Carver · 3D Nasal Cavity Depth',    min: 0.00, max: 1.80, step: 0.02 },
  { key: 'lipSoftness',      label: 'Carver · Soft Pillow Lip Roll',     min: 0.25, max: 1.80, step: 0.02 },
  { key: 'mouthLineDepth',   label: 'Carver · Mouth Lines (Vision)',     min: 0.00, max: 1.80, step: 0.02 },
  { key: 'neckWidth',        label: 'Neck Vision Cylindrical Width',     min: -1.2, max: 1.4,  step: 0.02 },
  { key: 'faceWidth',        label: 'Lean Cheek & Face Width',  min: -1.6, max: 1.6, step: 0.02 },
  { key: 'cheekHollow',      label: 'Buccal Cheek Slenderness', min: -1.5, max: 1.5, step: 0.02 },
  { key: 'jawWidth',         label: 'Mandibular Jaw Taper',     min: -1.5, max: 1.5, step: 0.02 },
  { key: 'chinProjection',   label: 'Chin Prominence',          min: -1.5, max: 1.5, step: 0.02 },
  { key: 'chinWidth',        label: 'Chin Point Breadth',       min: -1.5, max: 1.5, step: 0.02 },
  { key: 'faceHeight',       label: 'Vertical Facial Index',    min: -1.6, max: 1.6, step: 0.02 },
  { key: 'foreheadHeight',   label: 'Forehead Trichion Height', min: -1.6, max: 1.6, step: 0.02 },
  { key: 'eyeSpacing',       label: 'Interpupillary Span',      min: -1.6, max: 1.6, step: 0.02 },
  { key: 'eyeWidth',         label: 'Palpebral Fissure Width',  min: -1.5, max: 1.5, step: 0.02 },
  { key: 'eyeSize',          label: 'Palpebral Eye Opening',    min: -1.2, max: 1.2, step: 0.02 },
  { key: 'eyeTilt',          label: 'Canthal Eye Tilt',         min: -0.8, max: 0.8, step: 0.02 },
  { key: 'browHeight',       label: 'Eyebrow Height',           min: -1.5, max: 1.5, step: 0.02 },
  { key: 'browArch',         label: 'Eyebrow Arch Peak',        min: -1.5, max: 1.5, step: 0.02 },
  { key: 'browTilt',         label: 'Eyebrow Outer Tilt',       min: -1.5, max: 1.5, step: 0.02 },
  { key: 'noseProjection',   label: 'Nasal Dorsum & Tip Z',     min: -1.5, max: 1.5, step: 0.02 },
  { key: 'noseBridgeWidth',  label: 'Nasal Bridge Width',       min: -1.5, max: 1.5, step: 0.02 },
  { key: 'noseBridgeArch',   label: 'Dorsal Bridge Profile',    min: -1.5, max: 1.5, step: 0.02 },
  { key: 'noseTipBall',      label: 'Pronasale Tip Fullness',   min: -1.5, max: 1.5, step: 0.02 },
  { key: 'noseWidth',        label: 'Alar Nostril Flare',       min: -1.6, max: 1.6, step: 0.02 },
  { key: 'noseLength',       label: 'Nasal Vertical Length',    min: -1.5, max: 1.5, step: 0.02 },
  { key: 'upperLipFullness', label: 'Upper Lip & Cupid\'s Bow', min: -1.6, max: 1.6, step: 0.02 },
  { key: 'lowerLipFullness', label: 'Lower Vermilion Pillow',   min: -1.6, max: 1.6, step: 0.02 },
  { key: 'mouthOpen',        label: 'Open Smile / Laugh Jaw',   min: 0.0,  max: 1.5, step: 0.02 },
  { key: 'mouthWidth',       label: 'Oral Commissure Width',    min: -1.6, max: 1.6, step: 0.02 },
  { key: 'mouthCornerLift',  label: 'Mouth Corner Lift',        min: -1.2, max: 1.2, step: 0.02 },
  { key: 'mouthHeight',      label: 'Philtrum / Lip Height',    min: -1.5, max: 1.5, step: 0.02 },
  { key: 'browProminence',   label: 'Supraorbital Brow Arch',   min: -1.5, max: 1.5, step: 0.02 },
  { key: 'cheekbones',       label: 'Zygomatic Malar Arch',     min: -1.5, max: 1.5, step: 0.02 },
  { key: 'craniumScale',     label: '360° Cranial Vault',       min: 0.86, max: 1.16, step: 0.01 },
  { key: 'earProminence',    label: 'Sculpted Ear Scale',       min: 0.55, max: 1.45, step: 0.02 },
  { key: 'neckBustScale',    label: 'Neck & Bust Pedestal',     min: 0.85, max: 1.18, step: 0.01 },
];

function getLandmarkColor(k) {
  if (k.startsWith('iris')) return '#f8fafc';
  if (k.startsWith('eye')) return '#38bdf8';
  if (k.startsWith('brow') || k === 'glabella') return '#818cf8';
  if (k.includes('nose') || k.includes('nostril') || k.startsWith('alar') || k === 'nasion' || k === 'rhinion' || k === 'subnasale') {
    return '#34d399';
  }
  if (k.includes('mouth') || k.includes('Lip') || k.startsWith('cupid')) return '#fb7185';
  if (k.startsWith('ear')) return '#fb923c';
  if (k === 'hairline' || k.startsWith('forehead')) return '#f59e0b';
  return '#facc15';
}

const state = {
  subjectTitle: 'ELENA · 3-VIEW STEREO',
  subjectSlug: 'elena_stereo',
  views: [], // { id, label, dataUrl, imageEl, imageData, width, height, landmarks2D, initialPose, enabled, visionMs }
  selectedViewIdx: 0,
  density: 'standard',
  sfsStrength: 0.35,
  delightStrength: 0.28,
  hairStyleOverride: 'auto',
  hairVolumeScale: 1.0,
  hairProfile: null,
  userOverrides: {},
  recon: null,
  bakedTextures: null,
  webcamStream: null,
  webcamCaptures: {},
  draggingLandmarkKey: null,
  hoveredLandmarkKey: null,
};

let viewport = null;

function setStatus(msg, isWorking = false) {
  const banner = document.getElementById('status-banner');
  if (!banner) return;
  banner.textContent = msg;
  banner.style.borderColor = isWorking ? 'rgba(56, 189, 248, 0.55)' : 'rgba(16, 185, 129, 0.38)';
  banner.style.color = isWorking ? '#38bdf8' : '#34d399';
  banner.style.background = isWorking ? 'rgba(56, 189, 248, 0.14)' : 'rgba(16, 185, 129, 0.14)';
}

function loadImageElement(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (e) => reject(e);
    img.src = src;
  });
}

function extractImageData(img, maxDim = 960) {
  let w = img.naturalWidth || img.width;
  let h = img.naturalHeight || img.height;
  if (Math.max(w, h) > maxDim) {
    const sc = maxDim / Math.max(w, h);
    w = Math.round(w * sc);
    h = Math.round(h * sc);
  }
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d');
  ctx.drawImage(img, 0, 0, w, h);
  return { imageData: ctx.getImageData(0, 0, w, h), width: w, height: h, dataUrl: c.toDataURL('image/jpeg', 0.9) };
}

function defaultFallbackLandmarks() {
  return {
    hairline: [0.50, 0.20],
    browLeft: [0.40, 0.34], browRight: [0.60, 0.34],
    eyeLeft: [0.41, 0.39], eyeRight: [0.59, 0.39],
    nasion: [0.50, 0.38], rhinion: [0.50, 0.44],
    noseTip: [0.50, 0.50], subnasale: [0.50, 0.53], alarLeft: [0.45, 0.52], alarRight: [0.55, 0.52],
    upperLipTop: [0.50, 0.58], mouthLeft: [0.43, 0.60], mouthCenter: [0.50, 0.60], mouthRight: [0.57, 0.60], lowerLipBottom: [0.50, 0.63],
    cheekLeft: [0.32, 0.41], cheekRight: [0.68, 0.41],
    midCheekLeft: [0.34, 0.53], midCheekRight: [0.66, 0.53],
    jawLeft: [0.36, 0.62], jawRight: [0.64, 0.62],
    chinLeft: [0.43, 0.69], chinRight: [0.57, 0.69],
    chin: [0.50, 0.73],
  };
}

async function createViewFromSource(srcUrl, label) {
  const img = await loadImageElement(srcUrl);
  const { imageData, width, height, dataUrl } = extractImageData(img, 960);
  const t0 = performance.now();
  const det = detectClassicalFaceLandmarks(imageData);
  const visionMs = performance.now() - t0;

  return {
    id: `${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    label,
    dataUrl,
    imageEl: img,
    imageData,
    width,
    height,
    landmarks2D: det ? det.landmarks2D : defaultFallbackLandmarks(),
    shapeMeasurements: det ? det.shapeMeasurements : {},
    initialPose: det ? det.initialPose : { yawDeg: 0, pitchDeg: 0, rollDeg: 0 },
    enabled: true,
    visionMs,
  };
}

/**
 * Build Right-Sidebar 3DMM Morph Sliders dynamically.
 */
function init3DMMSlidersUI() {
  const host = document.getElementById('sliders-3dmm-container');
  host.innerHTML = '';

  for (const def of SLIDER_DEFS) {
    const defVal = DEFAULT_3DMM_WEIGHTS[def.key];
    const row = document.createElement('div');
    row.className = 'slider-row';
    row.innerHTML = `
      <div class="slider-label-line">
        <span>${def.label}</span>
        <span class="slider-val" id="sval-${def.key}">${defVal.toFixed(2)}</span>
      </div>
      <input
        type="range"
        class="studio-slider"
        id="sinput-${def.key}"
        data-param="${def.key}"
        min="${def.min}"
        max="${def.max}"
        step="${def.step}"
        value="${defVal}"
      />
    `;
    host.appendChild(row);

    const input = row.querySelector('input');
    // Real-time 60 FPS mesh morphing while dragging!
    input.addEventListener('input', () => {
      const v = parseFloat(input.value);
      state.userOverrides[def.key] = v;
      document.getElementById(`sval-${def.key}`).textContent = (v >= 0 ? '+' : '') + v.toFixed(2);
      fastMorphGeometryInPlace();
    });
    // Re-seat scalp roots & collision capsules when slider finishes
    input.addEventListener('change', () => {
      rebuildHairFromCurrentBust();
    });
  }
}

function syncSlidersFromWeights(weights) {
  for (const def of SLIDER_DEFS) {
    const v = weights[def.key] ?? DEFAULT_3DMM_WEIGHTS[def.key];
    const input = document.getElementById(`sinput-${def.key}`);
    const lbl = document.getElementById(`sval-${def.key}`);
    if (input) input.value = String(v);
    if (lbl) lbl.textContent = (v >= 0 && def.min < 0 ? '+' : '') + v.toFixed(2);
  }
}

/**
 * Instant (<8 ms) 60 FPS geometry deformation on slider drag while retaining intrinsic baked UV maps!
 */
function fastMorphGeometryInPlace() {
  if (!state.recon || !viewport || !viewport.bustMesh) return;
  const mergedWeights = { ...state.recon.weights, ...state.userOverrides };
  const morphed = generate3DMMBustGeometry(mergedWeights, state.density);

  // Preserve smooth craniofacial silhouette warp offsets when interactively sculpting sliders!
  const warp = state.recon.geometry.warpOffsets;
  if (warp && warp.length === morphed.positions.length) {
    for (let i = 0; i < morphed.positions.length; i++) {
      morphed.positions[i] += warp[i];
    }
    morphed.normals = computeSeamlessGridNormals(
      morphed.positions,
      morphed.indices,
      morphed.cols,
      morphed.rows
    );
  }

  const blink = computeEyelidBlinkBuffers(
    morphed.positions,
    morphed.regionT,
    mergedWeights,
    morphed.keyLandmarks3D,
    morphed.indices,
    morphed.cols,
    morphed.rows,
    morphed.normals
  );
  state.recon.weights = mergedWeights;
  state.recon.geometry.positions.set(morphed.positions);
  state.recon.geometry.normals.set(morphed.normals);
  state.recon.geometry.cavityAO = morphed.cavityAO;
  state.recon.geometry.keyLandmarks3D = morphed.keyLandmarks3D;
  state.recon.geometry.blinkDeltas = blink.blinkDeltas;
  state.recon.geometry.blinkNormalDeltas = blink.blinkNormalDeltas;
  state.recon.geometry.blinkMask = blink.blinkMask;

  const geo = viewport.bustMesh.geometry;
  geo.attributes.position.array.set(morphed.positions);
  geo.attributes.position.needsUpdate = true;
  geo.attributes.normal.array.set(morphed.normals);
  geo.attributes.normal.needsUpdate = true;
  if (geo.attributes.aBlinkDelta) {
    geo.attributes.aBlinkDelta.array.set(blink.blinkDeltas);
    geo.attributes.aBlinkDelta.needsUpdate = true;
  }
  if (geo.attributes.aBlinkNormalDelta) {
    geo.attributes.aBlinkNormalDelta.array.set(blink.blinkNormalDeltas);
    geo.attributes.aBlinkNormalDelta.needsUpdate = true;
  }
  if (geo.attributes.aBlinkMask) {
    geo.attributes.aBlinkMask.array.set(blink.blinkMask);
    geo.attributes.aBlinkMask.needsUpdate = true;
  }

  // Update 3D landmark spheres & corneal domes
  viewport.updateCornealDomes(morphed.keyLandmarks3D);
  if (viewport.landmarkGroup && morphed.keyLandmarks3D) {
    for (const pin of viewport.landmarkGroup.children) {
      const p3 = morphed.keyLandmarks3D[pin.name];
      if (p3) pin.position.set(p3[0], p3[1], p3[2] + 0.10);
    }
  }
  drawLandmarkEditor();
}

function updateHairHUDAndSwatch(hairProfile, hairMetrics) {
  if (!hairProfile) return;
  const hm = hairMetrics || { strandCount: 0, flyawayCount: 0, triangleCount: 0 };
  const dot = document.getElementById('hair-swatch-dot');
  const lbl = document.getElementById('hair-detected-label');
  const hudHair = document.getElementById('hud-hair');

  const mid = hairProfile.midRGB || [36, 28, 22];
  const sr = Math.min(255, Math.round(Math.pow(mid[0] / 255, 0.72) * 255));
  const sg = Math.min(255, Math.round(Math.pow(mid[1] / 255, 0.72) * 255));
  const sb = Math.min(255, Math.round(Math.pow(mid[2] / 255, 0.72) * 255));
  if (dot) dot.style.background = `rgb(${sr}, ${sg}, ${sb})`;
  if (lbl) lbl.textContent = hairProfile.styleLabel || hairProfile.style;

  if (hudHair) {
    const activeStyleLbl =
      state.hairStyleOverride !== 'auto'
        ? `${state.hairStyleOverride.replace('_', ' ').toUpperCase()} (Override)`
        : hairProfile.styleLabel;
    hudHair.textContent =
      `Groom: ${activeStyleLbl} · ${hm.strandCount.toLocaleString()} strands + ${hm.flyawayCount} wisps · PBD 60 FPS`;
  }
}

function rebuildHairFromCurrentBust() {
  if (!state.recon || !state.hairProfile || !viewport) return;
  const hairMetrics = viewport.updateHairGroom(state.recon.geometry, state.hairProfile, {
    styleOverride: state.hairStyleOverride,
    volumeScale: state.hairVolumeScale,
  });
  updateHairHUDAndSwatch(state.hairProfile, hairMetrics);
}

/**
 * Render Multi-View Slot Cards in Left Panel.
 */
function renderViewSlots() {
  const container = document.getElementById('view-slots-container');
  container.innerHTML = '';

  const enabledCount = state.views.filter((v) => v.enabled).length;
  document.getElementById('active-views-badge').textContent = `${enabledCount} / ${state.views.length} Active`;

  state.views.forEach((v, idx) => {
    const card = document.createElement('div');
    card.className =
      'view-card' +
      (idx === state.selectedViewIdx ? ' selected' : '') +
      (!v.enabled ? ' disabled-view' : '');

    const yawTxt = `${Math.round(v.initialPose?.yawDeg || 0)}°`;
    card.innerHTML = `
      <img src="${v.dataUrl}" alt="${v.label}" />
      <div class="view-toggle-dot" title="Toggle view in multi-view fusion">${v.enabled ? '✓' : '–'}</div>
      <div class="view-card-badge">
        <span>${v.label}</span>
        <span>${yawTxt}</span>
      </div>
    `;

    card.addEventListener('click', (ev) => {
      if (ev.target.closest('.view-toggle-dot')) {
        // Keep at least 1 view enabled
        if (v.enabled && state.views.filter((x) => x.enabled).length <= 1) return;
        v.enabled = !v.enabled;
        renderViewSlots();
        runFullReconstruction();
        return;
      }
      state.selectedViewIdx = idx;
      renderViewSlots();
      drawLandmarkEditor();
      updateSelectedViewPoseHUD();
    });

    container.appendChild(card);
  });
}

/**
 * Draw Baked Texture Atlases into the 4 Left-Sidebar Preview Canvases.
 */
function renderAtlasThumbnails() {
  if (!state.bakedTextures) return;
  const { texSize, albedoData, normalData, roughnessData, coverageData } = state.bakedTextures;
  document.getElementById('bake-res-label').textContent = `${texSize}×${texSize}`;

  const blit = (canvasId, rgba) => {
    const dst = document.getElementById(canvasId);
    if (!dst) return;
    const tmp = document.createElement('canvas');
    tmp.width = texSize;
    tmp.height = texSize;
    tmp.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(rgba), texSize, texSize), 0, 0);
    const dctx = dst.getContext('2d');
    dctx.clearRect(0, 0, dst.width, dst.height);
    dctx.drawImage(tmp, 0, 0, dst.width, dst.height);
  };

  blit('atlas-albedo', albedoData);
  blit('atlas-normal', normalData);
  blit('atlas-roughness', roughnessData);
  blit('atlas-coverage', coverageData);
}

/**
 * Compute letterboxing transform for selected portrait on #landmark-canvas.
 */
function getLandmarkCanvasTransform(view, canvas) {
  const cw = canvas.width;
  const ch = canvas.height;
  const scale = Math.min(cw / view.width, ch / view.height);
  const drawW = view.width * scale;
  const drawH = view.height * scale;
  const offX = (cw - drawW) * 0.5;
  const offY = (ch - drawH) * 0.5;
  return { cw, ch, scale, drawW, drawH, offX, offY };
}

/**
 * Render the active portrait + 79 dense interactive landmarks + 3D reprojected ticks onto #landmark-canvas.
 */
function drawLandmarkEditor() {
  const canvas = document.getElementById('landmark-canvas');
  const ctx = canvas.getContext('2d');
  const view = state.views[state.selectedViewIdx];
  ctx.fillStyle = '#070a0f';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  if (!view) return;

  const tf = getLandmarkCanvasTransform(view, canvas);
  ctx.drawImage(view.imageEl, tf.offX, tf.offY, tf.drawW, tf.drawH);

  const lms = view.landmarks2D;
  const toCanvas = (nx, ny) => [tf.offX + nx * tf.drawW, tf.offY + ny * tf.drawH];

  // Draw dense 79-point anatomical contour wireframe
  const strokePoly = (keys, color, closed = false, width = 1.45) => {
    const valid = keys.filter((k) => Boolean(lms[k]));
    if (valid.length < 2) return;
    ctx.beginPath();
    valid.forEach((k, i) => {
      const [cx, cy] = toCanvas(lms[k][0], lms[k][1]);
      if (i === 0) ctx.moveTo(cx, cy);
      else ctx.lineTo(cx, cy);
    });
    if (closed) ctx.closePath();
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.stroke();
  };

  // 1. Hairline Arch + 17-Point Jaw & Cheek Contour Oval
  strokePoly(
    [
      'hairlineLeftTemple', 'hairlineLeftArch', 'hairline', 'hairlineRightArch', 'hairlineRightTemple',
      'templeRight', 'cheekRight', 'upperCheekRight', 'midCheekRight', 'lowerCheekRight',
      'jawRight', 'mandibleRight', 'chinRight', 'chin', 'chinLeft', 'mandibleLeft', 'jawLeft',
      'lowerCheekLeft', 'midCheekLeft', 'upperCheekLeft', 'cheekLeft', 'templeLeft',
    ],
    'rgba(250, 204, 21, 0.72)',
    true,
    1.4
  );

  // 2. Full Closed 8-Point Left & Right Upper+Lower Eyebrow Contour Rings + Centerline Arch Spine
  strokePoly(
    ['browLeftInner', 'browLeftUpperInner', 'browLeftUpper', 'browLeftUpperOuter', 'browLeftOuter', 'browLeftLowerOuter', 'browLeftLower', 'browLeftLowerInner'],
    'rgba(129, 140, 248, 0.94)',
    true,
    1.5
  );
  strokePoly(
    ['browRightInner', 'browRightUpperInner', 'browRightUpper', 'browRightUpperOuter', 'browRightOuter', 'browRightLowerOuter', 'browRightLower', 'browRightLowerInner'],
    'rgba(129, 140, 248, 0.94)',
    true,
    1.5
  );
  strokePoly(
    ['browLeftOuter', 'browLeftMidOuter', 'browLeft', 'browLeftMidInner', 'browLeftInner', 'glabella', 'browRightInner', 'browRightMidInner', 'browRight', 'browRightMidOuter', 'browRightOuter'],
    'rgba(165, 180, 252, 0.72)',
    false,
    1.15
  );

  // 3. Left & Right 8-Point Eyelid Palpebral Rings
  strokePoly(['eyeLeftInner', 'eyeLeftUpperInner', 'eyeLeftUpper', 'eyeLeftUpperOuter', 'eyeLeftOuter', 'eyeLeftLowerOuter', 'eyeLeftLower', 'eyeLeftLowerInner'], 'rgba(56, 189, 248, 0.94)', true, 1.5);
  strokePoly(['eyeRightInner', 'eyeRightUpperInner', 'eyeRightUpper', 'eyeRightUpperOuter', 'eyeRightOuter', 'eyeRightLowerOuter', 'eyeRightLower', 'eyeRightLowerInner'], 'rgba(56, 189, 248, 0.94)', true, 1.5);

  // 4. Nasal Bridge, Tip & Alar Nostril Loop
  strokePoly(['glabella', 'nasion', 'rhinion', 'supratip', 'noseTip', 'subnasale'], 'rgba(52, 211, 153, 0.86)', false, 1.45);
  strokePoly(['alarCrestLeft', 'alarLeft', 'nostrilLeft', 'subnasale', 'nostrilRight', 'alarRight', 'alarCrestRight'], 'rgba(52, 211, 153, 0.80)', false, 1.35);

  // 5. Outer Vermilion Lip Contour + Closed/Open Inner Oral Aperture Loop
  strokePoly(['mouthLeft', 'upperLipLeft', 'cupidPeakLeft', 'upperLipTop', 'cupidPeakRight', 'upperLipRight', 'mouthRight', 'lowerLipRight', 'lowerLipBottom', 'lowerLipLeft'], 'rgba(251, 113, 133, 0.92)', true, 1.5);
  strokePoly(['mouthLeft', 'stomionLeft', 'upperLipInner', 'stomionRight', 'mouthRight', 'stomionRight', 'lowerLipInner', 'stomionLeft'], 'rgba(251, 113, 133, 0.78)', true, 1.25);

  // Draw 3D-to-2D reprojection crosses (+) if view is part of active solve
  const enabledViews = state.views.filter((v) => v.enabled);
  const solvedIdx = enabledViews.indexOf(view);
  if (state.recon && solvedIdx >= 0 && state.recon.poses[solvedIdx]) {
    const pose = state.recon.poses[solvedIdx];
    const lms3D = getKeyAnatomicalLandmarks3D(state.recon.weights, pose.ry);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.55)';
    ctx.lineWidth = 1.0;
    for (const p3 of Object.values(lms3D)) {
      const [uPx, vPx] = projectPoint3D(p3, pose, view.width, view.height);
      const cx = tf.offX + (uPx / view.width) * tf.drawW;
      const cy = tf.offY + (vPx / view.height) * tf.drawH;
      ctx.beginPath();
      ctx.moveTo(cx - 2.5, cy); ctx.lineTo(cx + 2.5, cy);
      ctx.moveTo(cx, cy - 2.5); ctx.lineTo(cx, cy + 2.5);
      ctx.stroke();
    }
  }

  // Draw draggable 79 anatomical landmark handles
  for (const [k, [nx, ny]] of Object.entries(lms)) {
    const [cx, cy] = toCanvas(nx, ny);
    const isActive = k === state.draggingLandmarkKey || k === state.hoveredLandmarkKey;
    const isIris = k === 'eyeLeft' || k === 'eyeRight';
    const r = isActive ? 5.2 : isIris ? 3.1 : 2.05;

    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = isIris ? '#f8fafc' : getLandmarkColor(k);
    ctx.fill();
    ctx.lineWidth = isActive ? 1.8 : 0.85;
    ctx.strokeStyle = isActive ? '#ffffff' : '#05080f';
    ctx.stroke();
  }
}

function updateSelectedViewPoseHUD() {
  const view = state.views[state.selectedViewIdx];
  if (!view) return;
  const enabledViews = state.views.filter((v) => v.enabled);
  const solvedIdx = enabledViews.indexOf(view);
  const pose = state.recon && solvedIdx >= 0 ? state.recon.poses[solvedIdx] : null;

  const yaw = pose ? pose.yawDeg : view.initialPose?.yawDeg || 0;
  const pitch = pose ? pose.pitchDeg : view.initialPose?.pitchDeg || 0;
  const roll = pose ? pose.rollDeg : view.initialPose?.rollDeg || 0;
  const rmse = pose ? `${pose.reprojectionErrorPx.toFixed(1)}px` : '—';

  document.getElementById('pose-yaw').textContent = `${yaw >= 0 ? '+' : ''}${yaw.toFixed(1)}°`;
  document.getElementById('pose-pitch').textContent = `${pitch >= 0 ? '+' : ''}${pitch.toFixed(1)}°`;
  document.getElementById('pose-roll').textContent = `${roll >= 0 ? '+' : ''}${roll.toFixed(1)}°`;
  document.getElementById('pose-rmse').textContent = rmse;
}

/**
 * Run Full End-to-End Multi-View 3DMM + SfS Reconstruction + PBR Texture Baking!
 */
async function runFullReconstruction() {
  const activeViews = state.views.filter((v) => v.enabled);
  if (activeViews.length === 0) return;

  setStatus('Solving 3DMM + SfS + Hair Vision + UV Atlas…', true);
  await new Promise((r) => requestAnimationFrame(r));

  const t0 = performance.now();
  const recon = reconstruct3DHeadBust(activeViews, {
    density: state.density,
    sfsStrength: state.sfsStrength,
    userOverrides: state.userOverrides,
  });

  const texSize = state.density === 'hd' ? 2048 : 1536;
  const baked = bakeMultiViewBustTextures(recon, activeViews, {
    texSize,
    delightStrength: state.delightStrength,
  });

  const tHair0 = performance.now();
  const hairProfile = analyzeReferenceHairGroom(activeViews, recon.poses);
  state.recon = recon;
  state.bakedTextures = baked;
  state.hairProfile = hairProfile;

  viewport.updateBust(recon, baked);
  const hairMetrics =
    viewport.updateHairGroom(recon.geometry, hairProfile, {
      styleOverride: state.hairStyleOverride,
      volumeScale: state.hairVolumeScale,
    }) || { strandCount: 0, flyawayCount: 0, triangleCount: 0 };
  const hairMs = performance.now() - tHair0;
  const totalMs = performance.now() - t0;

  updateHairHUDAndSwatch(hairProfile, hairMetrics);
  syncSlidersFromWeights(recon.weights);
  renderAtlasThumbnails();
  drawLandmarkEditor();
  updateSelectedViewPoseHUD();

  const visionAvgMs =
    activeViews.reduce((s, v) => s + (v.visionMs || 0), 0) / Math.max(1, activeViews.length);
  const lmCount = Object.keys(activeViews[0]?.landmarks2D || {}).length;

  document.getElementById('hud-subject').textContent =
    `${state.subjectTitle} (${activeViews.length} VIEW${activeViews.length > 1 ? 'S' : ''} · ${lmCount} PTS)`;
  document.getElementById('hud-topology').textContent =
    `${recon.metrics.vertexCount.toLocaleString()} bust verts + ${hairMetrics.triangleCount.toLocaleString()} hair tris · 360° Digital Human`;
  document.getElementById('hud-timing').textContent =
    `Vision ${visionAvgMs.toFixed(0)}ms · 3DMM+SfS ${recon.metrics.elapsedMs.toFixed(0)}ms · Hair ${hairMs.toFixed(0)}ms · Bake ${baked.bakeMs.toFixed(0)}ms · RMSE ${recon.metrics.meanRmsePx.toFixed(1)}px`;

  setStatus(`360° Bust + 3D Hair Ready (${totalMs.toFixed(0)} ms)`, false);
}

/**
 * Load one of the built-in studio presets ('elena-stereo' | 'aria-single' | 'marcus-single' | 'elena-single').
 */
async function loadPreset(presetKey) {
  const preset = PRESETS[presetKey];
  if (!preset) return;

  document.querySelectorAll('.preset-btn').forEach((b) => {
    b.classList.toggle('active', b.dataset.preset === presetKey);
  });

  setStatus(`Running Classical Vision + Hair Analysis on ${preset.title}…`, true);
  state.subjectTitle = preset.title;
  state.subjectSlug = preset.slug;
  state.userOverrides = {};
  state.hairStyleOverride = 'auto';
  const styleSelect = document.getElementById('select-hair-style');
  if (styleSelect) styleSelect.value = 'auto';
  state.selectedViewIdx = 0;

  const loadedViews = [];
  for (const src of preset.sources) {
    loadedViews.push(await createViewFromSource(src.url, src.label));
  }
  state.views = loadedViews;
  renderViewSlots();
  await runFullReconstruction();
}

/**
 * Interactive Pointer Dragging on #landmark-canvas to Fine-Tune 2D Landmarks.
 */
function bindLandmarkCanvasInteractions() {
  const canvas = document.getElementById('landmark-canvas');
  const tooltip = document.getElementById('landmark-tooltip');

  const getPointerNormalized = (ev) => {
    const rect = canvas.getBoundingClientRect();
    const cx = ((ev.clientX - rect.left) / rect.width) * canvas.width;
    const cy = ((ev.clientY - rect.top) / rect.height) * canvas.height;
    const view = state.views[state.selectedViewIdx];
    if (!view) return null;
    const tf = getLandmarkCanvasTransform(view, canvas);
    return { cx, cy, tf, view };
  };

  const findNearestLandmark = (cx, cy, tf, view) => {
    let bestKey = null;
    let bestDist = 14.0;
    for (const [k, [nx, ny]] of Object.entries(view.landmarks2D)) {
      const lx = tf.offX + nx * tf.drawW;
      const ly = tf.offY + ny * tf.drawH;
      const d = Math.hypot(cx - lx, cy - ly);
      if (d < bestDist) {
        bestDist = d;
        bestKey = k;
      }
    }
    return bestKey;
  };

  canvas.addEventListener('pointerdown', (ev) => {
    const info = getPointerNormalized(ev);
    if (!info) return;
    const hit = findNearestLandmark(info.cx, info.cy, info.tf, info.view);
    if (hit) {
      state.draggingLandmarkKey = hit;
      canvas.setPointerCapture(ev.pointerId);
      tooltip.textContent = `Dragging: ${hit}`;
      drawLandmarkEditor();
    }
  });

  canvas.addEventListener('pointermove', (ev) => {
    const info = getPointerNormalized(ev);
    if (!info) return;
    if (state.draggingLandmarkKey) {
      const nx = Math.max(0.02, Math.min(0.98, (info.cx - info.tf.offX) / info.tf.drawW));
      const ny = Math.max(0.02, Math.min(0.98, (info.cy - info.tf.offY) / info.tf.drawH));
      info.view.landmarks2D[state.draggingLandmarkKey] = [nx, ny];
      tooltip.textContent = `${state.draggingLandmarkKey}: (${(nx * 100).toFixed(1)}%, ${(ny * 100).toFixed(1)}%)`;
      drawLandmarkEditor();
    } else {
      const hit = findNearestLandmark(info.cx, info.cy, info.tf, info.view);
      if (hit !== state.hoveredLandmarkKey) {
        state.hoveredLandmarkKey = hit;
        tooltip.textContent = hit ? `Landmark: ${hit} (drag to refine)` : 'Drag any node to refine 3D fit';
        drawLandmarkEditor();
      }
    }
  });

  const finishDrag = () => {
    if (state.draggingLandmarkKey) {
      state.draggingLandmarkKey = null;
      tooltip.textContent = 'Re-solving 3D bust from refined landmarks…';
      runFullReconstruction().then(() => {
        tooltip.textContent = 'Drag any node to refine 3D fit';
      });
    }
  };
  canvas.addEventListener('pointerup', finishDrag);
  canvas.addEventListener('pointercancel', finishDrag);
}

/**
 * Bind UI Controls, Modals, Uploads & Webcam Rig.
 */
function bindStudioControls() {
  // Preset buttons
  document.querySelectorAll('.preset-btn').forEach((btn) => {
    btn.addEventListener('click', () => loadPreset(btn.dataset.preset));
  });

  // Shader mode buttons
  const setShaderUI = (mode) => {
    viewport.setShaderMode(mode);
    document.querySelectorAll('[data-shader]').forEach((b) => {
      b.classList.toggle('active', b.dataset.shader === mode);
    });
    document.querySelectorAll('.atlas-item').forEach((item) => {
      item.classList.toggle('active', item.dataset.atlasMode === mode);
    });
  };

  document.querySelectorAll('[data-shader]').forEach((btn) => {
    btn.addEventListener('click', () => setShaderUI(btn.dataset.shader));
  });

  document.querySelectorAll('.atlas-item').forEach((item) => {
    item.addEventListener('click', () => setShaderUI(item.dataset.atlasMode));
  });

  // 3D Landmark pins toggle
  const btnPins = document.getElementById('btn-toggle-3d-lms');
  btnPins.addEventListener('click', () => {
    const next = !viewport.showLandmarks3D;
    viewport.setShowLandmarks3D(next);
    btnPins.classList.toggle('active', next);
  });

  // Camera yaw presets
  document.querySelectorAll('[data-cam-yaw]').forEach((btn) => {
    btn.addEventListener('click', () => {
      viewport.setAutoSpin(false);
      document.getElementById('btn-toggle-spin').classList.remove('active');
      viewport.setCameraPreset(parseFloat(btn.dataset.camYaw));
    });
  });

  // Auto-spin turntable
  const btnSpin = document.getElementById('btn-toggle-spin');
  btnSpin.addEventListener('click', () => {
    const next = !viewport.autoSpin;
    viewport.setAutoSpin(next);
    btnSpin.classList.toggle('active', next);
  });

  // Digital-Human & 3D Hair Physics Controls
  const btnHair = document.getElementById('btn-toggle-hair');
  btnHair.addEventListener('click', () => {
    const next = !viewport.hairEnabled;
    viewport.setHairEnabled(next);
    btnHair.classList.toggle('active', next);
  });

  const btnLiveMotion = document.getElementById('btn-toggle-live-motion');
  btnLiveMotion.addEventListener('click', () => {
    const next = !viewport.liveMotionEnabled;
    viewport.setLiveMotion(next);
    btnLiveMotion.classList.toggle('active', next);
  });

  const btnSSS = document.getElementById('btn-toggle-sss');
  btnSSS.addEventListener('click', () => {
    const next = !viewport.skinSSSEnabled;
    viewport.setSkinSSS(next);
    btnSSS.classList.toggle('active', next);
  });

  const btnBlink = document.getElementById('btn-blink-eyes');
  if (btnBlink) {
    btnBlink.addEventListener('click', () => {
      viewport.triggerBlink();
    });
  }

  document.getElementById('btn-head-impulse').addEventListener('click', () => {
    viewport.triggerHeadImpulse(1.0);
  });

  document.getElementById('select-hair-style').addEventListener('change', (e) => {
    state.hairStyleOverride = e.target.value;
    rebuildHairFromCurrentBust();
  });

  const windSlider = document.getElementById('slider-wind');
  const windDirSlider = document.getElementById('slider-wind-dir');
  const syncWind = () => {
    const w = parseFloat(windSlider.value);
    const d = parseFloat(windDirSlider.value);
    document.getElementById('val-wind').textContent = w.toFixed(2);
    document.getElementById('val-wind-dir').textContent = `${d >= 0 ? '+' : ''}${d.toFixed(0)}°`;
    viewport.setWindParams(w, d);
  };
  windSlider.addEventListener('input', syncWind);
  windDirSlider.addEventListener('input', syncWind);

  const hairVolSlider = document.getElementById('slider-hair-vol');
  hairVolSlider.addEventListener('input', () => {
    state.hairVolumeScale = parseFloat(hairVolSlider.value);
    document.getElementById('val-hair-vol').textContent = `${state.hairVolumeScale.toFixed(2)}×`;
    rebuildHairFromCurrentBust();
  });

  const hairStiffSlider = document.getElementById('slider-hair-stiff');
  hairStiffSlider.addEventListener('input', () => {
    const stf = parseFloat(hairStiffSlider.value);
    document.getElementById('val-hair-stiff').textContent = `${stf.toFixed(2)}×`;
    viewport.setHairStiffnessScale(stf);
  });

  // Key Light azimuth slider
  document.getElementById('light-azimuth-slider').addEventListener('input', (e) => {
    viewport.setLightAzimuth(parseFloat(e.target.value));
  });

  // Topology density toggle
  document.querySelectorAll('[data-density]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.density = btn.dataset.density;
      document.querySelectorAll('[data-density]').forEach((b) => {
        b.classList.toggle('active', b.dataset.density === state.density);
      });
      runFullReconstruction();
    });
  });

  // SfS & De-Lighting sliders
  const sfsSlider = document.getElementById('slider-sfs');
  sfsSlider.addEventListener('input', () => {
    state.sfsStrength = parseFloat(sfsSlider.value);
    document.getElementById('val-sfs').textContent = state.sfsStrength.toFixed(2);
  });
  sfsSlider.addEventListener('change', () => runFullReconstruction());

  const delightSlider = document.getElementById('slider-delight');
  delightSlider.addEventListener('input', () => {
    state.delightStrength = parseFloat(delightSlider.value);
    document.getElementById('val-delight').textContent = state.delightStrength.toFixed(2);
  });
  delightSlider.addEventListener('change', () => runFullReconstruction());

  document.getElementById('btn-rebuild-full').addEventListener('click', () => runFullReconstruction());

  document.getElementById('btn-reset-sliders').addEventListener('click', () => {
    state.userOverrides = {};
    runFullReconstruction();
  });

  // Auto-redetect landmarks on current view
  document.getElementById('btn-redetect-landmarks').addEventListener('click', () => {
    const view = state.views[state.selectedViewIdx];
    if (!view) return;
    const det = detectClassicalFaceLandmarks(view.imageData);
    if (det) {
      view.landmarks2D = det.landmarks2D;
      view.shapeMeasurements = det.shapeMeasurements || {};
      view.initialPose = det.initialPose;
      renderViewSlots();
      runFullReconstruction();
    }
  });

  // Custom photo upload (1 or multiple angles!)
  const uploadInput = document.getElementById('file-upload-input');
  document.getElementById('btn-upload-photos').addEventListener('click', () => uploadInput.click());
  uploadInput.addEventListener('change', async () => {
    const files = Array.from(uploadInput.files || []);
    if (!files.length) return;
    document.querySelectorAll('.preset-btn').forEach((b) => b.classList.remove('active'));
    setStatus(`Detecting faces across ${files.length} uploaded photo(s)…`, true);

    const newViews = [];
    for (let i = 0; i < files.length; i++) {
      const objUrl = URL.createObjectURL(files[i]);
      const v = await createViewFromSource(objUrl, files.length === 1 ? 'Front' : `Angle ${i + 1}`);
      URL.revokeObjectURL(objUrl);
      newViews.push(v);
    }
    state.subjectTitle = 'CUSTOM PORTRAIT';
    state.subjectSlug = 'custom_portrait';
    state.userOverrides = {};
    state.views = newViews;
    state.selectedViewIdx = 0;
    uploadInput.value = '';
    renderViewSlots();
    await runFullReconstruction();
  });

  // Exports: .GLB, .OBJ (.zip), .HTML, and Vanilla Three.js Code Modal
  document.getElementById('btn-export-glb').addEventListener('click', async () => {
    if (!state.bakedTextures) return;
    setStatus('Packaging binary glTF 2.0 (.GLB)…', true);
    const info = await downloadBustGLB(viewport, state.bakedTextures, state.subjectSlug);
    setStatus(`Exported ${info.filename} (${(info.byteLength / 1024 / 1024).toFixed(2)} MB)`, false);
  });

  document.getElementById('btn-export-obj').addEventListener('click', async () => {
    if (!state.recon || !state.bakedTextures) return;
    setStatus('Bundling .OBJ + .MTL + 3D Hair + PBR PNGs (.zip)…', true);
    const info = await downloadBustOBJZip(
      state.recon,
      state.bakedTextures,
      state.subjectSlug,
      viewport.hairEnabled ? viewport.hairState : null,
      state.hairProfile
    );
    setStatus(`Exported ${info.filename} (${(info.byteLength / 1024 / 1024).toFixed(2)} MB)`, false);
  });

  document.getElementById('btn-export-html').addEventListener('click', async () => {
    if (!state.recon || !state.bakedTextures) return;
    setStatus('Building standalone single-file .HTML viewer…', true);
    const info = await downloadStandaloneHTMLViewer(viewport, state.bakedTextures, state.recon, state.subjectSlug);
    setStatus(`Exported ${info.filename}`, false);
  });

  // Three.js Code Modal
  const codeModal = document.getElementById('code-modal');
  const codePre = document.getElementById('generated-code-pre');
  document.getElementById('btn-open-code').addEventListener('click', () => {
    if (!state.recon) return;
    codePre.textContent = generateVanillaThreeCode(state.recon, state.subjectSlug);
    codeModal.classList.remove('hidden');
  });
  document.getElementById('btn-close-code').addEventListener('click', () => codeModal.classList.add('hidden'));
  document.getElementById('btn-copy-code').addEventListener('click', async (ev) => {
    await navigator.clipboard.writeText(codePre.textContent);
    const btn = ev.currentTarget;
    const orig = btn.textContent;
    btn.textContent = 'Copied to Clipboard!';
    setTimeout(() => { btn.textContent = orig; }, 1800);
  });
  document.getElementById('btn-download-js').addEventListener('click', () => {
    triggerDownload(new Blob([codePre.textContent], { type: 'text/javascript;charset=utf-8' }), `${state.subjectSlug}_scene.js`);
  });
  document.getElementById('btn-modal-download-glb').addEventListener('click', async () => {
    if (!state.bakedTextures) return;
    await downloadBustGLB(viewport, state.bakedTextures, state.subjectSlug);
  });

  // Live Multi-Angle Webcam Capture Modal
  const webcamModal = document.getElementById('webcam-modal');
  const videoEl = document.getElementById('webcam-video');
  const webcamStatus = document.getElementById('webcam-status-text');

  const stopWebcam = () => {
    if (state.webcamStream) {
      state.webcamStream.getTracks().forEach((t) => t.stop());
      state.webcamStream = null;
    }
    videoEl.srcObject = null;
  };

  document.getElementById('btn-open-webcam').addEventListener('click', async () => {
    state.webcamCaptures = {};
    webcamModal.classList.remove('hidden');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 960 }, height: { ideal: 720 }, facingMode: 'user' },
        audio: false,
      });
      state.webcamStream = stream;
      videoEl.srcObject = stream;
      webcamStatus.textContent = 'Camera active — capture Front 0°, plus optional Left 3/4 & Right 3/4!';
    } catch (err) {
      webcamStatus.textContent = `Camera permission unavailable (${err.message}). Use "+ Upload Photo(s)" instead.`;
    }
  });

  document.getElementById('btn-close-webcam').addEventListener('click', () => {
    stopWebcam();
    webcamModal.classList.add('hidden');
  });

  document.querySelectorAll('[data-capture-slot]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (!videoEl.videoWidth) return;
      const slot = btn.dataset.captureSlot;
      const c = document.createElement('canvas');
      c.width = videoEl.videoWidth;
      c.height = videoEl.videoHeight;
      const ctx = c.getContext('2d');
      // Mirror horizontally to match preview
      ctx.translate(c.width, 0);
      ctx.scale(-1, 1);
      ctx.drawImage(videoEl, 0, 0);
      state.webcamCaptures[slot] = c.toDataURL('image/jpeg', 0.92);
      const count = Object.keys(state.webcamCaptures).length;
      webcamStatus.textContent = `Captured "${slot}" (${count} angle${count > 1 ? 's' : ''} staged).`;
    });
  });

  document.getElementById('btn-webcam-apply').addEventListener('click', async () => {
    const entries = Object.entries(state.webcamCaptures);
    if (!entries.length) {
      webcamStatus.textContent = 'Capture at least Front 0° before building bust.';
      return;
    }
    stopWebcam();
    webcamModal.classList.add('hidden');
    document.querySelectorAll('.preset-btn').forEach((b) => b.classList.remove('active'));

    setStatus(`Reconstructing 360° bust from ${entries.length} webcam angle(s)…`, true);
    const capturedViews = [];
    for (const [label, dataUrl] of entries) {
      capturedViews.push(await createViewFromSource(dataUrl, label));
    }
    state.subjectTitle = 'WEBCAM CAPTURE';
    state.subjectSlug = 'webcam_bust';
    state.userOverrides = {};
    state.views = capturedViews;
    state.selectedViewIdx = 0;
    renderViewSlots();
    await runFullReconstruction();
  });
}

/**
 * Boot VISAGE // FORGE Pure Vanilla JS Studio.
 */
async function boot() {
  window.addEventListener('error', (ev) => {
    setStatus(`Runtime Error: ${ev.message}`, true);
  });
  window.addEventListener('unhandledrejection', (ev) => {
    const msg = ev.reason?.message || String(ev.reason);
    setStatus(`Async Error: ${msg}`, true);
  });

  init3DMMSlidersUI();
  bindLandmarkCanvasInteractions();
  bindStudioControls();
  viewport = new BustViewport3D(document.getElementById('viewport-canvas-host'));
  window.__visageStudio = { state, getViewport: () => viewport, loadPreset };
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.get('skipBoot') !== '1') {
    await loadPreset(urlParams.get('preset') || 'elena-stereo');
  }
}

boot().catch((err) => {
  console.error('VISAGE // FORGE boot error:', err);
  setStatus(`Error: ${err.message}`, true);
});
