/**
 * VISAGE // FORGE — Pure Vanilla JS 3D Math, SO(3) Kinematics, Linear Solvers & Spherical Harmonics
 * Zero external dependencies. Right-handed metric coordinate system (+X right, +Y up, +Z forward).
 */

export function clamp(x, lo, hi) {
  return x < lo ? lo : x > hi ? hi : x;
}

export function mix(a, b, t) {
  return a + (b - a) * t;
}

export function smoothstep(e0, e1, x) {
  const t = clamp((x - e0) / (e1 - e0 || 1e-8), 0, 1);
  return t * t * (3 - 2 * t);
}

/**
 * Construct 3x3 rotation matrix R = Rz(roll) * Rx(pitch) * Ry(yaw) (row-major Float64Array(9)).
 * Convention:
 *  - +yaw (ry > 0) rotates +Z nose toward +X (image-right), exposing subject's -X cheek to camera (+Z).
 *  - +pitch (rx > 0) tilts nose downward / chin toward -Z or upward depending on sign; standard right-hand rule around +X.
 *  - +roll (rz > 0) tilts head in image plane.
 */
export function eulerToMat3(rx, ry, rz) {
  const cx = Math.cos(rx), sx = Math.sin(rx);
  const cy = Math.cos(ry), sy = Math.sin(ry);
  const cz = Math.cos(rz), sz = Math.sin(rz);

  // Ry(ry)
  // [ cy  0  sy ]
  // [  0  1   0 ]
  // [-sy  0  cy ]
  // Rx(rx) * Ry(ry):
  const m00 = cy,       m01 = 0,  m02 = sy;
  const m10 = sx * sy,  m11 = cx, m12 = -sx * cy;
  const m20 = -cx * sy, m21 = sx, m22 = cx * cy;

  // Rz(rz) * (Rx * Ry):
  return new Float64Array([
    cz * m00 - sz * m10, cz * m01 - sz * m11, cz * m02 - sz * m12,
    sz * m00 + cz * m10, sz * m01 + cz * m11, sz * m02 + cz * m12,
    m20,                 m21,                 m22,
  ]);
}

export function mat3Vec3(R, v) {
  const x = v[0], y = v[1], z = v[2];
  return [
    R[0] * x + R[1] * y + R[2] * z,
    R[3] * x + R[4] * y + R[5] * z,
    R[6] * x + R[7] * y + R[8] * z,
  ];
}

export function mat3TransposeVec3(R, v) {
  const x = v[0], y = v[1], z = v[2];
  return [
    R[0] * x + R[3] * y + R[6] * z,
    R[1] * x + R[4] * y + R[7] * z,
    R[2] * x + R[5] * y + R[8] * z,
  ];
}

/**
 * Weak-perspective + mild perspective foreshortening projection of 3D point p (in cm) to 2D pixel coords [u, v].
 * Camera sits at +Z looking toward -Z (focal distance fCm = 62 cm ~ 85mm portrait lens at 62cm subject distance).
 * u_px = 0.5 * W + tx + scale * x_cam * persp
 * v_px = 0.5 * H + ty - scale * y_cam * persp
 */
export function projectPoint3D(p, pose, W, H) {
  const R = pose.R || eulerToMat3(pose.rx, pose.ry, pose.rz);
  const xc = R[0] * p[0] + R[1] * p[1] + R[2] * p[2];
  const yc = R[3] * p[0] + R[4] * p[1] + R[5] * p[2];
  const zc = R[6] * p[0] + R[7] * p[1] + R[8] * p[2];

  // Portrait camera at z = +65cm: subtle realistic perspective factor 65 / (65 - zc)
  // Studio portrait telephoto perspective (~95mm portrait lens, camera at 112 cm — zero wide-angle selfie bloat!)
  const persp = 112.0 / Math.max(60.0, 112.0 - zc);
  const u = 0.5 * W + pose.tx + pose.scale * xc * persp;
  const v = 0.5 * H + pose.ty - pose.scale * yc * persp;
  return [u, v, zc];
}

/**
 * Solve symmetric or general N x N linear system A * x = b using Gaussian elimination with partial pivoting.
 */
export function solveLinearSystem(A, b, n = b.length) {
  const M = new Float64Array(n * (n + 1));
  const is2D = Array.isArray(A) && A[0] !== undefined && typeof A[0] === 'object';
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) M[i * (n + 1) + j] = is2D ? A[i][j] : A[i * n + j];
    M[i * (n + 1) + n] = b[i];
  }

  for (let col = 0; col < n; col++) {
    let pivotRow = col;
    let maxAbs = Math.abs(M[col * (n + 1) + col]);
    for (let row = col + 1; row < n; row++) {
      const val = Math.abs(M[row * (n + 1) + col]);
      if (val > maxAbs) {
        maxAbs = val;
        pivotRow = row;
      }
    }
    if (maxAbs < 1e-12) continue;

    if (pivotRow !== col) {
      for (let j = col; j <= n; j++) {
        const tmp = M[col * (n + 1) + j];
        M[col * (n + 1) + j] = M[pivotRow * (n + 1) + j];
        M[pivotRow * (n + 1) + j] = tmp;
      }
    }

    const diag = M[col * (n + 1) + col];
    for (let row = col + 1; row < n; row++) {
      const factor = M[row * (n + 1) + col] / diag;
      if (factor === 0) continue;
      for (let j = col; j <= n; j++) {
        M[row * (n + 1) + j] -= factor * M[col * (n + 1) + j];
      }
    }
  }

  const x = new Float64Array(n);
  for (let i = n - 1; i >= 0; i--) {
    let sum = M[i * (n + 1) + n];
    for (let j = i + 1; j < n; j++) {
      sum -= M[i * (n + 1) + j] * x[j];
    }
    const diag = M[i * (n + 1) + i];
    x[i] = Math.abs(diag) > 1e-12 ? sum / diag : 0.0;
  }
  return x;
}

/**
 * Evaluate the 9 real Order-2 Lambertian Spherical Harmonic basis functions Y_0..Y_8 for unit normal (nx, ny, nz).
 * Ramamoorthi & Hanrahan (2001) irradiance basis.
 */
export function evalSH9(nx, ny, nz) {
  return [
    1.0,
    nx,
    ny,
    nz,
    nx * ny,
    nx * nz,
    ny * nz,
    nx * nx - ny * ny,
    3.0 * nz * nz - 1.0,
  ];
}

export function evalSHIrradiance(coeffs, nx, ny, nz) {
  const b = evalSH9(nx, ny, nz);
  let sum = 0.0;
  for (let k = 0; k < 9; k++) sum += coeffs[k] * b[k];
  return Math.max(0.05, sum);
}
