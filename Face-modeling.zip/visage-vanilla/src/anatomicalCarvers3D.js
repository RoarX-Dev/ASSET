/**
 * VISAGE // FORGE — Dedicated 3D Nose, 3D Alar Nostril Wings, Silky Lip & Perioral Mouth-Line/Dimple Carvers
 * Pure Vanilla JS, Zero External Models (`v65_sculpt_gold_r3`)
 *
 * Sculpted Digital-Double Sub-Forms:
 *  1. Proud, Rounded 3D Nasal Tip + Distinct 3D Lateral Nostril Wings (`alae nasi`):
 *     - Preserves full proud nasal tip height (`ZERO` stubby tip squashing!) while rounding any sharp `<` apex,
 *     - Sculpts paired Lower Lateral Cartilage (LLC) tip-defining domes + soft interdomal valley,
 *     - Sculpts unmistakable 3D C-curved lateral nostril wings (`alae nasi`) separated from the central tip ball
 *       by an oblique inter-lobular/supra-alar groove and tucked into the maxilla by a crisp C-curved alar-facial sulcus,
 *     - Carves genuinely upward-and-inward recessed (`+dy, -dz`) 3D oval nasal cavities, hanging columella & nostril sills!
 *  2. Silky Smooth Upper Lip + Preserved Perfect Lower Lip:
 *     - Broad, C^infinity smooth upper-lip mucocutaneous roll & philtrum transition (zero abrupt horizontal shelf!),
 *     - Preserves the exact sculpted lower-lip bilobed pillow & toroidal inner kiss-margin roll!
 *  3. Perioral Mouth-Lines, Nasolabial Fold Cushion & Buccal/Commissure Dimples:
 *     - Curved alar-to-commissure nasolabial mouth line paired with a soft lateral cheek-pad roll,
 *     - Tucked oral commissure pockets, modiolus soft-tissue cushions, subtle buccal smile dimples & mentolabial depth!
 *  4. Structure-Preserving 4-Step Taubin Micro-Fairing:
 *     - Eliminates quad faceting while preserving 3D nostril wings, kiss-cleft, mouth lines & dimples!
 */

function clamp(v, lo, hi) {
  return v < lo ? lo : v > hi ? hi : v;
}

function mix(a, b, t) {
  return a + (b - a) * t;
}

function smoothstep(e0, e1, x) {
  const t = clamp((x - e0) / (e1 - e0 || 1e-8), 0.0, 1.0);
  return t * t * (3.0 - 2.0 * t);
}

function gauss(x, mu, sigma) {
  const d = (x - mu) / sigma;
  return Math.exp(-0.5 * d * d);
}

function gauss2D(x, y, mux, muy, sx, sy) {
  const dx = (x - mux) / sx;
  const dy = (y - muy) / sy;
  return Math.exp(-0.5 * (dx * dx + dy * dy));
}

/**
 * Apply dedicated 3D vector carving (`dx, dy, dz`) + structure-preserving micro-fairing in-place.
 * Returns `{ cavityAO: Float32Array(numVerts) }` in `[0..1]` for physiological 3D nostril, alar, mouth-line & dimple shading.
 */
export function applyDedicatedNoseAndSoftLipCarvers(positions, regionT, cols, rows, w = {}) {
  const numVerts = cols * rows;
  const cavityAO = new Float32Array(numVerts);
  const smoothWeights = new Float32Array(numVerts);

  const faceW = 1.0 + 0.080 * (w.faceWidth || 0);
  const faceH = 1.0 + 0.072 * (w.faceHeight || 0);

  const eyeY = 1.56 * faceH;
  const nasionY = eyeY + 0.42;
  const noseTipY = (-1.80 - 0.50 * (w.noseLength || 0)) * faceH;
  const subnasaleY = noseTipY - 0.56 * faceH;
  const alarW = clamp((1.40 + 0.32 * (w.noseWidth || 0)) * faceW, 1.15, 2.22);

  const tipRoundCtrl  = clamp(w.noseTipRoundness !== undefined ? w.noseTipRoundness : 1.0, 0.20, 1.80);
  const sideCarveCtrl = clamp(w.noseSideCarve !== undefined ? w.noseSideCarve : 1.0, 0.00, 1.80);
  const cavityCtrl    = clamp(w.nasalCavityDepth !== undefined ? w.nasalCavityDepth : 1.0, 0.00, 1.80);
  const lipSoftCtrl   = clamp(w.lipSoftness !== undefined ? w.lipSoftness : 1.0, 0.25, 1.80);
  const mouthLineCtrl = clamp(w.mouthLineDepth !== undefined ? w.mouthLineDepth : 0.0, 0.00, 1.80);
  const dimpleCtrl    = clamp(w.dimpleDepth !== undefined ? w.dimpleDepth : 0.0, 0.00, 1.65);

  const legacyLip = w.lipFullness || 0.0;
  const upLipW = w.upperLipFullness !== undefined ? w.upperLipFullness : legacyLip;
  const loLipW = w.lowerLipFullness !== undefined ? w.lowerLipFullness : legacyLip;
  const mOpen = clamp(w.mouthOpen || 0.0, 0.0, 1.55);
  const jawOpenDrop = 0.92 * mOpen;
  const mouthY = (-4.06 - 0.36 * (w.mouthHeight || 0)) * faceH - jawOpenDrop * 0.36;
  const mouthHalfW = (2.16 + 0.34 * (w.mouthWidth || 0) + 0.22 * mOpen) * faceW;
  const upVol = clamp(1.0 + 0.28 * upLipW, 0.88, 1.56);
  const loVol = clamp(1.0 + 0.28 * loLipW, 0.90, 1.60);
  const cornerLift = 0.26 * (w.mouthCornerLift || 0) + 0.16 * mOpen;
  const smileDrive = clamp(Math.max(0.0, w.mouthCornerLift || 0) * 0.85 + mOpen * 0.65, 0.0, 1.35);

  const M = cols - 1;
  for (let r = 1; r < rows - 1; r++) {
    const t = regionT[r * cols];
    if (t < 0.33 || t > 0.605) continue;

    for (let m = 0; m < M; m++) {
      const idx = r * cols + m;
      const i3 = idx * 3;
      const px = positions[i3];
      const py = positions[i3 + 1];
      const pz = positions[i3 + 2];
      if (pz < 2.0) continue;

      const ax = Math.abs(px);
      const sgnX = px >= 0 ? 1.0 : -1.0;
      let dx = 0.0, dy = 0.0, dz = 0.0;
      let softW = 0.0;

      // ---------------------------------------------------------------------
      // A. DEDICATED 3D NOSE & 3D LATERAL NOSTRIL WINGS (`alae nasi`) CARVER
      // ---------------------------------------------------------------------
      if (ax < 3.45 && py < nasionY + 0.85 && py > subnasaleY - 0.85) {
        // 1) Soft, Blunt, Naturally Rounded LLC Tip Bulb & Infratip Lobule (dilutes absolute tip sharpness in 90-deg profile!):
        const tipCenterY = noseTipY + 0.14 * faceH;
        const tipWidthScale = clamp(1.0 + 0.22 * (w.noseTipBall || 0), 0.90, 1.45);
        const llcDomes = gauss2D(ax, py, 0.32 * tipWidthScale, tipCenterY, 0.34 * tipWidthScale, 0.46);
        const interDomal = gauss2D(px, py, 0.0, tipCenterY, 0.16, 0.38);
        const infratipLobule = gauss2D(px, py, 0.0, noseTipY - 0.18 * faceH, 0.44 * tipWidthScale, 0.30);
        const tipPointSoftener = gauss2D(px, py, 0.0, tipCenterY - 0.06 * faceH, 0.38, 0.30);
        const extraBlunt = Math.max(0.0, tipRoundCtrl - 0.75);
        dz += (0.016 * llcDomes - 0.008 * interDomal + 0.020 * infratipLobule) * clamp(tipRoundCtrl, 0.4, 1.35)
            - (0.038 + 0.09 * extraBlunt) * tipPointSoftener;
        dx += sgnX * 0.042 * tipRoundCtrl * tipWidthScale * llcDomes;

        // 2) Bony-Cartilaginous Nasal Sidewall Planes & Nasofacial Groove (strictly ABOVE the nasal tip ball `py > noseTipY + 0.48`!):
        const supratipBreak = gauss2D(px, py, 0.0, noseTipY + 0.64 * faceH, 0.50, 0.28);
        dz -= 0.015 * sideCarveCtrl * supratipBreak;

        const bridgeScale = 0.94 + 0.14 * (w.noseBridgeWidth || 0);
        const sideWallZone =
          gauss(ax, 0.90 * bridgeScale, 0.28) *
          smoothstep(noseTipY + 0.48, noseTipY + 0.96, py) *
          (1.0 - smoothstep(nasionY - 0.42, nasionY + 0.05, py));
        const nasoFacialGroove =
          gauss(ax, 1.20 * bridgeScale, 0.22) *
          smoothstep(noseTipY + 0.42, noseTipY + 0.90, py) *
          (1.0 - smoothstep(nasionY - 0.36, nasionY + 0.04, py));
        dz -= (0.068 * sideWallZone + 0.042 * nasoFacialGroove) * sideCarveCtrl;
        dx -= sgnX * (0.024 * sideWallZone + 0.016 * nasoFacialGroove) * sideCarveCtrl;

        // 3) Gentle Supra-Alar Groove OUTSIDE the rounded tip bulb (`sepCurveX = alarW * 0.58..0.72` — NEVER pinches tip narrow!):
        const uAlarSep = clamp((py - (subnasaleY + 0.16 * faceH)) / (0.65 * faceH), 0.0, 1.0);
        const sepCurveX = mix(alarW * 0.58, alarW * 0.74, uAlarSep);
        const alarSepEnv =
          smoothstep(subnasaleY + 0.08, subnasaleY + 0.24, py) *
          (1.0 - smoothstep(noseTipY + 0.18, noseTipY + 0.48, py)) *
          smoothstep(0.46, 0.64, ax);
        const obliqueAlarGroove = gauss(ax, sepCurveX, 0.18) * alarSepEnv;
        dz -= 0.028 * obliqueAlarGroove * sideCarveCtrl;
        cavityAO[idx] = Math.max(cavityAO[idx], clamp(0.06 * sideCarveCtrl * obliqueAlarGroove, 0.0, 0.14));

        // 4) Delicate Thin Nostril Rim Margin (`alae nasi` — zero wide bulbous cushion!):
        const alarY = noseTipY - 0.20 * faceH;
        const alarRimArch = gauss2D(ax, py, alarW * 0.66, noseTipY - 0.21 * faceH, 0.20, 0.16);
        dz += 0.024 * alarRimArch * sideCarveCtrl;
        dy -= 0.008 * sideCarveCtrl * alarRimArch;

        // 5) Crisp Inward C-Curved Alar-Facial Tuck (slims and tucks the nostril wing base cleanly into the cheek!):
        const uSulc = clamp((py - alarY) / (0.30 * faceH), -1.0, 1.0);
        const sulcCurveX = alarW * 0.96 - 0.05 * (uSulc * uSulc);
        const alarSulcus =
          gauss(ax, sulcCurveX, 0.19) *
          gauss(py, alarY + 0.02, 0.26);
        dz -= 0.076 * sideCarveCtrl * alarSulcus;
        dx -= sgnX * 0.026 * sideCarveCtrl * alarSulcus;
        cavityAO[idx] = Math.max(cavityAO[idx], clamp(0.14 * sideCarveCtrl * alarSulcus, 0.0, 0.24));

        // 6) Diffeomorphic (`Jacobian > +0.62`, zero self-fold!) 3D Recessed Nasal Cavities + Columella + Sill:
        const cavCx = alarW * 0.46;
        const cavCy = subnasaleY + 0.17 * faceH;
        const cavTilt = -0.28;
        const lx = ax - cavCx;
        const ly = py - cavCy;
        const uMaj = (lx * 0.961 + ly * cavTilt) / (alarW * 0.245);
        const uMin = (-lx * cavTilt + ly * 0.961) / 0.185;
        const rCav2 = uMaj * uMaj + uMin * uMin;

        if (rCav2 < 1.05) {
          const cavProfile = Math.pow(Math.max(0.0, 1.0 - rCav2 / 1.05), 2.15);
          dy += 0.052 * cavityCtrl * cavProfile;
          dz -= 0.185 * cavityCtrl * cavProfile;
          dx -= sgnX * 0.015 * cavityCtrl * cavProfile * clamp(lx / 0.24, -1.0, 1.0);
          cavityAO[idx] = Math.max(cavityAO[idx], clamp(cavProfile * 0.86 * cavityCtrl, 0.0, 0.88));
        }

        // Defined Rounded Hanging Columella (`columellar show` in side profile — ~1.5 mm below alar rim!)
        const colMask = gauss(px, 0.0, 0.19) * gauss(py, subnasaleY + 0.15 * faceH, 0.17);
        dy -= 0.068 * cavityCtrl * colMask;
        dz += 0.065 * cavityCtrl * colMask;

        // Nostril Sill (floor rim of the nostril entrance connecting alar wing base to columella)
        const sillMask = gauss(ax, cavCx * 1.04, 0.22) * gauss(py, subnasaleY + 0.01, 0.075);
        dz += 0.044 * cavityCtrl * sillMask;

        const noseFairMask =
          (1.0 - smoothstep(alarW + 0.45, alarW + 0.92, ax)) *
          smoothstep(subnasaleY - 0.26, subnasaleY + 0.04, py) *
          (1.0 - smoothstep(nasionY - 0.35, nasionY + 0.15, py));
        const tipApexPolish = gauss2D(px, py, 0.0, noseTipY + 0.10 * faceH, 0.75, 0.55);
        const alarDetailKeep = 1.0 - 0.32 * Math.max(obliqueAlarGroove, alarSulcus);
        softW = Math.max(softW, (0.48 * noseFairMask * alarDetailKeep + 0.30 * tipApexPolish) * (1.0 - 0.72 * cavityAO[idx]));
      }

      // ---------------------------------------------------------------------
      // B. DEDICATED SOFT 3D LIP CARVER (Blunt, Non-Pointy 3D Cushion Profile in BOTH 0-deg & 90-deg!)
      // ---------------------------------------------------------------------
      const mx = clamp(ax / mouthHalfW, 0.0, 1.85);
      const horizPillow = mx < 1.0 ? Math.pow(1.0 - Math.pow(mx, 2.05), 1.26) : 0.0;
      const openSpanEnv = mx < 0.96 ? Math.pow(Math.max(0.0, 1.0 - Math.pow(mx / 0.96, 2.0)), 1.15) : 0.0;
      const halfOpenCm = 0.56 * mOpen * openSpanEnv;
      const closedWeight = 1.0 - clamp(mOpen / 0.22, 0.0, 1.0);
      const cupidsM = (0.095 * gauss(ax, 0.43, 0.26) - 0.038 * gauss(px, 0.0, 0.19)) * horizPillow;
      const partCenterY = mouthY + cornerLift * Math.min(1.25, mx * mx) - 0.022 * gauss(px, 0.0, 0.32);
      const upInnerY = partCenterY + halfOpenCm * 0.76;
      const loInnerY = partCenterY - halfOpenCm * 1.24;
      const upHeight = (0.60 + 0.15 * (upVol - 1.0)) * faceH + cupidsM * 0.88;
      const loHeight = (0.68 + 0.16 * (loVol - 1.0)) * faceH;
      const vermilionTopY = upInnerY + upHeight;
      const vermilionBotY = loInnerY - loHeight;

      if (ax < mouthHalfW * 1.55 && py < subnasaleY + 0.32 && py > mouthY - 2.05 - jawOpenDrop * 0.5) {
        // 1) Smooth, Continuous Philtral Columns & Philtral Dimple gliding seamlessly into the Upper Lip (ZERO shelf!):
        const pTopY = subnasaleY - 0.04;
        const philSpan = Math.max(0.38, pTopY - vermilionTopY);
        const uPhil = (pTopY - py) / philSpan;
        if (uPhil > -0.08 && uPhil < 1.18 && ax < 1.18) {
          const philEnv = smoothstep(-0.04, 0.26, uPhil) * (1.0 - smoothstep(0.64, 1.14, uPhil));
          const colPeakX = 0.35 + 0.08 * clamp(uPhil, 0.0, 1.0);
          const philCol = gauss(ax, colPeakX, 0.18) * philEnv;
          const philDimple = gauss(px, 0.0, 0.22) * philEnv;
          dz += 0.016 * philCol - 0.013 * philDimple;
        }

        // 2) Broad, Soft Vermilion Rolls (`sigma = 0.165 cm` on BOTH upper & lower — ZERO sharp pointy rim in 90-deg profile!):
        if (horizPillow > 0.02) {
          const whiteRollUp = gauss(py, vermilionTopY - 0.04, 0.165) * Math.pow(horizPillow, 0.82);
          const cupidAccent = 1.0 + 0.18 * gauss(ax, 0.43, 0.28);
          dz += 0.008 * whiteRollUp * cupidAccent;

          const whiteRollLo = gauss(py, vermilionBotY + 0.03, 0.160) * Math.pow(horizPillow, 0.85);
          dz += 0.009 * whiteRollLo;
        }

        // 3) Soft Blunt Central Tubercle & Lower Cushion (no excessive forward spike):
        const uRollUp = (py - upInnerY) / Math.max(0.34, upHeight);
        const uRollLo = (loInnerY - py) / Math.max(0.34, loHeight);
        if (horizPillow > 0.02) {
          const centralTubercle = gauss(px, 0.0, 0.48) * gauss(uRollUp, 0.46, 0.36);
          const lateralDipUp    = gauss(ax, 0.70, 0.28) * gauss(uRollUp, 0.42, 0.30);
          const lowerBilobe     = gauss(ax, 0.48, 0.38) * gauss(uRollLo, 0.48, 0.34);
          const lowerMedianDip  = gauss(px, 0.0, 0.16) * gauss(uRollLo, 0.44, 0.30);
          dz += (0.012 * centralTubercle - 0.006 * lateralDipUp + 0.016 * lowerBilobe - 0.009 * lowerMedianDip) * horizPillow;
        }

        // 4) Gentle Toroidal 3D Lip-Margin Curl (soft rounded cushions, ZERO sharp `<` beak notch in profile!):
        if (closedWeight > 0.01 && horizPillow > 0.01) {
          if (uRollUp > -0.08 && uRollUp < 1.20) {
            const marginTuckUp = gauss(uRollUp, 0.07, 0.22) * horizPillow * closedWeight * lipSoftCtrl;
            const bodyPlumpUp  = gauss(uRollUp, 0.54, 0.34) * horizPillow * closedWeight * lipSoftCtrl;
            dy -= 0.018 * gauss(uRollUp, 0.18, 0.22) * horizPillow * closedWeight * lipSoftCtrl;
            dz += 0.012 * bodyPlumpUp - 0.020 * marginTuckUp;
          }
          if (uRollLo > -0.05 && uRollLo < 1.15) {
            const marginTuckLo = gauss(uRollLo, 0.07, 0.20) * horizPillow * closedWeight * lipSoftCtrl;
            const bodyPlumpLo  = gauss(uRollLo, 0.54, 0.34) * horizPillow * closedWeight * lipSoftCtrl;
            dy += 0.026 * gauss(uRollLo, 0.20, 0.20) * horizPillow * closedWeight * lipSoftCtrl;
            dz += 0.015 * bodyPlumpLo - 0.024 * marginTuckLo;
          }

          const kissPocket = gauss(py, partCenterY, 0.048) * Math.pow(horizPillow, 1.12) * closedWeight;
          cavityAO[idx] = Math.max(cavityAO[idx], 0.32 * kissPocket);
        }

        // Strong silky Taubin fairing across BOTH upper and lower vermilion pillows so 90-deg profile has zero pointiness:
        const lipZoneMask =
          (1.0 - smoothstep(mouthHalfW * 0.98, mouthHalfW * 1.38, ax)) *
          smoothstep(vermilionBotY - 0.38, vermilionBotY + 0.04, py) *
          (1.0 - smoothstep(vermilionTopY + 0.14, vermilionTopY + 0.48, py));
        const detailProtect = 1.0 - 0.42 * closedWeight * gauss(py, partCenterY, 0.052);
        softW = Math.max(softW, clamp(0.70 * lipSoftCtrl, 0.30, 0.86) * lipZoneMask * detailProtect);
      }

      // ---------------------------------------------------------------------
      // C. VISION-MATCHED PERIORAL SOFT TISSUE (Zero artificial puppet lines on smooth faces!)
      // ---------------------------------------------------------------------
      if (ax < mouthHalfW + 1.80 * faceW && py < subnasaleY + 0.30 && py > vermilionBotY - 1.05) {
        const cornerY = mouthY + cornerLift;

        // 1) Natural Oral Commissure Corner Tuck (keeps the solved lips crisp & organic at the mouth corners):
        const cornerPocket = gauss2D(ax, py, mouthHalfW * 1.00, cornerY, 0.22, 0.17);
        const modiolusNode = gauss2D(ax, py, mouthHalfW + 0.30 * faceW, cornerY + 0.04 * faceH, 0.28, 0.26);
        dz -= 0.056 * lipSoftCtrl * cornerPocket;
        dz += 0.018 * lipSoftCtrl * modiolusNode;
        dx -= sgnX * 0.020 * lipSoftCtrl * cornerPocket;
        cavityAO[idx] = Math.max(cavityAO[idx], clamp(0.16 * lipSoftCtrl * cornerPocket, 0.0, 0.24));

        // 2) Feature-Matched Nasolabial Fold: ONLY active when Vision detects a real fold OR genuine open smile (`smileDrive`)!
        const effectiveFold = clamp(mouthLineCtrl + 0.38 * smileDrive, 0.0, 1.65);
        if (effectiveFold > 0.02) {
          const nlTopY = subnasaleY + 0.06 * faceH;
          const nlBotY = cornerY - 0.35 * faceH;
          const uNL = (nlTopY - py) / Math.max(0.85, nlTopY - nlBotY);
          if (uNL > -0.05 && uNL < 1.08) {
            const uClamped = clamp(uNL, 0.0, 1.0);
            const nlCurveX =
              mix(alarW * 0.96, mouthHalfW + 0.36 * faceW, Math.pow(uClamped, 0.86)) +
              0.08 * faceW * Math.sin(uClamped * Math.PI);
            const nlVertEnv = smoothstep(0.0, 0.24, uNL) * (1.0 - smoothstep(0.68, 1.05, uNL));
            const nlCrease  = gauss(ax - nlCurveX, 0.0, 0.24) * nlVertEnv;
            dz -= 0.046 * nlCrease * effectiveFold;
            dx -= sgnX * 0.014 * nlCrease * effectiveFold;
            cavityAO[idx] = Math.max(cavityAO[idx], clamp(0.06 * nlCrease * effectiveFold, 0.0, 0.14));
          }
        }

        // 3) Feature-Matched Cheek Dimple: ONLY active when Vision detects a real dimple hollow (`dimpleCtrl > 0.02`)!
        const effectiveDimple = clamp(dimpleCtrl + 0.25 * mouthLineCtrl * smileDrive, 0.0, 1.50);
        if (effectiveDimple > 0.02) {
          const buccalDimple = gauss2D(ax, py, mouthHalfW + 0.58 * faceW, cornerY + 0.06 * faceH, 0.28, 0.30);
          dz -= 0.042 * effectiveDimple * buccalDimple;
          cavityAO[idx] = Math.max(cavityAO[idx], clamp(0.07 * effectiveDimple * buccalDimple, 0.0, 0.14));
        }
      }

      positions[i3]     = px + dx;
      positions[i3 + 1] = py + dy;
      positions[i3 + 2] = pz + dz;
      smoothWeights[idx] = softW;
    }

    const i0 = r * cols * 3;
    const iM = (r * cols + M) * 3;
    positions[iM]     = positions[i0];
    positions[iM + 1] = positions[i0 + 1];
    positions[iM + 2] = positions[i0 + 2];
    cavityAO[r * cols + M] = cavityAO[r * cols];
    smoothWeights[r * cols + M] = smoothWeights[r * cols];
  }

  // =========================================================================
  // PASS 2: 4-Step Structure-Preserving Taubin Micro-Fairing
  //         Eliminates quad facet edges while preserving 3D nostril wings, kiss-cleft & mouth lines!
  // =========================================================================
  const tmpPos = new Float32Array(positions.length);
  const taubinSteps = [0.38, -0.398, 0.34, -0.355];

  for (let pass = 0; pass < taubinSteps.length; pass++) {
    const omega = taubinSteps[pass];
    tmpPos.set(positions);

    for (let r = 1; r < rows - 1; r++) {
      const t = regionT[r * cols];
      if (t < 0.34 || t > 0.59) continue;

      for (let m = 0; m < M; m++) {
        const idx = r * cols + m;
        const wSmooth = smoothWeights[idx];
        if (wSmooth <= 1e-3) continue;

        const mPrev = m === 0 ? M - 1 : m - 1;
        const mNext = m === M - 1 ? 0 : m + 1;

        const iC = idx * 3;
        const iL = (r * cols + mPrev) * 3;
        const iR = (r * cols + mNext) * 3;
        const iU = ((r - 1) * cols + m) * 3;
        const iD = ((r + 1) * cols + m) * 3;
        const iUL = ((r - 1) * cols + mPrev) * 3;
        const iUR = ((r - 1) * cols + mNext) * 3;
        const iDL = ((r + 1) * cols + mPrev) * 3;
        const iDR = ((r + 1) * cols + mNext) * 3;

        const avgX =
          0.20 * (tmpPos[iL] + tmpPos[iR] + tmpPos[iU] + tmpPos[iD]) +
          0.05 * (tmpPos[iUL] + tmpPos[iUR] + tmpPos[iDL] + tmpPos[iDR]);
        const avgY =
          0.20 * (tmpPos[iL + 1] + tmpPos[iR + 1] + tmpPos[iU + 1] + tmpPos[iD + 1]) +
          0.05 * (tmpPos[iUL + 1] + tmpPos[iUR + 1] + tmpPos[iDL + 1] + tmpPos[iDR + 1]);
        const avgZ =
          0.20 * (tmpPos[iL + 2] + tmpPos[iR + 2] + tmpPos[iU + 2] + tmpPos[iD + 2]) +
          0.05 * (tmpPos[iUL + 2] + tmpPos[iUR + 2] + tmpPos[iDL + 2] + tmpPos[iDR + 2]);

        const step = omega * wSmooth;
        positions[iC]     = tmpPos[iC]     + step * (avgX - tmpPos[iC]);
        positions[iC + 1] = tmpPos[iC + 1] + step * (avgY - tmpPos[iC + 1]);
        positions[iC + 2] = tmpPos[iC + 2] + step * (avgZ - tmpPos[iC + 2]);
      }

      const i0 = r * cols * 3;
      const iM = (r * cols + M) * 3;
      positions[iM]     = positions[i0];
      positions[iM + 1] = positions[i0 + 1];
      positions[iM + 2] = positions[i0 + 2];
    }
  }

  return { cavityAO };
}

/**
 * Gentle 2-Pair Post-Warp Taubin Micro-Polish:
 * Removes any tiny RBF-warp row kinks on nose tip & upper/lower lips without blurring 3D alar wings or mouth lines!
 */
export function polishNoseAndLipSoftTissue(positions, regionT, cols, rows, weights = {}) {
  const M = cols - 1;
  const faceW = 1.0 + 0.080 * (weights.faceWidth || 0);
  const faceH = 1.0 + 0.072 * (weights.faceHeight || 0);
  const mOpen = clamp(weights.mouthOpen || 0.0, 0.0, 1.55);
  const jawOpenDrop = 0.92 * mOpen;
  const noseTipY = (-1.80 - 0.50 * (weights.noseLength || 0)) * faceH;
  const subnasaleY = noseTipY - 0.56 * faceH;
  const mouthY = (-4.06 - 0.36 * (weights.mouthHeight || 0)) * faceH - jawOpenDrop * 0.36;
  const mouthHalfW = (2.16 + 0.34 * (weights.mouthWidth || 0) + 0.22 * mOpen) * faceW;
  const lipSoftCtrl = clamp(weights.lipSoftness !== undefined ? weights.lipSoftness : 1.0, 0.25, 1.80);
  const closedWeight = 1.0 - clamp(mOpen / 0.22, 0.0, 1.0);

  const tmpPos = new Float32Array(positions.length);
  const steps = [0.34, -0.354, 0.30, -0.312];

  for (let pass = 0; pass < steps.length; pass++) {
    const omega = steps[pass];
    tmpPos.set(positions);
    for (let r = 1; r < rows - 1; r++) {
      const t = regionT[r * cols];
      if (t < 0.36 || t > 0.57) continue;
      for (let m = 0; m < M; m++) {
        const idx = r * cols + m;
        const iC = idx * 3;
        const px = tmpPos[iC], py = tmpPos[iC + 1], pz = tmpPos[iC + 2];
        if (pz < 3.2) continue;
        const ax = Math.abs(px);

        // Keep post-warp polish confined to central tip dome (`ax < 0.62`) so 3D lateral nostril wings stay super crisp!
        const noseTipMask =
          0.48 *
          (1.0 - smoothstep(0.46, 0.72, ax)) *
          smoothstep(subnasaleY + 0.08, subnasaleY + 0.24, py) *
          (1.0 - smoothstep(noseTipY + 0.55, noseTipY + 1.00, py));

        // Unblocked silky upper + lower lip fairing (protecting ONLY the stomion kiss-cleft!)
        const lipMask =
          clamp(0.46 * lipSoftCtrl, 0.18, 0.68) *
          (1.0 - smoothstep(mouthHalfW * 0.90, mouthHalfW * 1.18, ax)) *
          smoothstep(mouthY - 1.05 - jawOpenDrop * 0.5, mouthY - 0.55 - jawOpenDrop * 0.5, py) *
          (1.0 - smoothstep(subnasaleY - 0.32, subnasaleY - 0.06, py)) *
          (1.0 - 0.68 * closedWeight * gauss(py, mouthY, 0.050));

        const wSmooth = Math.max(noseTipMask, lipMask);
        if (wSmooth <= 1e-3) continue;

        const mPrev = m === 0 ? M - 1 : m - 1;
        const mNext = m === M - 1 ? 0 : m + 1;
        const iL = (r * cols + mPrev) * 3, iR = (r * cols + mNext) * 3;
        const iU = ((r - 1) * cols + m) * 3, iD = ((r + 1) * cols + m) * 3;
        const iUL = ((r - 1) * cols + mPrev) * 3, iUR = ((r - 1) * cols + mNext) * 3;
        const iDL = ((r + 1) * cols + mPrev) * 3, iDR = ((r + 1) * cols + mNext) * 3;

        const avgX = 0.20 * (tmpPos[iL] + tmpPos[iR] + tmpPos[iU] + tmpPos[iD]) + 0.05 * (tmpPos[iUL] + tmpPos[iUR] + tmpPos[iDL] + tmpPos[iDR]);
        const avgY = 0.20 * (tmpPos[iL + 1] + tmpPos[iR + 1] + tmpPos[iU + 1] + tmpPos[iD + 1]) + 0.05 * (tmpPos[iUL + 1] + tmpPos[iUR + 1] + tmpPos[iDL + 1] + tmpPos[iDR + 1]);
        const avgZ = 0.20 * (tmpPos[iL + 2] + tmpPos[iR + 2] + tmpPos[iU + 2] + tmpPos[iD + 2]) + 0.05 * (tmpPos[iUL + 2] + tmpPos[iUR + 2] + tmpPos[iDL + 2] + tmpPos[iDR + 2]);

        const step = omega * wSmooth;
        positions[iC]     = px + step * (avgX - px);
        positions[iC + 1] = py + step * (avgY - py);
        positions[iC + 2] = pz + step * (avgZ - pz);
      }
      const i0 = r * cols * 3, iM = (r * cols + M) * 3;
      positions[iM] = positions[i0];
      positions[iM + 1] = positions[i0 + 1];
      positions[iM + 2] = positions[i0 + 2];
    }
  }
}
