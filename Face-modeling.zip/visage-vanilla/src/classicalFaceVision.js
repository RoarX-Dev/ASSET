/**
 * VISAGE//FORGE — Pure Vanilla JS First-Principles Classical Face & Pose Vision Engine
 * Zero neural networks, zero Google MediaPipe, zero external WASM/weights.
 */

function clamp(v, lo, hi) {
  return v < lo ? lo : v > hi ? hi : v;
}

function mix(a, b, t) {
  return a + (b - a) * t;
}

function smoothstep(e0, e1, x) {
  const t = clamp((x - e0) / (e1 - e0 || 1e-8), 0, 1);
  return t * t * (3 - 2 * t);
}

function downsampleImage(rgba, srcW, srcH, maxDim = 280) {
  const scale = Math.min(1.0, maxDim / Math.max(srcW, srcH));
  const W = Math.max(64, Math.round(srcW * scale));
  const H = Math.max(64, Math.round(srcH * scale));

  const L   = new Float32Array(W * H);
  const Cb  = new Float32Array(W * H);
  const Cr  = new Float32Array(W * H);
  const Lip = new Float32Array(W * H);
  const Rch = new Float32Array(W * H);
  const Gch = new Float32Array(W * H);
  const Bch = new Float32Array(W * H);

  for (let y = 0; y < H; y++) {
    const sy = Math.min(srcH - 1, Math.floor(((y + 0.5) / H) * srcH));
    for (let x = 0; x < W; x++) {
      const sx = Math.min(srcW - 1, Math.floor(((x + 0.5) / W) * srcW));
      const si = (sy * srcW + sx) * 4;
      const r = rgba[si];
      const g = rgba[si + 1];
      const b = rgba[si + 2];
      const di = y * W + x;

      Rch[di] = r; Gch[di] = g; Bch[di] = b;
      const lum = 0.299 * r + 0.587 * g + 0.114 * b;
      const cb  = 128.0 - 0.168736 * r - 0.331264 * g + 0.5 * b;
      const cr  = 128.0 + 0.5 * r - 0.418688 * g - 0.081312 * b;

      L[di]  = lum;
      Cb[di] = cb;
      Cr[di] = cr;
      Lip[di] = (cr - 128.0) - 0.65 * (cb - 128.0) + 0.25 * (r - g);
    }
  }

  return { W, H, scale, L, Cb, Cr, Lip, Rch, Gch, Bch };
}

function buildIntegralImage(arr, W, H) {
  const sat = new Float64Array((W + 1) * (H + 1));
  const stride = W + 1;
  for (let y = 0; y < H; y++) {
    let rowSum = 0;
    for (let x = 0; x < W; x++) {
      rowSum += arr[y * W + x];
      sat[(y + 1) * stride + (x + 1)] = sat[y * stride + (x + 1)] + rowSum;
    }
  }
  return sat;
}

function boxMean(sat, W, H, cx, cy, rx, ry) {
  const x0 = clamp(Math.round(cx - rx), 0, W - 1);
  const y0 = clamp(Math.round(cy - ry), 0, H - 1);
  const x1 = clamp(Math.round(cx + rx) + 1, x0 + 1, W);
  const y1 = clamp(Math.round(cy + ry) + 1, y0 + 1, H);
  const stride = W + 1;
  const sum =
    sat[y1 * stride + x1] -
    sat[y0 * stride + x1] -
    sat[y1 * stride + x0] +
    sat[y0 * stride + x0];
  return sum / ((x1 - x0) * (y1 - y0));
}

export function detectClassicalFaceLandmarks(imageData) {
  const { width: srcW, height: srcH, data } = imageData;
  const work = downsampleImage(data, srcW, srcH, 280);
  const { W, H, L, Cb, Cr, Lip, Rch, Gch, Bch } = work;

  // 1. Model Studio / Ambient Background from outer border strips
  const bgL = [], bgCb = [], bgCr = [];
  const marginX = Math.max(3, Math.floor(W * 0.06));
  const marginY = Math.max(3, Math.floor(H * 0.05));
  for (let y = 0; y < Math.floor(H * 0.65); y++) {
    for (let x = 0; x < W; x++) {
      if (x < marginX || x >= W - marginX || y < marginY) {
        const idx = y * W + x;
        bgL.push(L[idx]);
        bgCb.push(Cb[idx]);
        bgCr.push(Cr[idx]);
      }
    }
  }
  const median = (arr) => {
    const s = [...arr].sort((a, b) => a - b);
    return s[Math.floor(s.length / 2)] || 0;
  };
  const medL = median(bgL);
  const medCb = median(bgCb);
  const medCr = median(bgCr);

  // 2. Melanin-Invariant Skin Chrominance + Foreground Map
  const skinProb = new Float32Array(W * H);
  for (let i = 0; i < W * H; i++) {
    const lum = L[i];
    const cb = Cb[i];
    const cr = Cr[i];
    const r = Rch[i], g = Gch[i], b = Bch[i];

    const dBg = Math.hypot((lum - medL) * 0.55, (cb - medCb) * 1.4, (cr - medCr) * 1.4);
    const isFg = smoothstep(7.5, 22.0, dBg);

    const chromaDiff = cr - cb;
    const pCr = smoothstep(129.5, 136.5, cr) * (1.0 - smoothstep(172.0, 185.0, cr));
    const pCb = smoothstep(74.0, 84.0, cb) * (1.0 - smoothstep(124.0, 131.5, cb));
    const pWarm = smoothstep(5.5, 14.5, chromaDiff);
    const pLum = smoothstep(16.0, 32.0, lum) * (1.0 - smoothstep(244.0, 254.0, lum));
    const pRgbOrder = r > g * 0.96 && r > b * 1.04 ? 1.0 : 0.25;

    skinProb[i] = pCr * pCb * pWarm * pLum * pRgbOrder * (0.25 + 0.75 * isFg);
  }

  const satSkin = buildIntegralImage(skinProb, W, H);
  const satL    = buildIntegralImage(L, W, H);

  const L2 = new Float32Array(W * H);
  const absGy = new Float32Array(W * H);
  for (let y = 1; y < H - 1; y++) {
    for (let x = 1; x < W - 1; x++) {
      const idx = y * W + x;
      L2[idx] = L[idx] * L[idx];
      absGy[idx] = Math.abs(L[(y + 1) * W + x] - L[(y - 1) * W + x]);
    }
  }
  const satL2    = buildIntegralImage(L2, W, H);
  const satAbsGy = buildIntegralImage(absGy, W, H);
  const satLip   = buildIntegralImage(Lip, W, H);

  // 3. Connected-Component Face Skin Blob
  const skinMask = new Uint8Array(W * H);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const centerPrior = 1.0 - 0.30 * Math.pow((x / W - 0.5) * 2.0, 4);
      skinMask[y * W + x] = boxMean(satSkin, W, H, x, y, 2, 2) * centerPrior > 0.26 ? 1 : 0;
    }
  }

  const visited = new Uint8Array(W * H);
  let bestComp = null;
  let bestScore = -1;
  const q = new Int32Array(W * H);

  for (let y = Math.floor(H * 0.08); y < Math.floor(H * 0.78); y++) {
    for (let x = Math.floor(W * 0.15); x < Math.floor(W * 0.85); x++) {
      const start = y * W + x;
      if (!skinMask[start] || visited[start]) continue;
      let head = 0, tail = 0;
      q[tail++] = start;
      visited[start] = 1;
      let sumX = 0, sumY = 0;
      while (head < tail) {
        const cur = q[head++];
        const cy = Math.floor(cur / W);
        const cx = cur - cy * W;
        sumX += cx; sumY += cy;
        const nbrs = [cur - 1, cur + 1, cur - W, cur + W];
        for (const nb of nbrs) {
          if (nb >= 0 && nb < W * H && skinMask[nb] && !visited[nb]) {
            if (Math.abs((nb % W) - cx) <= 1) {
              visited[nb] = 1;
              q[tail++] = nb;
            }
          }
        }
      }
      if (tail > (W * H) * 0.012) {
        const meanX = sumX / tail / W;
        const meanY = sumY / tail / H;
        const centrality = 1.0 - Math.hypot(meanX - 0.5, (meanY - 0.44) * 0.8);
        const sc = tail * Math.max(0.2, centrality);
        if (sc > bestScore) {
          bestScore = sc;
          bestComp = q.slice(0, tail);
        }
      }
    }
  }

  if (!bestComp) return null;

  const faceBlob = new Uint8Array(W * H);
  let yMinSkin = H, yMaxSkin = 0;
  for (let i = 0; i < bestComp.length; i++) {
    const idx = bestComp[i];
    faceBlob[idx] = 1;
    const ry = Math.floor(idx / W);
    if (ry < yMinSkin) yMinSkin = ry;
    if (ry > yMaxSkin) yMaxSkin = ry;
  }

  const rowLeft  = new Float32Array(H).fill(-1);
  const rowRight = new Float32Array(H).fill(-1);
  const rowWidth = new Float32Array(H).fill(0);

  for (let y = yMinSkin; y <= yMaxSkin; y++) {
    let lx = -1, rx = -1;
    for (let x = 0; x < W; x++) {
      if (faceBlob[y * W + x]) {
        if (lx === -1) lx = x;
        rx = x;
      }
    }
    if (lx !== -1 && rx - lx >= 4) {
      rowLeft[y]  = lx;
      rowRight[y] = rx;
      rowWidth[y] = rx - lx;
    }
  }

  // Find maximum upper-head skin width & hairline top BEFORE searching eyes
  let maxUpperWidth = 0;
  let yAtMaxWidth = yMinSkin;
  const searchUpperLimit = Math.min(yMaxSkin, yMinSkin + Math.floor(H * 0.52));
  for (let y = yMinSkin; y <= searchUpperLimit; y++) {
    if (rowWidth[y] > maxUpperWidth) {
      maxUpperWidth = rowWidth[y];
      yAtMaxWidth = y;
    }
  }

  let yHairline = yMinSkin;
  for (let y = yMinSkin; y <= yAtMaxWidth; y++) {
    if (rowWidth[y] >= maxUpperWidth * 0.28) {
      yHairline = y;
      break;
    }
  }

  // Approximate initial head height solely to bound the EYE search band [0.28 .. 0.68 of maxUpperWidth below hairline]!
  // Notice: human eyes ALWAYS lie between 0.30 * headWidth and 0.68 * headWidth below the hairline — completely independent of shirt/neck length!
  const eyeY0 = clamp(Math.round(yHairline + maxUpperWidth * 0.28), 2, H - 4);
  const eyeY1 = clamp(Math.round(yHairline + maxUpperWidth * 0.72), eyeY0 + 4, H - 3);

  // Measure horizontal head silhouette span across the eye search band
  const bandL = [], bandR = [];
  for (let y = eyeY0; y <= eyeY1; y++) {
    if (rowLeft[y] >= 0) {
      bandL.push(rowLeft[y]);
      bandR.push(rowRight[y]);
    }
  }
  const silLeft  = bandL.length ? median(bandL) : W * 0.28;
  const silRight = bandR.length ? median(bandR) : W * 0.72;
  const headSpanW = Math.max(16, silRight - silLeft);

  // 4. Multi-Angle Eye-Pair Detector (works on Frontal 0 deg AND Turned +-45 deg 3/4 Views!)
  const rIris = Math.max(2, Math.round(headSpanW * 0.035));
  const rSurrX = Math.max(4, Math.round(headSpanW * 0.085));
  const rSurrY = Math.max(3, Math.round(headSpanW * 0.050));
  const browStepY = Math.max(4, Math.round(headSpanW * 0.125));

  const eyeMap = new Float32Array(W * H);
  const eyeX0 = Math.max(2, Math.round(silLeft + 0.02 * headSpanW));
  const eyeX1 = Math.min(W - 3, Math.round(silRight - 0.02 * headSpanW));

  for (let y = eyeY0; y <= eyeY1; y++) {
    for (let x = eyeX0; x <= eyeX1; x++) {
      // CRITICAL GUARD 1: Must have real SKIN cheek below AND real SKIN forehead ABOVE the eyebrow (~0.28*headSpanW up)!
      // (Note: 0.16*headSpanW up is the dark eyebrow itself where satSkin=0, whereas 0.28*headSpanW up is open forehead skin!)
      const cheekSkinBelow = boxMean(satSkin, W, H, x, y + Math.round(headSpanW * 0.11), rIris + 1, rIris + 1);
      const foreheadPosY   = Math.max(yHairline + 2, y - Math.round(headSpanW * 0.28));
      const foreheadSkinAbove = boxMean(satSkin, W, H, x, foreheadPosY, rIris + 2, rIris + 1);
      if (cheekSkinBelow < 0.45 || foreheadSkinAbove < 0.30) continue;

      // Cue A: Dark iris core vs surrounding sclera/eyelids + Bilateral Horizontal Sclera-Iris-Sclera Dip!
      const irisLum = boxMean(satL, W, H, x, y, rIris, Math.max(1, rIris - 1));
      const surrLum = boxMean(satL, W, H, x, y, rSurrX, rSurrY);
      const darkCore = Math.max(0, surrLum - irisLum);

      const dxSclera = Math.max(3, Math.round(rIris * 1.85));
      const lumScleraL = boxMean(satL, W, H, Math.max(1, x - dxSclera), y, Math.max(1, rIris - 1), Math.max(1, rIris - 1));
      const lumScleraR = boxMean(satL, W, H, Math.min(W - 2, x + dxSclera), y, Math.max(1, rIris - 1), Math.max(1, rIris - 1));
      // Both left AND right sides of a pupil are brighter sclera/canthus (rejects horizontal eyebrows & vertical hairlines!)
      const bilateralSclera = Math.max(0, Math.min(lumScleraL - irisLum, lumScleraR - irisLum));
      const meanHorizDip = Math.max(0, 0.5 * (lumScleraL + lumScleraR) - irisLum);

      // Cue B: Sclera-iris horizontal contrast variance
      const meanSq = boxMean(satL2, W, H, x, y, rSurrX * 0.85, rIris);
      const meanL  = boxMean(satL, W, H, x, y, rSurrX * 0.85, rIris);
      const stdL   = Math.sqrt(Math.max(0, meanSq - meanL * meanL));

      // Cue C: Eyelid horizontal edge energy
      const lashEdge = boxMean(satAbsGy, W, H, x, y, rSurrX * 0.75, rIris);

      // Cue D: True Eyebrow-Arch Guard!
      // Above a REAL eye (at ~0.13..0.18*headSpanW up) sits a darker eyebrow arch relative to open forehead skin (~0.28*headSpanW up).
      // Above an eyebrow itself sits ONLY bright open forehead skin (no darker brow above a brow!).
      const foreheadLum = boxMean(satL, W, H, x, foreheadPosY, rSurrX * 0.65, rIris);
      const browLum1 = boxMean(satL, W, H, x, Math.max(1, y - Math.round(headSpanW * 0.13)), rSurrX * 0.70, Math.max(1, rIris - 1));
      const browLum2 = boxMean(satL, W, H, x, Math.max(1, y - Math.round(headSpanW * 0.18)), rSurrX * 0.70, Math.max(1, rIris - 1));
      const minBrowLum = Math.min(browLum1, browLum2);
      const browDip = foreheadLum - minBrowLum; // strongly positive for real eyes, ~0 or negative when (x,y) IS the eyebrow!
      const hasBrowAbove = 0.45 + 0.95 * smoothstep(-2.0, 14.0, browDip);

      // Cue D: Infraorbital Cheek Rise below the eye!
      // Below an eyebrow (+2.5*rIris) sits the DARK eye socket/lashes; below a REAL pupil (+2.5*rIris) sits bright cheek skin!
      const lumBelowCheek = boxMean(
        satL, W, H, x,
        Math.min(H - 2, y + Math.round(rIris * 2.5)),
        Math.round(rIris * 1.3),
        Math.max(1, rIris - 1)
      );
      const infraorbitalRise = smoothstep(5.0, 22.0, lumBelowCheek - irisLum);

      const skinWeight = smoothstep(0.32, 0.72, foreheadSkinAbove) * smoothstep(0.45, 0.82, cheekSkinBelow);
      eyeMap[y * W + x] =
        (darkCore * 1.15 + bilateralSclera * 1.85 + meanHorizDip * 0.95 + stdL * 0.85 + lashEdge * 0.35) *
        hasBrowAbove *
        infraorbitalRise *
        skinWeight;
    }
  }

  const candidates = [];
  const nmsR = Math.max(3, Math.round(headSpanW * 0.05));
  for (let y = eyeY0 + 1; y <= eyeY1 - 1; y++) {
    for (let x = eyeX0 + 1; x <= eyeX1 - 1; x++) {
      const val = eyeMap[y * W + x];
      if (val <= 3.5) continue;
      let isMax = true;
      for (let dy = -nmsR; dy <= nmsR && isMax; dy++) {
        for (let dx = -nmsR; dx <= nmsR; dx++) {
          const ny = y + dy, nx = x + dx;
          if (ny >= eyeY0 && ny <= eyeY1 && nx >= eyeX0 && nx <= eyeX1 && eyeMap[ny * W + nx] > val) {
            isMax = false;
            break;
          }
        }
      }
      if (isMax) {
        const cIrisLum = boxMean(satL, W, H, x, y, rIris, Math.max(1, rIris - 1));
        candidates.push({ x, y, val, irisLum: cIrisLum });
      }
    }
  }
  candidates.sort((a, b) => b.val - a.val);
  const topCands = candidates.slice(0, 20);

  let eyeL = { x: silLeft + 0.30 * headSpanW, y: yHairline + 0.48 * headSpanW };
  let eyeR = { x: silLeft + 0.70 * headSpanW, y: yHairline + 0.48 * headSpanW };
  let bestPairScore = -1;

  for (let i = 0; i < topCands.length; i++) {
    for (let j = 0; j < topCands.length; j++) {
      if (i === j) continue;
      const cL = topCands[i];
      const cR = topCands[j];
      const dx = cR.x - cL.x;
      const dy = cR.y - cL.y;

      if (dx < headSpanW * 0.22 || dx > headSpanW * 0.56) continue;
      if (Math.abs(dy / dx) > 0.25) continue;

      const midBridgeX = 0.5 * (cL.x + cR.x);
      const midBridgeY = 0.5 * (cL.y + cR.y);
      const bridgeSkin = boxMean(satSkin, W, H, midBridgeX, midBridgeY, Math.max(2, Math.round(dx * 0.2)), 2);
      if (bridgeSkin < 0.55) continue;

      const irisMatch    = Math.exp(-0.5 * (((cL.irisLum - cR.irisLum) / 18.0) ** 2));
      const spacingPrior = Math.exp(-0.5 * (((dx / headSpanW - 0.38) / 0.125) ** 2));
      const levelPrior   = Math.exp(-0.5 * (((dy / dx) / 0.11) ** 2));
      const yRelW        = (midBridgeY - yHairline) / headSpanW;
      const heightPrior  = Math.exp(-0.5 * (((yRelW - 0.53) / 0.14) ** 2));

      const pairScore = Math.sqrt(cL.val * cR.val) * irisMatch * spacingPrior * levelPrior * heightPrior;
      if (pairScore > bestPairScore) {
        bestPairScore = pairScore;
        eyeL = { x: cL.x, y: cL.y };
        eyeR = { x: cR.x, y: cR.y };
      }
    }
  }

  // Sub-pixel circular-disc + sclera-flank iris refinement (prevents medial tear-trough / brow shadows from pulling iris inward!)
  const refineIris = (pt, rx, ry) => {
    const rDisc = Math.max(2, Math.round(rx * 0.85));
    const flankD = Math.max(rDisc + 2, Math.round(rx * 1.45));
    let bestX = pt.x, bestY = pt.y, bestSc = -1e9;
    const scanR = Math.max(2, Math.round(rx * 0.75));
    for (let oy = -scanR; oy <= scanR; oy++) {
      for (let ox = -scanR; ox <= scanR; ox++) {
        const cx = clamp(Math.round(pt.x + ox), 4, W - 5);
        const cy = clamp(Math.round(pt.y + oy), 4, H - 5);
        const discLum = boxMean(satL, W, H, cx, cy, Math.max(1, rDisc - 1), Math.max(1, rDisc - 1));
        const sclL = boxMean(satL, W, H, clamp(cx - flankD, 2, W - 3), cy, 1, 1);
        const sclR = boxMean(satL, W, H, clamp(cx + flankD, 2, W - 3), cy, 1, 1);
        const skinBelow = boxMean(satL, W, H, cx, clamp(cy + flankD + 1, 2, H - 3), 2, 1);
        const flankContrast = 0.5 * (sclL + sclR) - discLum;
        const symFlank = -0.35 * Math.abs(sclL - sclR);
        const prior = Math.exp(-0.5 * ((ox * ox + oy * oy) / Math.max(4.0, scanR * scanR * 0.85)));
        const sc = (flankContrast * 1.35 + (skinBelow - discLum) * 0.55 + symFlank) * prior;
        if (sc > bestSc) {
          bestSc = sc;
          bestX = cx;
          bestY = cy;
        }
      }
    }
    // Fine sub-pixel centroid strictly inside the tight iris disc (`rDisc`)
    let sumW = 0, sx = 0, sy = 0;
    const refSkin = boxMean(satL, W, H, bestX, clamp(bestY + flankD + 1, 2, H - 3), 3, 2);
    for (let dy = -rDisc; dy <= rDisc; dy++) {
      for (let dx = -rDisc; dx <= rDisc; dx++) {
        if (dx * dx + dy * dy > rDisc * rDisc + 1) continue;
        const px = clamp(bestX + dx, 0, W - 1);
        const py = clamp(bestY + dy, 0, H - 1);
        const lum = L[py * W + px];
        if (lum > refSkin * 0.90) continue; // ignore specular catchlight
        const w = Math.max(0, refSkin * 0.92 - lum);
        sumW += w; sx += w * px; sy += w * py;
      }
    }
    return sumW > 1e-3 ? { x: sx / sumW, y: sy / sumW } : { x: bestX, y: bestY };
  };
  eyeL = refineIris(eyeL, rIris + 1, rIris);
  eyeR = refineIris(eyeR, rIris + 1, rIris);

  // 5. Solve Hair-Immune 3D Head Yaw, Roll & True Metric Scale from Eyes + Inter-Ocular Nasal Axis + Cheek Silhouette!
  const yEyes = clamp(Math.round(0.5 * (eyeL.y + eyeR.y)), 0, H - 1);
  const cheekRowL = rowLeft[yEyes] >= 0 ? rowLeft[yEyes] : silLeft;
  const cheekRowR = rowRight[yEyes] >= 0 ? rowRight[yEyes] : silRight;

  const dLeftCheek  = Math.max(1.5, eyeL.x - cheekRowL);
  const dRightCheek = Math.max(1.5, cheekRowR - eyeR.x);
  const cheekAsym = (dLeftCheek - dRightCheek) / (dLeftCheek + dRightCheek);

  const ipdPx = Math.hypot(eyeR.x - eyeL.x, eyeR.y - eyeL.y);
  const eyeMidX = 0.5 * (eyeL.x + eyeR.x);
  const eyeMidY = 0.5 * (eyeL.y + eyeR.y);

  // Locate inter-ocular nasal bridge & nostril symmetry axis (100% immune to side-part hair or exposed ears!):
  const prelimNoseY = clamp(Math.round(eyeMidY + ipdPx * 0.56), 4, H - 5);
  const prelimSubY  = clamp(Math.round(eyeMidY + ipdPx * 0.65), 4, H - 5);
  const nScanL = Math.max(4, Math.round(eyeL.x + ipdPx * 0.20));
  const nScanR = Math.min(W - 5, Math.round(eyeR.x - ipdPx * 0.20));
  let prelimNoseX = eyeMidX;
  let bestPrelimSc = -1e9;
  const nSpan = Math.max(2, Math.round(ipdPx * 0.11));
  for (let tx = nScanL; tx <= nScanR; tx++) {
    const ridgeL = boxMean(satL, W, H, tx, prelimNoseY, 1, 2);
    const nostA  = boxMean(satL, W, H, clamp(tx - nSpan, 2, W - 3), prelimSubY, 1, 1);
    const nostB  = boxMean(satL, W, H, clamp(tx + nSpan, 2, W - 3), prelimSubY, 1, 1);
    const flankA = boxMean(satL, W, H, clamp(tx - Math.round(ipdPx * 0.17), 2, W - 3), prelimNoseY, 1, 2);
    const flankB = boxMean(satL, W, H, clamp(tx + Math.round(ipdPx * 0.17), 2, W - 3), prelimNoseY, 1, 2);
    const sc =
      (ridgeL - 0.5 * (flankA + flankB)) * 0.85 +
      (ridgeL - 0.5 * (nostA + nostB)) * 0.95 -
      0.55 * Math.abs(nostA - nostB);
    if (sc > bestPrelimSc) {
      bestPrelimSc = sc;
      prelimNoseX = tx;
    }
  }
  const dEyeNoseL = prelimNoseX - eyeL.x;
  const dEyeNoseR = eyeR.x - prelimNoseX;
  const noseEyeAsym = clamp((dEyeNoseL - dEyeNoseR) / Math.max(8.0, ipdPx), -0.68, 0.68);
  // Convex blend (`weights <= 1`): suppresses false cheek-hair yaw on frontal portraits while preserving true +-32 deg 3/4 poses!
  const noseYawDeg  = noseEyeAsym * 44.0;
  const cheekYawDeg = cheekAsym * 40.0;
  const turnGate = smoothstep(0.038, 0.125, Math.abs(noseEyeAsym)) *
                   (noseEyeAsym * cheekAsym >= -0.005 ? 1.0 : 0.15);
  const estYawDeg = clamp(
    mix(noseYawDeg * 0.30, 0.30 * noseYawDeg + 0.70 * cheekYawDeg, turnGate),
    -44.0,
    44.0
  );
  const estYawRad = (estYawDeg * Math.PI) / 180.0;
  const estRollRad = Math.atan2(-(eyeR.y - eyeL.y), eyeR.x - eyeL.x);

  // Metric px-per-cm calibrated primarily from foreshortened IPD (`85%` weight so low/high hairlines don't skew chin/nose scale!)

  // Refine `yHairline` using true forehead-skin luminance contrast above `eyeMidY`!
  // Prevents dark warm-toned hair (e.g. buzz-cuts with R > G > B) from pushing `yHairline` up to the crown top!
  const pxPerCmIpdInit = ipdPx / Math.max(3.5, 6.16 * Math.cos(estYawRad * 0.72));
  const fhRefY = clamp(Math.round(eyeMidY - pxPerCmIpdInit * 2.6), 4, H - 5);
  const fhBaseLum = boxMean(satL, W, H, eyeMidX, fhRefY, Math.max(4, Math.round(pxPerCmIpdInit * 1.4)), 3);
  const hlSearchBot = clamp(Math.round(eyeMidY - pxPerCmIpdInit * 4.3), 5, H - 6);
  const hlSearchTop = Math.max(3, Math.round(eyeMidY - pxPerCmIpdInit * 8.0));
  let refinedHairY = clamp(Math.round(eyeMidY - pxPerCmIpdInit * 6.5), hlSearchTop, hlSearchBot);
  let bestHlScore = -1e9;
  for (let wy = hlSearchBot; wy >= hlSearchTop; wy--) {
    const belowL = boxMean(satL, W, H, eyeMidX, Math.min(H - 3, wy + 3), 4, 2);
    const aboveL = boxMean(satL, W, H, eyeMidX, Math.max(2, wy - 3), 4, 2);
    const skinUp = boxMean(satSkin, W, H, eyeMidX, Math.max(2, wy - 3), 4, 2);
    const darkHairDrop = Math.max(0.0, fhBaseLum * 0.82 - aboveL);
    const distCm = (eyeMidY - wy) / pxPerCmIpdInit;
    const prior = Math.exp(-0.5 * (((distCm - 6.45) / 1.15) ** 2));
    const sc = ((belowL - aboveL) * 1.35 + darkHairDrop * 0.85 + (1.0 - skinUp) * 28.0) * prior;
    if (sc > bestHlScore) {
      bestHlScore = sc;
      refinedHairY = wy;
    }
  }
  if (bestHlScore > 6.0) {
    yHairline = refinedHairY;
  }
  const pxPerCm = 0.85 * pxPerCmIpdInit + 0.15 * (Math.max(8, yEyes - yHairline) / 6.55);

  // Forward 3D midline feature projections in pixels due to 3D Yaw:
  const yawNoseShiftX  = 2.65 * Math.sin(estYawRad) * pxPerCm;
  const yawMouthShiftX = 1.45 * Math.sin(estYawRad) * pxPerCm;
  const yawChinShiftX  = 0.85 * Math.sin(estYawRad) * pxPerCm;

  // 6. Localize Eyebrows (supports both low-set masculine brows & high-arched editorial/East Asian brows up to 2.75 cm!)
  const findBrow = (eyePt) => {
    let bestY = eyePt.y - pxPerCm * 1.45;
    let bestSc = -1e9;
    const y0 = Math.max(yHairline + Math.round(pxPerCm * 0.65), Math.round(eyePt.y - pxPerCm * 2.70));
    const y1 = Math.max(y0 + 1, Math.round(eyePt.y - pxPerCm * 0.82));
    for (let y = y0; y <= y1; y++) {
      const bLum = boxMean(satL, W, H, eyePt.x, y, Math.max(3, rIris * 1.3), 1);
      const fhAbove = boxMean(satL, W, H, eyePt.x, Math.max(2, y - Math.round(pxPerCm * 0.55)), Math.max(3, rIris * 1.3), 2);
      const lidBelow = boxMean(satL, W, H, eyePt.x, Math.min(H - 3, y + Math.round(pxPerCm * 0.45)), Math.max(3, rIris * 1.2), 1);
      const sc = (fhAbove - bLum) * 1.35 + (lidBelow - bLum) * 0.85 - bLum * 0.25;
      if (sc > bestSc) {
        bestSc = sc;
        bestY = y;
      }
    }
    return { x: eyePt.x, y: bestY };
  };
  const browL = findBrow(eyeL);
  const browR = findBrow(eyeR);

  // 7. Precision Nasal Bridge, Tip, Alar Flare & Profile Silhouette Tracer!
  const nasionX = eyeMidX + 0.32 * yawNoseShiftX;
  const nasionY = eyeMidY - pxPerCm * 0.36;
  const nosePredX = eyeMidX + yawNoseShiftX;
  const noseSearchY0 = clamp(Math.round(eyeMidY + pxPerCm * 2.75), 4, H - 8);
  const noseSearchY1 = clamp(Math.round(eyeMidY + pxPerCm * 4.95), noseSearchY0 + 2, H - 6);
  const alarEstPx = Math.max(4, pxPerCm * 1.68);

  let subnasaleY = Math.round(eyeMidY + pxPerCm * 3.88);
  let bestNoseScore = -1e9;
  for (let y = noseSearchY0; y <= noseSearchY1; y++) {
    const cx = clamp(Math.round(nosePredX), 4, W - 5);
    const tipAbove = boxMean(satL, W, H, cx, y - Math.max(2, Math.round(pxPerCm * 0.55)), Math.round(alarEstPx * 0.42), 2);
    const nostDark = 0.5 * (
      boxMean(satL, W, H, clamp(cx - Math.round(alarEstPx * 0.36), 1, W - 2), y - 1, 2, 1) +
      boxMean(satL, W, H, clamp(cx + Math.round(alarEstPx * 0.36), 1, W - 2), y - 1, 2, 1)
    );
    const philBelow = boxMean(satL, W, H, cx, y + Math.max(2, Math.round(pxPerCm * 0.42)), Math.round(alarEstPx * 0.38), 2);
    const yPrior = Math.exp(-0.5 * ((((y - eyeMidY) / pxPerCm - 3.88) / 0.58) ** 2));
    const sc = ((tipAbove - nostDark) * 1.30 + (philBelow - nostDark) * 0.75) * yPrior;
    if (sc > bestNoseScore) {
      bestNoseScore = sc;
      subnasaleY = y;
    }
  }

  let noseTipY = subnasaleY - pxPerCm * 0.64;
  let noseTipX = nosePredX;
  let rhinionY = 0.5 * (nasionY + noseTipY);
  let rhinionX = 0.5 * (nasionX + noseTipX);

  if (Math.abs(estYawDeg) > 16.0) {
    // On turned 3/4 views (+-20..45 deg), the far cheek is STILL visible behind the nasal bridge,
    // so locate the pronasale tip via (nostril shadow below + dorsal highlight peak + tip-to-cheek shadow step)
    // strictly within realistic anatomical projection [1.6 .. 3.4] cm * sin(yaw) from eyeMidX!
    const dir = estYawDeg < 0 ? -1 : 1;
    const absSin = Math.abs(Math.sin(estYawRad));
    const minTipShift = pxPerCm * 1.55 * absSin;
    const maxTipShift = pxPerCm * 3.45 * absSin;
    const tipRow = clamp(Math.round(noseTipY), 3, H - 4);
    const subRow = clamp(Math.round(subnasaleY), 3, H - 4);

    let bestTipScore = -1e9;
    for (let s = Math.round(minTipShift); s <= Math.round(maxTipShift); s++) {
      const tx = clamp(Math.round(eyeMidX + dir * s), 4, W - 5);
      if (!faceBlob[tipRow * W + tx]) break;
      const tipLum = boxMean(satL, W, H, tx, tipRow, 2, 2);
      const outLum = boxMean(satL, W, H, clamp(tx + dir * 4, 2, W - 3), tipRow, 2, 2);
      // Near-side nostril dark cavity sits slightly inward (-dir * 0.55cm) at subRow!
      const nostInX = clamp(Math.round(tx - dir * pxPerCm * 0.55), 2, W - 3);
      const nostDark = boxMean(satL, W, H, nostInX, subRow - 1, 2, 1);
      const prior = Math.exp(-0.5 * (((s / (pxPerCm * Math.max(0.25, absSin)) - 2.65) / 0.55) ** 2));
      const sc = ((tipLum - nostDark) * 1.25 + (tipLum - outLum) * 0.95) * prior;
      if (sc > bestTipScore) {
        bestTipScore = sc;
        noseTipX = tx;
      }
    }

    // Refine rhinion (mid-bridge) within +-0.32cm of the straight nasion->noseTip chord (rhinion sits 38% down from nasion!)
    const straightRhinX = 0.62 * nasionX + 0.38 * noseTipX;
    const rRow = clamp(Math.round(rhinionY), 3, H - 4);
    let bestRhScore = -1e9;
    rhinionX = straightRhinX;
    for (let dx = -Math.round(pxPerCm * 0.30); dx <= Math.round(pxPerCm * 0.30); dx++) {
      const tx = clamp(Math.round(straightRhinX + dx), 4, W - 5);
      if (!faceBlob[rRow * W + tx]) continue;
      const ridgeLum = boxMean(satL, W, H, tx, rRow, 1, 2);
      const outLum   = boxMean(satL, W, H, clamp(tx + dir * 3, 2, W - 3), rRow, 1, 2);
      const prior    = Math.exp(-0.5 * (((dx / pxPerCm) / 0.25) ** 2));
      const sc = (ridgeLum * 0.55 + (ridgeLum - outLum) * 1.15) * prior;
      if (sc > bestRhScore) {
        bestRhScore = sc;
        rhinionX = tx;
      }
    }
  } else {
    // On frontal views, refine exact nose tip highlight / nostril-pair symmetry center X anchored gently near `nosePredX`
    let bestSym = -1e9;
    const maxDx = Math.round(pxPerCm * 0.36);
    for (let dx = -maxDx; dx <= maxDx; dx++) {
      const tx = clamp(Math.round(nosePredX + dx), 4, W - 5);
      const tipBright = boxMean(satL, W, H, tx, Math.round(noseTipY), 2, 2);
      const nostL = boxMean(satL, W, H, tx - Math.round(pxPerCm * 0.64), subnasaleY - 1, 2, 1);
      const nostR = boxMean(satL, W, H, tx + Math.round(pxPerCm * 0.64), subnasaleY - 1, 2, 1);
      const centerPrior = Math.exp(-0.5 * (((dx / pxPerCm) / 0.24) ** 2));
      const symScore = (tipBright * 0.55 + (tipBright - 0.5 * (nostL + nostR)) * 1.15 - 0.85 * Math.abs(nostL - nostR)) * centerPrior;
      if (symScore > bestSym) {
        bestSym = symScore;
        noseTipX = tx;
      }
    }
    rhinionX = 0.5 * (nasionX + noseTipX);
  }

  // Measure ACTUAL Alar Nostril Wing Width from pixel alar-facial shadow creases!
  // On near-frontal views (`|estYawDeg| <= 16°`), couple left & right alar-facial groove scores symmetrically
  // so unilateral nose cast shadows or nasolabial laugh lines (`> 2.0 cm`) NEVER pull one nostril wing outward!
  const alarY = noseTipY + (subnasaleY - noseTipY) * 0.55;
  const nostRow = clamp(Math.round(subnasaleY - pxPerCm * 0.12), 3, H - 4);
  const alarBaseCenter = Math.abs(estYawDeg) > 16 ? eyeMidX + 0.55 * (noseTipX - eyeMidX) : noseTipX;

  const evalAlarGrooveAt = (dir, off, foreshorten) => {
    const ry = clamp(Math.round(alarY), 3, H - 4);
    const x = clamp(Math.round(alarBaseCenter + dir * off), 4, W - 5);
    const grooveLum = boxMean(satL, W, H, x, ry, 1, 2);
    const cheekOut  = boxMean(satL, W, H, clamp(x + dir * Math.max(2, Math.round(pxPerCm * 0.28)), 2, W - 3), ry, 2, 2);
    const lobeIn    = boxMean(satL, W, H, clamp(x - dir * Math.max(2, Math.round(pxPerCm * 0.24)), 2, W - 3), ry, 1, 2);
    const cmDist    = off / (pxPerCm * foreshorten);
    const prior     = Math.exp(-0.5 * (((cmDist - 1.50) / 0.36) ** 2));
    return ((cheekOut - grooveLum) * 1.35 + (lobeIn - grooveLum) * 0.90) * prior;
  };

  let alarLeftX, alarRightX;
  if (Math.abs(estYawDeg) <= 16.0) {
    const fL = 1.0 - 0.34 * Math.max(0, -Math.sin(estYawRad));
    const fR = 1.0 - 0.34 * Math.max(0,  Math.sin(estYawRad));
    let bestHalfCm = 1.50;
    let bestPairAlar = -1e9;
    for (let cm = 1.12; cm <= 2.02; cm += 0.04) {
      const scL = evalAlarGrooveAt(-1, cm * pxPerCm * fL, fL);
      const scR = evalAlarGrooveAt(+1, cm * pxPerCm * fR, fR);
      const pairSc = scL + scR - 0.20 * Math.abs(scL - scR);
      if (pairSc > bestPairAlar) {
        bestPairAlar = pairSc;
        bestHalfCm = cm;
      }
    }
    const refineSideAlar = (dir, fSide) => {
      let bestX = alarBaseCenter + dir * bestHalfCm * pxPerCm * fSide;
      let bestSc = -1e9;
      for (let dCm = -0.10; dCm <= 0.101; dCm += 0.025) {
        const off = (bestHalfCm + dCm) * pxPerCm * fSide;
        const sc = evalAlarGrooveAt(dir, off, fSide);
        if (sc > bestSc) {
          bestSc = sc;
          bestX = alarBaseCenter + dir * off;
        }
      }
      return bestX;
    };
    alarLeftX  = refineSideAlar(-1, fL);
    alarRightX = refineSideAlar(+1, fR);
  } else {
    const findTurnedAlarSide = (dir) => {
      const foreshorten = dir < 0
        ? 1.0 - 0.36 * Math.max(0, -Math.sin(estYawRad))
        : 1.0 - 0.36 * Math.max(0,  Math.sin(estYawRad));
      let nostOff = Math.round(pxPerCm * 0.80 * foreshorten);
      let darkestNost = 1e9;
      const nMin = Math.max(2, Math.round(pxPerCm * 0.45 * foreshorten));
      const nMax = Math.max(nMin + 2, Math.round(pxPerCm * 1.25 * foreshorten));
      for (let off = nMin; off <= nMax; off++) {
        const nx = clamp(Math.round(alarBaseCenter + dir * off), 4, W - 5);
        const nLum = boxMean(satL, W, H, nx, nostRow, 1, 1);
        if (nLum < darkestNost) {
          darkestNost = nLum;
          nostOff = off;
        }
      }
      const minOff = Math.max(nostOff + Math.max(2, Math.round(pxPerCm * 0.28 * foreshorten)), Math.round(pxPerCm * 1.12 * foreshorten));
      const maxOff = Math.max(minOff + 3, Math.round(pxPerCm * 2.08 * foreshorten));
      let bestX = alarBaseCenter + dir * pxPerCm * 1.50 * foreshorten;
      let bestScore = -1e9;
      for (let off = minOff; off <= maxOff; off++) {
        const sc = evalAlarGrooveAt(dir, off, foreshorten);
        if (sc > bestScore) {
          bestScore = sc;
          bestX = alarBaseCenter + dir * off;
        }
      }
      return bestX;
    };
    alarLeftX  = findTurnedAlarSide(-1);
    alarRightX = findTurnedAlarSide(+1);
  }

  // Measure Nasal Bridge Width & Tip Bulbosity on frontal/near-frontal views!
  const measureDorsumHalfWidthCm = (cy, centerX, minCm, maxCm, priorCm) => {
    const ry = clamp(Math.round(cy), 3, H - 4);
    const cx = clamp(Math.round(centerX), 4, W - 5);
    const centerLum = boxMean(satL, W, H, cx, ry, 1, 2);
    let bestOff = priorCm * pxPerCm;
    let bestDrop = -1e9;
    const o0 = Math.max(2, Math.round(minCm * pxPerCm));
    const o1 = Math.max(o0 + 2, Math.round(maxCm * pxPerCm));
    for (let off = o0; off <= o1; off++) {
      const lL = boxMean(satL, W, H, Math.max(2, cx - off), ry, 1, 2);
      const lR = boxMean(satL, W, H, Math.min(W - 3, cx + off), ry, 1, 2);
      const drop = centerLum - 0.5 * (lL + lR);
      // Slope of horizontal sidewall gradient
      const lLIn = boxMean(satL, W, H, Math.max(2, cx - off + 2), ry, 1, 2);
      const lRIn = boxMean(satL, W, H, Math.min(W - 3, cx + off - 2), ry, 1, 2);
      const grad = 0.5 * ((lLIn - lL) + (lRIn - lR));
      const prior = Math.exp(-0.5 * (((off / pxPerCm - priorCm) / 0.35) ** 2));
      const sc = (grad * 1.6 + drop * 0.55) * prior;
      if (sc > bestDrop) {
        bestDrop = sc;
        bestOff = off;
      }
    }
    return bestOff / pxPerCm;
  };

  const bridgeHalfWidthCm = Math.abs(estYawDeg) < 20
    ? measureDorsumHalfWidthCm(rhinionY, rhinionX, 0.36, 1.05, 0.58)
    : 0.58;
  const tipHalfWidthCm = Math.abs(estYawDeg) < 20
    ? measureDorsumHalfWidthCm(noseTipY, noseTipX, 0.48, 1.30, 0.78)
    : 0.78;

  // 8. Precision Lip, Laughing/Smiling Open-Mouth, Teeth/Cavity & Commissure Detector!
  const mouthPredX = eyeMidX + yawMouthShiftX;
  const mouthHalfEst = Math.max(5, pxPerCm * 2.55 * Math.cos(estYawRad * 0.48));

  // Sample subject's clean left/right cheek skin baseline (RGB, Lum, Lip-chroma) for skin-vs-oral & skin-vs-background contrast!
  const sampleCheekPatch = (cx, cy) => {
    const rx = Math.max(2, Math.round(pxPerCm * 0.45));
    const ry = Math.max(2, Math.round(pxPerCm * 0.45));
    let rS = 0, gS = 0, bS = 0, lS = 0, lipS = 0, n = 0;
    for (let dy = -ry; dy <= ry; dy++) {
      const yy = clamp(Math.round(cy + dy), 1, H - 2);
      for (let dx = -rx; dx <= rx; dx++) {
        const xx = clamp(Math.round(cx + dx), 1, W - 2);
        const idx = yy * W + xx;
        rS += Rch[idx]; gS += Gch[idx]; bS += Bch[idx];
        lS += L[idx]; lipS += Lip[idx]; n++;
      }
    }
    return {
      r: rS / Math.max(1, n),
      g: gS / Math.max(1, n),
      b: bS / Math.max(1, n),
      lum: lS / Math.max(1, n),
      lip: lipS / Math.max(1, n),
    };
  };
  const cheekPatchL = sampleCheekPatch(eyeMidX - pxPerCm * 2.75 * Math.max(0.45, 1.0 + 0.45 * Math.sin(estYawRad)), subnasaleY - pxPerCm * 0.25);
  const cheekPatchR = sampleCheekPatch(eyeMidX + pxPerCm * 2.75 * Math.max(0.45, 1.0 - 0.45 * Math.sin(estYawRad)), subnasaleY - pxPerCm * 0.25);
  const cheekBaseLum = 0.5 * (cheekPatchL.lum + cheekPatchR.lum);
  const cheekBaseLip = 0.5 * (cheekPatchL.lip + cheekPatchR.lip);
  const cheekBaseRB  = 0.5 * ((cheekPatchL.r - cheekPatchL.b) + (cheekPatchR.r - cheekPatchR.b));

  // Sample clean lower-chin / mentolabial skin baseline as well so philtrum highlights or blush NEVER skew lip chroma!
  const chinSkinRefPatch = sampleCheekPatch(
    mouthPredX,
    clamp(subnasaleY + pxPerCm * 3.95, 6, Math.min(yMaxSkin - 2, H - 6))
  );
  const baseOralSkinLip = Math.min(cheekBaseLip, 0.55 * cheekBaseLip + 0.45 * chinSkinRefPatch.lip);

  // Build 1D vertical oral profile below subnasale (`vermilion redness`, `green-dip lip pigment`, `white/ivory teeth`, `dark oral slit`)!
  const scanTopY = clamp(Math.round(subnasaleY + pxPerCm * 0.42), 4, H - 8);
  const scanBotY = clamp(Math.round(subnasaleY + pxPerCm * 5.15), scanTopY + 6, H - 5);
  const oralStripHalfX = Math.max(3, Math.round(pxPerCm * 1.12 * Math.cos(estYawRad * 0.4)));

  // Refine horizontal mouth center X from lip redness + oral symmetry
  let maxLipX = mouthPredX;
  let bestLipVal = -1e9;
  const roughMidY = clamp(Math.round(subnasaleY + pxPerCm * 2.10), scanTopY, scanBotY);
  for (let dx = -Math.round(pxPerCm * 0.65); dx <= Math.round(pxPerCm * 0.65); dx++) {
    const tx = clamp(Math.round(mouthPredX + dx), 4, W - 5);
    const v = boxMean(satLip, W, H, tx, roughMidY, Math.round(mouthHalfEst * 0.48), Math.max(2, Math.round(pxPerCm * 0.85)));
    if (v > bestLipVal) {
      bestLipVal = v;
      maxLipX = tx;
    }
  }
  const mouthCenterX = Math.abs(estYawDeg) < 12
    ? (0.62 * (0.5 * mouthPredX + 0.5 * noseTipX) + 0.38 * maxLipX)
    : (0.55 * mouthPredX + 0.45 * maxLipX);

  const rowLipRaw = new Float32Array(H);
  const rowLipExc = new Float32Array(H);
  const rowTeeth  = new Float32Array(H);
  const rowCavity = new Float32Array(H);
  const rowLum    = new Float32Array(H);
  for (let y = Math.max(2, scanTopY - 3); y <= Math.min(H - 3, scanBotY + 4); y++) {
    let lSum = 0, lipRawS = 0, lipSum = 0, tSum = 0, cSum = 0, cnt = 0;
    for (let dx = -oralStripHalfX; dx <= oralStripHalfX; dx++) {
      const xx = clamp(Math.round(mouthCenterX + dx), 1, W - 2);
      const idx = y * W + xx;
      const lum = L[idx];
      const rb = Rch[idx] - Bch[idx];
      const lipV = Lip[idx];
      const lipExc = Math.max(0.0, lipV - baseOralSkinLip * 0.96);
      // White/ivory enamel teeth: bright luminance AND distinctly less orange/red than facial skin (`rb < cheekBaseRB * 0.72`)!
      const isTooth = smoothstep(cheekBaseLum * 0.76, cheekBaseLum * 1.02, lum) *
                      (1.0 - smoothstep(Math.max(10.0, cheekBaseRB * 0.50), Math.max(18.0, cheekBaseRB * 0.80), rb));
      // True deep open oral interior: strictly near-black shadow (`lum < min(32, cheekBaseLum * 0.29)`) — NEVER pigmented closed lips!
      const isCav = smoothstep(Math.min(32.0, cheekBaseLum * 0.29), Math.min(17.0, cheekBaseLum * 0.16), lum);
      lSum += lum;
      lipRawS += lipV;
      lipSum += lipExc;
      tSum += isTooth;
      cSum += isCav;
      cnt++;
    }
    const inv = 1.0 / Math.max(1, cnt);
    rowLum[y]    = lSum * inv;
    rowLipRaw[y] = lipRawS * inv;
    rowLipExc[y] = lipSum * inv;
    rowTeeth[y]  = tSum * inv;
    rowCavity[y] = cSum * inv;
  }

  // Measure peak vermilion chrominance excess across the oral band (`0.90..3.75 cm` below subnasale)
  let peakLipExc = 0.0;
  let yAtPeakLip = Math.round(subnasaleY + pxPerCm * 1.95);
  const pk0 = clamp(Math.round(subnasaleY + pxPerCm * 0.90), scanTopY, scanBotY - 3);
  const pk1 = clamp(Math.round(subnasaleY + pxPerCm * 3.75), pk0 + 2, scanBotY - 2);
  for (let y = pk0; y <= pk1; y++) {
    if (rowLipExc[y] > peakLipExc) {
      peakLipExc = rowLipExc[y];
      yAtPeakLip = y;
    }
  }

  // Detect if bright white enamel teeth appear in the oral zone (`Sofia` laughing/smiling):
  // Upper vermilion border MUST lie ABOVE the top of any visible upper teeth row!
  let firstTeethY = -1;
  let globalMaxTeeth = 0.0;
  for (let y = pk0; y <= pk1; y++) {
    if (rowTeeth[y] > globalMaxTeeth) globalMaxTeeth = rowTeeth[y];
    if (firstTeethY < 0 && rowTeeth[y] > 0.28) firstTeethY = y;
  }

  // Step 8A: Upper Vermilion Peak (`0.78..2.22 cm` below subnasale, and strictly ABOVE `firstTeethY` when teeth show!)
  let upperLipTopY = Math.round(subnasaleY + pxPerCm * 1.38);
  let bestUpBorder = -1e9;
  const upY0 = clamp(Math.round(subnasaleY + pxPerCm * 0.78), scanTopY, scanBotY - 6);
  const maxUpAllowed = firstTeethY > 0
    ? Math.max(upY0 + 1, Math.round(firstTeethY - pxPerCm * 0.24))
    : Math.round(subnasaleY + pxPerCm * 2.22);
  const upY1 = clamp(maxUpAllowed, upY0 + 1, scanBotY - 5);
  for (let y = upY0; y <= upY1; y++) {
    const lipBelowMean = 0.5 * (rowLipExc[y + 1] + rowLipExc[Math.min(H - 3, y + 2)]);
    const lipAboveMean = 0.5 * (rowLipExc[y - 1] + rowLipExc[y - 2]);
    const lipRise = lipBelowMean - lipAboveMean;
    const lumDrop = 0.5 * (rowLum[y - 1] + rowLum[y - 2]) - 0.5 * (rowLum[y + 1] + rowLum[y + 2]);
    const notTeethYet = 1.0 - 0.90 * rowTeeth[y];
    const vermGate = (peakLipExc > 11.0 && firstTeethY < 0)
      ? (0.25 + 0.75 * smoothstep(peakLipExc * 0.14, peakLipExc * 0.38, lipBelowMean))
      : 1.0;
    const priorCenterCm = firstTeethY > 0 ? Math.min(1.36, ((firstTeethY - subnasaleY) / pxPerCm) - 0.42) : 1.40;
    const distSubCm = (y - subnasaleY) / pxPerCm;
    const prior = Math.exp(-0.5 * (((distSubCm - priorCenterCm) / 0.44) ** 2));
    const sc = (lipRise * 2.45 + lumDrop * 0.72 + lipBelowMean * 0.52) * notTeethYet * vermGate * prior;
    if (sc > bestUpBorder) {
      bestUpBorder = sc;
      upperLipTopY = y;
    }
  }

  // Step 8B: Two-Lobe / Anti-Stomion-Lock Lower Vermilion Bottom Border FIRST (`upperLipTopY + 0.82..3.15 cm`)!
  // CRITICAL INSIGHT: On parted lips (`image-15.png`, `qa_custom_portrait.jpg`), the dark parting slit / shadowed teeth
  // sits ABOVE a lush second vermilion lobe (`maxBelowLipExc ~ peakLipExc`), whereas the TRUE bottom of the lower lip
  // transitions into clean mentolabial/chin skin with ZERO vermilion lobe below it!
  const loSpanMin = clamp(Math.round(upperLipTopY + pxPerCm * 0.80), upY0 + 3, scanBotY - 3);
  const loSpanMax = clamp(Math.round(upperLipTopY + pxPerCm * 3.15), loSpanMin + 2, scanBotY - 2);
  const lipStripHalfX = Math.max(2, Math.round(pxPerCm * 0.68));

  // Precompute max vermilion excess in the `[+0.12 cm .. +0.78 cm]` window BELOW any candidate `y`:
  // If `maxVermBelow > 0.38 * peakLipExc`, then `y` is INSIDE the mouth / at the parted teeth slit — NEVER the lower lip bottom!
  let lowerLipBottomY = Math.round(upperLipTopY + pxPerCm * 1.25);
  let bestLoBorder = -1e9;
  const lookAhead0 = Math.max(2, Math.round(pxPerCm * 0.14));
  const lookAhead1 = Math.max(lookAhead0 + 2, Math.round(pxPerCm * 0.82));

  for (let y = loSpanMin; y <= loSpanMax; y++) {
    let maxVermBelow = 0.0;
    let sumSkinBelowLip = 0.0, cntBelow = 0;
    for (let dy = lookAhead0; dy <= lookAhead1; dy++) {
      const yy = Math.min(H - 3, y + dy);
      if (rowLipExc[yy] > maxVermBelow) maxVermBelow = rowLipExc[yy];
      sumSkinBelowLip += rowLipExc[yy];
      cntBelow++;
    }
    const meanVermBelow = sumSkinBelowLip / Math.max(1, cntBelow);

    const lipAboveChr  = boxMean(satLip, W, H, mouthCenterX, Math.max(2, y - 2), lipStripHalfX, 1);
    const chinBelowChr = boxMean(satLip, W, H, mouthCenterX, Math.min(H - 3, y + 3), lipStripHalfX, 1);
    const gyVal        = boxMean(satAbsGy, W, H, mouthCenterX, y, lipStripHalfX, 1);
    const lipAboveLum  = boxMean(satL, W, H, mouthCenterX, Math.max(2, y - 2), lipStripHalfX, 1);
    const shadowAtY    = boxMean(satL, W, H, mouthCenterX, Math.min(H - 3, y + 1), lipStripHalfX, 1);
    const chinBelowLum = boxMean(satL, W, H, mouthCenterX, Math.min(H - 3, y + Math.max(2, Math.round(pxPerCm * 0.30))), lipStripHalfX, 1);

    // Anti-stomion guard: heavily suppress any row that still has a vermilion lower-lip lobe underneath it!
    const noLipBelowGuard = peakLipExc > 7.5
      ? (1.0 - 0.92 * smoothstep(peakLipExc * 0.28, peakLipExc * 0.52, maxVermBelow)) *
        (1.0 - 0.65 * smoothstep(peakLipExc * 0.18, peakLipExc * 0.38, meanVermBelow))
      : 1.0;
    // Also require actual vermilion pigment or lower-lip cushion immediately above `y` (`y - 1..3`)!
    const localLipAbove = 0.5 * (rowLipExc[Math.max(2, y - 1)] + rowLipExc[Math.max(2, y - 2)]);
    const hasLipAboveGuard = peakLipExc > 8.5
      ? (0.25 + 0.75 * smoothstep(peakLipExc * 0.18, peakLipExc * 0.45, localLipAbove))
      : 1.0;

    // Mentolabial transition cue: shadow shelf right under fuller lower lip OR bright lit chin skin emerging below darker coral lip!
    const lumTransition = Math.max(0.0, lipAboveLum - shadowAtY) * 0.76 +
                          (peakLipExc > 11.5 ? Math.max(0.0, chinBelowLum - lipAboveLum) * 0.42 : 0.0);
    const totalMouthCm = (y - upperLipTopY) / pxPerCm;
    // Adaptive mouth-height prior: ~1.06 cm for closed un-lipsticked mouths (`Elena`, `Marcus`), wider `1.45..1.85 cm` when teeth or vivid vermilion lobes exist!
    const hasOpenOrVivid = globalMaxTeeth > 0.24 || peakLipExc > 11.5;
    const priorMeanCm  = globalMaxTeeth > 0.28 ? 1.85 : (hasOpenOrVivid ? 1.38 : 1.06);
    const priorSigmaCm = globalMaxTeeth > 0.28 ? 0.68 : (hasOpenOrVivid ? 0.58 : 0.34);
    const spanPrior = Math.exp(-0.5 * (((totalMouthCm - priorMeanCm) / priorSigmaCm) ** 2));

    const edge = ((lipAboveChr - chinBelowChr) * 1.95 + gyVal * 0.55 + lumTransition) *
                 noLipBelowGuard * hasLipAboveGuard * spanPrior;
    if (edge > bestLoBorder) {
      bestLoBorder = edge;
      lowerLipBottomY = y;
    }
  }

  // Step 8C: Detect Open Laugh, Softly Parted Slit (`1-4mm` teeth/cleft dip between vermilion lobes), or Closed Stomion
  //          STRICTLY bracketed inside `[upperLipTopY + 0.28 cm .. lowerLipBottomY - 0.30 cm]`!
  const apSearch0 = clamp(Math.round(upperLipTopY + pxPerCm * 0.28), upY0 + 1, lowerLipBottomY - 2);
  const apSearch1 = clamp(Math.round(lowerLipBottomY - pxPerCm * 0.28), apSearch0 + 1, scanBotY - 2);

  // Measure upper-lobe & lower-lobe reference vermilion/luminance to spot parted-lip chroma/luminance valleys!
  let upLobeLip = 0.0, loLobeLip = 0.0, upLobeLum = cheekBaseLum * 0.7, loLobeLum = cheekBaseLum * 0.7;
  const midBracketY = 0.5 * (upperLipTopY + lowerLipBottomY);
  for (let y = upperLipTopY + 1; y <= Math.floor(midBracketY); y++) {
    if (rowLipRaw[y] > upLobeLip) { upLobeLip = rowLipRaw[y]; upLobeLum = rowLum[y]; }
  }
  for (let y = Math.ceil(midBracketY); y <= lowerLipBottomY - 1; y++) {
    if (rowLipRaw[y] > loLobeLip) { loLobeLip = rowLipRaw[y]; loLobeLum = rowLum[y]; }
  }
  const refLobeLip = Math.min(upLobeLip, loLobeLip);
  const refLobeLum = 0.5 * (upLobeLum + loLobeLum);

  let maxApertureSignal = 0.0;
  let maxTeethRow = 0.0;
  const apProfile = new Float32Array(H);
  for (let y = apSearch0; y <= apSearch1; y++) {
    // Parted-lip teeth/cleft dip: strong drop in lip redness (`refLobeLip - rowLipRaw[y]`) between TWO vivid red lip cushions!
    const bothLobesVivid = (upLobeLip - baseOralSkinLip) > 13.5 && (loLobeLip - baseOralSkinLip) > 13.5;
    const vermSandwichDip = (peakLipExc > 12.0 && bothLobesVivid)
      ? smoothstep(12.0, 26.0, refLobeLip - rowLipRaw[y]) * smoothstep(refLobeLum * 0.95, refLobeLum * 0.70, rowLum[y])
      : 0.0;
    const sig = rowTeeth[y] * 1.35 + rowCavity[y] * 1.15 + vermSandwichDip * 0.95;
    apProfile[y] = sig;
    if (sig > maxApertureSignal) maxApertureSignal = sig;
    if (rowTeeth[y] > maxTeethRow) maxTeethRow = rowTeeth[y];
  }

  let upperLipInnerY = 0.52 * upperLipTopY + 0.48 * lowerLipBottomY;
  let lowerLipInnerY = upperLipInnerY + pxPerCm * 0.05;

  if (maxApertureSignal > 0.36 && (maxTeethRow > 0.20 || maxApertureSignal > 0.54)) {
    const thresh = Math.max(0.26, maxApertureSignal * 0.46);
    let bestRunStart = -1, bestRunEnd = -1, curStart = -1;
    for (let y = apSearch0; y <= apSearch1; y++) {
      if (apProfile[y] >= thresh) {
        if (curStart < 0) curStart = y;
        if (bestRunStart < 0 || (y - curStart) > (bestRunEnd - bestRunStart)) {
          bestRunStart = curStart;
          bestRunEnd = y;
        }
      } else {
        curStart = -1;
      }
    }
    const spanCm = bestRunStart >= 0 ? (bestRunEnd - bestRunStart + 1) / pxPerCm : 0.0;
    if (spanCm >= 0.14) {
      upperLipInnerY = clamp(bestRunStart - 0.4, upperLipTopY + pxPerCm * 0.26, lowerLipBottomY - pxPerCm * 0.30);
      lowerLipInnerY = clamp(Math.max(upperLipInnerY + pxPerCm * 0.10, bestRunEnd + 0.4), upperLipTopY + pxPerCm * 0.34, lowerLipBottomY - pxPerCm * 0.26);
    }
  }

  if (lowerLipInnerY - upperLipInnerY < pxPerCm * 0.09) {
    // Closed or nearly-closed mouth — locate dark stomion parting crease strictly inside the central [30%..68%] of `[upperLipTopY..lowerLipBottomY]`!
    const mouthSpanPx = Math.max(pxPerCm * 0.72, lowerLipBottomY - upperLipTopY);
    const st0 = clamp(Math.round(upperLipTopY + mouthSpanPx * 0.30), apSearch0, apSearch1);
    const st1 = clamp(Math.round(upperLipTopY + mouthSpanPx * 0.68), st0 + 1, apSearch1);
    let bestStomY = Math.round(upperLipTopY + mouthSpanPx * 0.47);
    let bestStomSc = -1e9;
    for (let y = st0; y <= st1; y++) {
      const darkCrease = 0.5 * (rowLum[Math.max(2, y - 2)] + rowLum[Math.min(H - 3, y + 2)]) - rowLum[y] +
                         0.32 * (rowLipExc[Math.max(2, y - 2)] + rowLipExc[Math.min(H - 3, y + 2)]);
      const frac = (y - upperLipTopY) / mouthSpanPx;
      const prior = Math.exp(-0.5 * (((frac - 0.47) / 0.16) ** 2));
      if (darkCrease * prior > bestStomSc) {
        bestStomSc = darkCrease * prior;
        bestStomY = y;
      }
    }
    upperLipInnerY = bestStomY - pxPerCm * 0.025;
    lowerLipInnerY = bestStomY + pxPerCm * 0.025;
  }

  // Mustache-proof anatomical clamp: upper vermilion border lies `0.32..0.84 cm` above `upperLipInnerY`,
  // and lower vermilion border lies `0.34..1.02 cm` below `lowerLipInnerY`!
  upperLipTopY = clamp(upperLipTopY, Math.round(upperLipInnerY - pxPerCm * 0.84), Math.round(upperLipInnerY - pxPerCm * 0.32));
  lowerLipBottomY = clamp(lowerLipBottomY, Math.round(lowerLipInnerY + pxPerCm * 0.34), Math.round(lowerLipInnerY + pxPerCm * 1.02));

  const mouthCenterY = 0.5 * (upperLipInnerY + lowerLipInnerY);
  const mouthOpenCmEst = Math.max(0.0, (lowerLipInnerY - upperLipInnerY) / pxPerCm);

  // Step 8D: Laugh- & Smile-Capable Oral Commissure Corner Tracer (`dx ∈ [1.95..3.65 cm]`, `dy ∈ [-1.25..+0.50 cm]`)!
  const findMouthCorner = (dir) => {
    const foreshorten = dir < 0
      ? 1.0 - 0.36 * Math.max(0, -Math.sin(estYawRad))
      : 1.0 - 0.36 * Math.max(0,  Math.sin(estYawRad));
    const minDx = Math.max(5, Math.round(pxPerCm * 1.96 * foreshorten));
    const maxDx = Math.max(minDx + 3, Math.round(pxPerCm * (mouthOpenCmEst > 0.25 ? 3.58 : 3.05) * foreshorten));

    const cheekRefX = clamp(Math.round(mouthCenterX + dir * pxPerCm * 3.65 * foreshorten), 4, W - 5);
    const cheekLip  = boxMean(satLip, W, H, cheekRefX, Math.round(mouthCenterY), 3, 3);
    const centerLip = Math.max(
      boxMean(satLip, W, H, mouthCenterX, Math.round(upperLipTopY + pxPerCm * 0.22), 3, 1),
      boxMean(satLip, W, H, mouthCenterX, Math.round(lowerLipBottomY - pxPerCm * 0.22), 3, 1)
    );
    const hasRedContrast = (centerLip - cheekLip) > 4.2;
    const lipRange = Math.max(4.2, centerLip - cheekLip);

    const priorHalfW = mouthOpenCmEst > 0.25 ? 2.86 : 2.42;
    const priorSigmaW = mouthOpenCmEst > 0.25 ? 0.56 : 0.38;
    const priorLiftCm = mouthOpenCmEst > 0.25 ? -0.34 : -0.04; // upturned corners when smiling/laughing!

    let bestCornerX = mouthCenterX + dir * pxPerCm * priorHalfW * foreshorten;
    let bestCornerY = mouthCenterY + priorLiftCm * pxPerCm;
    let bestCornerSc = -1e9;

    const minDy = -Math.max(3, Math.round(pxPerCm * (mouthOpenCmEst > 0.20 ? 1.18 : 0.48)));
    const maxDy =  Math.max(2, Math.round(pxPerCm * 0.38));
    const vSpan =  Math.max(2, Math.round(pxPerCm * 0.28));

    for (let dx = minDx; dx <= maxDx; dx++) {
      const tx = clamp(Math.round(mouthCenterX + dir * dx), 4, W - 5);
      const distCm = dx / Math.max(1e-3, pxPerCm * foreshorten);
      const dPrior = Math.exp(-0.5 * (((distCm - priorHalfW) / priorSigmaW) ** 2));

      for (let dy = minDy; dy <= maxDy; dy++) {
        const ty = clamp(Math.round(mouthCenterY + dy), 4, H - 5);
        // Inside corner (`tx - dir*2`): dark commissure pocket / oral corner pinch!
        const cleftIn  = boxMean(satL, W, H, clamp(tx - dir * 2, 2, W - 3), ty, 1, 0);
        const aboveIn  = boxMean(satL, W, H, clamp(tx - dir * 2, 2, W - 3), clamp(ty - vSpan, 2, H - 3), 1, 1);
        const belowIn  = boxMean(satL, W, H, clamp(tx - dir * 2, 2, W - 3), clamp(ty + vSpan, 2, H - 3), 1, 1);
        const pinchIn  = Math.max(0.0, 0.5 * (aboveIn + belowIn) - cleftIn);

        // Outside corner (`tx + dir*3`): oral cleft terminates into clean cheek skin (NOT dark cavity)!
        const skinOut  = boxMean(satL, W, H, clamp(tx + dir * 3, 2, W - 3), ty, 2, 1);
        const stillDarkOut = Math.max(0.0, cheekBaseLum * 0.68 - skinOut); // penalize stopping INSIDE an open dark smile!
        const lipIn    = boxMean(satLip, W, H, clamp(tx - dir * 3, 2, W - 3), ty, 2, 2);
        const lipOut   = boxMean(satLip, W, H, clamp(tx + dir * 3, 2, W - 3), ty, 2, 2);

        const lumTerm  = Math.max(0.0, skinOut - cleftIn) - stillDarkOut * 1.65;
        const chrTerm  = hasRedContrast ? (Math.max(0.0, lipIn - lipOut) / lipRange) * 14.0 : lumTerm * 0.45;
        const dyCm     = dy / pxPerCm;
        const yPrior   = Math.exp(-0.5 * (((dyCm - priorLiftCm) / (mouthOpenCmEst > 0.20 ? 0.46 : 0.24)) ** 2));

        const sc = (pinchIn * 1.35 + lumTerm * 1.15 + chrTerm * 0.95) * dPrior * yPrior;
        if (sc > bestCornerSc) {
          bestCornerSc = sc;
          bestCornerX = tx;
          bestCornerY = ty;
        }
      }
    }
    return { x: bestCornerX, y: bestCornerY };
  };

  let mCornerL = findMouthCorner(-1);
  let mCornerR = findMouthCorner(+1);
  // Bilateral sanity harmonization on frontal views (`|estYawDeg| < 12°`) so unilateral shadow/stubble never collapses one mouth corner!
  if (Math.abs(estYawDeg) < 12) {
    const dL = mouthCenterX - mCornerL.x;
    const dR = mCornerR.x - mouthCenterX;
    const meanD = 0.5 * (dL + dR);
    if (Math.abs(dL - dR) > pxPerCm * 0.15) {
      mCornerL.x = mouthCenterX - (0.38 * dL + 0.62 * meanD);
      mCornerR.x = mouthCenterX + (0.38 * dR + 0.62 * meanD);
    }
    const meanY = 0.5 * (mCornerL.y + mCornerR.y);
    mCornerL.y = 0.45 * mCornerL.y + 0.55 * meanY;
    mCornerR.y = 0.45 * mCornerR.y + 0.55 * meanY;
  }

  // 9. Localize True Chin Tip (Menton) — detects BOTH step-edge AND dark submental shadow valley right under the chin!
  //    Anchored below `lowerLipBottomY` using IPD-calibrated cm scale so lit necks or mentolabial shadows NEVER stop high!
  const chinPredX = (Math.abs(estYawDeg) < 12 ? 0.55 * mouthCenterX + 0.45 * eyeMidX : eyeMidX) + yawChinShiftX;
  const chinScale = 0.88 * pxPerCmIpdInit + 0.12 * pxPerCm;
  const chinY0 = clamp(Math.round(lowerLipBottomY + chinScale * 2.15), 5, Math.min(yMaxSkin, H - 6));
  const chinY1 = clamp(Math.round(lowerLipBottomY + chinScale * 4.25), chinY0 + 1, Math.min(yMaxSkin, H - 5));

  let bestChinY = clamp(Math.round(lowerLipBottomY + chinScale * 3.02), chinY0, chinY1);
  let bestChinScore = -1e9;
  const subOff = Math.max(2, Math.round(chinScale * 0.28));
  const neckOff = Math.max(subOff + 2, Math.round(chinScale * 0.95));
  for (let y = chinY0; y <= chinY1; y++) {
    const cx = clamp(Math.round(chinPredX), 4, W - 5);
    const spanX = Math.max(3, Math.round(chinScale * 1.15));
    const lumChinPad = boxMean(satL, W, H, cx, Math.max(2, y - subOff), spanX, 2);
    const lumCrease  = boxMean(satL, W, H, cx, Math.min(H - 3, y + Math.max(1, Math.round(subOff * 0.55))), spanX, 1);
    const lumNeckLo  = boxMean(satL, W, H, cx, Math.min(H - 2, y + neckOff), spanX, 2);
    const shadowStep = lumChinPad - lumCrease;
    // Submental valley cue: on studio-lit portraits (like `aria-front.jpg`), the neck below the submental shadow lights up again!
    const submentalValley = Math.max(0.0, lumNeckLo - lumCrease);
    const gyEdge = boxMean(satAbsGy, W, H, cx, y, spanX, 1);
    const yPrior = Math.exp(-0.5 * ((((y - lowerLipBottomY) / chinScale - 3.04) / 0.58) ** 2));
    const sc = (shadowStep * 1.38 + submentalValley * 0.85 + gyEdge * 0.46) * yPrior;
    if (sc > bestChinScore) {
      bestChinScore = sc;
      bestChinY = y;
    }
  }

  // 10. Cheek-Color-Guided True Cheekbone, Gonion Jawline & Chin Contour Tracer!
  // Uses the subject's OWN cheek RGB + diagonal submandibular shadow while REJECTING interior smile/marionette creases
  // (where pixels outside the crease still match the same bright cheek skin!).
  const traceCheekContourX = (dir, yRow, minCmFromCenter, maxCmFromCenter, priorCm, allowNeckShadow = false) => {
    const ry = clamp(Math.round(yRow), 2, H - 3);
    const rawBlobEdge = dir < 0 ? rowLeft[ry] : rowRight[ry];
    const sidePatch = dir < 0 ? cheekPatchL : cheekPatchR;
    const isFarSide = (dir < 0 && estYawDeg < -14) || (dir > 0 && estYawDeg > 14);
    const yawFactor = dir < 0
      ? 1.0 + 0.58 * Math.sin(estYawRad)
      : 1.0 - 0.58 * Math.sin(estYawRad);
    const effYawFactor = clamp(yawFactor, 0.32, 1.22);

    if (isFarSide && rawBlobEdge >= 0 && !allowNeckShadow) {
      return rawBlobEdge;
    }

    const minXDist = minCmFromCenter * pxPerCm * effYawFactor;
    const maxXDist = maxCmFromCenter * pxPerCm * effYawFactor;
    const refCenterX = allowNeckShadow
      ? (chinPredX * 0.65 + (eyeMidX + 0.35 * yawNoseShiftX) * 0.35)
      : (eyeMidX + 0.35 * yawNoseShiftX);

    let bestX = refCenterX + dir * priorCm * pxPerCm * effYawFactor;
    const upperLim = rawBlobEdge >= 0 ? Math.min(maxXDist, Math.abs(rawBlobEdge - refCenterX) + 3) : maxXDist;
    const lowerLim = Math.min(minXDist, upperLim);
    let bestEdgeScore = -1e9;
    for (let d = Math.round(lowerLim); d <= Math.round(upperLim); d++) {
      const tx = clamp(Math.round(refCenterX + dir * d), 4, W - 5);
      const inX  = clamp(tx - dir * 3, 2, W - 3);
      const outX = clamp(tx + dir * 4, 2, W - 3);
      const inY  = Math.max(2, ry - (allowNeckShadow ? 2 : 0));
      const outY = Math.min(H - 3, ry + (allowNeckShadow ? 2 : 0));

      const lumInside  = boxMean(satL, W, H, inX, inY, 2, 2);
      const lumOutside = boxMean(satL, W, H, outX, outY, 2, 2);
      const skinIn     = boxMean(satSkin, W, H, inX, ry, 1, 2);
      const skinOut    = boxMean(satSkin, W, H, outX, outY, 2, 2);

      // Measure RGB color departure from the subject's own cheek outside `tx` (detects hair, studio bg, OR shadowed neck!)
      const oIdx = outY * W + outX;
      const iIdx = inY * W + inX;
      const rgbDistOut = Math.hypot(Rch[oIdx] - sidePatch.r, Gch[oIdx] - sidePatch.g, Bch[oIdx] - sidePatch.b);
      const rgbDistIn  = Math.hypot(Rch[iIdx] - sidePatch.r, Gch[iIdx] - sidePatch.g, Bch[iIdx] - sidePatch.b);

      // CRITICAL ANTI-MARIONETTE GUARD: If pixels OUTSIDE `tx` are still bright, warm cheek skin (`lumOutside > sidePatch.lum * 0.88`
      // AND `rgbDistOut < 20` AND `skinOut > 0.72`), then `tx` is an INTERIOR cheek/smile fold — NOT the outer jawline!
      if (skinOut > 0.72 && lumOutside > sidePatch.lum * 0.88 && rgbDistOut < 20.0) continue;

      const skinDrop = Math.max(0.0, skinIn - skinOut);
      const lumStep  = lumInside - lumOutside;
      const colorStep = Math.max(0.0, rgbDistOut - rgbDistIn * 0.55);
      const insideIsSkin = clamp(1.25 - rgbDistIn / 68.0, 0.25, 1.0); // don't drift outside into dark hair!

      const priorSigma = allowNeckShadow ? 0.72 : 1.15;
      const prior = Math.exp(-0.5 * (((d / (pxPerCm * effYawFactor) - priorCm) / priorSigma) ** 2));
      const contrast = (lumStep * 1.25 + colorStep * 0.90 + (1.0 - skinOut) * 34.0 + skinDrop * 26.0) * insideIsSkin;
      const sc = contrast * prior;
      if (sc > bestEdgeScore) {
        bestEdgeScore = sc;
        bestX = tx;
      }
    }
    if (bestEdgeScore < -1e8 && rawBlobEdge >= 0) {
      const clampedDist = clamp(Math.abs(rawBlobEdge - refCenterX), lowerLim, maxXDist);
      bestX = Math.round(refCenterX + dir * clampedDist);
    }
    return bestX;
  };

  const yTemple   = clamp(eyeMidY - pxPerCm * 1.15, 2, H - 3);
  const yZygoma   = clamp(eyeMidY + pxPerCm * 0.42, 2, H - 3);
  const yUpCheek  = clamp(eyeMidY + pxPerCm * 1.85, 2, H - 3);
  const yMidCheek = clamp(subnasaleY + pxPerCm * 0.18, 2, H - 3);
  const yLoCheek  = clamp(0.5 * (subnasaleY + upperLipTopY) + pxPerCm * 0.35, 2, H - 3);
  const yJaw      = clamp(lowerLipInnerY + pxPerCm * 0.22, 2, H - 3);
  const yMandible = clamp(0.54 * lowerLipBottomY + 0.46 * bestChinY, 2, H - 3);
  const yChinSide = clamp(0.20 * lowerLipBottomY + 0.80 * bestChinY, 2, H - 3);

  // True Farkas Anthropometric Half-Width Bounds (captures slender oval jaws AND strong broad masculine/laughing jaws!)
  const templeLX   = traceCheekContourX(-1, yTemple,   4.9, 6.85, 5.98, false);
  const templeRX   = traceCheekContourX(+1, yTemple,   4.9, 6.85, 5.98, false);
  const cheekLX    = traceCheekContourX(-1, yZygoma,   5.3, 7.15, 6.36, false);
  const cheekRX    = traceCheekContourX(+1, yZygoma,   5.3, 7.15, 6.36, false);
  const upCheekLX  = traceCheekContourX(-1, yUpCheek,  5.1, 6.95, 6.12, false);
  const upCheekRX  = traceCheekContourX(+1, yUpCheek,  5.1, 6.95, 6.12, false);
  const midCheekLX = traceCheekContourX(-1, yMidCheek, 4.8, 6.65, 5.82, false);
  const midCheekRX = traceCheekContourX(+1, yMidCheek, 4.8, 6.65, 5.82, false);
  const loCheekLX  = traceCheekContourX(-1, yLoCheek,  4.5, 6.35, 5.52, false);
  const loCheekRX  = traceCheekContourX(+1, yLoCheek,  4.5, 6.35, 5.52, false);
  const jawLX      = traceCheekContourX(-1, yJaw,      4.2, 6.12, 5.22, true);
  const jawRX      = traceCheekContourX(+1, yJaw,      4.2, 6.12, 5.22, true);
  const mandibleLX = traceCheekContourX(-1, yMandible, 3.4, 5.18, 4.32, true);
  const mandibleRX = traceCheekContourX(+1, yMandible, 3.4, 5.18, 4.32, true);
  const chinLX     = traceCheekContourX(-1, yChinSide, 2.1, 3.60, 2.86, true);
  const chinRX     = traceCheekContourX(+1, yChinSide, 2.1, 3.60, 2.86, true);

  // Smooth & enforce anatomical convexity along the 8 lateral contour stations (temple -> chinSide)
  const smoothContourSide = (xs, dir) => {
    const out = xs.slice();
    for (let pass = 0; pass < 2; pass++) {
      for (let i = 1; i < out.length - 1; i++) {
        const med = 0.5 * (out[i - 1] + out[i + 1]);
        if (dir * (med - out[i]) > pxPerCm * 0.10) {
          out[i] = 0.80 * med + 0.20 * out[i];
        } else {
          out[i] = 0.22 * out[i - 1] + 0.56 * out[i] + 0.22 * out[i + 1];
        }
      }
    }
    for (let i = 2; i < out.length; i++) {
      if (dir < 0 && out[i] < out[i - 1]) out[i] = out[i - 1];
      if (dir > 0 && out[i] > out[i - 1]) out[i] = out[i - 1];
    }
    return out;
  };

  const smoothL = smoothContourSide([templeLX, cheekLX, upCheekLX, midCheekLX, loCheekLX, jawLX, mandibleLX, chinLX], -1);
  const smoothR = smoothContourSide([templeRX, cheekRX, upCheekRX, midCheekRX, loCheekRX, jawRX, mandibleRX, chinRX], +1);

  // Bilateral frontal jaw symmetry stabilization: if hair drapes over one cheek on a frontal portrait (`|yaw| < 12°`),
  // harmonize left/right half-widths around the true facial midline so side-part hair NEVER pinches one side inward!
  if (Math.abs(estYawDeg) < 12) {
    for (let i = 0; i < smoothL.length; i++) {
      const refC = i >= 5 ? (chinPredX * 0.65 + noseTipX * 0.35) : (0.55 * eyeMidX + 0.45 * noseTipX);
      const wL = refC - smoothL[i];
      const wR = smoothR[i] - refC;
      const symW = Math.abs(wL - wR) > pxPerCm * 0.36
        ? (0.76 * Math.max(wL, wR) + 0.24 * Math.min(wL, wR))
        : (0.5 * (wL + wR));
      smoothL[i] = refC - (0.48 * wL + 0.52 * symW);
      smoothR[i] = refC + (0.48 * wR + 0.52 * symW);
    }
  }
  const [sTempleLX, sCheekLX, sUpCheekLX, sMidCheekLX, sLoCheekLX, sJawLX, sMandibleLX, sChinLX] = smoothL;
  const [sTempleRX, sCheekRX, sUpCheekRX, sMidCheekRX, sLoCheekRX, sJawRX, sMandibleRX, sChinRX] = smoothR;

  // =========================================================================
  // 11. FULL-RESOLUTION (srcW x srcH) 79-POINT DENSE ANATOMICAL CURVE TRACERS
  //     Locks down exact eyelids, canthal tilt, iris radii, 5-pt eyebrow arches,
  //     5-pt hairline arch, 12-pt nose/nostrils, 15-pt outer+inner lips & ears!
  // =========================================================================
  const invScale = 1.0 / work.scale;
  const fullPxPerCm = pxPerCm * invScale;

  const sampleFullLum = (fx, fy, rx = 1, ry = 1) => {
    const cx = clamp(Math.round(fx), 0, srcW - 1);
    const cy = clamp(Math.round(fy), 0, srcH - 1);
    let s = 0, n = 0;
    for (let dy = -ry; dy <= ry; dy++) {
      const yy = clamp(cy + dy, 0, srcH - 1);
      for (let dx = -rx; dx <= rx; dx++) {
        const xx = clamp(cx + dx, 0, srcW - 1);
        const o = (yy * srcW + xx) * 4;
        s += 0.299 * data[o] + 0.587 * data[o + 1] + 0.114 * data[o + 2];
        n++;
      }
    }
    return s / Math.max(1, n);
  };

  const sampleFullLipChr = (fx, fy, rx = 2, ry = 1) => {
    const cx = clamp(Math.round(fx), 0, srcW - 1);
    const cy = clamp(Math.round(fy), 0, srcH - 1);
    let s = 0, n = 0;
    for (let dy = -ry; dy <= ry; dy++) {
      const yy = clamp(cy + dy, 0, srcH - 1);
      for (let dx = -rx; dx <= rx; dx++) {
        const xx = clamp(cx + dx, 0, srcW - 1);
        const o = (yy * srcW + xx) * 4;
        const r = data[o], g = data[o + 1], b = data[o + 2];
        const cb = 128.0 - 0.168736 * r - 0.331264 * g + 0.5 * b;
        const cr = 128.0 + 0.5 * r - 0.418688 * g - 0.081312 * b;
        s += (cr - 128.0) - 0.65 * (cb - 128.0) + 0.25 * (r - g);
        n++;
      }
    }
    return s / Math.max(1, n);
  };

  // A. Precision High-Res Eye Palpebral Fissure & Limbus Tracer (9 points per eye!)
  const traceDenseEye = (eyeSeed, sideSign) => {
    // sideSign: -1 for subject's right eye (image-left), +1 for subject's left eye (image-right)
    const foreshorten = sideSign < 0
      ? clamp(1.0 + 0.42 * Math.sin(estYawRad), 0.52, 1.15)
      : clamp(1.0 - 0.42 * Math.sin(estYawRad), 0.52, 1.15);

    let cx = eyeSeed.x * invScale;
    let cy = eyeSeed.y * invScale;
    const rLimbus = Math.max(4, Math.round(fullPxPerCm * 0.48));

    // Circular-disc + sclera-flank full-res iris refinement (prevents medial tear-trough shadow from pulling iris cross-eyed!)
    const localSkinLum = sampleFullLum(cx, cy + fullPxPerCm * 1.15, 4, 3);
    const searchR = Math.max(2, Math.round(fullPxPerCm * 0.22));
    const stepPx = Math.max(1, Math.round(fullPxPerCm * 0.05));
    let bestIx = cx, bestIy = cy, bestDiscSc = -1e9;
    const rProbe = Math.max(2, Math.round(fullPxPerCm * 0.28));
    const flankPx = Math.max(rProbe + 2, Math.round(fullPxPerCm * 0.68 * foreshorten));
    for (let oy = -searchR; oy <= searchR; oy += stepPx) {
      for (let ox = -searchR; ox <= searchR; ox += stepPx) {
        const tx = cx + ox, ty = cy + oy;
        const discL = sampleFullLum(tx, ty, rProbe, rProbe);
        const sclL  = sampleFullLum(tx - flankPx, ty, 2, 1);
        const sclR  = sampleFullLum(tx + flankPx, ty, 2, 1);
        const prior = Math.exp(-0.5 * ((ox * ox + oy * oy) / Math.max(4.0, (fullPxPerCm * 0.18) ** 2)));
        const sc = (0.5 * (sclL + sclR) - discL - 0.30 * Math.abs(sclL - sclR)) * prior;
        if (sc > bestDiscSc) {
          bestDiscSc = sc;
          bestIx = tx;
          bestIy = ty;
        }
      }
    }
    let sumW = 0, wx = 0, wy = 0;
    for (let dy = -rLimbus; dy <= rLimbus; dy++) {
      for (let dx = -rLimbus; dx <= rLimbus; dx++) {
        if (dx * dx + dy * dy > rLimbus * rLimbus) continue;
        const lum = sampleFullLum(bestIx + dx, bestIy + dy, 0, 0);
        if (lum > localSkinLum * 0.90) continue;
        const w = Math.pow(Math.max(0, localSkinLum * 0.92 - lum), 1.25);
        sumW += w; wx += w * (bestIx + dx); wy += w * (bestIy + dy);
      }
    }
    if (sumW > 1e-2) {
      cx = 0.55 * bestIx + 0.45 * (wx / sumW);
      cy = 0.55 * bestIy + 0.45 * (wy / sumW);
    }

    // Medial (toward nose: -sideSign) & Lateral (toward temple: +sideSign) Canthi
    const findCanthus = (dirToCorner, priorHalfWCm) => {
      const fShort = dirToCorner * sideSign > 0 ? foreshorten : clamp(2.0 - foreshorten, 0.65, 1.15);
      const minD = Math.max(4, Math.round(fullPxPerCm * 0.92 * fShort));
      const maxD = Math.max(minD + 3, Math.round(fullPxPerCm * 1.78 * fShort));
      let bestX = cx + dirToCorner * fullPxPerCm * priorHalfWCm * fShort;
      let bestY = cy;
      let bestScore = -1e9;

      for (let d = minD; d <= maxD; d++) {
        const tx = clamp(cx + dirToCorner * d, 4, srcW - 5);
        // Search vertical corner position within +-0.20 cm of iris center (prevents upward-flicked outer eyeshadow wings from skewing canthal tilt!)
        const isLateral = dirToCorner * sideSign > 0;
        const maxDy = Math.max(2, Math.round(fullPxPerCm * 0.20));
        const priorDyCm = isLateral ? -0.04 : 0.03;
        for (let dy = -maxDy; dy <= maxDy; dy++) {
          const ty = clamp(cy + dy, 4, srcH - 5);
          const cleftLum = sampleFullLum(tx - dirToCorner * 2, ty, 1, 0);
          const skinOut  = sampleFullLum(tx + dirToCorner * 4, ty, 2, 1);
          const lidAbove = sampleFullLum(tx, ty - Math.max(2, Math.round(fullPxPerCm * 0.22)), 1, 1);
          const lidBelow = sampleFullLum(tx, ty + Math.max(2, Math.round(fullPxPerCm * 0.20)), 1, 1);
          // Require genuine lower-lid bright skin directly below the canthus (rejects winged eyeliner floating above the outer corner!)
          const lowerSupport = Math.max(0.0, lidBelow - cleftLum);
          const pinch = 0.45 * (lidAbove - cleftLum) + 0.55 * lowerSupport;
          const stepOut = skinOut - cleftLum;
          const dPrior = Math.exp(-0.5 * (((d / (fullPxPerCm * fShort) - priorHalfWCm) / 0.26) ** 2));
          const yPrior = Math.exp(-0.5 * ((((dy / fullPxPerCm) - priorDyCm) / 0.13) ** 2));
          const sc = (pinch * 1.25 + stepOut * 1.10) * dPrior * yPrior;
          if (sc > bestScore) {
            bestScore = sc;
            bestX = tx;
            bestY = ty;
          }
        }
      }
      return [bestX, bestY];
    };

    const innerPt = findCanthus(-sideSign, 1.36);
    const outerPt = findCanthus(+sideSign, 1.44);

    // Trace Upper & Lower Eyelid Margins at u = 0.28, 0.50, 0.72 between innerPt and outerPt
    const traceLidAtU = (uFrac, isUpper) => {
      const bx = innerPt[0] + (outerPt[0] - innerPt[0]) * uFrac;
      const chordY = innerPt[1] + (outerPt[1] - innerPt[1]) * uFrac;
      const archPriorCm = Math.sin(uFrac * Math.PI) * (isUpper ? 0.44 : 0.34);

      const dMin = Math.max(1, Math.round(fullPxPerCm * 0.16));
      const dMax = Math.max(dMin + 2, Math.round(fullPxPerCm * (isUpper ? 0.76 : 0.62)));
      let bestY = chordY + (isUpper ? -1 : 1) * archPriorCm * fullPxPerCm;
      let bestSc = -1e9;

      for (let d = dMin; d <= dMax; d++) {
        const ty = isUpper ? chordY - d : chordY + d;
        if (ty < 4 || ty >= srcH - 4) continue;
        if (isUpper) {
          // Upper lash line: dark lash/ciliary band with brighter upper tarsal skin above!
          const lashLum = sampleFullLum(bx, ty, 2, 0);
          const skinAbove = sampleFullLum(bx, ty - Math.max(2, Math.round(fullPxPerCm * 0.24)), 2, 1);
          const eyeBelow  = sampleFullLum(bx, ty + 2, 2, 0);
          const prior = Math.exp(-0.5 * (((d / fullPxPerCm - archPriorCm) / 0.18) ** 2));
          const sc = ((skinAbove - lashLum) * 1.45 + Math.abs(eyeBelow - lashLum) * 0.45 - lashLum * 0.25) * prior;
          if (sc > bestSc) {
            bestSc = sc;
            bestY = ty;
          }
        } else {
          // Lower lid margin: transition from darker iris/sclera cleft above to warm bright lower-lid skin below!
          const insideEye = sampleFullLum(bx, ty - 2, 2, 0);
          const lowerSkin = sampleFullLum(bx, ty + Math.max(2, Math.round(fullPxPerCm * 0.22)), 2, 1);
          const prior = Math.exp(-0.5 * (((d / fullPxPerCm - archPriorCm) / 0.16) ** 2));
          const sc = ((lowerSkin - insideEye) * 1.25 + lowerSkin * 0.20) * prior;
          if (sc > bestSc) {
            bestSc = sc;
            bestY = ty;
          }
        }
      }
      return [bx, bestY];
    };

    const upIn  = traceLidAtU(0.27, true);
    const upMid = traceLidAtU(0.50, true);
    const upOut = traceLidAtU(0.73, true);
    const loIn  = traceLidAtU(0.27, false);
    const loMid = traceLidAtU(0.50, false);
    const loOut = traceLidAtU(0.73, false);

    return {
      iris: [cx, cy],
      inner: innerPt,
      outer: outerPt,
      upIn, upMid, upOut,
      loIn, loMid, loOut,
      openCm: Math.max(0.45, (loMid[1] - upMid[1]) / fullPxPerCm),
      widthCm: Math.hypot(outerPt[0] - innerPt[0], outerPt[1] - innerPt[1]) / Math.max(1e-3, fullPxPerCm * foreshorten),
      tiltCm: (innerPt[1] - outerPt[1]) / fullPxPerCm, // + = outer corner higher than inner corner
    };
  };

  const denseEyeL = traceDenseEye(eyeL, -1);
  const denseEyeR = traceDenseEye(eyeR, +1);
  // Bilateral palpebral opening & iris-centering harmonization on frontal views (`|yaw| < 12°`)
  // so unilateral eyebrow/tear-trough shadow NEVER causes one droopy or misaligned eye!
  if (Math.abs(estYawDeg) < 12) {
    const meanOpen = 0.5 * (denseEyeL.openCm + denseEyeR.openCm) * fullPxPerCm;
    const harmonizeEyeVert = (dE) => {
      const curOpen = Math.max(2.0, dE.loMid[1] - dE.upMid[1]);
      const targetOpen = 0.65 * curOpen + 0.35 * meanOpen;
      const scaleV = clamp(targetOpen / curOpen, 0.84, 1.18);
      const midY = 0.5 * (dE.upMid[1] + dE.loMid[1]);
      for (const k of ['upIn', 'upMid', 'upOut', 'loIn', 'loMid', 'loOut']) {
        dE[k][1] = midY + (dE[k][1] - midY) * scaleV;
      }
      // Keep iris centered horizontally within [0.43..0.57] of inner->outer palpebral span!
      const spanX = dE.outer[0] - dE.inner[0];
      if (Math.abs(spanX) > 4.0) {
        const uIris = clamp((dE.iris[0] - dE.inner[0]) / spanX, 0.43, 0.57);
        dE.iris[0] = dE.inner[0] + uIris * spanX;
      }
      dE.iris[1] = clamp(dE.iris[1], midY - targetOpen * 0.16, midY + targetOpen * 0.16);
      dE.openCm = Math.max(0.45, (dE.loMid[1] - dE.upMid[1]) / fullPxPerCm);
    };
    harmonizeEyeVert(denseEyeL);
    harmonizeEyeVert(denseEyeR);
  }

  // B. Full Closed 11-Point Upper+Center+Lower Eyebrow Contour Ring Tracer per Side (22 total)!
  //    Eyeshadow-immune + high/low arch adaptive (`0.85..2.75 cm` above eye) + active medial head & lateral tail extent tracing!
  const sampleFullRB = (fx, fy, rx = 2, ry = 1) => {
    const cx = clamp(Math.round(fx), 0, srcW - 1);
    const cy = clamp(Math.round(fy), 0, srcH - 1);
    let s = 0, n = 0;
    for (let dy = -ry; dy <= ry; dy++) {
      const yy = clamp(cy + dy, 0, srcH - 1);
      for (let dx = -rx; dx <= rx; dx++) {
        const xx = clamp(cx + dx, 0, srcW - 1);
        const o = (yy * srcW + xx) * 4;
        s += data[o] - data[o + 2];
        n++;
      }
    }
    return s / Math.max(1, n);
  };

  const traceDenseBrow = (dEye, sideSign) => {
    const eyeSpanRatio = clamp(Math.abs(dEye.outer[0] - dEye.inner[0]) / Math.max(1e-3, fullPxPerCm * 2.55), 0.55, 1.18);
    const eyeBaseY = 0.5 * (dEye.inner[1] + dEye.outer[1]);
    const sideSkinRB = Math.max(12.0, sideSign < 0 ? (cheekPatchL.r - cheekPatchL.b) : (cheekPatchR.r - cheekPatchR.b));
    const sideSkinLum = Math.max(45.0, sideSign < 0 ? cheekPatchL.lum : cheekPatchR.lum);

    const anchorX = clamp(0.55 * dEye.inner[0] + 0.45 * dEye.outer[0], 6, srcW - 7);
    const hlFloorY = yHairline * invScale + fullPxPerCm * 0.72;
    const ancYMin = Math.max(6, Math.round(Math.max(hlFloorY, eyeBaseY - fullPxPerCm * 2.75)));
    const ancYMax = Math.max(ancYMin + 3, Math.round(Math.min(dEye.upMid[1] - fullPxPerCm * 0.36, eyeBaseY - fullPxPerCm * 0.82)));

    let anchorBrowY = clamp(eyeBaseY - fullPxPerCm * 1.45, ancYMin, ancYMax);
    let bestAnchorSc = -1e9;
    for (let ty = ancYMin; ty <= ancYMax; ty++) {
      const bLum      = sampleFullLum(anchorX, ty, 4, 1);
      const fhAbove   = sampleFullLum(anchorX, Math.max(3, ty - Math.round(fullPxPerCm * 0.58)), 4, 2);
      const boneBelow = sampleFullLum(anchorX, Math.min(srcH - 4, ty + Math.round(fullPxPerCm * 0.46)), 4, 2);
      const bRB       = sampleFullRB(anchorX, ty, 3, 1);
      const hairCoolBonus = 1.0 + 0.36 * clamp(1.0 - (bRB / Math.max(25.0, bLum)) / (sideSkinRB / sideSkinLum), -0.3, 0.9);
      const distCm = (eyeBaseY - ty) / fullPxPerCm;
      const hPrior = Math.exp(-0.5 * (((distCm - 1.56) / 0.72) ** 2));
      const darkness = Math.max(0.0, sideSkinLum * 0.92 - bLum);
      const sc = ((fhAbove - bLum) * 1.35 + (boneBelow - bLum) * 0.92 + darkness * 0.42) * hairCoolBonus * hPrior;
      if (sc > bestAnchorSc) {
        bestAnchorSc = sc;
        anchorBrowY = ty;
      }
    }
    const anchorHeightCm = (eyeBaseY - anchorBrowY) / fullPxPerCm;
    const anchorDarkness = Math.max(10.0, sampleFullLum(anchorX, Math.max(3, anchorBrowY - fullPxPerCm * 0.60), 4, 2) - sampleFullLum(anchorX, anchorBrowY, 4, 1));

    const templeLimX = sideSign < 0
      ? Math.max(6, (sTempleLX * invScale) + fullPxPerCm * 0.32)
      : Math.min(srcW - 7, (sTempleRX * invScale) - fullPxPerCm * 0.32);

    let innerX = dEye.inner[0] - sideSign * fullPxPerCm * 0.36 * eyeSpanRatio;
    for (let dCm = 0.16; dCm <= 0.68; dCm += 0.08) {
      const tx = dEye.inner[0] - sideSign * fullPxPerCm * dCm * eyeSpanRatio;
      const ty = anchorBrowY + fullPxPerCm * 0.14;
      const fhL = sampleFullLum(tx, Math.max(3, ty - fullPxPerCm * 0.56), 2, 2);
      const brL = Math.min(
        sampleFullLum(tx, ty - fullPxPerCm * 0.12, 2, 1),
        sampleFullLum(tx, ty, 2, 1),
        sampleFullLum(tx, ty + fullPxPerCm * 0.14, 2, 1)
      );
      if (fhL - brL >= anchorDarkness * 0.30) {
        innerX = tx;
      } else if (dCm > 0.32) {
        break;
      }
    }

    let outerX = dEye.outer[0] + sideSign * fullPxPerCm * 0.72 * eyeSpanRatio;
    let curTailY = anchorBrowY - fullPxPerCm * 0.04;
    for (let dCm = 0.36; dCm <= 1.05; dCm += 0.09) {
      const tx = dEye.outer[0] + sideSign * fullPxPerCm * dCm * eyeSpanRatio;
      if ((sideSign < 0 && tx < templeLimX) || (sideSign > 0 && tx > templeLimX)) break;
      let bestTailY = curTailY + fullPxPerCm * 0.08;
      let bestTailContrast = -1e9;
      // Lateral brow tail past the arch (`u > 0.6`) always tapers horizontally or downward (`offCm >= 0.0`), never upward into temple hair!
      for (let offCm = 0.00; offCm <= 0.26; offCm += 0.06) {
        const ty = clamp(curTailY + offCm * fullPxPerCm, ancYMin, eyeBaseY - fullPxPerCm * 0.38);
        const fhL = sampleFullLum(tx, Math.max(3, ty - fullPxPerCm * 0.52), 2, 1);
        const dnL = sampleFullLum(tx, Math.min(srcH - 4, ty + fullPxPerCm * 0.42), 2, 1);
        const brL = sampleFullLum(tx, ty, 2, 1);
        const c = 0.55 * (fhL - brL) + 0.45 * (dnL - brL);
        if (c > bestTailContrast) {
          bestTailContrast = c;
          bestTailY = ty;
        }
      }
      const outsideTempleSkin = sampleFullLum(tx + sideSign * fullPxPerCm * 0.26, bestTailY + fullPxPerCm * 0.18, 2, 2);
      if (bestTailContrast >= Math.max(6.5, anchorDarkness * 0.24) && outsideTempleSkin > sideSkinLum * 0.52) {
        outerX = tx;
        curTailY = bestTailY;
      } else if (dCm >= 0.72) {
        break;
      }
    }

    const uStations = [0.0, 0.26, 0.56, 0.80, 1.0];
    const evalArchShape = (u) =>
      (anchorHeightCm - 0.22) + 0.34 * Math.sin(Math.pow(u, 0.86) * Math.PI) - 0.18 * u * u;

    const centerYs = [];
    const halfThickPx = [];
    const xs = [];

    for (let si = 0; si < uStations.length; si++) {
      const u = uStations[si];
      const bx = clamp(innerX + (outerX - innerX) * u, 4, srcW - 5);
      xs.push(bx);

      const archShape = evalArchShape(u);
      const prevPredY = si > 0
        ? centerYs[si - 1] - (evalArchShape(u) - evalArchShape(uStations[si - 1])) * fullPxPerCm
        : eyeBaseY - fullPxPerCm * archShape;

      const lidFloorCm = u > 0.72 ? 0.44 : 0.72;
      const minClearAboveUpperLid = u > 0.76 ? (eyeBaseY - fullPxPerCm * 0.42) : (dEye.upMid[1] - fullPxPerCm * 0.32);
      const yMin = Math.max(6, Math.round(Math.max(hlFloorY, eyeBaseY - fullPxPerCm * 2.82)));
      const yMax = Math.max(yMin + 2, Math.min(Math.round(minClearAboveUpperLid), Math.round(eyeBaseY - fullPxPerCm * lidFloorCm)));

      let bestY = clamp(prevPredY, yMin, yMax);
      let bestDark = -1e9;
      for (let ty = yMin; ty <= yMax; ty++) {
        const bLum = sampleFullLum(bx, ty, 3, 1);
        const fhAbove = sampleFullLum(bx, Math.max(2, ty - Math.round(fullPxPerCm * 0.54)), 3, 2);
        const lidBelow = sampleFullLum(bx, Math.min(srcH - 3, ty + Math.round(fullPxPerCm * 0.42)), 3, 1);
        const bRB = sampleFullRB(bx, ty, 2, 1);
        const hairCool = 1.0 + 0.28 * clamp(1.0 - (bRB / Math.max(25.0, bLum)) / (sideSkinRB / sideSkinLum), -0.3, 0.9);
        const distCm = (eyeBaseY - ty) / fullPxPerCm;
        const prior = Math.exp(-0.5 * (((distCm - archShape) / 0.36) ** 2));
        const contPrior = si > 0 ? Math.exp(-0.5 * ((((ty - prevPredY) / fullPxPerCm) / 0.26) ** 2)) : 1.0;
        const sc = ((fhAbove - bLum) * 1.32 + (lidBelow - bLum) * 0.78) * hairCool * prior * contPrior;
        if (sc > bestDark) {
          bestDark = sc;
          bestY = ty;
        }
      }

      const refSkinAbove = sampleFullLum(bx, Math.max(2, bestY - Math.round(fullPxPerCm * 0.58)), 3, 2);
      const cWin = Math.max(2, Math.round(fullPxPerCm * 0.20));
      let wSum = 0.0, wySum = 0.0;
      for (let dy = -cWin; dy <= cWin; dy++) {
        const yy = clamp(bestY + dy, yMin, yMax);
        const l = sampleFullLum(bx, yy, 2, 0);
        const w = Math.max(0.0, refSkinAbove * 0.90 - l);
        wSum += w;
        wySum += w * yy;
      }
      if (wSum > 4.0) bestY = 0.45 * bestY + 0.55 * (wySum / wSum);
      centerYs.push(bestY);

      const baseHalfCm = 0.24 - 0.11 * Math.pow(u, 1.5);
      const centerLum = sampleFullLum(bx, bestY, 2, 0);
      const skinAbove = sampleFullLum(bx, Math.max(2, bestY - Math.round(fullPxPerCm * 0.58)), 2, 1);
      const threshLum = centerLum + 0.54 * Math.max(8.0, skinAbove - centerLum);
      let hPx = Math.round(fullPxPerCm * baseHalfCm);
      const maxHPx = Math.max(2, Math.round(fullPxPerCm * (0.35 - 0.09 * u)));
      for (let dy = 2; dy <= maxHPx; dy++) {
        const lUp = sampleFullLum(bx, Math.max(2, bestY - dy), 2, 0);
        const lDn = sampleFullLum(bx, Math.min(srcH - 3, bestY + dy), 2, 0);
        if (0.5 * (lUp + lDn) < threshLum) hPx = dy;
        else break;
      }
      halfThickPx.push(clamp(hPx, Math.max(2, Math.round(fullPxPerCm * 0.12)), maxHPx));
    }

    // Enforce natural arch convexity: lateral tail (`u=0.80, 1.00`) never curls upward above the arch peak (`u=0.56`) into temple hair!
    if (centerYs[3] < centerYs[2] - fullPxPerCm * 0.03) centerYs[3] = centerYs[2] + fullPxPerCm * 0.02;
    if (centerYs[4] < Math.max(centerYs[2], centerYs[3]) + fullPxPerCm * 0.03) {
      centerYs[4] = Math.max(centerYs[2], centerYs[3]) + fullPxPerCm * 0.10;
    }

    for (let pass = 0; pass < 2; pass++) {
      for (let i = 1; i <= 3; i++) {
        centerYs[i] = 0.22 * centerYs[i - 1] + 0.56 * centerYs[i] + 0.22 * centerYs[i + 1];
      }
    }

    const chordMidY = 0.5 * (centerYs[0] + centerYs[4]);
    return {
      center: xs.map((x, i) => [x, centerYs[i]]),
      upper:  [1, 2, 3].map((i) => [xs[i], centerYs[i] - halfThickPx[i]]),
      lower:  [1, 2, 3].map((i) => [xs[i], centerYs[i] + halfThickPx[i]]),
      halfThickPx,
      heightCm: (eyeBaseY - centerYs[2]) / fullPxPerCm,
      archCm:   (chordMidY - centerYs[2]) / fullPxPerCm,
      tiltCm:   (centerYs[0] - centerYs[4]) / fullPxPerCm,
    };
  };

  const denseBrowL = traceDenseBrow(denseEyeL, -1);
  const denseBrowR = traceDenseBrow(denseEyeR, +1);
  if (Math.abs(estYawDeg) < 12) {
    const outSpanL = Math.max(0, -(denseBrowL.center[4][0] - denseEyeL.outer[0]));
    const outSpanR = Math.max(0,  (denseBrowR.center[4][0] - denseEyeR.outer[0]));
    if (Math.abs(outSpanL - outSpanR) > fullPxPerCm * 0.22) {
      const targetOut = 0.72 * Math.max(outSpanL, outSpanR) + 0.28 * Math.min(outSpanL, outSpanR);
      const adjustBrowSpan = (dE, dB, sgn) => {
        const innerX = dB.center[0][0];
        const newOuterX = dE.outer[0] + sgn * (0.40 * Math.max(0, sgn * (dB.center[4][0] - dE.outer[0])) + 0.60 * targetOut);
        const uSt = [0.0, 0.26, 0.56, 0.80, 1.0];
        for (let i = 0; i < 5; i++) dB.center[i][0] = innerX + (newOuterX - innerX) * uSt[i];
        for (let k = 0; k < 3; k++) {
          dB.upper[k][0] = dB.center[k + 1][0];
          dB.lower[k][0] = dB.center[k + 1][0];
        }
      };
      adjustBrowSpan(denseEyeL, denseBrowL, -1);
      adjustBrowSpan(denseEyeR, denseBrowR, +1);
    }
    for (let i = 0; i < 5; i++) {
      const hL = denseEyeL.iris[1] - denseBrowL.center[i][1];
      const hR = denseEyeR.iris[1] - denseBrowR.center[i][1];
      if (Math.abs(hL - hR) > fullPxPerCm * 0.24) {
        const hMean = 0.5 * (hL + hR);
        denseBrowL.center[i][1] = denseEyeL.iris[1] - (0.45 * hL + 0.55 * hMean);
        denseBrowR.center[i][1] = denseEyeR.iris[1] - (0.45 * hR + 0.55 * hMean);
      }
    }
    for (let k = 0; k < 3; k++) {
      denseBrowL.upper[k][1] = denseBrowL.center[k + 1][1] - denseBrowL.halfThickPx[k + 1];
      denseBrowL.lower[k][1] = denseBrowL.center[k + 1][1] + denseBrowL.halfThickPx[k + 1];
      denseBrowR.upper[k][1] = denseBrowR.center[k + 1][1] - denseBrowR.halfThickPx[k + 1];
      denseBrowR.lower[k][1] = denseBrowR.center[k + 1][1] + denseBrowR.halfThickPx[k + 1];
    }
    denseBrowL.heightCm = (0.5 * (denseEyeL.inner[1] + denseEyeL.outer[1]) - denseBrowL.center[2][1]) / fullPxPerCm;
    denseBrowR.heightCm = (0.5 * (denseEyeR.inner[1] + denseEyeR.outer[1]) - denseBrowR.center[2][1]) / fullPxPerCm;
  }

  // C. 5-Point Forehead Hairline Arch Tracer
  const traceHairlineAtX = (fx, dropCmPrior) => {
    const wx = clamp(fx * work.scale, 3, W - 4);
    const yStart = clamp(Math.round(eyeMidY - pxPerCm * 2.4), 4, H - 5);
    const yTop   = 3;
    const baseSkinL = boxMean(satL, W, H, wx, yStart, 3, 3);
    let bestWY = yHairline + dropCmPrior * pxPerCm;
    let bestStep = -1e9;
    for (let wy = yStart; wy >= yTop; wy--) {
      const belowL = boxMean(satL, W, H, wx, Math.min(H - 3, wy + 3), 2, 2);
      const aboveL = boxMean(satL, W, H, wx, Math.max(2, wy - 3), 2, 2);
      const skinUp = boxMean(satSkin, W, H, wx, Math.max(2, wy - 3), 2, 2);
      const prior = Math.exp(-0.5 * ((((wy - (yHairline + dropCmPrior * pxPerCm)) / pxPerCm) / 1.15) ** 2));
      const step = ((belowL - aboveL) * 1.1 + (1.0 - skinUp) * 32.0 - Math.abs(belowL - baseSkinL) * 0.25) * prior;
      if (step > bestStep) {
        bestStep = step;
        bestWY = wy;
      }
    }
    return [fx, bestWY * invScale];
  };

  const hairlineX = eyeMidX - 0.35 * yawNoseShiftX;
  const fhCenterX = hairlineX * invScale;
  const hlLeftArch    = traceHairlineAtX(fhCenterX - fullPxPerCm * 2.25, 0.22);
  const hlRightArch   = traceHairlineAtX(fhCenterX + fullPxPerCm * 2.25, 0.22);
  const hlLeftTemple  = traceHairlineAtX(fhCenterX - fullPxPerCm * 4.25, 1.35);
  const hlRightTemple = traceHairlineAtX(fhCenterX + fullPxPerCm * 4.25, 1.35);

  // D. Dense 15-Point Outer + Inner Lip Vermilion Contour Tracer (supports BOTH closed AND open laughing/smiling mouths!)
  const fMouthL  = [mCornerL.x * invScale, mCornerL.y * invScale];
  const fMouthR  = [mCornerR.x * invScale, mCornerR.y * invScale];
  const fMouthCX = mouthCenterX * invScale;
  const fMouthCY = mouthCenterY * invScale;
  const fUpTopY  = upperLipTopY * invScale;
  const fUpInY   = upperLipInnerY * invScale;
  const fLoInY   = lowerLipInnerY * invScale;
  const fLoBotY  = lowerLipBottomY * invScale;

  const traceLipStation = (uFromCenter, sideSign) => {
    const corner = sideSign < 0 ? fMouthL : fMouthR;
    const sx = fMouthCX + (corner[0] - fMouthCX) * uFromCenter;
    const env = Math.pow(Math.max(0, 1.0 - uFromCenter * uFromCenter), 0.72);
    const openEnv = Math.pow(Math.max(0, 1.0 - uFromCenter * uFromCenter), 0.68);
    const chordMidY = fMouthCY + (corner[1] - fMouthCY) * Math.pow(uFromCenter, 1.75);

    const halfOpenAtU = 0.5 * Math.max(0, fLoInY - fUpInY) * openEnv;
    let stomY = chordMidY;
    if (halfOpenAtU < fullPxPerCm * 0.08) {
      // Closed mouth: refine subtle dark stomion line
      let darkestStom = 1e9;
      const sRange = Math.max(2, Math.round(fullPxPerCm * 0.14));
      for (let dy = -sRange; dy <= sRange; dy++) {
        const lum = sampleFullLum(sx, chordMidY + dy, 2, 0);
        if (lum < darkestStom) {
          darkestStom = lum;
          stomY = chordMidY + dy;
        }
      }
    }

    const upInnerAtU = stomY - halfOpenAtU;
    const loInnerAtU = stomY + halfOpenAtU;
    const cupidsLift = uFromCenter < 0.42 ? fullPxPerCm * 0.08 * Math.sin((uFromCenter / 0.42) * Math.PI) : 0;
    const upThickCenter = Math.max(fullPxPerCm * 0.24, fUpInY - fUpTopY);
    const loThickCenter = Math.max(fullPxPerCm * 0.28, fLoBotY - fLoInY);
    const upEstY = upInnerAtU - Math.max(2, upThickCenter * env + cupidsLift);
    const loEstY = loInnerAtU + Math.max(2, loThickCenter * env);

    // Refine upper & lower outer vermilion borders via chroma + luminance edge, guarding against stopping inside a parted slit!
    let bestUpY = upEstY, bestUpSc = -1e9;
    const rSearchUp = Math.max(2, Math.round(fullPxPerCm * 0.18));
    for (let dy = -rSearchUp; dy <= rSearchUp; dy++) {
      const ty = upEstY + dy;
      const chrIn  = sampleFullLipChr(sx, ty + 2, 2, 1);
      const chrOut = sampleFullLipChr(sx, ty - 2, 2, 1);
      const lumOut = sampleFullLum(sx, ty - 2, 2, 1);
      const lumIn  = sampleFullLum(sx, ty + 2, 2, 1);
      const sc = (chrIn - chrOut) * 1.65 + (lumOut - lumIn) * 0.55 - Math.abs(dy) * 0.36;
      if (sc > bestUpSc) { bestUpSc = sc; bestUpY = ty; }
    }

    const rSearchLo = Math.max(3, Math.round(fullPxPerCm * 0.22));
    const skinChinChr = sampleFullLipChr(sx, loEstY + fullPxPerCm * 0.55, 3, 2);
    let bestLoY = loEstY, bestLoSc = -1e9;
    for (let dy = -rSearchLo; dy <= rSearchLo; dy++) {
      const ty = loEstY + dy;
      const chrIn   = sampleFullLipChr(sx, ty - 2, 2, 1);
      const chrOut  = sampleFullLipChr(sx, ty + 3, 2, 1);
      const chrDeep = sampleFullLipChr(sx, ty + Math.round(fullPxPerCm * 0.22), 2, 1);
      const lumIn   = sampleFullLum(sx, ty - 2, 2, 1);
      const lumOut  = sampleFullLum(sx, ty + 3, 2, 1);
      // Penalize if strong vermilion still continues below `ty + 0.22 cm`!
      const stillLipBelow = Math.max(0.0, chrDeep - (skinChinChr + 6.5));
      const sc = (chrIn - chrOut) * 1.70 + Math.abs(lumOut - lumIn) * 0.35 - stillLipBelow * 1.45 - Math.abs(dy) * 0.32;
      if (sc > bestLoSc) { bestLoSc = sc; bestLoY = ty; }
    }

    return { sx, stomY, upY: bestUpY, loY: bestLoY };
  };

  const lipCupidL = traceLipStation(0.24, -1);
  const lipCupidR = traceLipStation(0.24, +1);
  const lipMidL   = traceLipStation(0.58, -1);
  const lipMidR   = traceLipStation(0.58, +1);

  // E. Visible Outer Ear Prominence Tracer
  const traceEarOuterX = (dir) => {
    const baseCheekX = (dir < 0 ? cheekLX : cheekRX);
    const ry = clamp(Math.round(0.5 * (eyeMidY + subnasaleY)), 3, H - 4);
    const blobEdge = dir < 0 ? rowLeft[ry] : rowRight[ry];
    if (blobEdge >= 0 && dir * (blobEdge - baseCheekX) > pxPerCm * 0.18 && dir * (blobEdge - baseCheekX) < pxPerCm * 1.45) {
      return [blobEdge * invScale, ry * invScale];
    }
    return [(baseCheekX + dir * pxPerCm * 0.42) * invScale, ry * invScale];
  };
  const earLPt = traceEarOuterX(-1);
  const earRPt = traceEarOuterX(+1);

  // Sample authentic upper-eyelid skin RGB right above lash crease for realistic 3D Blink Shader!
  const sampleBoxRGB = (fx, fy, rad = 3) => {
    const cx = clamp(Math.round(fx), 0, srcW - 1);
    const cy = clamp(Math.round(fy), 0, srcH - 1);
    let r = 0, g = 0, b = 0, n = 0;
    for (let dy = -rad; dy <= rad; dy++) {
      const yy = clamp(cy + dy, 0, srcH - 1);
      for (let dx = -rad; dx <= rad; dx++) {
        const xx = clamp(cx + dx, 0, srcW - 1);
        const o = (yy * srcW + xx) * 4;
        r += data[o]; g += data[o + 1]; b += data[o + 2]; n++;
      }
    }
    return n ? [Math.round(r / n), Math.round(g / n), Math.round(b / n)] : [192, 152, 128];
  };
  const lidUpL = sampleBoxRGB(denseEyeL.upMid[0], denseEyeL.upMid[1] - fullPxPerCm * 0.50, 3);
  const lidUpR = sampleBoxRGB(denseEyeR.upMid[0], denseEyeR.upMid[1] - fullPxPerCm * 0.50, 3);
  const lidLoL = sampleBoxRGB(denseEyeL.loMid[0], denseEyeL.loMid[1] + fullPxPerCm * 0.44, 3);
  const lidLoR = sampleBoxRGB(denseEyeR.loMid[0], denseEyeR.loMid[1] + fullPxPerCm * 0.44, 3);
  const eyelidSkinRGB = [
    Math.round(0.22 * (lidUpL[0] + lidUpR[0]) + 0.28 * (lidLoL[0] + lidLoR[0])),
    Math.round(0.22 * (lidUpL[1] + lidUpR[1]) + 0.28 * (lidLoL[1] + lidLoR[1])),
    Math.round(0.22 * (lidUpL[2] + lidUpR[2]) + 0.28 * (lidLoL[2] + lidLoR[2])),
  ];

  const normWork = (x, y) => [clamp(x / W, 0.01, 0.99), clamp(y / H, 0.01, 0.99)];
  const normFull = (pt) => [clamp(pt[0] / srcW, 0.01, 0.99), clamp(pt[1] / srcH, 0.01, 0.99)];

  const glabellaPt  = [nasionX, nasionY - pxPerCm * 0.72];
  const supratipPt  = [0.35 * rhinionX + 0.65 * noseTipX, 0.35 * rhinionY + 0.65 * noseTipY];
  const alarCrestLPt = [alarLeftX + pxPerCm * 0.14, noseTipY - pxPerCm * 0.18];
  const alarCrestRPt = [alarRightX - pxPerCm * 0.14, noseTipY - pxPerCm * 0.18];
  const nostrilLPt   = [0.52 * noseTipX + 0.48 * alarLeftX, subnasaleY - pxPerCm * 0.14];
  const nostrilRPt   = [0.52 * noseTipX + 0.48 * alarRightX, subnasaleY - pxPerCm * 0.14];

  // Full-resolution (`srcW x srcH`) sub-pixel chin (`menton`), alar-wing & vermilion-border refinement before assembling `landmarks2D`!
  const fChinX = chinPredX * invScale;
  let fChinY = bestChinY * invScale;
  {
    const cSpanX = Math.max(4, Math.round(fullPxPerCm * 0.85));
    const cStep  = Math.max(2, Math.round(fullPxPerCm * 0.24));
    const cNeck  = Math.max(4, Math.round(fullPxPerCm * 0.95));
    const rScan  = Math.max(5, Math.round(fullPxPerCm * 0.68));
    let bestFullChinSc = -1e9;
    let refinedY = fChinY;
    for (let dy = -Math.round(rScan * 0.65); dy <= rScan; dy++) {
      const ty = clamp(fChinY + dy, 6, srcH - 8);
      const lumAbove  = sampleFullLum(fChinX, ty - cStep, cSpanX, 2);
      const lumAt     = sampleFullLum(fChinX, ty, cSpanX, 1);
      const lumCrease = sampleFullLum(fChinX, ty + Math.round(cStep * 0.75), cSpanX, 2);
      const lumNeck   = sampleFullLum(fChinX, Math.min(srcH - 4, ty + cNeck), cSpanX, 2);
      const valleyDepth = Math.max(0.0, lumNeck - lumCrease);
      // Favor the exact lower inflection border right above the submental shadow trough!
      const borderAlign = -0.35 * Math.abs(lumAt - (0.52 * lumAbove + 0.48 * lumCrease));
      const prior = Math.exp(-0.5 * ((dy / (fullPxPerCm * 0.62)) ** 2));
      const sc = ((lumAbove - lumCrease) * 1.38 + valleyDepth * 0.92 + borderAlign) * prior;
      if (sc > bestFullChinSc) {
        bestFullChinSc = sc;
        refinedY = ty;
      }
    }
    fChinY = refinedY;
  }

  // Full-resolution (`srcW x srcH`) Cupid's-bow `upperLipTop` & `lowerLipBottom` sub-pixel refinement!
  let fUpLipTopY = upperLipTopY * invScale;
  let fLoLipBotY = lowerLipBottomY * invScale;
  {
    const lipScan = Math.max(3, Math.round(fullPxPerCm * 0.24));
    const skinChinChrCenter = sampleFullLipChr(fMouthCX, fLoLipBotY + fullPxPerCm * 0.62, 4, 2);
    let bestUpSc = -1e9, bestLoSc = -1e9;
    for (let dy = -lipScan; dy <= lipScan; dy++) {
      const tyU = clamp(upperLipTopY * invScale + dy, 4, fMouthCY - 2);
      const chrInU  = sampleFullLipChr(fMouthCX, tyU + 2, 3, 1);
      const chrOutU = sampleFullLipChr(fMouthCX, tyU - 2, 3, 1);
      const lumOutU = sampleFullLum(fMouthCX, tyU - 2, 3, 1);
      const lumInU  = sampleFullLum(fMouthCX, tyU + 2, 3, 1);
      const scU = ((chrInU - chrOutU) * 1.45 + (lumOutU - lumInU) * 0.55) * Math.exp(-0.5 * ((dy / (fullPxPerCm * 0.18)) ** 2));
      if (scU > bestUpSc) { bestUpSc = scU; fUpLipTopY = tyU; }

      const tyL = clamp(lowerLipBottomY * invScale + dy, fMouthCY + 3, srcH - 6);
      const chrInL   = sampleFullLipChr(fMouthCX, tyL - 2, 3, 1);
      const chrOutL  = sampleFullLipChr(fMouthCX, tyL + 2, 3, 1);
      const chrDeepL = sampleFullLipChr(fMouthCX, tyL + Math.round(fullPxPerCm * 0.24), 3, 1);
      const lumInL   = sampleFullLum(fMouthCX, tyL - 2, 3, 1);
      const lumOutL  = sampleFullLum(fMouthCX, tyL + 3, 3, 1);
      const stillLipBelow = Math.max(0.0, chrDeepL - (skinChinChrCenter + 6.5));
      const scL = ((chrInL - chrOutL) * 1.55 + Math.abs(lumOutL - lumInL) * 0.45 - stillLipBelow * 1.55) *
                  Math.exp(-0.5 * ((dy / (fullPxPerCm * 0.22)) ** 2));
      if (scL > bestLoSc) { bestLoSc = scL; fLoLipBotY = tyL; }
    }
  }

  const chinWorkRefinedY = fChinY * work.scale;
  const yMandibleRefined = 0.54 * lowerLipBottomY + 0.46 * chinWorkRefinedY;
  const yChinSideRefined = 0.20 * lowerLipBottomY + 0.80 * chinWorkRefinedY;

  // Assemble all 91 Dense Anatomical Landmarks (preserving all core keys for 100% compatibility!)
  const landmarks2D = {
    // 1. Forehead Hairline Arch (5 pts)
    hairlineLeftTemple:  normFull(hlLeftTemple),
    hairlineLeftArch:    normFull(hlLeftArch),
    hairline:            normWork(hairlineX, yHairline),
    hairlineRightArch:   normFull(hlRightArch),
    hairlineRightTemple: normFull(hlRightTemple),

    // 2. Full Closed 8-Point Upper+Lower Eyebrow Contour Rings + Centerline (22 pts: 11 left + 11 right!)
    browLeftInner:       normFull(denseBrowL.center[0]),
    browLeftMidInner:    normFull(denseBrowL.center[1]),
    browLeft:            normFull(denseBrowL.center[2]),
    browLeftMidOuter:    normFull(denseBrowL.center[3]),
    browLeftOuter:       normFull(denseBrowL.center[4]),
    browLeftUpperInner:  normFull(denseBrowL.upper[0]),
    browLeftUpper:       normFull(denseBrowL.upper[1]),
    browLeftUpperOuter:  normFull(denseBrowL.upper[2]),
    browLeftLowerInner:  normFull(denseBrowL.lower[0]),
    browLeftLower:       normFull(denseBrowL.lower[1]),
    browLeftLowerOuter:  normFull(denseBrowL.lower[2]),

    browRightInner:      normFull(denseBrowR.center[0]),
    browRightMidInner:   normFull(denseBrowR.center[1]),
    browRight:           normFull(denseBrowR.center[2]),
    browRightMidOuter:   normFull(denseBrowR.center[3]),
    browRightOuter:      normFull(denseBrowR.center[4]),
    browRightUpperInner: normFull(denseBrowR.upper[0]),
    browRightUpper:      normFull(denseBrowR.upper[1]),
    browRightUpperOuter: normFull(denseBrowR.upper[2]),
    browRightLowerInner: normFull(denseBrowR.lower[0]),
    browRightLower:      normFull(denseBrowR.lower[1]),
    browRightLowerOuter: normFull(denseBrowR.lower[2]),

    // 3. Dense Palpebral Eye Contours + Iris Centers (18 pts: 9 left + 9 right)
    eyeLeft:             normFull(denseEyeL.iris),
    eyeLeftInner:        normFull(denseEyeL.inner),
    eyeLeftUpperInner:   normFull(denseEyeL.upIn),
    eyeLeftUpper:        normFull(denseEyeL.upMid),
    eyeLeftUpperOuter:   normFull(denseEyeL.upOut),
    eyeLeftOuter:        normFull(denseEyeL.outer),
    eyeLeftLowerOuter:   normFull(denseEyeL.loOut),
    eyeLeftLower:        normFull(denseEyeL.loMid),
    eyeLeftLowerInner:   normFull(denseEyeL.loIn),

    eyeRight:            normFull(denseEyeR.iris),
    eyeRightInner:       normFull(denseEyeR.inner),
    eyeRightUpperInner:  normFull(denseEyeR.upIn),
    eyeRightUpper:       normFull(denseEyeR.upMid),
    eyeRightUpperOuter:  normFull(denseEyeR.upOut),
    eyeRightOuter:       normFull(denseEyeR.outer),
    eyeRightLowerOuter:  normFull(denseEyeR.loOut),
    eyeRightLower:       normFull(denseEyeR.loMid),
    eyeRightLowerInner:  normFull(denseEyeR.loIn),

    // 4. Dense Nasal Pyramid, Tip, Alar Crests & Nostrils (12 pts)
    glabella:            normWork(glabellaPt[0], glabellaPt[1]),
    nasion:              normWork(nasionX, nasionY),
    rhinion:             normWork(rhinionX, rhinionY),
    supratip:            normWork(supratipPt[0], supratipPt[1]),
    noseTip:             normWork(noseTipX, noseTipY),
    subnasale:           normWork(0.5 * (noseTipX + mouthCenterX), subnasaleY),
    alarCrestLeft:       normWork(alarCrestLPt[0], alarCrestLPt[1]),
    alarLeft:            normWork(alarLeftX, alarY),
    nostrilLeft:         normWork(nostrilLPt[0], nostrilLPt[1]),
    nostrilRight:        normWork(nostrilRPt[0], nostrilRPt[1]),
    alarRight:           normWork(alarRightX, alarY),
    alarCrestRight:      normWork(alarCrestRPt[0], alarCrestRPt[1]),

    // 5. Dense Outer + Inner Vermilion Lip Contours (15 pts)
    mouthLeft:           normFull(fMouthL),
    upperLipLeft:        normFull([lipMidL.sx, lipMidL.upY]),
    cupidPeakLeft:       normFull([lipCupidL.sx, lipCupidL.upY]),
    upperLipTop:         normFull([fMouthCX, fUpLipTopY]),
    cupidPeakRight:      normFull([lipCupidR.sx, lipCupidR.upY]),
    upperLipRight:       normFull([lipMidR.sx, lipMidR.upY]),
    mouthRight:          normFull(fMouthR),
    lowerLipRight:       normFull([lipMidR.sx, lipMidR.loY]),
    lowerLipBottom:      normFull([fMouthCX, fLoLipBotY]),
    lowerLipLeft:        normFull([lipMidL.sx, lipMidL.loY]),
    stomionLeft:         normFull([lipMidL.sx, lipMidL.stomY]),
    upperLipInner:       normFull([fMouthCX, Math.min(fMouthCY - 1.0, fUpInY)]),
    mouthCenter:         normFull([fMouthCX, fMouthCY]),
    lowerLipInner:       normFull([fMouthCX, Math.max(fMouthCY + 1.0, fLoInY)]),
    stomionRight:        normFull([lipMidR.sx, lipMidR.stomY]),

    // 6. Dense 17-Point Face Oval & Gonial Jawline Silhouette (17 pts)
    templeLeft:          normWork(sTempleLX, yTemple),
    cheekLeft:           normWork(sCheekLX, yZygoma),
    upperCheekLeft:      normWork(sUpCheekLX, yUpCheek),
    midCheekLeft:        normWork(sMidCheekLX, yMidCheek),
    lowerCheekLeft:      normWork(sLoCheekLX, yLoCheek),
    jawLeft:             normWork(sJawLX, yJaw),
    mandibleLeft:        normWork(sMandibleLX, yMandibleRefined),
    chinLeft:            normWork(sChinLX, yChinSideRefined),
    chin:                normFull([fChinX, fChinY]),
    chinRight:           normWork(sChinRX, yChinSideRefined),
    mandibleRight:       normWork(sMandibleRX, yMandibleRefined),
    jawRight:            normWork(sJawRX, yJaw),
    lowerCheekRight:     normWork(sLoCheekRX, yLoCheek),
    midCheekRight:       normWork(sMidCheekRX, yMidCheek),
    upperCheekRight:     normWork(sUpCheekRX, yUpCheek),
    cheekRight:          normWork(sCheekRX, yZygoma),
    templeRight:         normWork(sTempleRX, yTemple),

    // 7. Visible Outer Ear Prominence Anchors (2 pts)
    earLeft:             normFull(earLPt),
    earRight:            normFull(earRPt),
  };

  // Helper: sample full-resolution RGB box average
  const sampleFullRGB = (fx, fy, rx = 2, ry = 2) => {
    const cx = clamp(Math.round(fx), 0, srcW - 1);
    const cy = clamp(Math.round(fy), 0, srcH - 1);
    let sr = 0, sg = 0, sb = 0, n = 0;
    for (let dy = -ry; dy <= ry; dy++) {
      const yy = clamp(cy + dy, 0, srcH - 1);
      for (let dx = -rx; dx <= rx; dx++) {
        const xx = clamp(cx + dx, 0, srcW - 1);
        const o = (yy * srcW + xx) * 4;
        sr += data[o];
        sg += data[o + 1];
        sb += data[o + 2];
        n++;
      }
    }
    const inv = 1.0 / Math.max(1, n);
    return [sr * inv, sg * inv, sb * inv];
  };

  // =========================================================================
  // 12A. TRUE 2ND-DERIVATIVE NASOLABIAL FOLD & DIMPLE DETECTOR
  //      Zero artificial creases on smooth resting faces; activates ONLY when
  //      genuine shadow valleys / dimple hollows exist along the subject's features!
  // =========================================================================
  let mouthLineCue = 0.0;
  let dimpleCue = 0.0;
  if (Math.abs(estYawDeg) < 24) {
    const measureTrueNLValleySide = (sgn) => {
      const ax0 = (sgn < 0 ? alarLeftX : alarRightX) * invScale + sgn * fullPxPerCm * 0.08;
      const ay0 = (subnasaleY * invScale) - fullPxPerCm * 0.06;
      const mx1 = (sgn < 0 ? fMouthL[0] : fMouthR[0]) + sgn * fullPxPerCm * 0.24;
      const my1 = (sgn < 0 ? fMouthL[1] : fMouthR[1]) + fullPxPerCm * 0.04;
      const vx = mx1 - ax0, vy = my1 - ay0;
      const vLen = Math.max(1.0, Math.hypot(vx, vy));
      // Unit normal perpendicular to the subject's actual alar->corner fold trajectory
      const nx = (sgn * vy) / vLen;
      const ny = (-sgn * vx) / vLen;
      const dFlank = fullPxPerCm * 0.36;

      let valleySum = 0.0;
      const stations = [0.35, 0.55, 0.75];
      for (let k = 0; k < stations.length; k++) {
        const u = stations[k];
        const px = ax0 + vx * u;
        const py = ay0 + vy * u;
        const cLum   = sampleFullLum(px, py, 2, 2);
        const outLum = sampleFullLum(px + nx * dFlank, py + ny * dFlank, 2, 2);
        const inLum  = sampleFullLum(px - nx * dFlank, py - ny * dFlank, 2, 2);
        const flankMean = 0.5 * (outLum + inLum);
        const localRef  = Math.max(42.0, flankMean);
        // Symmetric 2nd-difference valley with noise deadzone (`0.026`): 0.0 on smooth linear/convex cheeks!
        valleySum += Math.max(0.0, (flankMean - cLum) / localRef - 0.026);
      }
      return valleySum / stations.length;
    };

    const measureDimpleHollowSide = (sgn) => {
      const cx = (sgn < 0 ? fMouthL[0] : fMouthR[0]) + sgn * fullPxPerCm * 0.58;
      const cy = (sgn < 0 ? fMouthL[1] : fMouthR[1]) - fullPxPerCm * 0.04;
      const rRing = fullPxPerCm * 0.32;
      const cLum = sampleFullLum(cx, cy, 2, 2);
      const ringMean = 0.25 * (
        sampleFullLum(cx - rRing, cy, 2, 2) +
        sampleFullLum(cx + rRing, cy, 2, 2) +
        sampleFullLum(cx, cy - rRing, 2, 2) +
        sampleFullLum(cx, cy + rRing, 2, 2)
      );
      return Math.max(0.0, (ringMean - cLum) / Math.max(42.0, ringMean) - 0.032);
    };

    const nlValL = measureTrueNLValleySide(-1);
    const nlValR = measureTrueNLValleySide(+1);
    // Require bilateral corroboration or genuine open-smile lift so unilateral hair/lighting never fakes a line
    const nlValley = 0.65 * Math.min(nlValL, nlValR) + 0.35 * Math.max(nlValL, nlValR);
    mouthLineCue = clamp(nlValley * 9.5, 0.0, 1.25);

    const dmVal = 0.65 * Math.min(measureDimpleHollowSide(-1), measureDimpleHollowSide(+1)) +
                  0.35 * Math.max(measureDimpleHollowSide(-1), measureDimpleHollowSide(+1));
    dimpleCue = clamp(dmVal * 10.5, 0.0, 1.15);
  }

  // =========================================================================
  // 12B. CUSTOM NECK VISION (`detectNeckAnatomy`)
  //      Detects exact neck skin corridor, hair/backdrop neck silhouette width,
  //      and exact clothing/T-shirt collar boundary (`collarTopY`)!
  // =========================================================================
  const chinRefRGB = sampleFullRGB(fChinX, fChinY - fullPxPerCm * 0.58, 5, 3);
  const chinRefSum = chinRefRGB[0] + chinRefRGB[1] + chinRefRGB[2] + 1e-4;
  const chinRG0 = chinRefRGB[0] / chinRefSum;
  const chinRG1 = chinRefRGB[1] / chinRefSum;
  const chinRefLum = 0.299 * chinRefRGB[0] + 0.587 * chinRefRGB[1] + 0.114 * chinRefRGB[2];

  // Sample clean upper-mid neck reference skin (`0.9..2.0 cm` below chin tip, skipping narrow submental shadow)
  let neckRefR = chinRefRGB[0] * 0.90, neckRefG = chinRefRGB[1] * 0.90, neckRefB = chinRefRGB[2] * 0.90;
  let neckRefW = 0.25;
  const yNeckProbe0 = clamp(Math.round(fChinY + fullPxPerCm * 0.85), 4, srcH - 5);
  const yNeckProbe1 = clamp(Math.round(fChinY + fullPxPerCm * 2.15), yNeckProbe0 + 1, srcH - 4);
  for (let py = yNeckProbe0; py <= yNeckProbe1; py += Math.max(2, Math.round(fullPxPerCm * 0.18))) {
    const rgb = sampleFullRGB(fChinX, py, Math.max(3, Math.round(fullPxPerCm * 0.55)), 2);
    const s = rgb[0] + rgb[1] + rgb[2] + 1e-4;
    const chD = Math.hypot(rgb[0] / s - chinRG0, rgb[1] / s - chinRG1);
    const lum = 0.299 * rgb[0] + 0.587 * rgb[1] + 0.114 * rgb[2];
    if (chD < 0.068 && lum > chinRefLum * 0.42 && lum < chinRefLum * 1.28) {
      neckRefR += rgb[0];
      neckRefG += rgb[1];
      neckRefB += rgb[2];
      neckRefW += 1.0;
    }
  }
  const neckSkinRGB = [neckRefR / neckRefW, neckRefG / neckRefW, neckRefB / neckRefW];
  const neckSkinSum = neckSkinRGB[0] + neckSkinRGB[1] + neckSkinRGB[2] + 1e-4;
  const neckRG0 = neckSkinRGB[0] / neckSkinSum;
  const neckRG1 = neckSkinRGB[1] / neckSkinSum;
  const neckSkinLum = Math.max(28.0, 0.299 * neckSkinRGB[0] + 0.587 * neckSkinRGB[1] + 0.114 * neckSkinRGB[2]);

  // Scan downward along neck centerline to pin down exact shirt-collar / clothing top rim (`collarTopY`)
  let collarTopY = srcH - 2;
  const yCollarStart = clamp(Math.round(fChinY + fullPxPerCm * 0.95), 4, srcH - 6);
  const yCollarEnd   = clamp(Math.round(fChinY + fullPxPerCm * 8.20), yCollarStart + 2, srcH - 3);
  const stripRx = Math.max(4, Math.round(fullPxPerCm * 0.65));
  let nonSkinStreak = 0;
  for (let py = yCollarStart; py <= yCollarEnd; py += 2) {
    const rgb = sampleFullRGB(fChinX, py, stripRx, 1);
    const s = rgb[0] + rgb[1] + rgb[2] + 1e-4;
    const chD = Math.hypot(rgb[0] / s - neckRG0, rgb[1] / s - neckRG1);
    const lum = 0.299 * rgb[0] + 0.587 * rgb[1] + 0.114 * rgb[2];
    const isCloth = chD > 0.044 || lum < neckSkinLum * 0.54 || lum > neckSkinLum * 1.48;
    if (isCloth) {
      nonSkinStreak += 2;
      if (nonSkinStreak >= Math.max(6, Math.round(fullPxPerCm * 0.22))) {
        collarTopY = py - nonSkinStreak + 2;
        break;
      }
    } else {
      nonSkinStreak = 0;
    }
  }

  // Trace hair-immune & backdrop-immune Left/Right Neck Silhouette Edges above `collarTopY`
  const jawHalfWPx = Math.max(fullPxPerCm * 3.8, 0.5 * (sJawRX - sJawLX) * invScale);
  const traceNeckEdgeSide = (sgn, scanY) => {
    const foreshorten = sgn < 0
      ? clamp(1.0 + 0.35 * Math.sin(estYawRad), 0.55, 1.15)
      : clamp(1.0 - 0.35 * Math.sin(estYawRad), 0.55, 1.15);
    const minDx = Math.round(fullPxPerCm * 3.15 * foreshorten);
    const maxDx = Math.round(Math.min(jawHalfWPx * 1.12, fullPxPerCm * 5.65) * foreshorten);
    const priorDx = jawHalfWPx * 0.91 * foreshorten;
    let bestX = fChinX + sgn * priorDx;
    let bestSc = -1e9;
    const step = Math.max(1, Math.round(fullPxPerCm * 0.08));
    for (let dx = minDx; dx <= maxDx; dx += step) {
      const tx = clamp(fChinX + sgn * dx, 6, srcW - 7);
      const inRGB  = sampleFullRGB(tx - sgn * Math.max(2, Math.round(fullPxPerCm * 0.22)), scanY, 2, 3);
      const outRGB = sampleFullRGB(tx + sgn * Math.max(2, Math.round(fullPxPerCm * 0.24)), scanY, 2, 3);
      const inS = inRGB[0] + inRGB[1] + inRGB[2] + 1e-4;
      const outS = outRGB[0] + outRGB[1] + outRGB[2] + 1e-4;
      const inChD  = Math.hypot(inRGB[0] / inS - neckRG0, inRGB[1] / inS - neckRG1);
      const outChD = Math.hypot(outRGB[0] / outS - neckRG0, outRGB[1] / outS - neckRG1);
      const inLum  = 0.299 * inRGB[0] + 0.587 * inRGB[1] + 0.114 * inRGB[2];
      const outLum = 0.299 * outRGB[0] + 0.587 * outRGB[1] + 0.114 * outRGB[2];

      const inIsNeckSkin = (1.0 - smoothstep(0.032, 0.078, inChD)) * smoothstep(neckSkinLum * 0.42, neckSkinLum * 0.72, inLum);
      const rgbJump = Math.hypot(inRGB[0] - outRGB[0], inRGB[1] - outRGB[1], inRGB[2] - outRGB[2]);
      const chromaJump = Math.max(0.0, outChD - inChD) * 320.0;
      const prior = Math.exp(-0.5 * (((dx - priorDx) / (fullPxPerCm * 0.68)) ** 2));
      const sc = (rgbJump * 0.85 + chromaJump + Math.max(0.0, inLum - outLum) * 0.45) * (0.25 + 0.75 * inIsNeckSkin) * prior;
      if (sc > bestSc) {
        bestSc = sc;
        bestX = tx;
      }
    }
    return bestX;
  };

  const validNeckSpan = Math.max(fullPxPerCm * 1.1, collarTopY - fChinY);
  // Sample cylindrical upper & mid neck waist (`0.22` and `0.44` of neck span, ABOVE any lower trapezius/collar root flare!)
  const yNeckUpper = clamp(fChinY + Math.min(validNeckSpan * 0.22, fullPxPerCm * 1.25), 4, srcH - 5);
  const yNeckMid   = clamp(fChinY + Math.min(validNeckSpan * 0.44, fullPxPerCm * 2.45), 4, srcH - 5);
  let neckLeftPx  = 0.5 * (traceNeckEdgeSide(-1, yNeckUpper) + traceNeckEdgeSide(-1, yNeckMid));
  let neckRightPx = 0.5 * (traceNeckEdgeSide(+1, yNeckUpper) + traceNeckEdgeSide(+1, yNeckMid));

  if (Math.abs(estYawDeg) < 15) {
    const wNL = fChinX - neckLeftPx;
    const wNR = neckRightPx - fChinX;
    // Prefer the cleaner/wider side slightly when dark hair drapes across one side of the neck!
    const symNW = Math.abs(wNL - wNR) > fullPxPerCm * 0.32
      ? (0.68 * Math.max(wNL, wNR) + 0.32 * Math.min(wNL, wNR))
      : 0.5 * (wNL + wNR);
    neckLeftPx  = fChinX - (0.42 * wNL + 0.58 * symNW);
    neckRightPx = fChinX + (0.42 * wNR + 0.58 * symNW);
  }

  const neckWidthCm = clamp((neckRightPx - neckLeftPx) / Math.max(1e-3, fullPxPerCm * Math.max(0.68, Math.cos(estYawRad))), 7.5, 11.2);
  const jawWidthCm  = clamp((2.0 * jawHalfWPx) / Math.max(1e-3, fullPxPerCm * Math.max(0.68, Math.cos(estYawRad))), 8.4, 12.2);
  const neckToJawRatio = clamp(neckWidthCm / jawWidthCm, 0.80, 0.99);

  // Direct Anthropometric Feature Measurements (in metric cm) for exact eye, nose, lip, laugh, jaw & neck fidelity!
  const upperLipCm = clamp((upperLipInnerY - upperLipTopY) / pxPerCm, 0.24, 0.92);
  const lowerLipCm = clamp((lowerLipBottomY - lowerLipInnerY) / pxPerCm, 0.28, 1.05);
  const mouthOpenCm = clamp((lowerLipInnerY - upperLipInnerY - 0.06 * pxPerCm) / pxPerCm, 0.0, 1.85);
  const avgCornerY = 0.5 * (mCornerL.y + mCornerR.y);
  const cornerLiftCm = (mouthCenterY - avgCornerY) / pxPerCm;
  const eyeOpenCm = 0.5 * (denseEyeL.openCm + denseEyeR.openCm);
  const eyeWidthCm = 0.5 * (denseEyeL.widthCm + denseEyeR.widthCm);
  const eyeTiltCm = 0.5 * (denseEyeL.tiltCm + denseEyeR.tiltCm);
  const browHeightCm = 0.5 * (denseBrowL.heightCm + denseBrowR.heightCm);
  const browArchCm = 0.5 * (denseBrowL.archCm + denseBrowR.archCm);
  const browTiltCm = 0.5 * (denseBrowL.tiltCm + denseBrowR.tiltCm);

  const shapeMeasurements = {
    bridgeHalfWidthCm,
    tipHalfWidthCm,
    upperLipCm,
    lowerLipCm,
    mouthOpenCm,
    cornerLiftCm,
    mouthLineCue,
    dimpleCue,
    neckWidthCm,
    neckToJawRatio,
    collarTopNormY: clamp(collarTopY / srcH, 0.0, 1.0),
    neckLeftNormX:  clamp(neckLeftPx / srcW, 0.0, 1.0),
    neckRightNormX: clamp(neckRightPx / srcW, 0.0, 1.0),
    neckSkinRGB,
    eyeOpenCm,
    eyeWidthCm,
    eyeTiltCm,
    browHeightCm,
    browArchCm,
    browTiltCm,
    eyelidSkinRGB,
  };

  const dEyeNose = noseTipY - eyeMidY;
  const dNoseChin = bestChinY - noseTipY;
  const vertRatio = dEyeNose / Math.max(4.0, dEyeNose + dNoseChin);
  const estPitchDeg = clamp((vertRatio - 0.33) * 85.0, -26.0, 26.0);

  return {
    landmarks2D,
    shapeMeasurements,
    initialPose: {
      yawDeg: estYawDeg,
      pitchDeg: estPitchDeg,
      rollDeg: (estRollRad * 180) / Math.PI,
    },
    confidence: clamp(bestPairScore / 30.0, 0.4, 0.99),
  };
}
