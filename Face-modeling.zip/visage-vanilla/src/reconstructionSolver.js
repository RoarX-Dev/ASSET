/**
 * VISAGE // FORGE — Pure Vanilla JS Multi-View 3D Face, Pose, Silhouette & Feature Reconstruction Solver (v3.1)
 * Zero Google MediaPipe — First-Principles Photogrammetric Bundle Adjustment:
 *  1. 6-DoF Perspective Pose (SO(3) + translation + IPD/midface-anchored metric scale)
 *  2. 21-Parameter Multi-View 3DMM Fit across 25 Anatomical Landmarks + IPD-Normalized Shape Priors
 *  3. Smooth Alias-Free Craniofacial Wendland-C2 Contour & Alar/Commissure Alignment
 *  4. Order-2 Spherical Harmonics (9-band SH) Lambertian Illumination Fit + SfS Micro-Relief
 */

import {
  DEFAULT_3DMM_WEIGHTS,
  generate3DMMBustGeometry,
  getKeyAnatomicalLandmarks3D,
  computeSeamlessGridNormals,
  computeEyelidBlinkBuffers,
} from './morphableHead3DMM.js?v=v81_sculpt_gold';
import { polishNoseAndLipSoftTissue } from './anatomicalCarvers3D.js?v=v81_sculpt_gold';
import {
  clamp,
  mix,
  eulerToMat3,
  projectPoint3D,
  solveLinearSystem,
  evalSH9,
  evalSHIrradiance,
} from './math3d.js?v=v81_sculpt_gold';

function smoothstep(e0, e1, x) {
  const t = clamp((x - e0) / (e1 - e0 || 1e-8), 0, 1);
  return t * t * (3 - 2 * t);
}

export const FITTABLE_PARAMS = [
  'faceWidth',
  'faceHeight',
  'foreheadHeight',
  'jawWidth',
  'cheekHollow',
  'chinProjection',
  'chinWidth',
  'eyeSpacing',
  'eyeWidth',
  'eyeSize',
  'eyeTilt',
  'browHeight',
  'browArch',
  'browTilt',
  'noseProjection',
  'noseBridgeWidth',
  'noseBridgeArch',
  'noseWidth',
  'noseTipBall',
  'noseLength',
  'mouthWidth',
  'mouthHeight',
  'upperLipFullness',
  'lowerLipFullness',
  'mouthCornerLift',
  'mouthOpen',
  'browProminence',
  'cheekbones',
];

export const LANDMARK_KEYS = [
  // Hairline Arch (5)
  'hairlineLeftTemple', 'hairlineLeftArch', 'hairline', 'hairlineRightArch', 'hairlineRightTemple',
  // Full Closed Upper+Lower Eyebrow Contour Rings + Centerline (22)
  'browLeftInner', 'browLeftMidInner', 'browLeft', 'browLeftMidOuter', 'browLeftOuter',
  'browLeftUpperInner', 'browLeftUpper', 'browLeftUpperOuter',
  'browLeftLowerInner', 'browLeftLower', 'browLeftLowerOuter',
  'browRightInner', 'browRightMidInner', 'browRight', 'browRightMidOuter', 'browRightOuter',
  'browRightUpperInner', 'browRightUpper', 'browRightUpperOuter',
  'browRightLowerInner', 'browRightLower', 'browRightLowerOuter',
  // Dense Eyes & Palpebral Eyelids (18)
  'eyeLeft', 'eyeLeftInner', 'eyeLeftUpperInner', 'eyeLeftUpper', 'eyeLeftUpperOuter',
  'eyeLeftOuter', 'eyeLeftLowerOuter', 'eyeLeftLower', 'eyeLeftLowerInner',
  'eyeRight', 'eyeRightInner', 'eyeRightUpperInner', 'eyeRightUpper', 'eyeRightUpperOuter',
  'eyeRightOuter', 'eyeRightLowerOuter', 'eyeRightLower', 'eyeRightLowerInner',
  // Dense Nose (12)
  'glabella', 'nasion', 'rhinion', 'supratip', 'noseTip', 'subnasale',
  'alarCrestLeft', 'alarLeft', 'nostrilLeft', 'nostrilRight', 'alarRight', 'alarCrestRight',
  // Dense Outer + Inner Lips (15)
  'mouthLeft', 'upperLipLeft', 'cupidPeakLeft', 'upperLipTop', 'cupidPeakRight', 'upperLipRight',
  'mouthRight', 'lowerLipRight', 'lowerLipBottom', 'lowerLipLeft',
  'stomionLeft', 'upperLipInner', 'mouthCenter', 'lowerLipInner', 'stomionRight',
  // Dense 17-Point Face Oval & Gonial Jawline (17)
  'templeLeft', 'cheekLeft', 'upperCheekLeft', 'midCheekLeft', 'lowerCheekLeft',
  'jawLeft', 'mandibleLeft', 'chinLeft', 'chin', 'chinRight', 'mandibleRight',
  'jawRight', 'lowerCheekRight', 'midCheekRight', 'upperCheekRight', 'cheekRight', 'templeRight',
];

function isLateralSilhouetteKey(k) {
  return (
    k !== 'chin' &&
    (k.startsWith('temple') ||
      k.startsWith('cheek') ||
      k.startsWith('upperCheek') ||
      k.startsWith('midCheek') ||
      k.startsWith('lowerCheek') ||
      k.startsWith('jaw') ||
      k.startsWith('mandible') ||
      k.startsWith('chinLeft') ||
      k.startsWith('chinRight'))
  );
}

function getPoseWeight(k) {
  if (k === 'eyeLeft' || k === 'eyeRight') return 2.40;
  if (k.startsWith('eyeLeftInner') || k.startsWith('eyeRightInner') || k.startsWith('eyeLeftOuter') || k.startsWith('eyeRightOuter')) return 1.55;
  if (k.startsWith('eye')) return 0.85;
  if (k === 'nasion' || k === 'noseTip' || k === 'mouthCenter' || k === 'chin') return 1.95;
  if (k === 'subnasale' || k === 'mouthLeft' || k === 'mouthRight') return 1.50;
  if (k.startsWith('hairline')) return 0.25;
  if (k.startsWith('brow')) return 0.65;
  if (isLateralSilhouetteKey(k)) return 0.45;
  return 0.85;
}

function getShapeWeight(k) {
  if (k === 'eyeLeft' || k === 'eyeRight' || k.endsWith('Inner') || k.endsWith('Outer')) return 1.85;
  if (k.startsWith('eye')) return 1.45;
  if (k.startsWith('brow')) return 1.05;
  if (k === 'noseTip' || k === 'alarLeft' || k === 'alarRight' || k === 'chin') return 2.05;
  if (k.startsWith('mouth') || k.includes('Lip') || k.startsWith('cupid') || k.startsWith('stomion')) return 1.55;
  if (isLateralSilhouetteKey(k)) return 1.45;
  return 1.35;
}

function lmPx(landmarks2D, key, width, height) {
  const pt = landmarks2D[key];
  if (!pt) return null;
  // Support both normalized [0..1] (standard) and raw pixel coordinates seamlessly
  const isNorm = pt[0] <= 1.5 && pt[1] <= 1.5;
  return isNorm ? [pt[0] * width, pt[1] * height] : [pt[0], pt[1]];
}

/**
 * Solve 6-DoF pose [rx, ry, rz, tx, ty, scale] for a single view using damped Gauss-Newton.
 */
export function solveViewPose(landmarks2D, weights3DMM, width, height, initYawDeg = 0, initPitchDeg = 0) {
  const eyeL = lmPx(landmarks2D, 'eyeLeft', width, height);
  const eyeR = lmPx(landmarks2D, 'eyeRight', width, height);
  const nas  = lmPx(landmarks2D, 'nasion', width, height);
  const mCtr = lmPx(landmarks2D, 'mouthCenter', width, height);
  const chin = lmPx(landmarks2D, 'chin', width, height);

  const eyeDistPx = Math.hypot(eyeR[0] - eyeL[0], eyeR[1] - eyeL[1]);
  const midFaceHPx = Math.hypot(
    chin[0] - 0.5 * (eyeL[0] + eyeR[0]),
    chin[1] - 0.5 * (eyeL[1] + eyeR[1])
  );

  // Anchor initial scale to IPD (5.95 cm) & Eye-to-Chin (9.85 cm) — immune to high/low hairlines!
  const absInitYaw = Math.abs((initYawDeg * Math.PI) / 180);
  const cosYaw = Math.max(0.55, Math.cos(absInitYaw));
  const initScale = Math.max(4.0, 0.50 * (eyeDistPx / (5.95 * cosYaw)) + 0.50 * (midFaceHPx / 9.85));

  const midX = 0.5 * (nas[0] + mCtr[0]);
  const midY = 0.5 * (nas[1] + mCtr[1]);

  let p = [
    (initPitchDeg * Math.PI) / 180,
    (initYawDeg * Math.PI) / 180,
    Math.atan2(eyeR[1] - eyeL[1], Math.max(12, eyeR[0] - eyeL[0])) * 0.6,
    midX - width * 0.5,
    midY - height * 0.5,
    initScale,
  ];

  const eps = 1e-4;
  let lambda = 1.6;

  const initYawRad = (initYawDeg * Math.PI) / 180;
  const isTurnedView = Math.abs(initYawDeg) > 14.0;

  const evalResiduals = (vec) => {
    const R = eulerToMat3(vec[0], vec[1], vec[2]);
    const pose = { R, tx: vec[3], ty: vec[4], scale: Math.max(2.0, vec[5]) };
    const lm3d = getKeyAnatomicalLandmarks3D(weights3DMM, vec[1]);
    const res = [];
    for (const key of LANDMARK_KEYS) {
      // CRITICAL: On turned 3/4 views (>14 deg), never let sliding cheek/jaw contour silhouettes
      // pull true 3D yaw (-33 deg / +28 deg) toward 0 deg! Rigid interior dense landmarks solve PnP cleanly!
      if (isTurnedView && isLateralSilhouetteKey(key)) continue;

      const target = lmPx(landmarks2D, key, width, height);
      const pt3 = lm3d[key];
      if (!target || !pt3) continue;
      let wt = getPoseWeight(key);
      const absYaw = Math.abs(vec[1]);
      if (absYaw > 0.22) {
        if (vec[1] > 0 && (key.includes('Right') && key.startsWith('alar'))) wt *= 0.35;
        if (vec[1] < 0 && (key.includes('Left') && key.startsWith('alar'))) wt *= 0.35;
      }
      const [u, v] = projectPoint3D(pt3, pose, width, height);
      res.push((u - target[0]) * wt, (v - target[1]) * wt);
    }
    if (isTurnedView) {
      // Gentle perspective yaw prior anchored to iris-to-cheek horizon ratio
      res.push((vec[1] - initYawRad) * 28.0);
    }
    return res;
  };

  let curRes = evalResiduals(p);
  let curCost = curRes.reduce((s, v) => s + v * v, 0);

  for (let iter = 0; iter < 24; iter++) {
    const m = curRes.length;
    const J = Array.from({ length: m }, () => new Float64Array(6));

    for (let j = 0; j < 6; j++) {
      const step = j >= 3 ? 0.25 : eps;
      const pPlus = p.slice();
      pPlus[j] += step;
      const rPlus = evalResiduals(pPlus);
      for (let i = 0; i < m; i++) {
        J[i][j] = (rPlus[i] - curRes[i]) / step;
      }
    }

    const JTJ = Array.from({ length: 6 }, () => new Float64Array(6));
    const JTr = new Float64Array(6);
    for (let j = 0; j < 6; j++) {
      let sumR = 0;
      for (let i = 0; i < m; i++) sumR += J[i][j] * curRes[i];
      JTr[j] = -sumR;
      for (let k = j; k < 6; k++) {
        let sumJ = 0;
        for (let i = 0; i < m; i++) sumJ += J[i][j] * J[i][k];
        JTJ[j][k] = sumJ;
        JTJ[k][j] = sumJ;
      }
      JTJ[j][j] += lambda * (j < 3 ? 12.0 : 0.15);
    }

    const dp = solveLinearSystem(JTJ, JTr);
    const cand = p.map((v, idx) => v + dp[idx]);
    cand[0] = clamp(cand[0], -0.68, 0.68);
    cand[1] = clamp(cand[1], -1.28, 1.28);
    cand[2] = clamp(cand[2], -0.58, 0.58);
    cand[5] = Math.max(2.5, cand[5]);

    const candRes = evalResiduals(cand);
    const candCost = candRes.reduce((s, v) => s + v * v, 0);
    if (candCost < curCost) {
      p = cand;
      curRes = candRes;
      curCost = candCost;
      lambda = Math.max(0.04, lambda * 0.55);
      if (Math.hypot(...dp) < 1e-4) break;
    } else {
      lambda *= 2.5;
    }
  }

  const R = eulerToMat3(p[0], p[1], p[2]);
  const lmFinal = getKeyAnatomicalLandmarks3D(weights3DMM, p[1]);
  let sqPx = 0;
  let cnt = 0;
  for (const key of LANDMARK_KEYS) {
    if (isTurnedView && isLateralSilhouetteKey(key)) continue;
    const target = lmPx(landmarks2D, key, width, height);
    if (!target || !lmFinal[key]) continue;
    const [u, v] = projectPoint3D(lmFinal[key], { R, tx: p[3], ty: p[4], scale: p[5] }, width, height);
    sqPx += (u - target[0]) ** 2 + (v - target[1]) ** 2;
    cnt++;
  }
  const rmsePx = Math.sqrt(sqPx / Math.max(1, cnt));

  return {
    rx: p[0],
    ry: p[1],
    rz: p[2],
    pitchDeg: (p[0] * 180) / Math.PI,
    yawDeg: (p[1] * 180) / Math.PI,
    rollDeg: (p[2] * 180) / Math.PI,
    tx: p[3],
    ty: p[4],
    scale: p[5],
    R,
    rmsePx,
    reprojectionErrorPx: rmsePx,
  };
}

/**
 * Compute IPD-normalized anatomical priors from direct pixel measurements (nose bridge, alar flare,
 * tip roundness, vermilion lips, cheek/jaw slenderness) so single-view AND multi-view meshes capture
 * the subject's unmistakable nose, lip & facial silhouette character immediately!
 */
function estimateDirectShapePriors(views, poses) {
  const priors = {};
  let bestIdx = -1;
  let bestAbsYaw = 999;
  for (let i = 0; i < views.length; i++) {
    const ay = Math.abs(poses[i]?.yawDeg ?? 90);
    if (ay < bestAbsYaw) {
      bestAbsYaw = ay;
      bestIdx = i;
    }
  }
  if (bestIdx < 0) return priors;

  const v = views[bestIdx];
  const W = v.width;
  const H = v.height;
  const P = (k) => lmPx(v.landmarks2D, k, W, H);
  const sm = v.shapeMeasurements || {};

  const eyeL = P('eyeLeft');
  const eyeR = P('eyeRight');
  const ipdPx = Math.max(16, Math.hypot(eyeR[0] - eyeL[0], eyeR[1] - eyeL[1]));
  const cmFromPx = 6.00 / ipdPx;

  if (bestAbsYaw < 22) {
    // 1. Forehead Height & Vertical Face Index Priors (compensating `eyeToChinCm` for open-mouth jaw drop!)
    const hair = P('hairline');
    const chinPt = P('chin');
    const eyeMidY = 0.5 * (eyeL[1] + eyeR[1]);
    const fhCm = (eyeMidY - hair[1]) * cmFromPx;
    const openJawCm = sm.mouthOpenCm !== undefined ? sm.mouthOpenCm : 0.0;
    const neutralEyeToChinCm = (chinPt[1] - eyeMidY) * cmFromPx - openJawCm * 0.82;
    priors.foreheadHeight = clamp((fhCm - 7.15) / 1.05, -0.35, 0.28);
    priors.faceHeight = clamp((neutralEyeToChinCm - 9.85) / 1.05, -0.42, 0.45);

    // 2. Dynamic Face Breadth, Buccal Taper, Jaw Width & Oval Chin Width!
    const cheekL = P('cheekLeft'), cheekR = P('cheekRight');
    const midCL  = P('midCheekLeft'), midCR = P('midCheekRight');
    const jawL   = P('jawLeft'), jawR = P('jawRight');
    const chinL  = P('chinLeft'), chinR = P('chinRight');

    const cheekSpanCm = Math.hypot(cheekR[0] - cheekL[0], cheekR[1] - cheekL[1]) * cmFromPx;
    const midCheekCm  = Math.hypot(midCR[0] - midCL[0], midCR[1] - midCL[1]) * cmFromPx;
    const jawSpanCm   = Math.hypot(jawR[0] - jawL[0], jawR[1] - jawL[1]) * cmFromPx;
    const chinSpanCm  = chinL && chinR ? Math.hypot(chinR[0] - chinL[0], chinR[1] - chinL[1]) * cmFromPx : 5.60;

    priors.faceWidth = clamp((cheekSpanCm - 11.65) / 1.15, -0.12, 0.85);
    const taperRatio = midCheekCm / Math.max(8.0, cheekSpanCm);
    priors.cheekHollow = clamp((0.895 - taperRatio) * 2.6, -0.35, 0.28);
    priors.cheekbones = clamp((cheekSpanCm / Math.max(8.2, jawSpanCm) - 1.14) * 2.8, -0.05, 0.72);
    priors.jawWidth = clamp((jawSpanCm - 9.85) / 1.15, -0.38, 0.95);
    priors.chinWidth = clamp((chinSpanCm - 4.45) / 0.90, -0.22, 0.55);

    // 2B. Wide-Awake Palpebral Eye Opening, Canthal Tilt & Multi-Point Eyebrow Curve Priors!
    if (sm.eyeOpenCm !== undefined) {
      priors.eyeSize = clamp((sm.eyeOpenCm - 0.68) / 0.17, -0.15, 0.82);
    }
    if (sm.eyeTiltCm !== undefined) {
      priors.eyeTilt = clamp((sm.eyeTiltCm - 0.04) / 0.24, -0.40, 0.40);
    }
    if (sm.browHeightCm !== undefined) {
      priors.browHeight = clamp((sm.browHeightCm - 1.32) / 0.36, -1.05, 2.15);
    }
    if (sm.browArchCm !== undefined) {
      priors.browArch = clamp((sm.browArchCm - 0.28) / 0.20, -1.05, 1.40);
    }
    if (sm.browTiltCm !== undefined) {
      priors.browTilt = clamp(sm.browTiltCm / 0.28, -0.60, 0.60);
    }

    // 3. Nose Width (Alar Flare), Bridge Width & Tip Bulbousness!
    const alarL = P('alarLeft'), alarR = P('alarRight');
    const alarSpanCm = Math.hypot(alarR[0] - alarL[0], alarR[1] - alarL[1]) * cmFromPx;
    priors.noseWidth = clamp((alarSpanCm - 2.76) / 0.74, -1.10, 1.35);

    if (sm.bridgeHalfWidthCm !== undefined) {
      priors.noseBridgeWidth = clamp((sm.bridgeHalfWidthCm - 0.56) / 0.19, -1.15, 1.30);
    }
    // Drive `noseTipBall` directly from the reference photo's measured `tipHalfWidthCm` + alar fullness so
    // rounded/bulbous tips (like Elena & Aria) stay genuinely full and NEVER pinch narrower than the reference!
    const tipBallFromVision = sm.tipHalfWidthCm !== undefined
      ? (sm.tipHalfWidthCm - 0.68) / 0.20
      : 0.30;
    priors.noseTipBall = clamp(
      0.42 + 0.45 * Math.max(-0.15, tipBallFromVision) + 0.30 * Math.max(0.0, priors.noseWidth || 0) + 0.14 * (priors.noseBridgeWidth || 0),
      0.28,
      1.35
    );

    // 4. Upper & Lower Vermilion Lip Fullness, Open-Mouth Laugh Aperture, Width & Corner Lift!
    const upTop = P('upperLipTop'), upIn = P('upperLipInner'), loIn = P('lowerLipInner'), mCtr = P('mouthCenter'), loBot = P('lowerLipBottom');
    const mL = P('mouthLeft'), mR = P('mouthRight');
    const mouthSpanCm = Math.hypot(mR[0] - mL[0], mR[1] - mL[1]) * cmFromPx;

    const innerOpenCm = upIn && loIn
      ? Math.max(0.0, (loIn[1] - upIn[1]) * cmFromPx - 0.06)
      : openJawCm;
    const mOpenPrior = clamp(innerOpenCm / 0.92, 0.0, 1.48);
    priors.mouthOpen = mOpenPrior;

    priors.mouthWidth = clamp((mouthSpanCm - (4.76 + 0.44 * mOpenPrior)) / 0.88, -1.05, 1.25);

    const upLipCm = sm.upperLipCm !== undefined
      ? sm.upperLipCm
      : Math.max(0.24, ((upIn ? upIn[1] : mCtr[1]) - upTop[1]) * cmFromPx);
    const loLipCm = sm.lowerLipCm !== undefined
      ? sm.lowerLipCm
      : Math.max(0.28, (loBot[1] - (loIn ? loIn[1] : mCtr[1])) * cmFromPx);
    priors.upperLipFullness = clamp((upLipCm - 0.44) / 0.18, -0.60, 1.25);
    priors.lowerLipFullness = clamp((loLipCm - 0.54) / 0.20, -0.60, 1.25);

    const cornerMidY = 0.5 * (mL[1] + mR[1]);
    const cornerLiftCm = (mCtr[1] - cornerMidY) * cmFromPx - 0.16 * mOpenPrior;
    priors.mouthCornerLift = clamp(cornerLiftCm / 0.26, -0.95, 1.15);
  }

  // 5. Shading cue for single-view Z relief
  if (v.imageData) {
    const { data, width, height } = v.imageData;
    const lumAt = (pt) => {
      const ix = clamp(Math.round(pt[0]), 0, width - 1);
      const iy = clamp(Math.round(pt[1]), 0, height - 1);
      const o = (iy * width + ix) * 4;
      return (0.299 * data[o] + 0.587 * data[o + 1] + 0.114 * data[o + 2]) / 255;
    };
    const tipL = lumAt(P('noseTip'));
    const subPt = P('subnasale');
    const subL = lumAt([subPt[0], subPt[1] + 2]);
    priors.noseProjection = clamp((tipL - subL - 0.08) * 2.2, -0.75, 1.10);
  }

  return priors;
}

/**
 * Jointly optimize shared 3DMM shape weights across all active views + direct anatomical priors.
 */
export function solveShared3DMMWeights(views, poses, initWeights = DEFAULT_3DMM_WEIGHTS) {
  const nParams = FITTABLE_PARAMS.length;
  let wVec = FITTABLE_PARAMS.map((k) => initWeights[k] || 0);
  const directPriors = estimateDirectShapePriors(views, poses);

  const eps = 1e-3;
  const regPrior = views.length >= 2 ? 0.65 : 1.05;

  const hasFrontalView = poses.some((p) => Math.abs(p.ry) < 0.25);

  const evalResiduals = (vec) => {
    const wObj = { ...initWeights };
    FITTABLE_PARAMS.forEach((k, idx) => { wObj[k] = vec[idx]; });
    wObj.lipFullness = 0.5 * ((wObj.upperLipFullness || 0) + (wObj.lowerLipFullness || 0));

    const res = [];
    for (let vIdx = 0; vIdx < views.length; vIdx++) {
      const view = views[vIdx];
      const pose = poses[vIdx];
      const lm3d = getKeyAnatomicalLandmarks3D(wObj, pose.ry);
      const norm = 1.0 / Math.max(6.0, pose.scale);
      const absYaw = Math.abs(pose.ry);

      // CRITICAL MULTI-VIEW PRINCIPLE:
      // When a crisp frontal view exists, weight frontal interior & coronal silhouette 2.2x,
      // and NEVER allow angled (>14 deg) views' foreshortened silhouettes to crush jaw/chin/cheek width!
      const viewBoost = hasFrontalView && absYaw < 0.25 ? 1.85 : 0.85;

      for (const key of LANDMARK_KEYS) {
        if (absYaw > 0.24 && isLateralSilhouetteKey(key)) continue;

        const target = lmPx(view.landmarks2D, key, view.width, view.height);
        const pt3 = lm3d[key];
        if (!target || !pt3) continue;
        let kw = getShapeWeight(key) * viewBoost;

        if (absYaw > 0.24) {
          if (key === 'noseTip' || key === 'rhinion' || key === 'nasion' || key === 'supratip' || key === 'chin' || key === 'subnasale') {
            kw *= 1.85;
          } else {
            kw *= 0.45;
          }
        }

        const [u, v] = projectPoint3D(pt3, pose, view.width, view.height);
        res.push((u - target[0]) * norm * kw, (v - target[1]) * norm * kw);
      }
    }

    for (let j = 0; j < nParams; j++) {
      const kName = FITTABLE_PARAMS[j];
      const targetPrior = directPriors[kName] !== undefined ? directPriors[kName] : 0.0;
      let priorStrength = regPrior * 0.34;
      if (kName === 'noseTipBall') {
        // Lock `noseTipBall` directly to Classical Vision's measured `tipHalfWidthCm` (`no 2D tip-width landmark exists in LM!`)
        priorStrength = regPrior * 4.8;
      } else if (
        kName === 'upperLipFullness' ||
        kName === 'lowerLipFullness' ||
        kName === 'mouthCornerLift' ||
        kName === 'mouthOpen' ||
        kName === 'noseBridgeWidth' ||
        kName === 'noseTipBall' ||
        kName === 'noseWidth' ||
        kName === 'foreheadHeight' ||
        kName === 'eyeSpacing' ||
        kName === 'eyeSize' ||
        kName === 'eyeTilt' ||
        kName === 'browHeight' ||
        kName === 'browArch' ||
        kName === 'browTilt' ||
        kName === 'faceWidth' ||
        kName === 'faceHeight' ||
        kName === 'cheekbones' ||
        kName === 'cheekHollow' ||
        kName === 'jawWidth' ||
        kName === 'chinWidth'
      ) {
        priorStrength = 0.95;
      } else if (kName === 'noseProjection' || kName === 'chinProjection' || kName === 'noseBridgeArch' || kName === 'browProminence') {
        priorStrength = views.length === 1 ? 1.25 : 1.15;
      }
      res.push((vec[j] - targetPrior) * priorStrength);
    }
    return res;
  };

  let curRes = evalResiduals(wVec);
  let curCost = curRes.reduce((s, v) => s + v * v, 0);
  let lambda = 0.35;

  for (let iter = 0; iter < 8; iter++) {
    const m = curRes.length;
    const J = Array.from({ length: m }, () => new Float64Array(nParams));

    for (let j = 0; j < nParams; j++) {
      const vPlus = wVec.slice();
      vPlus[j] += eps;
      const rPlus = evalResiduals(vPlus);
      for (let i = 0; i < m; i++) {
        J[i][j] = (rPlus[i] - curRes[i]) / eps;
      }
    }

    const JTJ = Array.from({ length: nParams }, () => new Float64Array(nParams));
    const JTr = new Float64Array(nParams);
    for (let j = 0; j < nParams; j++) {
      let sr = 0;
      for (let i = 0; i < m; i++) sr += J[i][j] * curRes[i];
      JTr[j] = -sr;
      for (let k = j; k < nParams; k++) {
        let sj = 0;
        for (let i = 0; i < m; i++) sj += J[i][j] * J[i][k];
        JTJ[j][k] = sj;
        JTJ[k][j] = sj;
      }
      JTJ[j][j] += lambda;
    }

    const dw = solveLinearSystem(JTJ, JTr);
    const cand = wVec.map((v, idx) => {
      const kName = FITTABLE_PARAMS[idx];
      if (kName === 'foreheadHeight') return clamp(v + dw[idx], -0.38, 0.30);
      if (kName === 'jawWidth') return clamp(v + dw[idx], -0.38, 0.95);
      if (kName === 'chinWidth') return clamp(v + dw[idx], -0.22, 0.55);
      if (kName === 'faceWidth') return clamp(v + dw[idx], -0.12, 0.88);
      if (kName === 'faceHeight') return clamp(v + dw[idx], -0.45, 0.42);
      if (kName === 'eyeSpacing') return clamp(v + dw[idx], -0.36, 0.38);
      if (kName === 'eyeTilt') return clamp(v + dw[idx], -0.45, 0.45);
      if (kName === 'eyeSize') return clamp(v + dw[idx], -0.12, 0.85);
      if (kName === 'browProminence') return clamp(v + dw[idx], -0.22, 0.48);
      if (kName === 'browHeight') {
        return clamp(v + dw[idx], -1.15, 2.25);
      }
      if (kName === 'browArch') {
        return clamp(v + dw[idx], -1.15, 1.50);
      }
      if (kName === 'browTilt') return clamp(v + dw[idx], -0.65, 0.65);
      if (kName === 'cheekHollow') return clamp(v + dw[idx], -0.35, 0.48);
      if (kName === 'noseLength') return clamp(v + dw[idx], -0.65, 0.78);
      if (kName === 'mouthHeight') return clamp(v + dw[idx], -0.60, 0.65);
      if (kName === 'upperLipFullness' || kName === 'lowerLipFullness') {
        return clamp(v + dw[idx], -0.22, 1.15);
      }
      if (kName === 'mouthOpen') {
        return clamp(v + dw[idx], 0.0, 1.50);
      }
      if (kName === 'mouthWidth') return clamp(v + dw[idx], -0.65, 0.55);
      if (kName === 'chinProjection') {
        return views.length === 1 ? clamp(v + dw[idx], -0.15, 0.45) : clamp(v + dw[idx], -0.32, 0.65);
      }
      if (kName === 'noseProjection') {
        return clamp(v + dw[idx], -0.28, 0.34);
      }
      if (kName === 'noseBridgeArch') {
        return clamp(v + dw[idx], -0.32, 0.45);
      }
      if (kName === 'noseTipBall') {
        return clamp(v + dw[idx], 0.16, 1.35);
      }
      if (kName === 'noseWidth') {
        return clamp(v + dw[idx], -0.95, 1.35);
      }
      if (kName === 'cheekbones') {
        return clamp(v + dw[idx], 0.02, 0.85);
      }
      return clamp(v + dw[idx], -1.35, 1.35);
    });
    const candRes = evalResiduals(cand);
    const candCost = candRes.reduce((s, v) => s + v * v, 0);

    if (candCost < curCost) {
      wVec = cand;
      curRes = candRes;
      curCost = candCost;
      lambda = Math.max(0.05, lambda * 0.6);
      if (Math.hypot(...dw) < 1e-3) break;
    } else {
      lambda *= 2.4;
    }
  }

  const out = { ...initWeights };
  FITTABLE_PARAMS.forEach((k, idx) => {
    out[k] = Number(wVec[idx].toFixed(3));
  });
  out.lipFullness = Number((0.5 * ((out.upperLipFullness || 0) + (out.lowerLipFullness || 0))).toFixed(3));
  return out;
}

/**
 * Well-Conditioned Bilateral Wendland-C2 Craniofacial Silhouette, Brow, Nose & Oral Warp:
 * Uses 1 centroid eye anchor per eye (preserving 100% spherical eyeball & crisp lid geometry!),
 * full open/closed lip + inner aperture anchors, and smooth Z fade behind the jaw (`pz > -5.4 cm`)
 * so cheeks and jawlines NEVER crease or shear!
 */
const SMOOTH_WARP_ANCHORS = [
  'hairlineLeftTemple', 'hairlineLeftArch', 'hairline', 'hairlineRightArch', 'hairlineRightTemple',
  // Clean 6-Point Eyebrow Arch Stations (3 Left + 3 Right — zero clustered RBF ringing!)
  'browLeftInner', 'browLeft', 'browLeftOuter',
  'browRightInner', 'browRight', 'browRightOuter',
  // 1 Clean Centroid Anchor Per Eye (preserves 100% undistorted spherical eyeball & tarsal lids!)
  'eyeLeft', 'eyeRight',
  // Clean Non-Conflicting Nasal Anchors (`nasion` + `noseTip` + `alarLeft/Right` — avoids 5mm `rhinion`/`subnasale` RBF pinching!)
  'nasion', 'noseTip', 'alarLeft', 'alarRight',
  // Clean Outer + Inner Oral Anchors (`mouthLeft`, `upperLipTop`, `mouthRight`, `lowerLipBottom`, `upperLipInner`, `lowerLipInner`)
  'mouthLeft', 'upperLipTop', 'mouthRight', 'lowerLipBottom', 'upperLipInner', 'lowerLipInner',
  // 17-Point Cheek / Gonial Jaw / Mandible / Oval Chin Silhouette
  'templeLeft', 'templeRight',
  'cheekLeft', 'cheekRight',
  'upperCheekLeft', 'upperCheekRight',
  'midCheekLeft', 'midCheekRight',
  'lowerCheekLeft', 'lowerCheekRight',
  'jawLeft', 'jawRight',
  'mandibleLeft', 'mandibleRight',
  'chinLeft', 'chinRight',
  'chin',
];

function wendlandC2(dist, radius) {
  const q = dist / radius;
  if (q >= 1.0) return 0.0;
  const om = 1.0 - q;
  return om * om * om * om * (4.0 * q + 1.0);
}

export function computeSmoothWarpField(basePositions, regionT, weights, views, poses, keyLandmarks3D = null) {
  let frontalIdx = -1;
  let minYaw = 999;
  for (let i = 0; i < views.length; i++) {
    const ay = Math.abs(poses[i].yawDeg);
    if (ay < minYaw) {
      minYaw = ay;
      frontalIdx = i;
    }
  }
  const numVerts = basePositions.length / 3;
  const zeroField = new Float32Array(basePositions.length);
  if (frontalIdx < 0 || minYaw > 24) return zeroField;

  const fView = views[frontalIdx];
  const fPose = poses[frontalIdx];
  const lm3d = getKeyAnatomicalLandmarks3D(weights, fPose.ry);

  const anchors = [];
  const anchorKeys = [];
  const deltas = [];

  for (const key of SMOOTH_WARP_ANCHORS) {
    const p3 = lm3d[key];
    const t2 = lmPx(fView.landmarks2D, key, fView.width, fView.height);
    if (!p3 || !t2) continue;

    const [u, v] = projectPoint3D(p3, fPose, fView.width, fView.height);
    const zc = fPose.R[6] * p3[0] + fPose.R[7] * p3[1] + fPose.R[8] * p3[2];
    const persp = 112.0 / Math.max(60.0, 112.0 - zc);
    const pxToCm = 1.0 / Math.max(4.0, fPose.scale * persp);

    const isSilhouette =
      key.startsWith('temple') ||
      key.startsWith('cheek') ||
      key.startsWith('upperCheek') ||
      key.startsWith('midCheek') ||
      key.startsWith('lowerCheek') ||
      key.startsWith('jaw') ||
      key.startsWith('mandible') ||
      key.startsWith('chin');

    const isNasalOrOralInterior =
      key === 'noseTip' ||
      key === 'alarLeft' ||
      key === 'alarRight' ||
      key === 'upperLipTop' ||
      key === 'lowerLipBottom' ||
      key === 'upperLipInner' ||
      key === 'lowerLipInner' ||
      key === 'mouthLeft' ||
      key === 'mouthRight';

    const maxDu = isSilhouette ? 0.95 : 0.42;
    const maxDv = isSilhouette || key.startsWith('hairline') ? 0.68 : isNasalOrOralInterior ? 0.14 : 0.34;

    const duCm = clamp((t2[0] - u) * pxToCm, -maxDu, maxDu);
    const dvCm = clamp(-(t2[1] - v) * pxToCm, -maxDv, maxDv);

    const dx = fPose.R[0] * duCm + fPose.R[3] * dvCm;
    const dy = fPose.R[1] * duCm + fPose.R[4] * dvCm;

    const noY =
      key.startsWith('temple') ||
      key.startsWith('cheek') ||
      key.startsWith('upperCheek') ||
      key.startsWith('midCheek') ||
      key.startsWith('lowerCheek');

    const gainX = isSilhouette ? 0.82 : 0.70;
    const gainY = noY ? 0.0 : isSilhouette ? 0.76 : isNasalOrOralInterior ? 0.42 : 0.68;

    anchors.push([p3[0], p3[1], p3[2]]);
    anchorKeys.push(key);
    deltas.push([dx * gainX, dy * gainY, 0.0]);
  }

  const symPairs = [
    ['hairlineLeftTemple', 'hairlineRightTemple'],
    ['hairlineLeftArch', 'hairlineRightArch'],
    ['browLeftInner', 'browRightInner'],
    ['browLeft', 'browRight'],
    ['browLeftOuter', 'browRightOuter'],
    ['eyeLeft', 'eyeRight'],
    ['alarLeft', 'alarRight'],
    ['mouthLeft', 'mouthRight'],
    ['upperLipLeft', 'upperLipRight'],
    ['lowerLipLeft', 'lowerLipRight'],
    ['templeLeft', 'templeRight'],
    ['cheekLeft', 'cheekRight'],
    ['upperCheekLeft', 'upperCheekRight'],
    ['midCheekLeft', 'midCheekRight'],
    ['lowerCheekLeft', 'lowerCheekRight'],
    ['jawLeft', 'jawRight'],
    ['mandibleLeft', 'mandibleRight'],
    ['chinLeft', 'chinRight'],
  ];
  for (const [kL, kR] of symPairs) {
    const iL = anchorKeys.indexOf(kL);
    const iR = anchorKeys.indexOf(kR);
    if (iL >= 0 && iR >= 0) {
      let symOutX = 0.5 * (-deltas[iL][0] + deltas[iR][0]);
      const symY = 0.5 * (deltas[iL][1] + deltas[iR][1]);
      // Prevent bright anterior neck skin right behind the chin from pulling `mandible`/`chinLeft/Right` outward into square jowls!
      if (kL === 'mandibleLeft' || kL === 'chinLeft') {
        symOutX = Math.min(symOutX, 0.12);
      } else if (kL === 'jawLeft' || kL === 'lowerCheekLeft') {
        symOutX = Math.min(symOutX, 0.32);
      }
      deltas[iL][0] = mix(deltas[iL][0], -symOutX, 0.76);
      deltas[iR][0] = mix(deltas[iR][0],  symOutX, 0.76);
      deltas[iL][1] = mix(deltas[iL][1],  symY,    0.72);
      deltas[iR][1] = mix(deltas[iR][1],  symY,    0.72);
    }
  }

  // Harmonize nasal tip & alar vertical shift so opposing RBF `dy` NEVER compresses the infratip lobule into a beak or cheek crease!
  {
    const iTip = anchorKeys.indexOf('noseTip');
    const iAlL = anchorKeys.indexOf('alarLeft');
    const iAlR = anchorKeys.indexOf('alarRight');
    if (iTip >= 0 && iAlL >= 0 && iAlR >= 0) {
      const meanNasalDY = 0.50 * deltas[iTip][1] + 0.25 * (deltas[iAlL][1] + deltas[iAlR][1]);
      deltas[iTip][1] = mix(deltas[iTip][1], meanNasalDY, 0.75);
      deltas[iAlL][1] = mix(deltas[iAlL][1], meanNasalDY, 0.75);
      deltas[iAlR][1] = mix(deltas[iAlR][1], meanNasalDY, 0.75);
    }
  }

  const N = anchors.length;
  if (N === 0) return zeroField;
  const rSupport = 3.05;
  const nugget = 0.42;

  const Phi = Array.from({ length: N }, () => new Float64Array(N));
  const rhsX = new Float64Array(N);
  const rhsY = new Float64Array(N);

  for (let i = 0; i < N; i++) {
    rhsX[i] = deltas[i][0];
    rhsY[i] = deltas[i][1];
    for (let j = i; j < N; j++) {
      // Scale Z separation by 0.26 so protruding 3D nasal tip (`+1.4 cm` Z) moves coherently with infratip/alar base (ZERO Z-cliff fold!)
      const dist = Math.hypot(
        anchors[i][0] - anchors[j][0],
        anchors[i][1] - anchors[j][1],
        (anchors[i][2] - anchors[j][2]) * 0.26
      );
      const val = wendlandC2(dist, rSupport);
      Phi[i][j] = val;
      Phi[j][i] = val;
    }
    Phi[i][i] += nugget;
  }

  const coefX = solveLinearSystem(Phi, rhsX);
  const coefY = solveLinearSystem(Phi, rhsY);

  // Pre-evaluate smooth bilateral jaw width warp AND vertical chin base shift (`chinBaseWY`)
  // at the actual 3D jaw/chin landmark coordinates so the cervical neck glides & scales smoothly with the jaw
  // (100% eliminating vertical neck buckling / double-chin folds and sideways jowl shelves on every face!)
  const pJawL = lm3d.jawLeft || [-4.9, -4.9, -0.8];
  const pJawR = lm3d.jawRight || [4.9, -4.9, -0.8];
  const pChin = lm3d.chin || [0.0, -7.8, 3.6];
  let jawCornerWXLeft = 0.0, jawCornerWXRight = 0.0, chinBaseWY = 0.0;
  for (let i = 0; i < N; i++) {
    const dL = Math.hypot(pJawL[0] - anchors[i][0], pJawL[1] - anchors[i][1], (pJawL[2] - anchors[i][2]) * 0.26);
    if (dL < rSupport) jawCornerWXLeft += coefX[i] * wendlandC2(dL, rSupport);
    const dR = Math.hypot(pJawR[0] - anchors[i][0], pJawR[1] - anchors[i][1], (pJawR[2] - anchors[i][2]) * 0.26);
    if (dR < rSupport) jawCornerWXRight += coefX[i] * wendlandC2(dR, rSupport);
    const dC = Math.hypot(pChin[0] - anchors[i][0], pChin[1] - anchors[i][1], (pChin[2] - anchors[i][2]) * 0.26);
    if (dC < rSupport) chinBaseWY += coefY[i] * wendlandC2(dC, rSupport);
  }

  const evalWarpAt = (px, py, pz, tVal) => {
    if (tVal < 0.12 || tVal > 0.88 || pz < -8.8) return [0.0, 0.0];
    const sZy = clamp((pz + 6.4) / 4.8, 0.0, 1.0);
    const fadeZy = sZy * sZy * (3.0 - 2.0 * sZy);
    const sZx = clamp((pz + 8.8) / 6.8, 0.0, 1.0);
    const fadeZx = sZx * sZx * (3.0 - 2.0 * sZx);
    const sTop = clamp((tVal - 0.12) / 0.08, 0.0, 1.0);
    const fadeTop = sTop * sTop * (3.0 - 2.0 * sTop);
    const sBotY = clamp((0.86 - tVal) / 0.26, 0.0, 1.0);
    const fadeBotY = sBotY * sBotY * (3.0 - 2.0 * sBotY);
    const sBotX = clamp((0.88 - tVal) / 0.22, 0.0, 1.0);
    const fadeBotX = sBotX * sBotX * (3.0 - 2.0 * sBotX);
    if (fadeTop <= 1e-4 || (fadeBotX <= 1e-4 && fadeBotY <= 1e-4)) return [0.0, 0.0];

    const isNeckCheck = smoothstep(0.535, 0.635, tVal);
    let headWX = 0.0, headWY = 0.0;
    if (isNeckCheck < 0.999) {
      for (let i = 0; i < N; i++) {
        const dxA = px - anchors[i][0];
        const dyA = py - anchors[i][1];
        const dzScaled = (pz - anchors[i][2]) * 0.26;
        const dist = Math.hypot(dxA, dyA, dzScaled);
        if (dist < rSupport) {
          const wVal = wendlandC2(dist, rSupport);
          headWY += coefY[i] * wVal;
          headWX += coefX[i] * wVal;
        }
      }
    }
    // Keep slender neck width independent of wide cheekbones/jaw corners (`NO symJawScale inflation on neck!`):
    // Only carry mild lateral center shift (`asymJawShift`) + smooth vertical chin-shift continuation down the neck!
    const uRad = clamp(px / Math.max(4.0, Math.abs(pJawR[0]) * 0.95), -1.0, 1.0);
    const asymJawShift = 0.5 * (jawCornerWXRight + jawCornerWXLeft);
    const neckWX = asymJawShift * (1.0 - 0.5 * uRad * uRad) * 0.65;
    const neckWY = chinBaseWY * 0.85;
    const neckCarry = smoothstep(0.535, 0.635, tVal);
    const wx = mix(headWX, neckWX, neckCarry);
    const wy = mix(headWY, neckWY, neckCarry);
    return [wx * fadeZx * fadeTop * fadeBotX, wy * fadeZy * fadeTop * fadeBotY];
  };

  const offsets = new Float32Array(basePositions.length);
  for (let v = 0; v < numVerts; v++) {
    const [ox, oy] = evalWarpAt(
      basePositions[3 * v],
      basePositions[3 * v + 1],
      basePositions[3 * v + 2],
      regionT[v]
    );
    offsets[3 * v] = ox;
    offsets[3 * v + 1] = oy;
  }

  // Also deform 3D anatomical landmarks by the exact same smooth RBF field!
  if (keyLandmarks3D) {
    for (const [k, pt] of Object.entries(keyLandmarks3D)) {
      if (!pt) continue;
      const approxT = k.startsWith('hairline') ? 0.18 : k.includes('chin') ? 0.58 : 0.38;
      const [ox, oy] = evalWarpAt(pt[0], pt[1], pt[2], approxT);
      pt[0] += ox;
      pt[1] += oy;
    }
  }

  // Local Landmark-Exact Palpebral Contour Alignment:
  // Aligns the sculpted 3D medial/lateral canthi and upper/lower eyelid arches directly to the subject's
  // 8-point detected eye contours while keeping the central corneal dome (`rIris < 0.42`) circular & undistorted!
  const refLms = keyLandmarks3D || lm3d;
  const buildLocalEyeAlign = (sidePrefix) => {
    const keys = [
      `${sidePrefix}Inner`,
      `${sidePrefix}UpperInner`,
      `${sidePrefix}Upper`,
      `${sidePrefix}UpperOuter`,
      `${sidePrefix}Outer`,
      `${sidePrefix}LowerInner`,
      `${sidePrefix}Lower`,
      `${sidePrefix}LowerOuter`,
      sidePrefix,
    ];
    const pts3 = {};
    const resX = {};
    const resY = {};
    for (const k of keys) {
      const p3 = refLms[k];
      const t2 = lmPx(fView.landmarks2D, k, fView.width, fView.height);
      if (!p3 || !t2) return null;
      pts3[k] = p3;
      const [u, v] = projectPoint3D(p3, fPose, fView.width, fView.height);
      const zc = fPose.R[6] * p3[0] + fPose.R[7] * p3[1] + fPose.R[8] * p3[2];
      const persp = 112.0 / Math.max(60.0, 112.0 - zc);
      const pxToCm = 1.0 / Math.max(4.0, fPose.scale * persp);
      const duCm = clamp((t2[0] - u) * pxToCm, -0.22, 0.22);
      const dvCm = clamp(-(t2[1] - v) * pxToCm, -0.18, 0.18);
      resX[k] = (fPose.R[0] * duCm + fPose.R[3] * dvCm) * 0.82;
      resY[k] = (fPose.R[1] * duCm + fPose.R[4] * dvCm) * 0.85;
    }
    const pIn = pts3[`${sidePrefix}Inner`];
    const pOut = pts3[`${sidePrefix}Outer`];
    const pCtr = pts3[sidePrefix];
    const axIn = Math.abs(pIn[0]);
    const axOut = Math.abs(pOut[0]);
    return {
      isRight: pCtr[0] > 0,
      cx: pCtr[0],
      cy: pCtr[1],
      axIn,
      spanX: Math.max(1.8, axOut - axIn),
      dxIn: resX[`${sidePrefix}Inner`],
      dxOut: resX[`${sidePrefix}Outer`],
      dyIn: resY[`${sidePrefix}Inner`],
      dyOut: resY[`${sidePrefix}Outer`],
      dxCtr: resX[sidePrefix],
      dyCtr: resY[sidePrefix],
      upDY: [
        resY[`${sidePrefix}Inner`],
        resY[`${sidePrefix}UpperInner`],
        resY[`${sidePrefix}Upper`],
        resY[`${sidePrefix}UpperOuter`],
        resY[`${sidePrefix}Outer`],
      ],
      loDY: [
        resY[`${sidePrefix}Inner`],
        resY[`${sidePrefix}LowerInner`],
        resY[`${sidePrefix}Lower`],
        resY[`${sidePrefix}LowerOuter`],
        resY[`${sidePrefix}Outer`],
      ],
    };
  };

  const eyeAlignL = buildLocalEyeAlign('eyeLeft');
  const eyeAlignR = buildLocalEyeAlign('eyeRight');
  const evalPiecewise5 = (vals, u) => {
    const ks = [0.0, 0.27, 0.50, 0.73, 1.0];
    const uc = clamp(u, 0.0, 1.0);
    let idx = 0;
    while (idx < 3 && uc > ks[idx + 1]) idx++;
    const f = clamp((uc - ks[idx]) / (ks[idx + 1] - ks[idx]), 0.0, 1.0);
    const s = f * f * (3.0 - 2.0 * f);
    return mix(vals[idx], vals[idx + 1], s);
  };

  const evalLocalEyeDelta = (px, py, pz) => {
    if (pz < 2.2) return [0.0, 0.0];
    const ea = px < 0 ? eyeAlignL : eyeAlignR;
    if (!ea) return [0.0, 0.0];
    const ax = Math.abs(px);
    const uRaw = (ax - ea.axIn) / ea.spanX;
    if (uRaw < -0.56 || uRaw > 1.56) return [0.0, 0.0];
    const dyRel = py - ea.cy;
    if (Math.abs(dyRel) > 1.58) return [0.0, 0.0];

    const hWin = smoothstep(-0.54, -0.02, uRaw) * (1.0 - smoothstep(1.02, 1.54, uRaw));
    const vWin = 1.0 - smoothstep(0.36, 1.55, Math.abs(dyRel));
    // Protect central iris circle (`rIris < 0.36`) with wide smooth transition so rows never invert or crease!
    const rIris = Math.hypot((px - ea.cx) / 0.56, dyRel / 0.48);
    const lidRingGate = smoothstep(0.24, 0.86, rIris);

    const uC = clamp(uRaw, 0.0, 1.0);
    const lx = clamp(mix(ea.dxIn, ea.dxOut, uC), -0.11, 0.11) * hWin * vWin * lidRingGate;
    const upLoBlend = smoothstep(-0.26, 0.26, dyRel);
    // Smooth quadratic-blended lid delta (`loDY` gently damped so lower eyelid clay rim never waves!)
    const loSmooth = clamp(0.55 * evalPiecewise5(ea.loDY, uC) + 0.225 * (evalPiecewise5(ea.loDY, clamp(uC - 0.16, 0, 1)) + evalPiecewise5(ea.loDY, clamp(uC + 0.16, 0, 1))), -0.062, 0.062);
    const upSmooth = clamp(0.60 * evalPiecewise5(ea.upDY, uC) + 0.20 * (evalPiecewise5(ea.upDY, clamp(uC - 0.14, 0, 1)) + evalPiecewise5(ea.upDY, clamp(uC + 0.14, 0, 1))), -0.088, 0.088);
    const lyCurve = mix(loSmooth, upSmooth, upLoBlend);
    const ly = lyCurve * hWin * vWin * lidRingGate;
    return [lx, ly];
  };

  if (eyeAlignL || eyeAlignR) {
    for (let v = 0; v < numVerts; v++) {
      const t = regionT[v];
      if (t < 0.22 || t > 0.47) continue;
      const wx = basePositions[3 * v] + offsets[3 * v];
      const wy = basePositions[3 * v + 1] + offsets[3 * v + 1];
      const wz = basePositions[3 * v + 2];
      const [ex, ey] = evalLocalEyeDelta(wx, wy, wz);
      if (Math.abs(ex) > 1e-6 || Math.abs(ey) > 1e-6) {
        // Slide smoothly along the 3D ocular/orbital tangent plane so outer eye corners never fold or crumple!
        const ea = wx < 0 ? eyeAlignL : eyeAlignR;
        const slopeZ = ea ? clamp(-0.24 * (Math.abs(wx) - Math.abs(ea.cx)), -0.42, 0.12) : 0.0;
        const ez = clamp(slopeZ * Math.sign(wx || 1) * ex, -0.055, 0.055);
        offsets[3 * v]     += ex;
        offsets[3 * v + 1] += ey;
        offsets[3 * v + 2] += ez;
      }
    }
    if (keyLandmarks3D) {
      for (const [k, pt] of Object.entries(keyLandmarks3D)) {
        if (!pt || !k.startsWith('eye')) continue;
        if (k === 'eyeLeft' && eyeAlignL) {
          // Center corneal dome directly on the detected iris/pupil landmark!
          pt[0] += eyeAlignL.dxCtr;
          pt[1] += eyeAlignL.dyCtr;
        } else if (k === 'eyeRight' && eyeAlignR) {
          pt[0] += eyeAlignR.dxCtr;
          pt[1] += eyeAlignR.dyCtr;
        } else {
          const [ex, ey] = evalLocalEyeDelta(pt[0], pt[1], pt[2]);
          pt[0] += ex;
          pt[1] += ey;
        }
      }
    }
  }

  return offsets;
}

/**
 * Estimate 9-band Luminance Spherical Harmonics (`Float64Array(9)`) for de-lighting & SfS relief.
 */
export function estimateSphericalHarmonics9(view, pose, mesh) {
  const fallback = new Float64Array([0.82, 0.0, 0.06, 0.14, 0, 0, 0, 0, 0]);
  if (!view || !view.imageData) return fallback;

  const { data, width, height } = view.imageData;
  const { positions, normals, regionT } = mesh;
  const numVerts = regionT.length;

  const samples = [];
  for (let i = 0; i < numVerts; i += 5) {
    const t = regionT[i];
    if (t < 0.19 || t > 0.56) continue;
    const vx = positions[3 * i];
    const vy = positions[3 * i + 1];
    const vz = positions[3 * i + 2];
    if (vz < 2.2) continue;

    const nx = normals[3 * i];
    const ny = normals[3 * i + 1];
    const nz = normals[3 * i + 2];
    const rnx = pose.R[0] * nx + pose.R[1] * ny + pose.R[2] * nz;
    const rny = pose.R[3] * nx + pose.R[4] * ny + pose.R[5] * nz;
    const rnz = pose.R[6] * nx + pose.R[7] * ny + pose.R[8] * nz;
    if (rnz < 0.34) continue;

    const [u, v] = projectPoint3D([vx, vy, vz], pose, width, height);
    const ix = Math.round(u);
    const iy = Math.round(v);
    if (ix < 4 || ix >= width - 4 || iy < 4 || iy >= height - 4) continue;

    const idx = (iy * width + ix) * 4;
    const lum = (0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2]) / 255;
    if (lum < 0.12 || lum > 0.94) continue;

    samples.push({ sh: evalSH9(rnx, rny, rnz), lum });
  }

  if (samples.length < 30) return fallback;

  let meanLum = 0;
  for (const s of samples) meanLum += s.lum;
  meanLum = Math.max(0.18, meanLum / samples.length);

  const ATA = Array.from({ length: 9 }, () => new Float64Array(9));
  const ATb = new Float64Array(9);

  for (const s of samples) {
    const yNorm = s.lum / meanLum;
    for (let j = 0; j < 9; j++) {
      ATb[j] += s.sh[j] * yNorm;
      for (let k = j; k < 9; k++) {
        ATA[j][k] += s.sh[j] * s.sh[k];
      }
    }
  }
  for (let j = 0; j < 9; j++) {
    for (let k = 0; k < j; k++) ATA[j][k] = ATA[k][j];
    ATA[j][j] += j === 0 ? 1.0 : j < 4 ? 8.0 : 28.0;
  }

  return solveLinearSystem(ATA, ATb);
}

/**
 * Full Multi-View Photogrammetric Reconstruction Pipeline
 * Returns `{ weights, poses, geometry, shCoeffs, refViewIndex, metrics }`
 */
export function reconstruct3DHeadBust(views, options = {}) {
  const tStart = performance.now();
  const density = options.density || 'standard';
  let weights = { ...DEFAULT_3DMM_WEIGHTS, ...(options.initialWeights || {}) };

  let poses = views.map((v) =>
    solveViewPose(
      v.landmarks2D,
      weights,
      v.width,
      v.height,
      v.initialPose?.yawDeg ?? v.estYawDeg ?? 0,
      v.initialPose?.pitchDeg ?? v.estPitchDeg ?? 0
    )
  );

  for (let round = 0; round < 2; round++) {
    weights = solveShared3DMMWeights(views, poses, weights);
    poses = views.map((v, idx) =>
      solveViewPose(
        v.landmarks2D,
        weights,
        v.width,
        v.height,
        v.initialPose?.yawDeg ?? poses[idx].yawDeg,
        v.initialPose?.pitchDeg ?? poses[idx].pitchDeg
      )
    );
  }

  // Auto-seed Neck Vision breadth + vision-matched perioral fold/dimple cues (0.0 on smooth young faces!)
  {
    let fIdx = 0, bestAY = 999;
    poses.forEach((p, idx) => {
      if (Math.abs(p.yawDeg) < bestAY) { bestAY = Math.abs(p.yawDeg); fIdx = idx; }
    });
    const smF = views[fIdx]?.shapeMeasurements || {};
    weights.mouthLineDepth = clamp(smF.mouthLineCue ?? 0.0, 0.0, 1.40);
    weights.dimpleDepth    = clamp(smF.dimpleCue ?? 0.0, 0.0, 1.25);
    if (smF.neckWidthCm !== undefined) {
      weights.neckWidth = clamp((smF.neckWidthCm - 8.45) / 1.45, -0.85, 1.35);
    }
  }

  if (options.userOverrides && Object.keys(options.userOverrides).length > 0) {
    weights = { ...weights, ...options.userOverrides };
  }

  const geometry = generate3DMMBustGeometry(weights, density);

  // Smooth bilateral craniofacial contour & feature alignment warp (also updates keyLandmarks3D!)
  const warpOffsets = computeSmoothWarpField(
    geometry.positions,
    geometry.regionT,
    weights,
    views,
    poses,
    geometry.keyLandmarks3D
  );
  for (let i = 0; i < geometry.positions.length; i++) {
    geometry.positions[i] += warpOffsets[i];
  }
  geometry.warpOffsets = warpOffsets;

  // Choose the most frontal view as reference view for SH9 illumination & skin/hair palette
  let refViewIndex = 0;
  let minAbsYaw = 999;
  poses.forEach((p, idx) => {
    if (Math.abs(p.yawDeg) < minAbsYaw) {
      minAbsYaw = Math.abs(p.yawDeg);
      refViewIndex = idx;
    }
  });

  geometry.normals = computeSeamlessGridNormals(geometry.positions, geometry.indices, geometry.cols, geometry.rows);
  const shCoeffs = estimateSphericalHarmonics9(views[refViewIndex], poses[refViewIndex], geometry);

  // Gentle Shape-from-Shading (SfS) micro-relief along anterior facial normals (smoothly clamped!)
  const sfsStrength = options.sfsStrength ?? 0.35;
  if (sfsStrength > 0.01 && views[refViewIndex]?.imageData) {
    const refV = views[refViewIndex];
    const refP = poses[refViewIndex];
    const { data, width, height } = refV.imageData;
    const numVerts = geometry.regionT.length;

    // Compute mean skin luminance for normalized reflectance
    let sumLum = 0, cntLum = 0;
    for (let v = 0; v < numVerts; v += 6) {
      const t = geometry.regionT[v];
      if (t < 0.24 || t > 0.55 || geometry.positions[3 * v + 2] < 3.0) continue;
      const [pu, pv] = projectPoint3D(
        [geometry.positions[3 * v], geometry.positions[3 * v + 1], geometry.positions[3 * v + 2]],
        refP, width, height
      );
      const ix = clamp(Math.round(pu), 2, width - 3);
      const iy = clamp(Math.round(pv), 2, height - 3);
      const o = (iy * width + ix) * 4;
      const lum = (0.299 * data[o] + 0.587 * data[o + 1] + 0.114 * data[o + 2]) / 255;
      if (lum > 0.15 && lum < 0.90) { sumLum += lum; cntLum++; }
    }
    const meanLum = Math.max(0.22, sumLum / Math.max(1, cntLum));

    const disp = new Float32Array(numVerts);
    for (let v = 0; v < numVerts; v++) {
      const t = geometry.regionT[v];
      if (t < 0.22 || t > 0.56) continue;
      const vx = geometry.positions[3 * v];
      const vy = geometry.positions[3 * v + 1];
      const vz = geometry.positions[3 * v + 2];
      if (vz < 2.6 || Math.abs(vx) > 5.0) continue;

      // Exclude dark irises/eyebrows/nostrils from SfS depth push so dark pigmentation never dents clay!
      const nx = geometry.normals[3 * v], ny = geometry.normals[3 * v + 1], nz = geometry.normals[3 * v + 2];
      const rnx = refP.R[0] * nx + refP.R[1] * ny + refP.R[2] * nz;
      const rny = refP.R[3] * nx + refP.R[4] * ny + refP.R[5] * nz;
      const rnz = refP.R[6] * nx + refP.R[7] * ny + refP.R[8] * nz;
      if (rnz < 0.50) continue;

      const [pu, pv] = projectPoint3D([vx, vy, vz], refP, width, height);
      const ix = clamp(Math.round(pu), 2, width - 3);
      const iy = clamp(Math.round(pv), 2, height - 3);
      const o = (iy * width + ix) * 4;
      const lum = (0.299 * data[o] + 0.587 * data[o + 1] + 0.114 * data[o + 2]) / 255;
      if (lum < meanLum * 0.58) continue;

      const pred = evalSHIrradiance(shCoeffs, rnx, rny, rnz) * meanLum;
      const diff = clamp((lum - pred) / Math.max(0.18, meanLum), -0.20, 0.20);
      // Strictly protect sculpted 3D eyeballs/eyelids, eyebrows, nostrils, & pillowy vermilion lips from SfS pigment denting!
      const lmsK = geometry.keyLandmarks3D;
      const dEye = Math.min(
        Math.hypot((vx - lmsK.eyeLeft[0]) / 1.9, (vy - lmsK.eyeLeft[1]) / 1.25),
        Math.hypot((vx - lmsK.eyeRight[0]) / 1.9, (vy - lmsK.eyeRight[1]) / 1.25)
      );
      const dMouth = Math.hypot((vx - lmsK.mouthCenter[0]) / 3.2, (vy - lmsK.mouthCenter[1]) / 1.65);
      const dNose = Math.hypot(vx / 2.25, (vy - 0.5 * (lmsK.nasion[1] + lmsK.subnasale[1])) / 2.45);
      const featureGuard =
        (dEye < 1.05 ? 0.0 : clamp((dEye - 1.05) / 0.35, 0, 1)) *
        (dMouth < 1.05 ? 0.0 : clamp((dMouth - 1.05) / 0.35, 0, 1)) *
        (dNose < 1.0 ? 0.0 : clamp((dNose - 1.0) / 0.35, 0, 1));
      const mask =
        featureGuard *
        clamp((vz - 2.6) / 2.2, 0, 1) *
        clamp((5.0 - Math.abs(vx)) / 1.5, 0, 1) *
        clamp((t - 0.22) / 0.05, 0, 1) *
        clamp((0.56 - t) / 0.05, 0, 1);
      disp[v] = diff * 0.11 * sfsStrength * mask;
    }

    // Smooth 3x3 grid box filter on SfS micro-relief so clay stays 100% silky
    const { cols, rows } = geometry;
    for (let r = 1; r < rows - 1; r++) {
      for (let m = 0; m < cols; m++) {
        const mPrev = m === 0 ? cols - 2 : m - 1;
        const mNext = m === cols - 1 ? 1 : m + 1;
        const dAvg =
          0.40 * disp[r * cols + m] +
          0.15 * (disp[(r - 1) * cols + m] + disp[(r + 1) * cols + m] + disp[r * cols + mPrev] + disp[r * cols + mNext]);
        if (Math.abs(dAvg) > 1e-5) {
          const i3 = (r * cols + m) * 3;
          geometry.positions[i3]     += geometry.normals[i3] * dAvg;
          geometry.positions[i3 + 1] += geometry.normals[i3 + 1] * dAvg;
          geometry.positions[i3 + 2] += geometry.normals[i3 + 2] * dAvg;
        }
      }
    }
    geometry.normals = computeSeamlessGridNormals(geometry.positions, geometry.indices, geometry.cols, geometry.rows);
  }

  // Final Post-Warp / Post-SfS Soft-Tissue Polish so RBF landmark warps NEVER re-pinch nose tip or soft pillow lips!
  polishNoseAndLipSoftTissue(
    geometry.positions,
    geometry.regionT,
    geometry.cols,
    geometry.rows,
    weights
  );
  geometry.normals = computeSeamlessGridNormals(geometry.positions, geometry.indices, geometry.cols, geometry.rows);

  // Recompute exact Diffeomorphic 3D Eyelid Blink Deltas AND Recomputed Closed-Lid Normals (`blinkNormalDeltas`)
  // on the final polished mesh & warped 8-point eye landmarks!
  const blinkInfo = computeEyelidBlinkBuffers(
    geometry.positions,
    geometry.regionT,
    weights,
    geometry.keyLandmarks3D,
    geometry.indices,
    geometry.cols,
    geometry.rows,
    geometry.normals
  );
  geometry.blinkDeltas = blinkInfo.blinkDeltas;
  geometry.blinkNormalDeltas = blinkInfo.blinkNormalDeltas;
  geometry.blinkMask = blinkInfo.blinkMask;

  const meanRmsePx = poses.reduce((acc, p) => acc + p.rmsePx, 0) / Math.max(1, poses.length);
  const eyelidSkinRGB = views[refViewIndex]?.shapeMeasurements?.eyelidSkinRGB || [172, 132, 112];

  return {
    weights,
    poses,
    geometry,
    shCoeffs,
    refViewIndex,
    eyelidSkinRGB,
    metrics: {
      elapsedMs: performance.now() - tStart,
      meanRmsePx,
      meanReprojectionErrorPx: meanRmsePx,
      vertexCount: geometry.positions.length / 3,
      triangleCount: geometry.indices.length / 3,
      viewCount: views.length,
    },
  };
}

export const runMultiViewReconstruction = reconstruct3DHeadBust;
