/**
 * VISAGE // FORGE — Pure Vanilla JS Three.js 360° Digital-Human Bust Viewport (v10 Dense)
 *
 * Key v10 Upgrades:
 *  - True 3D Anatomical Eyelid Blink (`aBlinkDelta` + `aBlinkMask` + `uBlink` + `uEyelidSkin` + lash crease)
 *  - Zero-Haze Pure-Specular Wet Cornea & Tear-Meniscus Shader (eliminates milky cataract veil over pupils)
 *  - True Linear-Melanin Multi-Fiber Kajiya-Kay Silk Hair Shader (deep black / rich chestnut, zero grey wash)
 *  - Direct OrbitControls Drag-to-Hair Inertia Coupling (swinging/orbiting the model physically whips hair!)
 *  - Shift + Drag Interactive Head Sway + `triggerBlink()` + `buildExportablePBRMesh()` for `.GLB` export
 */

import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import {
  buildHairGroomState,
  stepHairPhysics,
  syncHairRibbonBuffers,
} from './hairPhysicsGroom.js?v=v81_sculpt_gold';

function shortestAngleDelta(a, b) {
  let d = a - b;
  while (d > Math.PI) d -= Math.PI * 2.0;
  while (d < -Math.PI) d += Math.PI * 2.0;
  return d;
}

function rgbaToCanvasTexture(rgba, texSize, isSRGB = false) {
  const c = document.createElement('canvas');
  c.width = texSize;
  c.height = texSize;
  c.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(rgba), texSize, texSize), 0, 0);
  const tex = new THREE.CanvasTexture(c);
  tex.flipY = true; // Matches textureBaker row 0 => vUv = 1.0 (crown)
  tex.colorSpace = isSRGB ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.generateMipmaps = true;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.needsUpdate = true;
  return tex;
}

/**
 * Custom GLSL Analytic-Derivative Band-Limited Multi-Fiber Kajiya-Kay / Marschner Silk Hair Shader (v13 Anti-Aliased).
 * Dual-pass mode:
 *  - isFringePass = false: Solid depth-writing interior lock core (writes Z-buffer cleanly without transparency sorting pops).
 *  - isFringePass = true:  True alpha-blended fwidth()-feathered silk edges, tapered tips & hairline baby wisps (ZERO pixel stair-stepping!).
 */
function createMarschnerHairMaterial(isFringePass = false) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uKeyDir:     { value: new THREE.Vector3(0.45, 0.56, 0.70).normalize() },
      uFillDir:    { value: new THREE.Vector3(-0.62, 0.24, 0.58).normalize() },
      uRimDir:     { value: new THREE.Vector3(0.0, 0.50, -0.86).normalize() },
      uSheen:      { value: 0.78 },
      uExposure:   { value: 1.04 },
      uFringePass: { value: isFringePass ? 1.0 : 0.0 },
    },
    vertexColors: true,
    side: THREE.DoubleSide,
    transparent: isFringePass,
    depthWrite: !isFringePass,
    depthTest: true,
    polygonOffset: isFringePass,
    polygonOffsetFactor: isFringePass ? -1 : 0,
    polygonOffsetUnits: isFringePass ? -1 : 0,
    alphaToCoverage: !isFringePass,
    vertexShader: /* glsl */ `
      attribute vec3 aTangent;
      attribute float aSeed;
      varying vec3 vColor;
      varying vec3 vLocalPos;
      varying vec3 vWorldPos;
      varying vec3 vNormalW;
      varying vec3 vTangentW;
      varying vec2 vUv;
      varying float vSeed;

      void main() {
        vColor = color;
        vLocalPos = position;
        vUv = uv;
        vSeed = aSeed;
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorldPos = wp.xyz;
        vNormalW = normalize(mat3(modelMatrix) * normal);
        vTangentW = normalize(mat3(modelMatrix) * aTangent);
        gl_Position = projectionMatrix * viewMatrix * wp;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform vec3 uKeyDir;
      uniform vec3 uFillDir;
      uniform vec3 uRimDir;
      uniform float uSheen;
      uniform float uExposure;
      uniform float uFringePass;

      varying vec3 vColor;
      varying vec3 vLocalPos;
      varying vec3 vWorldPos;
      varying vec3 vNormalW;
      varying vec3 vTangentW;
      varying vec2 vUv;
      varying float vSeed;

      float hash1(float n) {
        return fract(sin(n * 127.1 + 311.7) * 43758.5453123);
      }

      float kajiyaSpec(vec3 T, vec3 H, float shift, float expPow) {
        vec3 Ts = normalize(T + vNormalW * shift);
        float dotTH = clamp(dot(Ts, H), -1.0, 1.0);
        float sinTH = sqrt(max(0.0, 1.0 - dotTH * dotTH));
        float dirAtten = smoothstep(-1.0, 0.0, dotTH);
        return dirAtten * pow(sinTH, expPow);
      }

      void main() {
        vec3 V = normalize(cameraPosition - vWorldPos);
        vec3 N = normalize(gl_FrontFacing ? vNormalW : -vNormalW);
        vec3 T = normalize(vTangentW);

        vec3 basePigment = max(vColor, vec3(0.0014));
        bool isUndercoat = (vUv.x < -0.5);
        float outAlpha = 1.0;
        bool isBabyWisp = !isUndercoat && (vSeed >= 199.5);

        float fiberGroove = 1.0;
        float fiberShift = 0.0;

        if (isUndercoat) {
          // Crown & hairline follicular cushion: 100% solid across crown & part (0..0.72), then smooth g^2.3
          // follicular-pore fade across the outer ~1.0 cm (0.72..1.00) down to 0% right at the hairline!
          float uAz = -vUv.x - 1.0;
          float poreStipple = 0.58 + 0.42 * sin(uAz * 480.0 + vUv.y * 48.0 + sin(uAz * 119.0) * 2.8);
          float g = 1.0 - smoothstep(0.70, 1.00, vUv.y);
          outAlpha = pow(g, 2.3) * mix(1.0, poreStipple, smoothstep(0.70, 0.98, vUv.y));
          fiberGroove = 0.82 + 0.14 * poreStipple;
        } else {
          float rawBucket = isBabyWisp ? (floor(vSeed) - 200.0) : floor(vSeed);
          float vDensity  = clamp(rawBucket * 0.01, 0.12, 1.0);
          float seedFrac  = fract(vSeed);

          // Nyquist-Accurate Individual Hair Fiber Resolution (2.5 fibers per baby wisp, 4..6 per lock so fFw < 0.75
          // and EVERY hairline strand resolves into crisp 1-1.5px individual hairs instead of flat grey rectangles!)
          float numFibers = isBabyWisp ? 2.5 : mix(4.0, 6.5, vDensity);
          float uWarped = vUv.x + 0.008 * sin(vUv.y * 5.0 + seedFrac * 6.28318);
          float fCoord = uWarped * numFibers + seedFrac * 3.0;
          float fFw = fwidth(fCoord);
          float detailFade = 1.0 - smoothstep(0.55, 1.45, fFw);

          float fId = floor(fCoord);
          float fLocal = fract(fCoord);
          float fHash = hash1(fId + seedFrac * 37.0);

          float rawFiberCore = sin(clamp(fLocal, 0.0, 1.0) * 3.14159265);
          // Narrow crisp cylindrical strand profile on outer wisps so real skin shows cleanly between individual hairs!
          float crispStrand = pow(rawFiberCore, isBabyWisp ? 1.55 : mix(1.25, 0.62, vDensity));
          float fiberCore = mix(isBabyWisp ? 0.48 : 0.78, crispStrand, detailFade);

          // Screen-space anti-aliased lateral ribbon edge & tip taper!
          float edgeDist = abs(vUv.x - 0.5) * 2.0;
          float edgeFw = clamp(fwidth(edgeDist) * 1.45, 0.04, 0.38);
          float tipStart = mix(0.58, 0.94, mix(0.76, fHash, detailFade));
          float tipFw = clamp(fwidth(vUv.y) * 1.4, 0.03, 0.18);
          float tipFade = 1.0 - smoothstep(tipStart - tipFw, min(1.0, tipStart + 0.16 + tipFw), vUv.y);
          float lateralFeather = 1.0 - smoothstep(
            1.0 - max(mix(0.38, 0.20, vDensity), edgeFw * 2.0),
            1.0,
            edgeDist + (1.0 - rawFiberCore) * 0.24 * detailFade
          );

          // Physical-millimeter skin-pore emergence (2-8 mm along shaft, NEVER 4 cm grey strips!)
          float rootSpan = isBabyWisp
            ? max(0.18, tipFw * 1.5)
            : mix(0.042, 0.008, smoothstep(0.35, 0.90, vDensity));
          float rootEmerge = smoothstep(0.0, rootSpan, vUv.y);

          // Gradual Density Incrementation:
          // Outer ~1 cm hairline strands (vDensity < 0.72) split into crisp individual hairs over warm skin,
          // then smoothly coalesce into 100% dense hair mass deeper inside!
          float densityCoalesce = smoothstep(0.68, 0.96, vDensity);
          float shaftSolid = isBabyWisp
            ? 0.0
            : (1.0 - smoothstep(0.55, 0.90, vUv.y)) * (1.0 - smoothstep(0.52, 0.88, edgeDist)) * densityCoalesce;
          float rawAlpha = mix(fiberCore, 1.0, shaftSolid * 0.92) * tipFade * lateralFeather * rootEmerge;
          outAlpha = clamp(rawAlpha * vDensity, 0.0, 1.0);

          vec3 B = normalize(cross(N, T));
          float cylNx = (fLocal - 0.5) * 2.0 * detailFade;
          N = normalize(N + B * (cylNx * 0.34));
          fiberGroove = mix(0.92, (0.62 + 0.48 * rawFiberCore) * (0.86 + 0.28 * fHash), detailFade);
          fiberShift = 0.045 * (fHash - 0.5) * detailFade;
        }

        if (uFringePass < 0.5) {
          // Pass 1 (Opaque Z-writing inner crown & 93%+ dense core ONLY):
          // Raising cutoff to 0.93 eliminates ANY 0.68->1.00 black sawtooth cliff along the hairline!
          if (outAlpha < 0.93) discard;
          outAlpha = 1.0;
        } else {
          // Pass 2 (Continuous 0.01..0.93 Alpha-Blended Follicle Density Ramp, Baby Hairs & Split Tips):
          if (outAlpha < 0.008 || outAlpha >= 0.93) discard;
        }

        // Wrapped Kajiya diffuse (proportional to basePigment — ZERO grey wash!)
        float diffKey  = clamp(dot(N, uKeyDir) * 0.54 + 0.46, 0.0, 1.0);
        float diffFill = clamp(dot(N, uFillDir) * 0.5 + 0.5, 0.0, 1.0);
        float hemiUp   = clamp(N.y * 0.5 + 0.5, 0.0, 1.0);

        vec3 HKey  = normalize(uKeyDir + V);
        vec3 HFill = normalize(uFillDir + V);
        vec3 HRim  = normalize(uRimDir + V);

        // Crisp refractive keratin cuticle highlight (n=1.55) — sleek strand separation without silvery-grey wash!
        float specR1 = kajiyaSpec(T, HKey, -0.09 + fiberShift, 118.0) * 0.82 +
                       kajiyaSpec(T, HKey, -0.08 + fiberShift, 52.0) * 0.18;
        float specR2 = kajiyaSpec(T, HFill, -0.09 + fiberShift, 72.0) * 0.26;
        float specRim = kajiyaSpec(T, HRim, -0.05 + fiberShift, 54.0) * 0.32;

        float specTRT = kajiyaSpec(T, HKey, 0.13 + fiberShift, 52.0);
        vec3 trtTint = clamp(basePigment * vec3(3.8, 2.9, 2.2) + vec3(0.008, 0.006, 0.005), 0.0, 0.65);

        float wispSpecAtten = isBabyWisp ? 0.14 : smoothstep(0.22, 0.78, outAlpha);
        float capAtten = (isUndercoat ? 0.14 : 1.0) * wispSpecAtten;

        // Volumetric behind-neck & sub-mandibular internal hair pocket self-occlusion:
        // Strictly darkens interior hair BEHIND the neck coronal center plane (vLocalPos.z < +0.35 cm)
        // so forward-draping shoulder locks (z > +0.8 cm) stay warm & luminous right over the neck/clavicle border!
        float yPocket = smoothstep(1.6, -2.0, vLocalPos.y) * (1.0 - smoothstep(-15.5, -19.0, vLocalPos.y));
        float xPocket = 1.0 - smoothstep(5.2, 8.8, abs(vLocalPos.x));
        float zBehindNeck = smoothstep(0.35, -2.10, vLocalPos.z);
        float subJawRoof = smoothstep(1.8, -1.4, vLocalPos.y) *
                           (1.0 - smoothstep(4.2, 7.2, abs(vLocalPos.x))) *
                           smoothstep(0.95, -1.35, vLocalPos.z);
        float innerBackLayer = (!gl_FrontFacing && !isUndercoat)
          ? (0.40 * smoothstep(2.5, -1.6, vLocalPos.y) * smoothstep(0.85, -1.6, vLocalPos.z))
          : 0.0;
        float pocketDepth = clamp(max(yPocket * xPocket * zBehindNeck, subJawRoof * 0.88) + innerBackLayer, 0.0, 1.0);
        float diffuseOcc = mix(1.0, 0.11, pocketDepth);
        float specOcc    = mix(1.0, 0.02, smoothstep(0.06, 0.55, pocketDepth));

        vec3 col = basePigment * fiberGroove * diffuseOcc * (
          0.34 +
          0.94 * diffKey +
          0.38 * diffFill +
          0.22 * hemiUp
        );

        col += vec3(1.0, 0.985, 0.965) * (specR1 + specR2 + specRim * 0.35) * (0.068 * uSheen * capAtten * fiberGroove * specOcc);
        col += trtTint * specTRT * (0.26 * uSheen * capAtten * fiberGroove * specOcc);
        col += trtTint * specRim * (0.15 * uSheen * capAtten * specOcc);

        gl_FragColor = vec4(col * uExposure, outAlpha);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
  });
}

/**
 * Zero-Haze Additive Wet Cornea & Tear-Meniscus Shader.
 * Adds crisp dual studio catchlights + glancing Schlick-Fresnel wet sheen with ZERO white diffuse veil over dark pupils!
 */
function createWetCorneaMaterial() {
  return new THREE.ShaderMaterial({
    uniforms: {
      uKeyDir:  { value: new THREE.Vector3(0.42, 0.48, 0.77).normalize() },
      uFillDir: { value: new THREE.Vector3(-0.52, 0.26, 0.81).normalize() },
      uBlink:   { value: 0.0 },
    },
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    vertexShader: /* glsl */ `
      varying vec3 vWorldPos;
      varying vec3 vNormalW;
      varying vec3 vLocalPos;
      void main() {
        vLocalPos = position;
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorldPos = wp.xyz;
        vNormalW = normalize(mat3(modelMatrix) * normal);
        gl_Position = projectionMatrix * viewMatrix * wp;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform vec3 uKeyDir;
      uniform vec3 uFillDir;
      uniform float uBlink;
      varying vec3 vWorldPos;
      varying vec3 vNormalW;
      varying vec3 vLocalPos;

      void main() {
        float openFactor = 1.0 - smoothstep(0.15, 0.82, uBlink);
        if (openFactor <= 0.002) discard;

        vec3 N = normalize(vNormalW);
        vec3 V = normalize(cameraPosition - vWorldPos);
        float NoV = clamp(dot(N, V), 0.0, 1.0);
        // Fade cleanly at grazing 90° profile so zero glowing cornea bubble ever protrudes past the eyelids!
        float viewMask = smoothstep(0.22, 0.52, NoV);

        float rNorm = length(vec2(vLocalPos.x / 0.44, vLocalPos.y / 0.30));
        float edgeMask = 1.0 - smoothstep(0.62, 0.96, rNorm);

        vec3 HKey  = normalize(uKeyDir + V);
        vec3 HFill = normalize(uFillDir + V);

        float catchKey  = pow(max(0.0, dot(N, HKey)), 520.0) * 1.15;
        float catchFill = pow(max(0.0, dot(N, HFill)), 340.0) * 0.30;

        vec3 spec = vec3(1.0, 0.99, 0.97) * (catchKey + catchFill);
        gl_FragColor = vec4(spec * edgeMask * viewMask * openFactor, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
  });
}

export class BustViewport3D {
  constructor(hostElement) {
    this.host = hostElement;
    this.shaderMode = 'pbr';
    this.autoSpin = false;
    this.showLandmarks3D = false;

    // Digital-Human Realism State (wind = 0.00 by default so hair rests calmly until user interacts or turns up wind!)
    this.hairEnabled = true;
    this.liveMotionEnabled = true;
    this.skinSSSEnabled = true;
    this.windStrength = 0.0;
    this.windAzimuthRad = (35 * Math.PI) / 180;
    this.hairStiffnessScale = 1.0;
    this.headTiltDeg = { pitch: 0, yaw: 0, roll: 0 };
    this._prevRigidEuler = new THREE.Euler(0, 0, 0, 'YXZ');

    // Explicit Blink Animation State
    this._blinkValue = 0.0;
    this._manualBlinkTimer = -1.0;
    this._nextAutoBlinkTime = 1.9;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0c0e14);

    const w = Math.max(320, hostElement.clientWidth || 800);
    const h = Math.max(240, hostElement.clientHeight || 600);

    this.camera = new THREE.PerspectiveCamera(30, w / h, 0.5, 400);
    this.camera.position.set(0, -0.3, 62);

    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setSize(w, h);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.98;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    hostElement.innerHTML = '';
    hostElement.appendChild(this.renderer.domElement);
    this.canvas = this.renderer.domElement;

    this.controls = new OrbitControls(this.camera, this.canvas);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.075;
    this.controls.target.set(0, -2.2, 0);
    this.controls.minDistance = 24;
    this.controls.maxDistance = 125;
    this.controls.maxPolarAngle = Math.PI * 0.72;
    this.controls.minPolarAngle = Math.PI * 0.22;

    this._setupLights();
    this._setupPedestalGrid();
    this._bindShiftHeadDrag();

    this.bustGroup = new THREE.Group();
    this.scene.add(this.bustGroup);

    this.bustMesh = null;
    this.wireMesh = null;
    this.landmarkGroup = new THREE.Group();
    this.landmarkGroup.visible = false;
    this.bustGroup.add(this.landmarkGroup);

    this.corneaGroup = new THREE.Group();
    this.bustGroup.add(this.corneaGroup);

    this.hairGroup = new THREE.Group();
    this.bustGroup.add(this.hairGroup);
    this.hairRibbonMesh = null;
    this.hairFringeMesh = null;
    this.hairFlyawayLines = null;
    this.hairState = null;
    this.hairMaterial = createMarschnerHairMaterial(false);
    this.hairFringeMaterial = createMarschnerHairMaterial(true);

    this._textures = {};
    this._materials = this._createMaterials();
    this.corneaMaterial = createWetCorneaMaterial();

    // Motion & Orbit-to-Hair Inertia Trackers
    this._clockTime = 0;
    this._lastFrameTime = performance.now();
    this._prevGroupEuler = new THREE.Euler(0, 0, 0);
    this._prevGroupPos = new THREE.Vector3(0, 0, 0);
    this._prevAzimuth = this.controls.getAzimuthalAngle();
    this._prevPolar = this.controls.getPolarAngle();
    this._orbitAngularVel = { yaw: 0, pitch: 0 };
    this._impulseVel = { pitch: 0, yaw: 0, roll: 0 };
    this._impulseOffset = { pitch: 0, yaw: 0, roll: 0 };

    this._resizeObserver = new ResizeObserver(() => this.resize());
    this._resizeObserver.observe(hostElement);

    this._raf = null;
    this._animate = this._animate.bind(this);
    this._animate();
  }

  _setupLights() {
    // Dimensional studio portrait lighting: off-axis Rembrandt/Loop key (`18, 19, 31`) brings out crisp 3D relief on the
    // nasal bridge sidewalls, rounded tip, brow rim & cheekbones in 0-deg front view, while warm reflector ground (`0x907564`) keeps submental shading natural!
    this.hemiLight = new THREE.HemisphereLight(0xf4f7fd, 0x907564, 0.54);
    this.scene.add(this.hemiLight);

    this.keyLight = new THREE.DirectionalLight(0xfffaf3, 1.12);
    this.keyLight.position.set(18, 19, 31);
    this.scene.add(this.keyLight);

    this.fillLight = new THREE.DirectionalLight(0xeef4ff, 0.24);
    this.fillLight.position.set(-22, 4, 28);
    this.scene.add(this.fillLight);

    this.rimLight = new THREE.DirectionalLight(0xd9e6ff, 0.34);
    this.rimLight.position.set(0, 18, -32);
    this.scene.add(this.rimLight);

    this.ambient = new THREE.AmbientLight(0xffffff, 0.16);
    this.scene.add(this.ambient);
  }

  _setupPedestalGrid() {
    const ringGeo = new THREE.RingGeometry(12.6, 12.9, 96);
    ringGeo.rotateX(-Math.PI / 2);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x3b82f6,
      transparent: true,
      opacity: 0.22,
      side: THREE.DoubleSide,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.position.y = -17.95;
    this.scene.add(ring);

    const grid = new THREE.PolarGridHelper(20, 12, 6, 64, 0x1e2536, 0x161b28);
    grid.position.y = -18.00;
    this.scene.add(grid);
  }

  /**
   * Hold Shift + Drag in viewport to directly tilt & flick the 3D head while hair reacts!
   */
  _bindShiftHeadDrag() {
    let draggingHead = false;
    let lastX = 0;
    let lastY = 0;

    this.canvas.addEventListener('pointerdown', (ev) => {
      if (ev.shiftKey) {
        draggingHead = true;
        this.controls.enabled = false;
        lastX = ev.clientX;
        lastY = ev.clientY;
        this.canvas.setPointerCapture(ev.pointerId);
      }
    });

    this.canvas.addEventListener('pointermove', (ev) => {
      if (!draggingHead) return;
      const dx = ev.clientX - lastX;
      const dy = ev.clientY - lastY;
      lastX = ev.clientX;
      lastY = ev.clientY;
      this.headTiltDeg.yaw = Math.max(-35, Math.min(35, this.headTiltDeg.yaw + dx * 0.32));
      this.headTiltDeg.pitch = Math.max(-22, Math.min(22, this.headTiltDeg.pitch + dy * 0.24));
    });

    const endDrag = () => {
      if (draggingHead) {
        draggingHead = false;
        this.controls.enabled = true;
        // Spring back smoothly to neutral when released!
        this._impulseOffset.yaw += this.headTiltDeg.yaw;
        this._impulseOffset.pitch += this.headTiltDeg.pitch;
        this.headTiltDeg.yaw = 0;
        this.headTiltDeg.pitch = 0;
      }
    };
    this.canvas.addEventListener('pointerup', endDrag);
    this.canvas.addEventListener('pointercancel', endDrag);
  }

  _createMaterials() {
    const pbr = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      roughness: 1.0,
      metalness: 0.0,
      clearcoat: 0.0,
      sheen: 0.05,
      sheenRoughness: 0.72,
      sheenColor: new THREE.Color(0xffe4d6),
      normalScale: new THREE.Vector2(0.18, 0.18),
    });

    this._skinUniforms = {
      uBlink: { value: 0.0 },
      uEyelidSkin: { value: new THREE.Vector3(0.32, 0.17, 0.12) },
      uSSSEnabled: { value: 1.0 },
      uEyeLeftPos: { value: new THREE.Vector3(-2.82, 1.56, 5.42) },
      uEyeRightPos: { value: new THREE.Vector3(2.82, 1.56, 5.42) },
      uEyeLeftBounds: { value: new THREE.Vector4(-2.83, 1.56, 1.36, 0.30) },
      uEyeRightBounds: { value: new THREE.Vector4(2.83, 1.56, 1.36, 0.30) },
    };

    // Inject 3D Anatomical Eyelid Blink Deformation + Zero-Z-Fighting Wet Corneal Catchlights + SSS Wrap
    pbr.onBeforeCompile = (shader) => {
      shader.uniforms.uBlink = this._skinUniforms.uBlink;
      shader.uniforms.uEyelidSkin = this._skinUniforms.uEyelidSkin;
      shader.uniforms.uSSSEnabled = this._skinUniforms.uSSSEnabled;
      shader.uniforms.uEyeLeftPos = this._skinUniforms.uEyeLeftPos;
      shader.uniforms.uEyeRightPos = this._skinUniforms.uEyeRightPos;
      shader.uniforms.uEyeLeftBounds = this._skinUniforms.uEyeLeftBounds;
      shader.uniforms.uEyeRightBounds = this._skinUniforms.uEyeRightBounds;

      shader.vertexShader =
        `
        attribute vec3 aBlinkDelta;
        attribute vec3 aBlinkNormalDelta;
        attribute vec2 aBlinkMask;
        uniform float uBlink;
        varying vec2 vBlinkMask;
        varying float vBlinkLiftY;
        varying vec3 vObjPos;
        varying mat3 vNormalMat;
        ` + shader.vertexShader;

      shader.vertexShader = shader.vertexShader.replace(
        '#include <beginnormal_vertex>',
        `
        #include <beginnormal_vertex>
        if (uBlink > 0.001) {
          objectNormal = normalize(objectNormal + aBlinkNormalDelta * uBlink);
        }
        `
      );

      shader.vertexShader = shader.vertexShader.replace(
        '#include <begin_vertex>',
        `
        #include <begin_vertex>
        vBlinkMask = aBlinkMask;
        vBlinkLiftY = aBlinkDelta.y;
        vObjPos = position;
        vNormalMat = normalMatrix;
        transformed += aBlinkDelta * uBlink;
        `
      );

      shader.fragmentShader =
        `
        uniform float uBlink;
        uniform vec3 uEyelidSkin;
        uniform float uSSSEnabled;
        uniform vec3 uEyeLeftPos;
        uniform vec3 uEyeRightPos;
        uniform vec4 uEyeLeftBounds;
        uniform vec4 uEyeRightBounds;
        varying vec2 vBlinkMask;
        varying float vBlinkLiftY;
        varying vec3 vObjPos;
        varying mat3 vNormalMat;
        ` + shader.fragmentShader;

      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <map_fragment>',
        `
        #include <map_fragment>
        if (uBlink > 0.01 && vBlinkMask.x > 0.01) {
          float cover = smoothstep(0.04, 0.56, uBlink) * smoothstep(0.01, 0.88, vBlinkMask.x);
          float lashLine = vBlinkMask.y * smoothstep(0.42, 0.92, uBlink);
          // Natural convex tarsal highlight near center (-vBlinkLiftY peak) + soft orbital-fold shading toward upper rim!
          float domeHighlight = clamp(-vBlinkLiftY * 1.15, 0.0, 0.32);
          float upperSocketDepth = 1.0 - 0.13 * (1.0 - clamp(vBlinkMask.x * 1.15, 0.0, 1.0));
          float tarsalShade = (0.93 + 0.18 * domeHighlight) * upperSocketDepth;
          float poreMicro = fract(sin(dot(floor(vObjPos.xy * 115.0), vec2(12.9898, 78.233))) * 43758.5453);
          vec3 lidCol = uEyelidSkin * (tarsalShade + (poreMicro - 0.5) * 0.015);
          lidCol = mix(lidCol, lidCol * vec3(0.14, 0.10, 0.09), clamp(lashLine * 0.86, 0.0, 0.86));
          diffuseColor.rgb = mix(diffuseColor.rgb, lidCol, clamp(cover, 0.0, 1.0));
        }
        `
      );

      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <roughnessmap_fragment>',
        `
        #include <roughnessmap_fragment>
        {
          bool isLeftEyeR = (vObjPos.x < 0.0);
          vec4 eBndR = isLeftEyeR ? uEyeLeftBounds : uEyeRightBounds;
          float dxNR = (vObjPos.x - eBndR.x) / max(0.85, eBndR.z);
          float almHR = eBndR.w * pow(max(0.0, 1.0 - dxNR * dxNR), 0.72);
          float inGlobeR = (1.0 - smoothstep(0.82, 0.99, abs(dxNR))) *
                           (1.0 - smoothstep(almHR * 0.76, almHR * 1.02, abs(vObjPos.y - eBndR.y)));
          float openEyeRough = (1.0 - smoothstep(0.10, 0.62, uBlink)) * inGlobeR;
          if (openEyeRough > 0.005) {
            roughnessFactor = mix(roughnessFactor, 0.09, openEyeRough * 0.88);
          }
        }
        `
      );

      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <normal_fragment_maps>',
        `
        #include <normal_fragment_maps>
        // Suppress baked open-eye iris/lash normal map when eyelid is closed (uBlink > 0) so closed lids use smooth 3D tarsal geometry normals!
        if (uBlink > 0.01 && vBlinkMask.x > 0.01) {
          float closedNMask = smoothstep(0.04, 0.55, uBlink) * smoothstep(0.02, 0.52, vBlinkMask.x);
          normal = normalize(mix(normal, normalize(nonPerturbedNormal), closedNMask * 0.94));
        }
        // Analytical 3D Spherical Eyeball + Glassy Convex Corneal Meniscus Normal across the exact solved palpebral aperture:
        {
          bool isLeftEyeN = (vObjPos.x < 0.0);
          vec3 eCtr = isLeftEyeN ? uEyeLeftPos : uEyeRightPos;
          vec4 eBnd = isLeftEyeN ? uEyeLeftBounds : uEyeRightBounds;
          float dxN = (vObjPos.x - eBnd.x) / max(0.85, eBnd.z);
          float almH = eBnd.w * pow(max(0.0, 1.0 - dxN * dxN), 0.72);
          float inGlobeN = (1.0 - smoothstep(0.80, 0.99, abs(dxN))) *
                           (1.0 - smoothstep(almH * 0.74, almH * 1.02, abs(vObjPos.y - eBnd.y)));
          float openEyeNorm = (1.0 - smoothstep(0.10, 0.62, uBlink)) * inGlobeN;
          if (openEyeNorm > 0.005) {
            vec3 ballCenter = eCtr - vec3(0.0, 0.0, 1.24);
            vec3 scleraObjN = normalize(vObjPos - ballCenter);

            vec3 cornCenter = eCtr - vec3(0.0, 0.0, 0.74);
            vec2 dCornea = (vObjPos.xy - eCtr.xy) / vec2(0.57, 0.54);
            float rCorn = length(dCornea);
            float corneaDomeMask = 1.0 - smoothstep(0.66, 1.04, rCorn);
            vec3 corneaObjN = normalize(vObjPos - cornCenter);

            vec3 eyeObjNorm = normalize(mix(scleraObjN, corneaObjN, corneaDomeMask * 0.76));
            vec3 eyeViewNorm = normalize(vNormalMat * eyeObjNorm);
            normal = normalize(mix(normal, eyeViewNorm, openEyeNorm * 0.90));
          }
        }
        `
      );

      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <lights_fragment_end>',
        `
        #include <lights_fragment_end>
        if (uSSSEnabled > 0.5) {
          float sssRim = pow(1.0 - saturate(dot(geometryNormal, geometryViewDir)), 2.4);
          reflectedLight.directDiffuse += diffuseColor.rgb * vec3(0.11, 0.036, 0.020) * sssRim;
        }
        // High-Precision 3D Corneal Refraction Caustics, Wet Tear-Line Meniscus & Studio Softbox Catchlights:
        {
          bool isLeftEyeG = (vObjPos.x < 0.0);
          vec3 ePos = isLeftEyeG ? uEyeLeftPos : uEyeRightPos;
          vec4 eBndG = isLeftEyeG ? uEyeLeftBounds : uEyeRightBounds;
          float dxG = (vObjPos.x - eBndG.x) / max(0.85, eBndG.z);
          float almHG = eBndG.w * pow(max(0.0, 1.0 - dxG * dxG), 0.72);
          float inGlobe = (1.0 - smoothstep(0.80, 0.98, abs(dxG))) *
                          (1.0 - smoothstep(almHG * 0.74, almHG * 1.00, abs(vObjPos.y - eBndG.y)));
          float openEye = (1.0 - smoothstep(0.10, 0.62, uBlink)) * inGlobe;
          if (openEye > 0.005) {
            vec2 dC = (vObjPos.xy - ePos.xy) / vec2(0.56, 0.54);
            float rIris = length(dC);
            float irisMask = 1.0 - smoothstep(0.72, 1.04, rIris);

            vec3 cNorm = normalize(vNormalMat * normalize(mix(vObjPos - (ePos - vec3(0.0, 0.0, 1.24)), vObjPos - (ePos - vec3(0.0, 0.0, 0.74)), irisMask * 0.78)));
            float NoV_e = saturate(dot(cNorm, geometryViewDir));
            float viewGate = smoothstep(0.08, 0.42, NoV_e);

            // 1) Anterior-Chamber Corneal Refraction Caustic Glow on opposite lower-medial iris stroma
            if (irisMask > 0.01) {
              float causticFocus = clamp(-dC.x * 0.32 - dC.y * 0.55 + 0.24, 0.0, 1.0) * (1.0 - smoothstep(0.28, 0.88, rIris));
              reflectedLight.directDiffuse += diffuseColor.rgb * (0.20 * causticFocus + 0.05 * (1.0 - rIris * 0.6)) * irisMask * openEye;
            }

            // 2) Natural Soft-Edged Studio Window Catchlights + Wet Lower Tear-Line Meniscus (never hard CGI white dots!)
            vec3 kDir  = normalize(vec3(0.34, 0.42, 0.84));
            vec3 fDir  = normalize(vec3(-0.46, 0.26, 0.85));
            vec3 Hk = normalize(kDir + geometryViewDir);
            vec3 Hf = normalize(fDir + geometryViewDir);

            float specKeyCore = pow(max(0.0, dot(cNorm, Hk)), 280.0) * 0.56;
            float specKeyHalo = pow(max(0.0, dot(cNorm, Hk)), 58.0)  * 0.042;
            float specFill    = pow(max(0.0, dot(cNorm, Hf)), 320.0) * 0.14;
            float wetFresnel  = pow(1.0 - NoV_e, 4.2) * 0.024;

            // Wet lower tear-meniscus sparkle right along the lower lid margin
            float lowerTearDist = abs((vObjPos.y - (eBndG.y - almHG * 0.82)) / 0.032);
            float tearMeniscus = exp(-lowerTearDist * lowerTearDist) * (1.0 - smoothstep(0.60, 0.90, abs(dxG))) * pow(max(0.0, dot(geometryNormal, Hk)), 32.0) * 0.11;

            float corneaFocus = mix(0.22, 1.0, irisMask);
            vec3 eyeSpec = vec3(1.0, 0.985, 0.96) * ((specKeyCore + specKeyHalo + specFill) * corneaFocus + tearMeniscus)
                         + vec3(0.93, 0.97, 1.0) * (wetFresnel * mix(0.45, 1.0, irisMask));
            reflectedLight.directSpecular += eyeSpec * openEye * viewGate;
          }
        }
        `
      );
    };
    pbr.customProgramCacheKey = () => 'visage_sss_blink_cornea_v66';

    const injectGeomBlink = (mat, keyName) => {
      mat.onBeforeCompile = (shader) => {
        shader.uniforms.uBlink = this._skinUniforms.uBlink;
        shader.vertexShader =
          `
          attribute vec3 aBlinkDelta;
          attribute vec3 aBlinkNormalDelta;
          uniform float uBlink;
          ` + shader.vertexShader;
        shader.vertexShader = shader.vertexShader.replace(
          '#include <beginnormal_vertex>',
          `
          #include <beginnormal_vertex>
          if (uBlink > 0.001) {
            objectNormal = normalize(objectNormal + aBlinkNormalDelta * uBlink);
          }
          `
        );
        shader.vertexShader = shader.vertexShader.replace(
          '#include <begin_vertex>',
          `
          #include <begin_vertex>
          transformed += aBlinkDelta * uBlink;
          `
        );
      };
      mat.customProgramCacheKey = () => keyName;
    };

    const clay = new THREE.MeshStandardMaterial({
      color: 0xd8cfc8,
      roughness: 0.48,
      metalness: 0.03,
    });
    injectGeomBlink(clay, 'visage_clay_blink_v46');

    const normals = new THREE.MeshNormalMaterial({ flatShading: false });
    injectGeomBlink(normals, 'visage_normals_blink_v46');
    const albedoMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const coverageMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

    const wireOverlay = new THREE.MeshBasicMaterial({
      color: 0x60a5fa,
      wireframe: true,
      transparent: true,
      opacity: 0.24,
      depthTest: true,
    });
    injectGeomBlink(wireOverlay, 'visage_wire_blink_v46');

    return { pbr, clay, normals, albedoMat, coverageMat, wireOverlay };
  }

  /**
   * Primary studio entry point called by `app.js`: upload reconstructed 360° bust, blink buffers, PBR maps & wet eye corneas.
   */
  updateBust(recon, baked) {
    const geometry = recon.geometry;
    const eyelidSkinRGB = recon.eyelidSkinRGB;

    for (const key of Object.keys(this._textures)) {
      const oldTex = this._textures[key];
      if (oldTex) {
        if (oldTex.image && oldTex.image.width) {
          oldTex.image.width = 1;
          oldTex.image.height = 1;
        }
        oldTex.dispose();
      }
    }

    const sz = baked.texSize;
    const maxAniso = Math.min(16, this.renderer.capabilities.getMaxAnisotropy());
    const setAniso = (t) => { t.anisotropy = maxAniso; return t; };

    this._textures.albedo    = setAniso(rgbaToCanvasTexture(baked.albedoData, sz, true));
    this._textures.normal    = setAniso(rgbaToCanvasTexture(baked.normalData, sz, false));
    this._textures.roughness = setAniso(rgbaToCanvasTexture(baked.roughnessData, sz, false));
    this._textures.coverage  = setAniso(rgbaToCanvasTexture(baked.coverageData, sz, true));

    if (eyelidSkinRGB && eyelidSkinRGB.length === 3) {
      const c = new THREE.Color().setRGB(
        Math.max(0.02, eyelidSkinRGB[0] / 255),
        Math.max(0.02, eyelidSkinRGB[1] / 255),
        Math.max(0.02, eyelidSkinRGB[2] / 255),
        THREE.SRGBColorSpace
      );
      // Warm tarsal eyelid micro-tone (~97% luminance, subtle natural warmth)
      this._skinUniforms.uEyelidSkin.value.set(c.r * 0.98, c.g * 0.95, c.b * 0.94);
    }

    this._materials.pbr.map = this._textures.albedo;
    this._materials.pbr.normalMap = this._textures.normal;
    this._materials.pbr.roughnessMap = this._textures.roughness;
    this._materials.pbr.needsUpdate = true;

    this._materials.clay.normalMap = null;
    this._materials.clay.needsUpdate = true;

    this._materials.albedoMat.map = this._textures.albedo;
    this._materials.albedoMat.needsUpdate = true;

    this._materials.coverageMat.map = this._textures.coverage;
    this._materials.coverageMat.needsUpdate = true;

    const bufGeo = new THREE.BufferGeometry();
    bufGeo.setAttribute('position', new THREE.BufferAttribute(geometry.positions, 3));
    bufGeo.setAttribute('normal', new THREE.BufferAttribute(geometry.normals, 3));
    bufGeo.setAttribute('uv', new THREE.BufferAttribute(geometry.uvs, 2));

    const numVerts = geometry.positions.length / 3;
    const blinkDeltas = geometry.blinkDeltas || new Float32Array(numVerts * 3);
    const blinkNormalDeltas = geometry.blinkNormalDeltas || new Float32Array(numVerts * 3);
    const blinkMask = geometry.blinkMask || new Float32Array(numVerts * 2);
    bufGeo.setAttribute('aBlinkDelta', new THREE.BufferAttribute(blinkDeltas, 3));
    bufGeo.setAttribute('aBlinkNormalDelta', new THREE.BufferAttribute(blinkNormalDeltas, 3));
    bufGeo.setAttribute('aBlinkMask', new THREE.BufferAttribute(blinkMask, 2));
    bufGeo.setIndex(new THREE.BufferAttribute(geometry.indices, 1));
    bufGeo.computeBoundingSphere();

    if (this.bustMesh) {
      this.bustMesh.geometry.dispose();
      this.bustGroup.remove(this.bustMesh);
    }
    if (this.wireMesh) {
      this.bustGroup.remove(this.wireMesh);
    }

    this.bustMesh = new THREE.Mesh(bufGeo, this._materials.pbr);
    this.bustMesh.castShadow = false;
    this.bustMesh.receiveShadow = false;
    this.bustGroup.add(this.bustMesh);

    this.wireMesh = new THREE.Mesh(bufGeo, this._materials.wireOverlay);
    this.wireMesh.scale.setScalar(1.0012);
    this.wireMesh.visible = this.shaderMode === 'wireframe';
    this.bustGroup.add(this.wireMesh);

    this.updateCornealDomes(geometry.keyLandmarks3D, geometry, baked);
    this._rebuildLandmarks3D(geometry.keyLandmarks3D);
    this.setShaderMode(this.shaderMode);
  }

  /**
   * Update exact corneal bounds/iris centers AND synthesize delicate 3D Curved Tapered Eyelash Cilia (`VisageEyelashes3D`)!
   */
  updateCornealDomes(landmarks3d, geometry = null, baked = null) {
    while (this.corneaGroup.children.length > 0) {
      const ch = this.corneaGroup.children.pop();
      if (ch.geometry) ch.geometry.dispose();
    }
    this.eyelashMesh = null;
    if (!landmarks3d || !this._skinUniforms) return;

    const setEyeUniforms = (isLeft) => {
      const pCtr = isLeft ? landmarks3d.eyeLeft : landmarks3d.eyeRight;
      const pIn  = isLeft ? landmarks3d.eyeLeftInner : landmarks3d.eyeRightInner;
      const pOut = isLeft ? landmarks3d.eyeLeftOuter : landmarks3d.eyeRightOuter;
      const pUp  = isLeft ? landmarks3d.eyeLeftUpper : landmarks3d.eyeRightUpper;
      const pLo  = isLeft ? landmarks3d.eyeLeftLower : landmarks3d.eyeRightLower;
      if (!pCtr) return;
      const cy = pUp && pLo ? 0.5 * (pUp[1] + pLo[1]) + 0.015 : pCtr[1];
      const posU = isLeft ? this._skinUniforms.uEyeLeftPos : this._skinUniforms.uEyeRightPos;
      posU.value.set(pCtr[0], cy, pCtr[2]);
      if (pIn && pOut && pUp && pLo) {
        const midX = 0.5 * (pIn[0] + pOut[0]);
        const midY = 0.5 * (pUp[1] + pLo[1]);
        const halfW = Math.max(0.95, 0.5 * Math.abs(pOut[0] - pIn[0]));
        const halfH = Math.max(0.18, 0.58 * (pUp[1] - pLo[1]));
        const bndU = isLeft ? this._skinUniforms.uEyeLeftBounds : this._skinUniforms.uEyeRightBounds;
        bndU.value.set(midX, midY, halfW, halfH);
      }
    };
    setEyeUniforms(true);
    setEyeUniforms(false);

    if (!geometry || !geometry.positions) return;

    // Build delicate, individually curved, micro-tapered 3D Upper & Lower Eyelash Cilia anchored on the 3D tarsal margins!
    const positions = [];
    const normals = [];
    const blinkDeltasAttr = [];
    const alphas = [];
    const indices = [];

    const meshPos = geometry.positions;
    const meshBlink = geometry.blinkDeltas;
    const numMeshV = meshPos.length / 3;

    // Collect ocular surface candidate vertices once for fast nearest-surface root snapping
    const eyeVertsL = [], eyeVertsR = [];
    for (let v = 0; v < numMeshV; v++) {
      const vx = meshPos[3 * v], vy = meshPos[3 * v + 1], vz = meshPos[3 * v + 2];
      if (vz < 3.5 || vy < 0.2 || vy > 3.2 || Math.abs(vx) < 0.9 || Math.abs(vx) > 5.0) continue;
      if (vx < 0) eyeVertsL.push(v);
      else eyeVertsR.push(v);
    }

    const interp3D5 = (p0, p1, p2, p3, p4, u) => {
      const ks = [0.0, 0.26, 0.50, 0.74, 1.0];
      const pts = [p0, p1 || p2, p2, p3 || p2, p4];
      let k = 0;
      while (k < 3 && u > ks[k + 1]) k++;
      const f = Math.max(0, Math.min(1, (u - ks[k]) / (ks[k + 1] - ks[k])));
      const s = f * f * (3.0 - 2.0 * f);
      return [
        pts[k][0] + (pts[k + 1][0] - pts[k][0]) * s,
        pts[k][1] + (pts[k + 1][1] - pts[k][1]) * s,
        pts[k][2] + (pts[k + 1][2] - pts[k][2]) * s,
      ];
    };

    const snapRoot = (candList, tx, ty, fallbackZ) => {
      let bestV = -1, bestD2 = 1e9;
      for (let i = 0; i < candList.length; i++) {
        const v = candList[i];
        const dx = meshPos[3 * v] - tx;
        const dy = meshPos[3 * v + 1] - ty;
        const d2 = dx * dx + dy * dy;
        if (d2 < bestD2) { bestD2 = d2; bestV = v; }
      }
      if (bestV < 0) return { z: fallbackZ, bx: 0, by: 0, bz: 0 };
      return {
        z: meshPos[3 * bestV + 2],
        bx: meshBlink ? meshBlink[3 * bestV] : 0,
        by: meshBlink ? meshBlink[3 * bestV + 1] : 0,
        bz: meshBlink ? meshBlink[3 * bestV + 2] : 0,
      };
    };

    const SEGS = 5;
    const addEyeCilia = (isLeft) => {
      const sgn = isLeft ? -1.0 : 1.0;
      const cands = isLeft ? eyeVertsL : eyeVertsR;
      const pIn  = isLeft ? landmarks3d.eyeLeftInner : landmarks3d.eyeRightInner;
      const pOut = isLeft ? landmarks3d.eyeLeftOuter : landmarks3d.eyeRightOuter;
      const pUpI = isLeft ? landmarks3d.eyeLeftUpperInner : landmarks3d.eyeRightUpperInner;
      const pUpM = isLeft ? landmarks3d.eyeLeftUpper      : landmarks3d.eyeRightUpper;
      const pUpO = isLeft ? landmarks3d.eyeLeftUpperOuter : landmarks3d.eyeRightUpperOuter;
      const pLoI = isLeft ? landmarks3d.eyeLeftLowerInner : landmarks3d.eyeRightLowerInner;
      const pLoM = isLeft ? landmarks3d.eyeLeftLower      : landmarks3d.eyeRightLower;
      const pLoO = isLeft ? landmarks3d.eyeLeftLowerOuter : landmarks3d.eyeRightLowerOuter;
      if (!pIn || !pOut || !pUpM || !pLoM) return;

      // 1) 36 Subtle Curved Upper Eyelashes (`2.0..4.5 mm` natural anatomical length, fine keratin taper)
      const N_UP = 36;
      for (let i = 0; i < N_UP; i++) {
        const frac = i / (N_UP - 1);
        const jitter = ((Math.sin(i * 19.37 + (isLeft ? 0.0 : 2.1)) * 0.5));
        const u = 0.11 + 0.85 * frac + jitter * 0.006;
        const rootLm = interp3D5(pIn, pUpI, pUpM, pUpO, pOut, u);
        const rx = rootLm[0];
        const ry = rootLm[1] + 0.008;
        const snap = snapRoot(cands, rx, ry, rootLm[2]);
        const rz = snap.z - 0.006;

        // Subtle natural human lash length envelope (shortest medially, graceful peak around `u ~ 0.66`)
        const archBell = Math.sin(Math.pow(Math.max(0, Math.min(1, (u - 0.08) / 0.90)), 0.82) * Math.PI);
        const len = (0.17 + 0.23 * archBell) * (0.93 + 0.14 * Math.abs(Math.cos(i * 7.13)));
        const rootHalfW = 0.0062;
        const fanX = sgn * (0.34 * (u - 0.34) + jitter * 0.05);

        const baseV = positions.length / 3;
        for (let s = 0; s <= SEGS; s++) {
          const t = s / SEGS;
          const cx = rx + fanX * len * (0.75 * t + 0.25 * t * t);
          const cy = ry + len * (-0.14 * t + 0.64 * Math.pow(t, 1.85));
          const cz = rz + len * (0.86 * t - 0.12 * t * t);

          const halfW = rootHalfW * Math.pow(1.0 - t, 1.25) + 0.0005;
          const rootEmergence = Math.min(1.0, t * 4.2);
          const alpha = 0.64 * (1.0 - 0.25 * (1.0 - archBell)) * Math.pow(1.0 - t, 0.90) * rootEmergence;
          // Follow closing upper eyelid margin smoothly downward during `uBlink`
          const bDx = snap.bx;
          const bDy = snap.by - 0.032 - len * 0.48 * t;
          const bDz = snap.bz + len * 0.05 * t;

          positions.push(cx - halfW, cy, cz, cx + halfW, cy, cz);
          normals.push(0, 0.45, 0.89, 0, 0.45, 0.89);
          blinkDeltasAttr.push(bDx, bDy, bDz, bDx, bDy, bDz);
          alphas.push(alpha, alpha);
        }
        for (let s = 0; s < SEGS; s++) {
          const a = baseV + s * 2, b = a + 1, c = a + 2, d = a + 3;
          indices.push(a, b, c, b, d, c);
        }
      }

      // 2) 15 Ultra-Delicate Lower Outer Eyelashes (`1.4..2.1 mm` subtle downward-forward cilia)
      const N_LO = 15;
      for (let i = 0; i < N_LO; i++) {
        const frac = i / (N_LO - 1);
        const jitter = Math.cos(i * 13.7 + (isLeft ? 1.1 : 3.4)) * 0.5;
        const u = 0.20 + 0.72 * frac + jitter * 0.008;
        const rootLm = interp3D5(pIn, pLoI, pLoM, pLoO, pOut, u);
        const rx = rootLm[0];
        const ry = rootLm[1] - 0.022;
        const snap = snapRoot(cands, rx, ry, rootLm[2]);
        const rz = snap.z - 0.006;

        const archBell = Math.sin(Math.pow(frac, 0.85) * Math.PI);
        const len = 0.13 + 0.09 * archBell;
        const rootHalfW = 0.0046;
        const fanX = sgn * (0.28 * (u - 0.38));

        const baseV = positions.length / 3;
        for (let s = 0; s <= SEGS; s++) {
          const t = s / SEGS;
          const cx = rx + fanX * len * t;
          const cy = ry - len * (0.38 * t + 0.42 * t * t);
          const cz = rz + len * (0.80 * t - 0.15 * t * t);

          const halfW = rootHalfW * Math.pow(1.0 - t, 1.3) + 0.0004;
          const alpha = 0.38 * archBell * Math.pow(1.0 - t, 0.95);
          positions.push(cx - halfW, cy, cz, cx + halfW, cy, cz);
          normals.push(0, -0.45, 0.89, 0, -0.45, 0.89);
          blinkDeltasAttr.push(snap.bx, snap.by, snap.bz, snap.bx, snap.by, snap.bz);
          alphas.push(alpha, alpha);
        }
        for (let s = 0; s < SEGS; s++) {
          const a = baseV + s * 2, b = a + 1, c = a + 2, d = a + 3;
          indices.push(a, c, b, b, c, d);
        }
      }
    };

    addEyeCilia(true);
    addEyeCilia(false);

    if (indices.length > 0) {
      const lashGeo = new THREE.BufferGeometry();
      lashGeo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      lashGeo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
      lashGeo.setAttribute('aBlinkDelta', new THREE.Float32BufferAttribute(blinkDeltasAttr, 3));
      lashGeo.setAttribute('aAlpha', new THREE.Float32BufferAttribute(alphas, 1));
      lashGeo.setIndex(indices);

      const hRGB = baked && baked.palette && baked.palette.hairRGB ? baked.palette.hairRGB : [28, 20, 18];
      const lashCol = new THREE.Color().setRGB(
        Math.min(0.14, Math.max(0.025, (hRGB[0] / 255) * 0.55)),
        Math.min(0.11, Math.max(0.020, (hRGB[1] / 255) * 0.50)),
        Math.min(0.10, Math.max(0.018, (hRGB[2] / 255) * 0.48)),
        THREE.SRGBColorSpace
      );

      if (!this.corneaMaterial || !this.corneaMaterial.uniforms || !this.corneaMaterial.uniforms.uLashColor) {
        if (this.corneaMaterial && this.corneaMaterial.dispose) this.corneaMaterial.dispose();
        this.corneaMaterial = new THREE.ShaderMaterial({
          uniforms: {
            uBlink: { value: this._blinkValue || 0.0 },
            uLashColor: { value: lashCol.clone() },
          },
          transparent: true,
          depthWrite: false,
          side: THREE.DoubleSide,
          vertexShader: `
            attribute vec3 aBlinkDelta;
            attribute float aAlpha;
            uniform float uBlink;
            varying float vAlpha;
            void main() {
              vAlpha = aAlpha;
              vec3 pos = position + aBlinkDelta * uBlink;
              gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
            }
          `,
          fragmentShader: `
            uniform vec3 uLashColor;
            varying float vAlpha;
            void main() {
              if (vAlpha < 0.01) discard;
              gl_FragColor = vec4(uLashColor, vAlpha);
              #include <tonemapping_fragment>
              #include <colorspace_fragment>
            }
          `,
        });
      } else {
        this.corneaMaterial.uniforms.uLashColor.value.copy(lashCol);
      }

      this.eyelashMesh = new THREE.Mesh(lashGeo, this.corneaMaterial);
      this.eyelashMesh.name = 'VisageEyelashes3D';
      this.eyelashMesh.renderOrder = 2;
      this.corneaGroup.add(this.eyelashMesh);
    }
  }

  /**
   * Build & attach Hybrid 3D Hair Groom + Real-Time PBD Physics State.
   * Always returns `{ strandCount, flyawayCount, triangleCount }`.
   */
  updateHairGroom(geometry, hairProfile, options = {}) {
    const disposed = new Set();
    while (this.hairGroup.children.length > 0) {
      const ch = this.hairGroup.children.pop();
      if (ch.geometry && !disposed.has(ch.geometry)) {
        disposed.add(ch.geometry);
        ch.geometry.dispose();
      }
    }
    this.hairRibbonMesh = null;
    this.hairFringeMesh = null;
    this.hairFlyawayLines = null;
    this.hairState = null;

    if (!geometry || !hairProfile) {
      return { strandCount: 0, flyawayCount: 0, triangleCount: 0 };
    }

    const state = buildHairGroomState(geometry, hairProfile, options);
    this.hairState = state;

    const ribGeo = new THREE.BufferGeometry();
    const posAttr = new THREE.BufferAttribute(state.ribbonPositions, 3);
    const nrmAttr = new THREE.BufferAttribute(state.ribbonNormals, 3);
    const tanAttr = new THREE.BufferAttribute(state.ribbonTangents, 3);
    posAttr.setUsage(THREE.DynamicDrawUsage);
    nrmAttr.setUsage(THREE.DynamicDrawUsage);
    tanAttr.setUsage(THREE.DynamicDrawUsage);

    ribGeo.setAttribute('position', posAttr);
    ribGeo.setAttribute('normal', nrmAttr);
    ribGeo.setAttribute('aTangent', tanAttr);
    ribGeo.setAttribute('color', new THREE.BufferAttribute(state.ribbonColors, 3));
    ribGeo.setAttribute('uv', new THREE.BufferAttribute(state.ribbonUVs, 2));
    const seedArr = state.ribbonSeeds || new Float32Array(state.ribbonPositions.length / 3);
    ribGeo.setAttribute('aSeed', new THREE.BufferAttribute(seedArr, 1));
    ribGeo.setIndex(new THREE.BufferAttribute(state.ribbonIndices, 1));
    ribGeo.computeBoundingSphere();

    // Pass 1: Solid Z-writing interior lock core
    this.hairRibbonMesh = new THREE.Mesh(ribGeo, this.hairMaterial);
    this.hairRibbonMesh.frustumCulled = false;
    this.hairRibbonMesh.renderOrder = 2;
    this.hairGroup.add(this.hairRibbonMesh);

    // Pass 2: Shared-geometry smooth alpha-blended anti-aliased fringe, tips & baby hairs!
    this.hairFringeMesh = new THREE.Mesh(ribGeo, this.hairFringeMaterial);
    this.hairFringeMesh.frustumCulled = false;
    this.hairFringeMesh.renderOrder = 3;
    this.hairGroup.add(this.hairFringeMesh);

    if (state.flyawayPositions.length > 0) {
      const flyGeo = new THREE.BufferGeometry();
      const flyPosAttr = new THREE.BufferAttribute(state.flyawayPositions, 3);
      flyPosAttr.setUsage(THREE.DynamicDrawUsage);
      flyGeo.setAttribute('position', flyPosAttr);

      const hiRGB = hairProfile.tipRGB || hairProfile.highlightRGB || [48, 38, 32];
      const flyMat = new THREE.LineBasicMaterial({
        color: new THREE.Color(
          Math.pow(Math.max(0.03, hiRGB[0] / 255), 2.2),
          Math.pow(Math.max(0.03, hiRGB[1] / 255), 2.2),
          Math.pow(Math.max(0.03, hiRGB[2] / 255), 2.2)
        ),
        transparent: true,
        opacity: 0.16,
        depthWrite: false,
      });
      this.hairFlyawayLines = new THREE.LineSegments(flyGeo, flyMat);
      this.hairFlyawayLines.frustumCulled = false;
      this.hairFlyawayLines.renderOrder = 3;
      this.hairGroup.add(this.hairFlyawayLines);
    }

    this.hairGroup.visible = this.hairEnabled;
    this.setShaderMode(this.shaderMode);
    return state.metrics;
  }

  /**
   * Build clean standard glTF 2.0 exportable PBR Group (Bust + 3D Hair Groom in metric meters).
   */
  buildExportablePBRMesh(bakedTextures) {
    if (!this.bustMesh || !bakedTextures) return null;

    const root = new THREE.Group();
    root.name = 'VisageBustAndHair360';
    root.scale.setScalar(0.01); // cm -> glTF standard meters

    const sz = bakedTextures.texSize;
    const exportMat = new THREE.MeshStandardMaterial({
      name: 'VisageSkinPBR',
      map: rgbaToCanvasTexture(bakedTextures.albedoData, sz, true),
      normalMap: rgbaToCanvasTexture(bakedTextures.normalData, sz, false),
      normalScale: new THREE.Vector2(0.16, 0.16),
      roughnessMap: rgbaToCanvasTexture(bakedTextures.roughnessData, sz, false),
      roughness: 1.0,
      metalness: 0.0,
    });

    const bustGeo = new THREE.BufferGeometry();
    bustGeo.setAttribute('position', this.bustMesh.geometry.attributes.position.clone());
    bustGeo.setAttribute('normal', this.bustMesh.geometry.attributes.normal.clone());
    bustGeo.setAttribute('uv', this.bustMesh.geometry.attributes.uv.clone());
    bustGeo.setIndex(this.bustMesh.geometry.index.clone());

    const bustClone = new THREE.Mesh(bustGeo, exportMat);
    bustClone.name = 'VisageBust360';
    root.add(bustClone);

    if (this.hairEnabled && this.hairRibbonMesh) {
      const hairGeo = new THREE.BufferGeometry();
      hairGeo.setAttribute('position', this.hairRibbonMesh.geometry.attributes.position.clone());
      hairGeo.setAttribute('normal', this.hairRibbonMesh.geometry.attributes.normal.clone());
      hairGeo.setAttribute('color', this.hairRibbonMesh.geometry.attributes.color.clone());
      hairGeo.setAttribute('uv', this.hairRibbonMesh.geometry.attributes.uv.clone());
      hairGeo.setIndex(this.hairRibbonMesh.geometry.index.clone());

      const hairExportMat = new THREE.MeshStandardMaterial({
        name: 'VisageHairSilk',
        vertexColors: true,
        roughness: 0.36,
        metalness: 0.02,
        side: THREE.DoubleSide,
      });
      const hairClone = new THREE.Mesh(hairGeo, hairExportMat);
      hairClone.name = 'VisageHairGroom';
      root.add(hairClone);
    }

    if (this.eyelashMesh) {
      const lashExportGeo = new THREE.BufferGeometry();
      lashExportGeo.setAttribute('position', this.eyelashMesh.geometry.attributes.position.clone());
      lashExportGeo.setAttribute('normal', this.eyelashMesh.geometry.attributes.normal.clone());
      lashExportGeo.setIndex(this.eyelashMesh.geometry.index.clone());
      const lashExportMat = new THREE.MeshStandardMaterial({
        name: 'VisageEyelashes',
        color: this.corneaMaterial ? this.corneaMaterial.uniforms.uLashColor.value.clone() : new THREE.Color(0x181210),
        roughness: 0.42,
        side: THREE.DoubleSide,
      });
      const lashClone = new THREE.Mesh(lashExportGeo, lashExportMat);
      lashClone.name = 'VisageEyelashes3D';
      root.add(lashClone);
    }

    root.updateMatrixWorld(true);
    return root;
  }

  /**
   * Trigger an immediate lifelike human blink (`~240 ms` smooth close & reopen)!
   */
  triggerBlink() {
    this._manualBlinkTimer = 0.0;
  }

  /**
   * Trigger interactive physical head flick / shake impulse so hair whips & settles!
   */
  triggerHeadImpulse(strength = 1.0) {
    const dir = Math.random() > 0.5 ? 1 : -1;
    this._impulseVel.pitch += 24 * strength;
    this._impulseVel.yaw += 68 * strength * dir;
    this._impulseVel.roll += 18 * strength * dir;
    this._orbitAngularVel.yaw += 0.26 * strength * dir;
    this._orbitAngularVel.pitch += 0.14 * strength;
  }

  setHairEnabled(flag) {
    this.hairEnabled = Boolean(flag);
    this.hairGroup.visible = this.hairEnabled;
  }

  setLiveMotion(flag) {
    this.liveMotionEnabled = Boolean(flag);
  }

  setSkinSSS(flag) {
    this.skinSSSEnabled = Boolean(flag);
    if (this._skinUniforms) {
      this._skinUniforms.uSSSEnabled.value = this.skinSSSEnabled ? 1.0 : 0.0;
    }
    this.corneaGroup.visible = this.shaderMode === 'pbr' || this.shaderMode === 'albedo';
  }

  setWindParams(strength, azimuthDeg = 35) {
    this.windStrength = Number(strength) || 0;
    this.windAzimuthRad = ((Number(azimuthDeg) || 0) * Math.PI) / 180;
  }

  setHairStiffnessScale(scale) {
    this.hairStiffnessScale = Number(scale) || 1.0;
  }

  setLightAzimuth(azimuthDeg) {
    const rad = ((Number(azimuthDeg) || 28) * Math.PI) / 180;
    const r = 37.5;
    this.keyLight.position.set(Math.sin(rad) * r, 18, Math.cos(rad) * r);
    const keyDir = this.keyLight.position.clone().normalize();
    this.hairMaterial.uniforms.uKeyDir.value.copy(keyDir);
    if (this.hairFringeMaterial) this.hairFringeMaterial.uniforms.uKeyDir.value.copy(keyDir);
    this.corneaMaterial.uniforms.uKeyDir.value.copy(keyDir);
  }

  _rebuildLandmarks3D(landmarks3d) {
    while (this.landmarkGroup.children.length > 0) {
      const child = this.landmarkGroup.children.pop();
      if (child.geometry) child.geometry.dispose();
    }
    if (!landmarks3d) return;

    const sphereGeo = new THREE.SphereGeometry(0.105, 10, 10);
    const mats = {
      eye: new THREE.MeshBasicMaterial({ color: 0x38bdf8 }),
      brow: new THREE.MeshBasicMaterial({ color: 0x818cf8 }),
      nose: new THREE.MeshBasicMaterial({ color: 0x34d399 }),
      mouth: new THREE.MeshBasicMaterial({ color: 0xfb7185 }),
      jaw: new THREE.MeshBasicMaterial({ color: 0xfacc15 }),
      ear: new THREE.MeshBasicMaterial({ color: 0xfb923c }),
    };

    for (const [name, pt] of Object.entries(landmarks3d)) {
      if (!pt) continue;
      let mat = mats.jaw;
      if (name.startsWith('eye') || name.startsWith('iris')) mat = mats.eye;
      else if (name.startsWith('brow') || name === 'glabella') mat = mats.brow;
      else if (name.includes('nose') || name.includes('nostril') || name === 'nasion' || name === 'rhinion' || name === 'subnasale' || name.startsWith('alar')) mat = mats.nose;
      else if (name.includes('mouth') || name.includes('Lip') || name.startsWith('cupid')) mat = mats.mouth;
      else if (name.startsWith('ear')) mat = mats.ear;

      const dot = new THREE.Mesh(sphereGeo, mat);
      dot.name = name;
      dot.position.set(pt[0], pt[1], pt[2] + 0.10);
      this.landmarkGroup.add(dot);
    }

    // Add 3D multi-point contour polylines for closed eyebrow rings, eyelid rings, lips & jawline!
    const addContour3D = (keys, hexColor, closed = false) => {
      const pts = [];
      for (const k of keys) {
        const p = landmarks3d[k];
        if (p) pts.push(new THREE.Vector3(p[0], p[1], p[2] + 0.11));
      }
      if (pts.length < 2) return;
      if (closed) pts.push(pts[0].clone());
      const lineGeo = new THREE.BufferGeometry().setFromPoints(pts);
      const lineMat = new THREE.LineBasicMaterial({ color: hexColor, transparent: true, opacity: 0.88 });
      this.landmarkGroup.add(new THREE.Line(lineGeo, lineMat));
    };

    addContour3D(['browLeftInner', 'browLeftUpperInner', 'browLeftUpper', 'browLeftUpperOuter', 'browLeftOuter', 'browLeftLowerOuter', 'browLeftLower', 'browLeftLowerInner'], 0x818cf8, true);
    addContour3D(['browRightInner', 'browRightUpperInner', 'browRightUpper', 'browRightUpperOuter', 'browRightOuter', 'browRightLowerOuter', 'browRightLower', 'browRightLowerInner'], 0x818cf8, true);
    addContour3D(['eyeLeftInner', 'eyeLeftUpperInner', 'eyeLeftUpper', 'eyeLeftUpperOuter', 'eyeLeftOuter', 'eyeLeftLowerOuter', 'eyeLeftLower', 'eyeLeftLowerInner'], 0x38bdf8, true);
    addContour3D(['eyeRightInner', 'eyeRightUpperInner', 'eyeRightUpper', 'eyeRightUpperOuter', 'eyeRightOuter', 'eyeRightLowerOuter', 'eyeRightLower', 'eyeRightLowerInner'], 0x38bdf8, true);
    addContour3D(['mouthLeft', 'upperLipLeft', 'cupidPeakLeft', 'upperLipTop', 'cupidPeakRight', 'upperLipRight', 'mouthRight', 'lowerLipRight', 'lowerLipBottom', 'lowerLipLeft'], 0xfb7185, true);
  }

  setShaderMode(mode) {
    this.shaderMode = mode;
    if (!this.bustMesh) return;

    this.wireMesh.visible = false;
    this.corneaGroup.visible = mode === 'pbr' || mode === 'albedo';

    if (this.hairRibbonMesh) {
      if (mode === 'clay' || mode === 'wireframe') {
        this.hairRibbonMesh.material = this._materials.clay;
        if (this.hairFringeMesh) this.hairFringeMesh.visible = false;
      } else if (mode === 'normals') {
        this.hairRibbonMesh.material = this._materials.normals;
        if (this.hairFringeMesh) this.hairFringeMesh.visible = false;
      } else {
        this.hairRibbonMesh.material = this.hairMaterial;
        if (this.hairFringeMesh) this.hairFringeMesh.visible = true;
      }
    }

    switch (mode) {
      case 'pbr':
        this.bustMesh.material = this._materials.pbr;
        break;
      case 'albedo':
        this.bustMesh.material = this._materials.albedoMat;
        break;
      case 'clay':
        this.bustMesh.material = this._materials.clay;
        break;
      case 'wireframe':
        this.bustMesh.material = this._materials.clay;
        this.wireMesh.visible = true;
        break;
      case 'normals':
        this.bustMesh.material = this._materials.normals;
        break;
      case 'coverage':
        this.bustMesh.material = this._materials.coverageMat;
        break;
      default:
        this.bustMesh.material = this._materials.pbr;
    }
  }

  setAutoSpin(enabled) {
    this.autoSpin = Boolean(enabled);
  }

  setShowLandmarks3D(visible) {
    this.showLandmarks3D = Boolean(visible);
    this.landmarkGroup.visible = this.showLandmarks3D;
  }

  setCameraPreset(yawDeg) {
    this.autoSpin = false;
    const rad = ((Number(yawDeg) || 0) * Math.PI) / 180;
    const dist = 62;
    this.controls.target.set(0, -2.2, 0);
    this.camera.position.set(Math.sin(rad) * dist, -0.3, Math.cos(rad) * dist);
    this.controls.update();
    // Subtle physical inertia impulse when snapping camera angle!
    this.triggerHeadImpulse(0.35);
  }

  resize() {
    if (!this.host) return;
    const w = Math.max(300, this.host.clientWidth);
    const h = Math.max(240, this.host.clientHeight);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  _updateBlink(dt) {
    let blink = 0.0;

    // 1. Explicit manual blink (`👁 Blink` button): crisp 240 ms human fast-close / smooth-reopen curve
    if (this._manualBlinkTimer >= 0.0) {
      this._manualBlinkTimer += dt;
      const dur = 0.25;
      if (this._manualBlinkTimer < dur) {
        const u = this._manualBlinkTimer / dur;
        if (u < 0.36) {
          const s = u / 0.36;
          blink = s * s * (3.0 - 2.0 * s);
        } else if (u < 0.50) {
          blink = 1.0;
        } else {
          const s = (u - 0.50) / 0.50;
          blink = 1.0 - s * (2.0 - s);
        }
      } else {
        this._manualBlinkTimer = -1.0;
      }
    }

    // 2. Autonomous natural human blink (~every 2.8 - 4.2 seconds when Live Motion is active)
    if (this.liveMotionEnabled && this._clockTime >= this._nextAutoBlinkTime) {
      const elapsed = this._clockTime - this._nextAutoBlinkTime;
      const dur = 0.22;
      if (elapsed < dur) {
        const u = elapsed / dur;
        const autoB = u < 0.38 ? Math.sin((u / 0.38) * Math.PI * 0.5) : Math.cos(((u - 0.38) / 0.62) * Math.PI * 0.5);
        blink = Math.max(blink, autoB);
      } else {
        const isDouble = Math.sin(this._clockTime * 11.7) > 0.74;
        this._nextAutoBlinkTime = this._clockTime + (isDouble ? 0.36 : 2.7 + 1.4 * (0.5 + 0.5 * Math.sin(this._clockTime * 3.1)));
      }
    }

    if (typeof this.blinkOverride === 'number') {
      blink = this.blinkOverride;
    }
    this._blinkValue = blink;
    if (this._skinUniforms) {
      this._skinUniforms.uBlink.value = blink;
    }
    if (this.corneaMaterial && this.corneaMaterial.uniforms) {
      this.corneaMaterial.uniforms.uBlink.value = blink;
    }
  }

  _animate() {
    this._raf = requestAnimationFrame(this._animate);

    const now = performance.now();
    const dt = Math.min(0.033, Math.max(0.004, (now - this._lastFrameTime) * 0.001));
    this._lastFrameTime = now;
    this._clockTime += dt;

    // 1. Update OrbitControls first AND measure camera orbit angular delta so swinging the view moves the hair!
    this.controls.update();
    const curAz = this.controls.getAzimuthalAngle();
    const curPol = this.controls.getPolarAngle();
    const dAz = shortestAngleDelta(curAz, this._prevAzimuth);
    const dPol = curPol - this._prevPolar;
    this._prevAzimuth = curAz;
    this._prevPolar = curPol;

    // Accumulate & decay orbit momentum cleanly (with deadband so OrbitControls tail NEVER keeps twitching hair!)
    const rawAzImpulse = Math.abs(dAz) < 3.5e-4 ? 0.0 : -dAz * 1.45;
    const rawPolImpulse = Math.abs(dPol) < 3.5e-4 ? 0.0 : -dPol * 1.15;
    this._orbitAngularVel.yaw = this._orbitAngularVel.yaw * 0.60 + rawAzImpulse * 0.55;
    this._orbitAngularVel.pitch = this._orbitAngularVel.pitch * 0.60 + rawPolImpulse * 0.55;
    if (Math.abs(this._orbitAngularVel.yaw) < 0.0007) this._orbitAngularVel.yaw = 0.0;
    if (Math.abs(this._orbitAngularVel.pitch) < 0.0007) this._orbitAngularVel.pitch = 0.0;

    // 2. Update Anatomical 3D Eyelid Blink
    this._updateBlink(dt);

    // 3. Critically-damped spring-damper integration for interactive head flick / `⚡ Sway` impulse
    const kSpring = 44.0;
    const cDamp = 9.5;
    for (const axis of ['pitch', 'yaw', 'roll']) {
      const acc = -kSpring * this._impulseOffset[axis] - cDamp * this._impulseVel[axis];
      this._impulseVel[axis] += acc * dt;
      this._impulseOffset[axis] += this._impulseVel[axis] * dt;
      if (Math.abs(this._impulseOffset[axis]) < 0.012 && Math.abs(this._impulseVel[axis]) < 0.025) {
        this._impulseOffset[axis] = 0.0;
        this._impulseVel[axis] = 0.0;
      }
    }

    // 4. Subtle Live Motion breathing & calm micro-postural presence
    let breathY = 0;
    let microPitch = 0, microYaw = 0, microRoll = 0;
    if (this.liveMotionEnabled) {
      breathY = 0.07 * Math.sin(this._clockTime * 1.35);
      microPitch = 0.42 * Math.sin(this._clockTime * 0.78);
      microYaw   = 0.65 * Math.sin(this._clockTime * 0.52 + 0.7);
      microRoll  = 0.30 * Math.cos(this._clockTime * 0.64);
    }

    // Track deliberate/physical head rotation (`headTilt + impulse + autoSpin`) separately from subtle micro-breathing
    // so hair rests 100% peacefully when idle and responds briskly & smoothly to every real motion!
    const rigidPitchRad = ((this.headTiltDeg.pitch + this._impulseOffset.pitch) * Math.PI) / 180;
    const rigidRollRad  = ((this.headTiltDeg.roll + this._impulseOffset.roll) * Math.PI) / 180;
    let rigidYawRad = this._prevRigidEuler.y;
    if (this.autoSpin) {
      rigidYawRad += 0.0085;
    } else {
      const targetRigidYaw = ((this.headTiltDeg.yaw + this._impulseOffset.yaw) * Math.PI) / 180;
      rigidYawRad += (targetRigidYaw - rigidYawRad) * 0.25;
      if (Math.abs(targetRigidYaw - rigidYawRad) < 1.2e-4) rigidYawRad = targetRigidYaw;
    }

    // 5. Apply combined head pose to visual 3D bustGroup
    if (this.autoSpin) {
      this.bustGroup.rotation.y = rigidYawRad;
    } else {
      const targetYaw = ((this.headTiltDeg.yaw + microYaw + this._impulseOffset.yaw) * Math.PI) / 180;
      this.bustGroup.rotation.y += (targetYaw - this.bustGroup.rotation.y) * 0.22;
    }

    const targetPitch = ((this.headTiltDeg.pitch + microPitch + this._impulseOffset.pitch) * Math.PI) / 180;
    const targetRoll  = ((this.headTiltDeg.roll + microRoll + this._impulseOffset.roll) * Math.PI) / 180;

    this.bustGroup.rotation.x += (targetPitch - this.bustGroup.rotation.x) * 0.22;
    this.bustGroup.rotation.z += (targetRoll - this.bustGroup.rotation.z) * 0.22;
    this.bustGroup.position.y = breathY;

    this.bustGroup.updateMatrixWorld(true);

    // 6. Step Real-Time 60 FPS Hybrid Hair Physics (calm & dead-still at idle; smooth damped response on motion/wind!)
    if (this.hairState && this.hairEnabled && this.hairRibbonMesh) {
      const rigidQuat = new THREE.Quaternion().setFromEuler(
        new THREE.Euler(rigidPitchRad, rigidYawRad, rigidRollRad, 'XYZ')
      );
      const invQuat = rigidQuat.clone().invert();
      const gravLocal = new THREE.Vector3(0, -1, 0).applyQuaternion(invQuat);

      const gust = 0.65 + 0.35 * Math.sin(this._clockTime * 2.4) * Math.cos(this._clockTime * 1.1);
      const effWind = this.windStrength < 0.005 ? 0.0 : this.windStrength;
      const wx = Math.sin(this.windAzimuthRad) * effWind * 1.15 * gust;
      const wz = -Math.cos(this.windAzimuthRad) * effWind * 1.15 * gust;
      const wy = effWind * 0.16 * Math.sin(this._clockTime * 3.1);
      const windLocal = new THREE.Vector3(wx, wy, wz).applyQuaternion(invQuat);

      const dRx = shortestAngleDelta(rigidPitchRad, this._prevRigidEuler.x) + this._orbitAngularVel.pitch;
      const dRy = shortestAngleDelta(rigidYawRad, this._prevRigidEuler.y) + this._orbitAngularVel.yaw;
      const dRz = shortestAngleDelta(rigidRollRad, this._prevRigidEuler.z);

      this._prevRigidEuler.set(rigidPitchRad, rigidYawRad, rigidRollRad);
      this._prevGroupEuler.copy(this.bustGroup.rotation);
      this._prevGroupPos.copy(this.bustGroup.position);

      const didMove = stepHairPhysics(this.hairState, dt, {
        substeps: 2,
        damping: 0.78,
        stiffnessScale: this.hairStiffnessScale,
        gravityLocal: [gravLocal.x, gravLocal.y, gravLocal.z],
        windLocal: [windLocal.x, windLocal.y, windLocal.z],
        headEulerDelta: [
          Math.max(-0.32, Math.min(0.32, dRx)),
          Math.max(-0.38, Math.min(0.38, dRy)),
          Math.max(-0.26, Math.min(0.26, dRz)),
        ],
        headLinearDelta: [0, 0, 0],
      });

      if (didMove) {
        syncHairRibbonBuffers(this.hairState);
        this.hairRibbonMesh.geometry.attributes.position.needsUpdate = true;
        this.hairRibbonMesh.geometry.attributes.normal.needsUpdate = true;
        this.hairRibbonMesh.geometry.attributes.aTangent.needsUpdate = true;

        if (this.hairFlyawayLines) {
          this.hairFlyawayLines.geometry.attributes.position.needsUpdate = true;
        }
      }
    }

    this.renderer.render(this.scene, this.camera);
  }

  dispose() {
    if (this._raf) cancelAnimationFrame(this._raf);
    if (this._resizeObserver) this._resizeObserver.disconnect();
    this.renderer.dispose();
  }
}

export { BustViewport3D as StudioViewport3D };
